export type ModalProps = {
  title?: string;
  subtitle?: string;
  onFirstButtonClick?: () => void;
  onSecondButtonClick?: () => void;
  firstButtonLabel?: string;
  secondButtonLabel?: string;
};

export type ColumnProps = {
  align?: string;
  width?: string;
  whitespace?: string;
  paddingX?: string;
  paddingY?: string;
  paddingLeft?: string;
  paddingRight?: string;
  wordBreak?: string;
};

export type StatusChange = {
  id: number | string;
  status: string;
};

export type TrueOrFalse = 0 | 1;

export type PaginatedTable<T> = {
  data: T;
  current_page: number;
  first_page_url: string;
  from: 1;
  last_page: 1;
  last_page_url: string;
  links: Array<{
    active: boolean;
    label: string;
    url: string | null;
  }>;
  next_page_url: string | null;
  path: string;
  per_page: number;
  prev_page_url: string | null;
  to: number;
  total: number;
};

export type ErrorProps = {
  fontSize: 'string';
};
