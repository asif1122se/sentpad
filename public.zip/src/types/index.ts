export type {
  ModalProps,
  ColumnProps,
  StatusChange,
  TrueOrFalse,
  PaginatedTable,
  ErrorProps,
} from './general';
