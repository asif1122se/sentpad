const config = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL,
  amemberBaseUrl: import.meta.env.VITE_API_AMEMBER_API_BASE_URL,
  demoUser: 'demo@sendpad.com',
};

export default config;
