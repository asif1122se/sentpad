import { useState, useEffect } from 'react';
import { isLogin } from 'pages/Auth/authHeader';
import { useNavigate } from 'react-router-dom';

export const useGlobalLogout = () => {
  const navigate = useNavigate();
  const [isReload, setIsReload] = useState<boolean>(false);
  const globalLogout = (e: any) => {
    if (e.key == 'jwtToken' && e.oldValue && !e.newValue) {
      setIsReload(true);
    }
  };
  useEffect(() => {
    !isLogin() && navigate('/signin');
    window.addEventListener('storage', globalLogout);
    return () => {
      window.removeEventListener('storage', globalLogout);
    };
  }, []);

  return [isReload] as const;
};
