import React from 'react';

const HealthZ = () => {
  return (
    <>
      <p>OK</p>
    </>
  );
};

export default HealthZ;
