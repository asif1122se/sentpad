import { GlobalLayout } from 'components';
import { Dashboard } from 'pages';
import {
  ContactsPage,
  ListsDetailsAnalytics,
  ListsPage,
  SegmentsPage,
  SenderProfilePage,
} from 'pages/Audience';
import Details from 'pages/Audience/Contacts/Details';
import ListDetails from 'pages/Audience/Lists/components/Details';
import {
  BroadcastPage,
  CreateBroadcastPage,
  EmailBuilderPage,
  DesignTemplates,
} from 'pages/Broadcast';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import ROUTE_PATHS from './routePaths';
import {
  AutoresponderPage,
  CreateAutoresponderPage,
  SampleAutoresponderMainPage,
  SampleAutoresponderPage,
} from 'pages/Autoresponder';
import { FormsPage, CreateFormPage, ViewFormPage } from 'pages/Forms';
import { DetailsAnalyticsPage, DetailsPage } from 'pages/Broadcast/components';
import { SignInPage } from 'pages/Auth/Signin';
import {
  AccountInfoSetupPage,
  EmailSentPage,
  ExpiredActivationPage,
  SignUpPage,
  VerifiedActivationPage,
} from 'pages/Auth/Registration';
import { PaymentPage, SubscriptionPage } from 'pages/Auth/Subscription';
import { BillingPage, ChangePlan } from 'pages/Account/components';
import { AccountSettingsPage } from 'pages/Account';
import DashboardTestPage from 'pages/DashboardTest';
import BroadcastAnalyticPage from 'pages/Broadcast/BroadcastAnalyticPage';
import SampleListsPage from 'pages/Audience/Lists/SampleListsPage';
import SubscriptionPromoPage from 'pages/Auth/Subscription/SubscriptionPromoPage';
import ViewSegmentPage from 'pages/Audience/Segments/components/ViewSegmentPage';
import DomainSetupPage from 'pages/Account/components/DomainSetupPage';
import ForgotPasswordEmailEntryPage from 'pages/Auth/Signin/ForgotPasswordEmailEntryPage';
import ForgotPasswordNotificationPage from 'pages/Auth/Signin/ForgotPasswordNotificationPage';
import ResetPasswordPage from 'pages/Auth/Signin/ResetPasswordPage';
import OptInSettingsPage from 'pages/Account/components/OptInSettingsPage';
import UnsubscribePage from 'pages/Auth/Subscription/UnsubscribePage';
import OptInConfirmationPage from 'pages/Account/components/OptInConfirmationPage';
import MaintenancePage from 'pages/MaintenancePage';
import ThankYouPage from 'pages/Forms/ThankYouPage';
import AlreadySubscribedPage from 'pages/Forms/AlreadySubscribedPage';
import HealthZ from 'Healthz';

const AppRoutes: React.FC = () => (
  <BrowserRouter>
    <Routes>
      <Route path={ROUTE_PATHS.SIGNUP} element={<SignUpPage />} />
      <Route path={ROUTE_PATHS.SIGNIN} element={<SignInPage />} />
      <Route path={ROUTE_PATHS.EMAIL_SENT} element={<EmailSentPage />} />
      <Route path={ROUTE_PATHS.ACCOUNT_INFO_SETUP} element={<AccountInfoSetupPage />} />
      <Route path={ROUTE_PATHS.EXPIRED_ACTIVATION} element={<ExpiredActivationPage />} />
      <Route path={ROUTE_PATHS.VERIFIED_ACTIVATION} element={<VerifiedActivationPage />} />
      <Route path={ROUTE_PATHS.SUBSCRIPTION} element={<SubscriptionPage />} />
      <Route path={ROUTE_PATHS.SUBSCRIPTION_PROMO} element={<SubscriptionPromoPage />} />
      <Route path={ROUTE_PATHS.UNSUBSCRIBE} element={<UnsubscribePage />} />
      <Route path={ROUTE_PATHS.OPT_IN_CONFIRMATION} element={<OptInConfirmationPage />} />
      <Route path={ROUTE_PATHS.UNDER_MAINTENANCE} element={<MaintenancePage />} />
      <Route path={ROUTE_PATHS.THANK_YOU} element={<ThankYouPage />} />
      <Route path={ROUTE_PATHS.ALREADY_SUBSCRIBED} element={<AlreadySubscribedPage />} />
      <Route
        path={ROUTE_PATHS.FORGOT_PASSWORD_EMAIL_ENTRY}
        element={<ForgotPasswordEmailEntryPage />}
      />
      <Route
        path={ROUTE_PATHS.FORGOT_PASSWORD_NOTIFICATION}
        element={<ForgotPasswordNotificationPage />}
      />
      <Route path={ROUTE_PATHS.RESET_PASSWORD} element={<ResetPasswordPage />} />
      <Route path={ROUTE_PATHS.PAYMENT} element={<PaymentPage />} />
      <Route path={ROUTE_PATHS.HOME} element={<GlobalLayout />}>
        <Route path={ROUTE_PATHS.DASHBOARD} element={<Dashboard />} />
        <Route path={ROUTE_PATHS.BROADCAST} element={<BroadcastPage />} />
        <Route path={ROUTE_PATHS.BROADCAST_ANALYTICS} element={<BroadcastAnalyticPage />} />
        <Route path={ROUTE_PATHS.DASHBOARD_ANALYTICS} element={<DashboardTestPage />} />
        <Route path={ROUTE_PATHS.AUTORESPONDER} element={<AutoresponderPage />} />
        <Route path={ROUTE_PATHS.SAMPLE_AUTORESPONDER} element={<SampleAutoresponderMainPage />} />
        <Route path={ROUTE_PATHS.FORMS} element={<FormsPage />} />

        <Route path={ROUTE_PATHS.ACCOUNT_SETTINGS} element={<AccountSettingsPage />}>
          <Route
            path={`${ROUTE_PATHS.ACCOUNT_SETTINGS}/${ROUTE_PATHS.BILLING}`}
            element={<BillingPage />}
          />
          <Route
            path={`${ROUTE_PATHS.ACCOUNT_SETTINGS}/${ROUTE_PATHS.OPT_IN}`}
            element={<OptInSettingsPage />}
          />
          <Route
            path={`${ROUTE_PATHS.ACCOUNT_SETTINGS}/${ROUTE_PATHS.CHANGE_PLAN}`}
            element={<ChangePlan />}
          />
          <Route
            path={`${ROUTE_PATHS.ACCOUNT_SETTINGS}/${ROUTE_PATHS.DOMAIN_SETUP}`}
            element={<DomainSetupPage />}
          />
        </Route>
        <Route
          path={`${ROUTE_PATHS.AUTORESPONDER}/${ROUTE_PATHS.NEW}`}
          element={<CreateAutoresponderPage />}
        />
        <Route path={`${ROUTE_PATHS.AUTORESPONDER}/:id`} element={<SampleAutoresponderPage />} />
        <Route path={ROUTE_PATHS.FORMS} element={<FormsPage />} />
        <Route
          path={`${ROUTE_PATHS.BROADCAST}/${ROUTE_PATHS.NEW}`}
          element={<CreateBroadcastPage />}
        />
        <Route
          path={`${ROUTE_PATHS.BROADCAST}/${ROUTE_PATHS.BROADCAST_DETAILS}/:id`}
          element={<DetailsPage />}
        />
        <Route
          path={`${ROUTE_PATHS.BROADCAST}/${ROUTE_PATHS.BROADCAST_DETAILS_ANALYTICS}/:id`}
          element={<DetailsAnalyticsPage />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.CONTACTS}`}
          element={<ContactsPage />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.CONTACT_DETAILS}/:id`}
          element={<Details />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.CONTACT_DETAILS}/:id/:edit`}
          element={<Details />}
        />
        <Route path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.LISTS}`} element={<ListsPage />} />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.LISTS_SAMPLE}`}
          element={<SampleListsPage />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.LIST_DETAILS}`}
          element={<ListDetails />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.LIST_DETAILS_ANALYTICS}`}
          element={<ListsDetailsAnalytics />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.SEGMENTS}`}
          element={<SegmentsPage />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.VIEW_SEGMENT}/:id`}
          element={<ViewSegmentPage />}
        />
        <Route
          path={`${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.SENDER_PROFILE}`}
          element={<SenderProfilePage />}
        />
      </Route>
      <Route path={ROUTE_PATHS.DESIGN_TEMPLATES} element={<DesignTemplates />} />
      <Route
        path={`${ROUTE_PATHS.BROADCAST}/${ROUTE_PATHS.EMAIL_BUILDER}`}
        element={<EmailBuilderPage />}
      />
      <Route path={`${ROUTE_PATHS.FORMS}/:id`} element={<CreateFormPage />} />
      <Route path={`${ROUTE_PATHS.VIEW_FORM}/:id`} element={<ViewFormPage />} />
      <Route path={`${ROUTE_PATHS.HEALTHZ}`} element={<HealthZ />} />
    </Routes>
  </BrowserRouter>
);

export default AppRoutes;
