import { Box, Flex, Image, Text } from '@chakra-ui/react';
import React from 'react';

type chProps = {
  title: string;
  imgUrl: string;
};

const CardHeader = ({ title, imgUrl }: chProps) => {
  return (
    <>
      <Flex alignItems='center' justifyContent='flex-start'>
        <Box alignItems='center' m='2' padding='6px' background='purple.100' borderRadius='3px'>
          <Image w='24px' src={imgUrl} />
        </Box>
        <Box alignItems='center' mx='1'>
          <Text fontWeight='bold'>{title}</Text>
        </Box>
      </Flex>
    </>
  );
};

export default CardHeader;
