import React from 'react';

const Filters = () => {
  return <></>;
};

export default Filters;
