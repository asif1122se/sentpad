import { Box, Flex, Icon, Image, Text } from '@chakra-ui/react';
import SubscribeList from './SubscribeList';
import SendMsg from 'assets/icons/sendmsg.png';
import { OptionBox, OptionContainer } from '../styles';
import UnsubscribeList from './UnsubscribeList';
import { useStoreState, useStoreActions } from 'redux';
import { AutoresponderSetting } from '../types';
import { AutoresponderSettings } from '../consts';
import SubmitsForm from './SubmitsForm';
import { HiOutlineArrowLeft } from 'react-icons/hi';

type TriggersProps = {
  triggersList?: Array<AutoresponderSetting<'trigger'>>;
};

const Triggers = ({ triggersList }: TriggersProps) => {
  const { activeSetting, subscribeToListTriggerList, submitsAFormTriggerList } = useStoreState(
    (state) => state.autoresponder.autoresponderObj,
  );
  const {
    addTrigger,
    setActiveSetting,
    addSubscribeToListTriggerList,
    addSubmitsAFormTriggerList,
  } = useStoreActions((actions) => actions.autoresponder);

  const setSubscribeToList = (data: any) => {
    addSubscribeToListTriggerList(data.list);
  };

  const setSubmitsAForm = (data: any) => {
    addSubmitsAFormTriggerList(data.list);
  };

  const handleBack = () => (
    <Flex
      p='4'
      width='fit-content'
      justifyContent='flex-start'
      alignItems='center'
      cursor='pointer'
      onClick={() => setActiveSetting({ type: 'triggers' })}>
      <Icon as={HiOutlineArrowLeft} mr='2' />
      <Text fontSize='sm' fontWeight='400'>
        Go back
      </Text>
    </Flex>
  );

  return (
    <>
      {activeSetting?.type === 'triggers' && (
        <>
          <Box px='4' mb='6' mt='2'>
            <Text fontSize='md' fontWeight={'bold'}>
              Trigger(s)
            </Text>
          </Box>
          <Box px='0'>
            {triggersList?.map(({ id, name, description }) => (
              <OptionContainer key={id}>
                <OptionBox
                  onClick={() => {
                    setActiveSetting({ type: id });
                    addTrigger(id);
                  }}>
                  <Box width='40px' px='1'>
                    <Image width='40px' src={SendMsg} />
                  </Box>
                  <Box width='100%' mx='1'>
                    <Text fontWeight='bold'>{name}</Text>
                    <Text fontSize='sm' mt='1' color='gray.700'>
                      {description}
                    </Text>
                  </Box>
                </OptionBox>
              </OptionContainer>
            ))}
          </Box>
        </>
      )}

      {activeSetting?.type === AutoresponderSettings.SUBSCRIBE_TRIGGER && (
        <>
          {handleBack()}
          <Box mt={1}>
            <SubscribeList
              title='Subscribes to a List'
              desc='Contacts will enter this autoresponder when subscribed to the selected list(s)'
              setValues={setSubscribeToList}
              values={subscribeToListTriggerList}
            />
          </Box>
        </>
      )}
      {activeSetting?.type === AutoresponderSettings.SUBMITS_A_FORM_TRIGGER && (
        <>
          {handleBack()}
          <Box mt={1}>
            <SubmitsForm
              title='Submits a Form'
              desc='Contacts will enter this automation when the selected forms are submitted'
              setValues={setSubmitsAForm}
              values={submitsAFormTriggerList}
            />
          </Box>
        </>
      )}
    </>
  );
};

export default Triggers;
