import { TriangleDownIcon } from '@chakra-ui/icons';
import { Box, Button, Flex, Menu, MenuItem, MenuList, Stack, Text } from '@chakra-ui/react';
import { Option, Select, SelectBox } from 'pages/Audience/Lists/styles';
import { SenderProfiles } from 'pages/Audience/Contacts/types';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';

type SenderProps = {
  fontsize?: string;
  title?: string;
  getId: (id: number) => void;
  width?: string;
  value?: number;
  errorText: string;
};

const SenderProfileDropDown = ({
  fontsize = 'md',
  width,
  title = 'Select sender profile',
  getId,
  value,
  errorText = '',
}: SenderProps) => {
  const { data: senderProfiles } = useQuery<SenderProfiles>({
    queryKey: [QUERY_KEYS.SENDER_PROFILES],
    url: 'getSenderProfiles',
  });

  const selected = senderProfiles?.find((profile) => profile.id === value);

  const showSenderProfile = () => {
    return (
      <>
        <MenuItem width='100%'>
          <Option
            onClick={() => {
              getId && getId(0);
            }}>
            <Text textAlign='left' fontSize={fontsize} color='gray.500' lineHeight='48px'>
              Select Sender Profile
            </Text>
          </Option>
        </MenuItem>
        {senderProfiles?.map((item, i) => (
          <MenuItem width='100%' key={i}>
            <Option
              onClick={() => {
                getId && getId(item?.id);
              }}>
              <Flex width='100%'>
                <Text width='60px'>From</Text>
                <Text>{item?.from_email}</Text>
              </Flex>
              <Flex width='100%'>
                <Text width='60px'>Reply to</Text>
                <Text>{item?.reply_to_email}</Text>
              </Flex>
            </Option>
          </MenuItem>
        ))}
      </>
    );
  };
  return (
    <Stack>
      <Menu>
        <Text pb='1' fontSize={fontsize} lineHeight='14px'>
          {title}
        </Text>
        <Select as={Button} py='1' border='1px solid' $error={!!errorText}>
          {/* Render Selected Sender Profile Here */}
          <SelectBox>
            <Box width='100%'>
              {!value ? (
                <Text textAlign='left' fontSize={fontsize} color='gray.500' lineHeight='48px'>
                  Click to sender profile
                </Text>
              ) : (
                <>
                  <Flex>
                    <Text width='60px' textAlign='left'>
                      From
                    </Text>
                    <Text fontSize={fontsize} ml='2'>
                      {selected?.from_email}
                    </Text>
                  </Flex>
                  <Flex>
                    <Text width='60px' textAlign='left'>
                      Reply to
                    </Text>
                    <Text fontSize={fontsize} ml='2'>
                      {selected?.reply_to_email}
                    </Text>
                  </Flex>
                </>
              )}
            </Box>
            <TriangleDownIcon boxSize='2' color='gray.900' />
          </SelectBox>
        </Select>
        <MenuList width={width ?? undefined} maxH='300px' overflow='auto'>
          {/* Render All Sender Profile Here */}
          {showSenderProfile()}
        </MenuList>
      </Menu>
      {!!errorText && (
        <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
          {errorText}
        </Text>
      )}
    </Stack>
  );
};

export default SenderProfileDropDown;
