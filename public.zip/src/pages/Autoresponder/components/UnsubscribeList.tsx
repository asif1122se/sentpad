import { Box, Button, Text } from '@chakra-ui/react';
import AudienceList, { AudienceListItem } from 'pages/Broadcast/components/AudienceList';

type UnsubscribeListProps = {
  values: AudienceListItem[];
  setValues: any;
};

const UnsubscribeList = ({ values, setValues }: UnsubscribeListProps) => {
  const getFilteredData = (data: any) => {
    data?.list && setValues({ ...values, list: data?.list });
  };

  const getList = (data: any) => {
    getFilteredData({ list: data });
  };

  return (
    <Box>
      <Box px='4' mb='6' mt='2'>
        <Text fontWeight={'bold'}>Unsubscribe from List</Text>
        <Text color='gray.700' fontSize='sm' mt='2'>
          When a contact reaches this point in the autoresponder, they will be removed from the
          selected list(s).
        </Text>
      </Box>
      <Box p='0'>
        <Box px='4' width='100%'>
          <Box color='black' fontSize='md'>
            <AudienceList
              showSelectAll={false}
              getList={getList}
              headingText='Select List(s)'
              removeText='Remove All'
              values={{ list: values }}
              setValues={setValues}
            />
          </Box>
        </Box>
      </Box>
      <Box position='absolute' bottom={'25px'} px='4' justifyContent='left'>
        <Button>Done</Button>
      </Box>
    </Box>
  );
};

export default UnsubscribeList;
