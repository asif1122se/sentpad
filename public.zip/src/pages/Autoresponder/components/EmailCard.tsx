import React, { useState } from 'react';
import EmailIcon from 'assets/icons/email.svg';
import { Card } from '../styles';
import { Badge, Box, Flex, Image, Text, useDisclosure } from '@chakra-ui/react';
import TrashIcon from 'assets/icons/trash.svg';
import { BroadcastFormType } from 'redux/model/autoresponder';
import DeleteArModal from '../DeleteArModal';
import CardHeader from './CardHeader';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';

export type EmailStats = {
  emails_sent: string;
  open_rate: string;
  emails_opened: string;
  click_rate: string;
  emails_clicked: string;
};

type EmailCardProps = {
  arId?: string | number;
  email?: BroadcastFormType;
  onClick: () => void;
  onDelete?: () => void;
  emailAnalytics?: EmailStats;
};

const EmailCard = ({ arId, email, onClick }: EmailCardProps) => {
  const { data: analytics } = useQuery<EmailStats>({
    url: 'ar-email-analytics',
    params: {
      ar_id: arId,
      email_id: email?.id ? email?.id.toString() : undefined,
    },
    queryKey: [QUERY_KEYS.AUTORESPONDER_EMAIL_ANALYTICS, email?.id],
  });

  const [showDelete, setShowDelete] = useState<boolean>(false);
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  return (
    <>
      <DeleteArModal isOpen={isDeleteOpen} onClose={onDeleteClose} />
      <Card
        onClick={onClick}
        onFocus={() => setShowDelete(true)}
        onBlur={() => setShowDelete(false)}
        tabIndex={0}>
        <Box width='100%' height='100%'>
          <Flex justifyContent={'space-between'}>
            <CardHeader title='Email' imgUrl={EmailIcon} />
            <Box mt='2' mr='2'>
              {showDelete && <Image width='20px' src={TrashIcon} onClick={() => onDeleteOpen()} />}
            </Box>
          </Flex>
          <Flex px='2' justifyContent='space-between' fontSize='sm'>
            <Flex justifyContent='space-between' width='100%'>
              <Text fontSize='12px' mt='1'>
                {email?.subject} {email?.pre_header && ` - ${email.pre_header}`}
              </Text>
              <Badge
                fontSize='sm'
                variant={email?.is_active === 1 ? 'success' : 'danger'}
                textTransform='capitalize'>
                {email?.is_active === 1 ? 'Active' : 'Inactive'}
              </Badge>
            </Flex>
          </Flex>
          <Flex fontSize='12px' p='2' width='100%'>
            <Box>
              <Text>Emails</Text>
              <Text my='1' fontWeight='bold'>
                {analytics?.emails_sent}
              </Text>
              <Text>Sent</Text>
            </Box>
            <Box mx='3'>
              <Text>Open Rate</Text>
              <Text my='1' fontWeight='bold'>
                {analytics?.open_rate}%
              </Text>
              <Text>{analytics?.emails_opened} opens</Text>
            </Box>
            <Box>
              <Text>Click Rate</Text>
              <Text my='1' fontWeight='bold'>
                {analytics?.click_rate} %
              </Text>
              <Text>{analytics?.emails_clicked} clicked</Text>
            </Box>
          </Flex>
        </Box>
      </Card>
    </>
  );
};

export default EmailCard;
