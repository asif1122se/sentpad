import { Box, Button, Checkbox, Flex, Input, Select, Text } from '@chakra-ui/react';
import { TriangleDownIcon } from '@chakra-ui/icons';
import { useState } from 'react';
import { useStoreActions, useStoreState } from 'redux';
import { Field, Form, Formik } from 'formik';
import { format } from 'date-fns';
import { StyledTimePicker, TimeOption } from '../styles';
import { days, duration } from '../consts';
import { getTimeString } from 'utils';

type WaitForm = {
  waitType: string;
  waitTime?: number;
  time: string;
  time_zone: string;
  specificDays: string[];
};

const WaitTiming = () => {
  const { activeSetting, actions } = useStoreState((state) => state.autoresponder.autoresponderObj);
  const { addWait, onCloseLeftPanel } = useStoreActions((actions) => actions.autoresponder);

  const wait = activeSetting?.index !== undefined ? actions[activeSetting.index]?.wait : undefined;

  const initialWait: WaitForm = {
    waitType: wait?.wait_type ?? duration[0],
    waitTime: wait?.wait_time,
    time: wait?.specific_time ? getTimeString(wait?.specific_time) : format(new Date(), 'HH:mm'),
    time_zone: wait?.time_zone ?? format(new Date(), 'xx'),
    specificDays: wait?.specific_day?.split(',') ?? [],
  };
  const [showSpecificTime, setShowSpecificTime] = useState<boolean>(
    initialWait.waitType === 'days' &&
      (initialWait.time !== undefined || initialWait.time !== null),
  );
  const [showSpecificDay, setShowSpecificDay] = useState<boolean>(
    initialWait.waitType === 'days' && initialWait.specificDays.length !== 0,
  );

  const validateDuration = (value?: number) => {
    let error;
    if (!value) {
      error = 'Duration is required';
    }
    return error;
  };

  const validateDays = (value: string[]) => {
    let error;
    if (showSpecificDay && value.length === 0) {
      error = 'Specific days are required';
    }
    return error;
  };

  return (
    <Box>
      <Formik
        initialValues={initialWait}
        onSubmit={(values) => {
          addWait({
            index: activeSetting?.index ?? 0,
            wait_type: values.waitType,
            wait_time: values.waitTime,
            specific_time: values.waitType === 'days' && showSpecificTime ? values.time : null,
            time_zone: initialWait.time_zone,
            specific_day:
              values.waitType === 'days' && showSpecificDay ? values.specificDays.toString() : null,
          });

          onCloseLeftPanel();
        }}>
        {({ values, setFieldValue, errors }) => (
          <Form>
            <Box px='4' mb='5' mt='2'>
              <Text fontWeight={'bold'}>Wait</Text>
              <Text color='gray.700' fontSize='sm' mt='2'>
                Add a pause between actions in this autoresponder.
              </Text>
            </Box>
            <Box p='0'>
              <Box px='4' width='100%'>
                <Box color='black' fontSize='md'>
                  <Text fontSize={'sm'} mb='2'>
                    Duration
                  </Text>
                  <Flex>
                    <Field
                      as={Input}
                      fontSize={'sm'}
                      placeholder='Enter a number'
                      borderRightRadius='0px'
                      borderColor={errors.waitTime ? 'red.700' : 'gray.500'}
                      borderWidth={errors.waitTime && '2px'}
                      name='waitTime'
                      type='number'
                      validate={validateDuration}
                    />
                    <Field
                      as={Select}
                      name='waitType'
                      width='70%'
                      borderLeftRadius='0px'
                      borderColor='gray.500'
                      fontSize='sm'
                      textTransform='capitalize'
                      icon={<TriangleDownIcon fontSize='8px' color='gray.700' />}>
                      {duration.map((item) => (
                        <TimeOption key={item} value={item} style={{ textTransform: 'capitalize' }}>
                          {item}
                        </TimeOption>
                      ))}
                    </Field>
                  </Flex>
                  {errors.waitTime && (
                    <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
                      {errors.waitTime}
                    </Text>
                  )}
                  <Flex alignItems='center' gap='0.5rem'>
                    <Checkbox
                      id='cb_time'
                      isDisabled={values.waitType !== 'days'}
                      width='fit-content'
                      borderColor='#cccccc'
                      _checked={{ border: 'none' }}
                      mb='3'
                      mt='4'
                      onChange={(e) => setShowSpecificTime(e.target.checked)}
                      isChecked={showSpecificTime}></Checkbox>
                    <Text
                      fontSize='sm'
                      ml='1'
                      color={values.waitType !== 'days' ? 'gray.400' : '#11213C'}>
                      <label htmlFor='cb_time'>Wait for a specific time of day</label>
                    </Text>
                  </Flex>

                  {showSpecificTime && values.waitType === 'days' && (
                    <>
                      <StyledTimePicker
                        name='time'
                        value={values.time}
                        onChange={(e) => {
                          setFieldValue('time', e);
                        }}
                        clearIcon={null}
                        disableClock
                      />
                      <Text fontSize='sm' my='2' color='gray.600'>
                        {Intl.DateTimeFormat().resolvedOptions().timeZone} GMT{' '}
                        {new Date().toString().split('GMT')[1].split(' (')[0]}
                      </Text>
                    </>
                  )}
                  <Flex alignItems='center' gap='0.5rem'>
                    <Checkbox
                      id='cb_day'
                      isDisabled={values.waitType !== 'days'}
                      width='fit-content'
                      borderColor='#cccccc'
                      _checked={{ border: 'none' }}
                      my='3'
                      onChange={(e) => setShowSpecificDay(e.target.checked)}
                      isChecked={showSpecificDay}></Checkbox>
                    <Text
                      fontSize='sm'
                      ml='1'
                      color={values.waitType !== 'days' ? 'gray.400' : '#11213C'}>
                      <label htmlFor='cb_day'>Wait for specific day(s) of the week</label>
                    </Text>
                  </Flex>
                  {showSpecificDay && values.waitType === 'days' && (
                    <>
                      <Field as={Flex} gap='1' my='3' name='specificDays' validate={validateDays}>
                        {days.map(({ label, value }) => {
                          const isSelected = values.specificDays.indexOf(value) > -1;

                          return (
                            <Button
                              key={value}
                              width='36px'
                              height='28px'
                              fontSize='12px'
                              variant={isSelected ? 'info' : 'infoOutlined'}
                              onClick={() =>
                                setFieldValue(
                                  'specificDays',
                                  isSelected
                                    ? values.specificDays.filter((item) => item !== value)
                                    : [...values.specificDays, value],
                                )
                              }>
                              {label}
                            </Button>
                          );
                        })}
                      </Field>
                      {errors.specificDays && (
                        <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
                          {errors.specificDays}
                        </Text>
                      )}
                    </>
                  )}
                </Box>
              </Box>
            </Box>
            <Box mt='5'>
              <Button variant='info' type='submit' ml='2'>
                Done
              </Button>
            </Box>
          </Form>
        )}
      </Formik>
    </Box>
  );
};

export default WaitTiming;
