import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
} from '@chakra-ui/react';
import { InputField } from 'components';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStoreActions } from 'redux';
import { ROUTE_PATHS } from 'router';
import { useMutation } from 'hooks/useMutation';

type NewAutoresponderModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

const NewAutoresponderModal = ({ isOpen, onClose }: NewAutoresponderModalProps) => {
  const navigate = useNavigate();

  const { add } = useStoreActions((actions) => actions.autoresponder);

  const [value, setValue] = useState<string>('');
  const { mutate, isLoading } = useMutation<any>({
    url: 'save-auto-responder',
    onSuccess: (res) => navigate(`${ROUTE_PATHS?.NEW}?id=${res?.records?.id}`),
  });

  const saveArName = async () => {
    mutate({ name: value });
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered>
      <ModalOverlay />
      <ModalContent minW='540px'>
        <ModalHeader color='black' fontSize='18px' fontWeight='bold' p='2rem 2rem 1rem'>
          Create New Autoresponder
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody p='0 2rem'>
          <InputField
            autoFocus
            label='Autoresponder Name'
            placeholder='Enter Autoresponder Name'
            maxLength={50}
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </ModalBody>

        <ModalFooter display='flex' justifyContent='flex-start' p='1.5rem 2rem 2rem'>
          <Button
            isLoading={isLoading}
            isDisabled={value ? false : true}
            variant={value ? 'success' : 'default'}
            mr={3}
            onClick={() => {
              // onClose();
              saveArName();
              add(null);
            }}>
            Create
          </Button>
          <Button
            onClick={() => {
              setValue('');
              onClose();
            }}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default NewAutoresponderModal;
