import { useState } from 'react';
import { Box, Flex, Image, Text, Badge, useDisclosure } from '@chakra-ui/react';
import { Card } from '../styles';
import SubmitFormIcon from 'assets/icons/submit-form.svg';
import TrashIcon from 'assets/icons/trash.svg';
import CardHeader from './CardHeader';
import { AudienceListItem } from 'pages/Broadcast/components/AudienceList';
import DeleteArModal from '../DeleteArModal';

type SubmitsFormProps = {
  lists: AudienceListItem[];
  title?: string;
  onClick?: () => void;
  onDelete?: () => void;
  isTrigger?: boolean;
};

const SubmitsForm = ({ lists = [], title = 'Submits a Form', onClick }: SubmitsFormProps) => {
  const [showDelete, setShowDelete] = useState<boolean>(false);
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();

  return (
    <>
      <DeleteArModal isOpen={isDeleteOpen} onClose={onDeleteClose} isTrigger={true} />
      <Card
        onClick={onClick}
        onFocus={() => setShowDelete(true)}
        onBlur={() => setShowDelete(false)}
        tabIndex={0}>
        <Box width='100%' height='100%'>
          <Flex justifyContent={'space-between'}>
            <CardHeader title={title} imgUrl={SubmitFormIcon} />
            <Box mt='2' mr='2'>
              {showDelete && <Image width='20px' src={TrashIcon} onClick={() => onDeleteOpen()} />}
            </Box>
          </Flex>
          <Text fontSize='sm' m='2'>
            Form(s)
          </Text>
          <Flex display='inline-block'>
            {lists.map(({ id, name }) => (
              <Badge
                fontSize='12px'
                variant='pending'
                textTransform='capitalize'
                mb='2'
                ml='2'
                key={id}>
                {name}
              </Badge>
            ))}
          </Flex>
        </Box>
      </Card>
    </>
  );
};

export default SubmitsForm;
