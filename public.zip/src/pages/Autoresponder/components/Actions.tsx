import { Box, Flex, Icon, Image, Text } from '@chakra-ui/react';
import Subscriber from 'assets/icons/subscriber.png';
import SendMsg from 'assets/icons/sendmsg.png';
import SendMessage from './SendMessage';
import SubscribeList from './SubscribeList';
import UnsubscribeList from './UnsubscribeList';
import { HiOutlineArrowLeft } from 'react-icons/hi';
import { OptionBox, OptionContainer } from '../styles';
import { AutoresponderSetting } from '../types';
import { useStoreActions, useStoreState } from 'redux';
import { AutoresponderSettings } from '../consts';
import { AudienceListItem } from 'pages/Broadcast/components/AudienceList';
import SendEmail from './SendEmail';
import Time from 'assets/icons/time.png';
import WaitTiming from './WaitTiming';

type ActionsProps = {
  actionsList?: Array<AutoresponderSetting<'action'>>;
};
const Actions = ({ actionsList }: ActionsProps) => {
  const { activeSetting, actions } = useStoreState((state) => state.autoresponder.autoresponderObj);

  const {
    addAction,
    setActiveSetting,
    addSubscribeToListActionList,
    addUnsubscribeFromListActionList,
  } = useStoreActions((actions) => actions.autoresponder);

  const setSubscribeToList = (data: { list: AudienceListItem[] }) => {
    if (activeSetting?.index !== undefined) {
      addSubscribeToListActionList({ lists: data.list, index: activeSetting.index });
    }
  };

  const setUnsubscribeToList = (data: { list: AudienceListItem[] }) => {
    if (activeSetting?.index !== undefined) {
      addUnsubscribeFromListActionList({ lists: data.list, index: activeSetting.index });
    }
  };

  const handleBack = () => (
    <Flex
      p='4'
      width='fit-content'
      justifyContent='flex-start'
      alignItems='center'
      cursor='pointer'
      onClick={() => setActiveSetting({ type: 'actions' })}>
      <Icon as={HiOutlineArrowLeft} mr='2' />
      <Text fontSize='sm' fontWeight='400'>
        Go back
      </Text>
    </Flex>
  );

  return (
    <>
      {activeSetting?.type === 'actions' && (
        <>
          <Box px='4' mb='6' mt='2'>
            <Text fontSize='md' fontWeight='bold'>
              Actions
            </Text>
          </Box>
          <OptionContainer>
            <OptionBox
              onClick={() =>
                setActiveSetting({ type: 'send-message', index: activeSetting.index })
              }>
              <Box width='40px' px='1'>
                <Image width='40px' src={SendMsg} />
              </Box>
              <Box width='100%' mx='1'>
                <Text fontWeight='bold'>Send Message</Text>
                <Text fontSize='sm' mt='1' color='gray.700'>
                  Send a message when a contact gets to this point in the autoresponder.
                </Text>
              </Box>
            </OptionBox>
          </OptionContainer>
          <OptionContainer>
            <OptionBox
              onClick={() => {
                addAction({
                  type: AutoresponderSettings.SUBSCRIBE_ACTION,
                  index: activeSetting?.index ?? 0,
                });
              }}>
              <Box width='40px' px='1'>
                <Image width='40px' src={Subscriber} />
              </Box>
              <Box width='100%' mx='1'>
                <Text fontWeight='bold'>Subscribe to List</Text>
                <Text fontSize='sm' mt='1' color='gray.700'>
                  When a contact reaches this point in the autoresponder, they will be added to the
                  selected list(s).
                </Text>
              </Box>
            </OptionBox>
          </OptionContainer>
          <OptionContainer>
            <OptionBox
              onClick={() => {
                addAction({
                  type: AutoresponderSettings.UNSUBSCRIBE_ACTION,
                  index: activeSetting?.index ?? 0,
                });
              }}>
              <Box width='40px' px='1'>
                <Image width='40px' src={Subscriber} />
              </Box>
              <Box width='100%' mx='1'>
                <Text fontWeight='bold'>Unsubscribe from List</Text>
                <Text fontSize='sm' mt='1' color='gray.700'>
                  When a contact reaches this point in the autoresponder, they will be removed from
                  the selected list(s).
                </Text>
              </Box>
            </OptionBox>
          </OptionContainer>
          <OptionContainer>
            <OptionBox
              onClick={() => {
                addAction({
                  type: AutoresponderSettings.WAIT_TIMING,
                  index: activeSetting?.index ?? 0,
                });
              }}>
              <Box width='40px' px='1'>
                <Image width='40px' src={Time} />
              </Box>
              <Box width='100%' mx='1'>
                <Text fontWeight='bold'>Wait</Text>
                <Text fontSize='sm' mt='1' color='gray.700'>
                  Add a pause between actions in this autoresponder.
                </Text>
              </Box>
            </OptionBox>
          </OptionContainer>
        </>
      )}
      {activeSetting?.type === 'send-message' && <SendMessage />}
      {activeSetting?.type === AutoresponderSettings.SEND_MESSAGE_ACTION && <SendEmail />}
      {activeSetting?.type === AutoresponderSettings.SUBSCRIBE_ACTION && (
        <>
          {handleBack()}
          <SubscribeList
            title='Subscribe to List'
            desc='When a contact reaches this point in the autoresponder, they will be added to the
          selected list(s).'
            values={
              activeSetting.index !== undefined ? actions[activeSetting.index]?.lists ?? [] : []
            }
            setValues={setSubscribeToList}
          />
        </>
      )}
      {activeSetting?.type == AutoresponderSettings.UNSUBSCRIBE_ACTION && (
        <>
          {handleBack()}
          <UnsubscribeList
            values={
              activeSetting.index !== undefined
                ? actions[activeSetting.index]?.unsubscribeList ?? []
                : []
            }
            setValues={setUnsubscribeToList}
          />
        </>
      )}
      {activeSetting?.type == AutoresponderSettings.WAIT_TIMING && (
        <>
          {handleBack()}
          <WaitTiming />
        </>
      )}
    </>
  );
};

export default Actions;
