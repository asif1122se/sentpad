import { useState } from 'react';
import { Box, Flex, Image, Text, Badge, useDisclosure } from '@chakra-ui/react';
import { Card } from '../styles';
import Subscriber from 'assets/icons/subscriber.svg';
import TrashIcon from 'assets/icons/trash.svg';
import CardHeader from './CardHeader';
import { AudienceListItem } from 'pages/Broadcast/components/AudienceList';
import DeleteArModal from '../DeleteArModal';

type SubscribeToListCardProps = {
  lists: AudienceListItem[];
  title?: string;
  onClick?: () => void;
  onDelete?: () => void;
  isTrigger?: boolean;
};

const SubscribeToListCard = ({
  lists = [],
  title = 'Subscribes to a List',
  onClick,
  isTrigger = false,
}: SubscribeToListCardProps) => {
  const [showDelete, setShowDelete] = useState<boolean>(false);
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();

  return (
    <>
      <DeleteArModal isOpen={isDeleteOpen} onClose={onDeleteClose} isTrigger={isTrigger} />
      <Card
        onClick={onClick}
        onFocus={() => setShowDelete(true)}
        onBlur={() => setShowDelete(false)}
        tabIndex={0}>
        <Box width='100%' height='100%'>
          <Flex justifyContent='space-between'>
            <CardHeader title={title} imgUrl={Subscriber} />
            <Box mt='2' mr='2'>
              {showDelete && <Image width='20px' src={TrashIcon} onClick={() => onDeleteOpen()} />}
            </Box>
          </Flex>
          <Text fontSize='sm' m='2'>
            List(s)
          </Text>
          <Flex display='inline-block'>
            {lists.map(({ id, name }) => (
              <Badge
                fontSize='12px'
                variant='pending'
                textTransform='capitalize'
                mb='2'
                ml='2'
                key={id}>
                {name.length > 20 ? name.slice(0, 20) + '...' : name}
              </Badge>
            ))}
          </Flex>
        </Box>
      </Card>
    </>
  );
};

export default SubscribeToListCard;
