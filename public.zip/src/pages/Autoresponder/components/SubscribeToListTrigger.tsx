import { Box, Flex, Image, Text, Badge } from '@chakra-ui/react';
import { Card } from '../styles';
import Subscriber from 'assets/icons/subscriber.png';
import { useStoreState } from 'redux';

const SubscribeToListTrigger = () => {
  const lists = useStoreState(
    (state) => state.autoresponder.autoresponderObj.subscribeToListTriggerList,
  );

  return (
    <Card>
      <Box width='95%' height='90%'>
        <Flex alignItems='center' justifyContent='flex-start'>
          <Box alignItems={'center'} background='purple.100' borderRadius='3px'>
            <Image width='30px' src={Subscriber} />
          </Box>
          <Box alignItems={'center'} mx='1'>
            <Text fontWeight='bold'>Subscribe to a List</Text>
          </Box>
        </Flex>
        <Text fontSize='sm' my='1'>
          List
        </Text>
        <Flex width='fit-content' display='inline-block'>
          {lists.map(({ id, name }) => (
            <Badge
              fontSize='12px'
              variant='pending'
              textTransform='capitalize'
              mb='1'
              mr='1'
              key={id}>
              {name.length > 30 ? `${name.substring(0, 30)}...` : name}
            </Badge>
          ))}
        </Flex>
      </Box>
    </Card>
  );
};

export default SubscribeToListTrigger;
