import { Box, Button, Flex, Heading, Text, Link, Image } from '@chakra-ui/react';
import { InputField } from 'components';
import { CONTENT } from 'consts';
import { useNavigate } from 'react-router-dom';
import { BroadcastFormType } from 'redux/model/autoresponder';

type BroadcastNameType = {
  values: BroadcastFormType;
  error: boolean;
  showHeading?: boolean;
  fontSize?: string;
  fontWeight?: string;
  handleChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  isAutoresponder?: boolean;
};

const Content: React.FC<BroadcastNameType> = ({
  values,
  error,
  showHeading = true,
  fontSize,
  fontWeight = 'medium',
  handleChange,
  isAutoresponder = false,
}: BroadcastNameType) => {
  const navigate = useNavigate();

  return (
    <Box>
      {showHeading && (
        <>
          <Heading as='h1' size='h3' fontWeight='bold'>
            {CONTENT}
          </Heading>
          <Text color='gray.800' mb='18px' w='377px'>
            Choose broadcast setting such as subject, preheader and content.
          </Text>
        </>
      )}
      <InputField
        fontSize={'sm'}
        label='Subject'
        type='text'
        name='subject'
        onChange={handleChange}
        value={values.subject}
        placeholder='Enter email subject'
        formControlProps={{
          mb: '12px',
        }}
        errorText={!values?.subject && error ? 'The subject field is required' : ''}
      />
      <InputField
        fontSize={'sm'}
        label='Preheader'
        type='text'
        name='pre_header'
        onChange={handleChange}
        value={values.pre_header}
        placeholder='Enter preheader'
      />
      <Flex flexDirection='column' mt='12px'>
        <Text fontWeight={fontWeight} fontSize={fontSize} mb='10px'>
          Content
        </Text>
        <Flex
          background='red'
          h='172px'
          bg='#F4F0F7'
          flexDirection='column'
          justifyContent='center'
          alignItems='center'
          borderRadius='4px'
          gap='0.5rem'
          border={error && !values.body_content ? '2px solid' : undefined}
          borderColor={error && !values.body_content ? 'red.700' : undefined}>
          <>
            {values.body_content && (
              <Link
                onClick={() => (!values.body_content ? navigate('/design-templates') : null)}
                cursor={!values.body_content ? 'pointer' : 'default'}>
                <Image
                  boxSize='100px'
                  src={
                    values.templateThumbnail
                      ? values.templateThumbnail
                      : 'https://i.ibb.co/ZKGj1sw/thumbnail.png'
                  }
                />
              </Link>
            )}
            <Button
              variant='black'
              onClick={() =>
                navigate(
                  values.body_content
                    ? `/broadcast/email-builder?type=autoresponder&isEdit=true`
                    : `/design-templates${isAutoresponder && '?type=autoresponder'}`,
                )
              }>
              {values.body_content ? 'Edit Email' : 'Design Email'}
            </Button>
            {!values.body_content && (
              <Text fontSize='14px' color='gray.800'>
                No email design yet
              </Text>
            )}
          </>
        </Flex>
        {!values.templateThumbnail && !values.body_content && error && (
          <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
            Email content is required
          </Text>
        )}
      </Flex>
    </Box>
  );
};

export default Content;
