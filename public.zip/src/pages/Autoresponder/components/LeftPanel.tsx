import { Box, useOutsideClick } from '@chakra-ui/react';
import { useQuery } from 'hooks/useQuery';
import { useRef } from 'react';
import { useStoreActions } from 'redux';
import QUERY_KEYS from 'utils/queryKeys';
import { AutoresponderSettingsType } from '../types';
import Actions from './Actions';
import Triggers from './Triggers';

type LeftPanelProps = {
  isOpen: boolean;
  onOpen: () => void;
  onClose: () => void;
};

const LeftPanel = ({ isOpen, onOpen, onClose }: LeftPanelProps) => {
  const { data: settings, isLoading: isSettingsLoading } = useQuery<AutoresponderSettingsType>({
    url: 'auto-responder-settings',
    queryKey: [QUERY_KEYS.AUTORESPONDER_SETTINGS],
  });

  const { addTempEmail } = useStoreActions((state) => state.autoresponder);

  const ref = useRef<HTMLDivElement | null>(null);

  useOutsideClick({
    ref: ref,
    handler: () => {
      addTempEmail(null);
      onClose();
    },
  });

  return isOpen ? (
    <Box
      ref={ref}
      borderRightColor='gray.300'
      borderRightWidth='1px'
      height='100%'
      width='420px'
      background='#FFFFFF 0% 0% no-repeat padding-box'
      boxShadow='inset -12px 0px 25px #717C8D1A'
      opacity='1'>
      <Triggers triggersList={settings?.triggers} />
      <Actions actionsList={settings?.actions} />
    </Box>
  ) : null;
};

export default LeftPanel;
