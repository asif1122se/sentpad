import { Box, Text } from '@chakra-ui/react';
import AudienceList, { AudienceListItem } from 'pages/Broadcast/components/AudienceList';

type SubscribeListProps = {
  title: string;
  desc: string;
  values: AudienceListItem[];
  setValues: any;
};

const SubscribeList = ({ title, desc, values, setValues }: SubscribeListProps) => {
  const getFilteredData = (data: any) => {
    data?.list && setValues({ ...values, list: data?.list });
  };

  const getList = (data: any) => {
    getFilteredData({ list: data });
  };

  return (
    <>
      <Box px='4' mb='6' mt='2'>
        <Text fontWeight={'bold'}>{title}</Text>
        <Text color='gray.700' fontSize='sm' mt='2'>
          {desc}
        </Text>
      </Box>
      <Box p='0'>
        <Box px='4' width='100%'>
          <Box color='black' fontSize='md'>
            <AudienceList
              showSelectAll={false}
              getList={getList}
              headingText='Select List(s)'
              removeText='Remove All'
              values={{ list: values }}
              setValues={setValues}
            />
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default SubscribeList;
