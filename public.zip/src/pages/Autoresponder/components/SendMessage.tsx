import { Box, Flex, Icon, Image, Text } from '@chakra-ui/react';
import { HiOutlineArrowLeft } from 'react-icons/hi';
import SendMsg from 'assets/icons/sendmsg.png';
import { OptionBox, OptionContainer } from '../styles';
import { useStoreActions, useStoreState } from 'redux';
import { AutoresponderSettings } from '../consts';

const SendMessage = () => {
  const { activeSetting } = useStoreState((state) => state.autoresponder.autoresponderObj);
  const { setActiveSetting, addAction } = useStoreActions((actions) => actions.autoresponder);
  const setEmail = useStoreActions((actions) => actions.broadcast.add);

  return (
    <>
      <>
        <Flex
          p='4'
          width='fit-content'
          justifyContent='flex-start'
          alignItems='center'
          cursor='pointer'
          onClick={() => setActiveSetting({ type: 'actions' })}>
          <Icon as={HiOutlineArrowLeft} mr='2' />
          <Text fontSize='sm' fontWeight='400'>
            Go back
          </Text>
        </Flex>
        <Box px='4' py='0'>
          <Text fontWeight='bold'>Send Message</Text>
          <Text color='gray.700' fontSize='sm' mt='2'>
            Send a message when a contact gets to this point in the autoresponder.
          </Text>
        </Box>
        <Box px='0' py='4'>
          <OptionContainer>
            <OptionBox
              onClick={() => {
                addAction({
                  type: AutoresponderSettings.SEND_MESSAGE_ACTION,
                  index: activeSetting?.index ?? 0,
                });
                setEmail({});
              }}>
              <Box width='40px' px='1'>
                <Image width='40px' src={SendMsg} />
              </Box>
              <Box width='100%' mx='1'>
                <Text fontWeight='bold'>Email</Text>
                <Text fontSize='sm' mt='1' color='gray.700'>
                  Send an email message when a contact reaches this point in the autoresponder.
                </Text>
              </Box>
            </OptionBox>
          </OptionContainer>
        </Box>
      </>
    </>
  );
};

export default SendMessage;
