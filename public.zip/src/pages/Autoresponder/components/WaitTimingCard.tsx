import { Box, Flex, Image, Text, useDisclosure } from '@chakra-ui/react';
import { useState } from 'react';
import { Card } from '../styles';
import CardHeader from './CardHeader';
import TrashIcon from 'assets/icons/trash.svg';
import WaitIcon from 'assets/icons/wait.svg';
import DeleteArModal from '../DeleteArModal';
import { Wait } from 'redux/model/autoresponder';

type WaitTimingProps = {
  onClick?: () => void;
  wait?: Wait;
};

const WaitTimingCard = ({ onClick, wait }: WaitTimingProps) => {
  const [showDelete, setShowDelete] = useState<boolean>(false);
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  return (
    <>
      <DeleteArModal isOpen={isDeleteOpen} onClose={onDeleteClose} />
      <Card
        onClick={onClick}
        onFocus={() => setShowDelete(true)}
        onBlur={() => setShowDelete(false)}
        tabIndex={0}>
        <Box width='100%' height='100%'>
          <Flex justifyContent={'space-between'}>
            <CardHeader title='Wait' imgUrl={WaitIcon} />
            <Box mt='2' mr='2'>
              {showDelete && <Image width='20px' src={TrashIcon} onClick={onDeleteOpen} />}
            </Box>
          </Flex>
          <Flex fontSize='12px' p='2'>
            <Box mr='2'>
              <Text color='gray.700'>Wait</Text>
              <Text my='1' fontWeight='bold'>
                {wait?.wait_time}{' '}
                {wait?.wait_time && wait?.wait_time === 1
                  ? wait?.wait_type.slice(0, -1)
                  : wait?.wait_type}{' '}
                {wait?.specific_time && `and at ${wait.specific_time}`}{' '}
                {wait?.specific_day && `and on`}
              </Text>
              <Flex gap='2px' mt='12px'>
                {wait?.specific_day &&
                  wait.specific_day.split(',').map((day) => (
                    <Flex
                      key={day}
                      width='36px'
                      height='28px'
                      textTransform='capitalize'
                      color='blue.700'
                      border='1px solid var(--chakra-colors-blue-700)'
                      borderRadius='4px'
                      alignItems='center'
                      justifyContent='center'>
                      {day.slice(0, 3)}
                    </Flex>
                  ))}
              </Flex>
            </Box>
          </Flex>
          <Flex display='inline-block'></Flex>
        </Box>
      </Card>
    </>
  );
};

export default WaitTimingCard;
