import { Box, Button, Flex, Icon, Text } from '@chakra-ui/react';
import { HiOutlineArrowLeft } from 'react-icons/hi';
import { useEffect, useState } from 'react';
import { InputField } from 'components';
import { useStoreState, useStoreActions } from 'redux';
import SenderProfileDropDown from './SenderProfileDropdown';
import Content from './Content';
import { StyledSwitch } from '../styles';

const SendEmail = () => {
  const [emailStage, setEmailStage] = useState<string>('first');
  const [error, setError] = useState(false);
  const [isActive, setIsActive] = useState(false);

  const { activeSetting, actions, tempEmail } = useStoreState(
    (state) => state.autoresponder.autoresponderObj,
  );

  const isClearStore = useStoreState((state) => state.autoresponder.isClearStore);

  const { addSendEmailActionList, setActiveSetting, addTempEmail, onCloseLeftPanel } =
    useStoreActions((state) => state.autoresponder);

  const handleStepChange = (step: string) => {
    if (step === 'second') {
      if (tempEmail.email_name === '' || tempEmail.sender_profile_id === 0) {
        setError(true);
      } else {
        setError(false);
        setEmailStage(step);
      }
    }
  };

  const hasEmptyField = () => {
    return (
      tempEmail.email_name === '' ||
      tempEmail.sender_profile_id === 0 ||
      tempEmail.subject === '' ||
      tempEmail.body_content === ''
    );
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (hasEmptyField()) {
      setIsActive(false);
    }

    return addTempEmail({ ...tempEmail, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    if (tempEmail.subject === '' || tempEmail.body_content === '') {
      setError(true);
    } else {
      addSendEmailActionList({ ...tempEmail, is_active: isActive ? 1 : 0 });
      addTempEmail(null);
      onCloseLeftPanel();
    }
  };

  useEffect(() => {
    const values = actions[activeSetting?.index ?? 0].email;

    if (!isClearStore && values) {
      addTempEmail(values);
      setIsActive(values.is_active === 1);
    }
  }, [activeSetting]);

  return (
    <>
      <Box height='100%'>
        <Flex alignItems='center' justifyContent='space-between'>
          <Flex
            p='4'
            width='fit-content'
            justifyContent='flex-start'
            alignItems='center'
            cursor='pointer'
            onClick={() => setActiveSetting({ type: 'send-message' })}>
            <Icon as={HiOutlineArrowLeft} mr='2' />
            <Text fontSize='sm' fontWeight='400'>
              Go back
            </Text>
          </Flex>
        </Flex>
        <Box px='4' py='0' height='100%'>
          <Text fontWeight='bold'>Send Email</Text>
          <Text color='gray.700' fontSize='sm' my='2'>
            Send email based on the previous trigger.
          </Text>
          <Flex alignItems='center'>
            <StyledSwitch
              p='4'
              pl='0'
              size='lg'
              onChange={() => setIsActive(!isActive)}
              isChecked={isActive}
              isDisabled={hasEmptyField()}
            />
            <Text fontSize='sm' fontWeight='400'>
              {isActive ? 'Active' : 'Inactive'}
            </Text>
          </Flex>
          {emailStage === 'first' && (
            <Box mt='5'>
              <InputField
                fontSize={'sm'}
                label='Email Name'
                placeholder='Enter email name'
                name='email_name'
                onChange={handleChange}
                value={tempEmail ? tempEmail.email_name : ''}
                errorText={error && tempEmail.email_name === '' ? 'Email Name is required' : ''}
              />
              <Box mt='4' position='relative' zIndex='2'>
                <SenderProfileDropDown
                  fontsize='sm'
                  title='Sender Profile'
                  getId={(id: number) => addTempEmail({ ...tempEmail, sender_profile_id: id })}
                  value={tempEmail?.sender_profile_id}
                  errorText={
                    error && tempEmail.sender_profile_id === 0 ? 'Sender Profile is required' : ''
                  }
                />
              </Box>
              <Button mt='5' variant='info' onClick={() => handleStepChange('second')}>
                Next: Content
              </Button>
            </Box>
          )}
          {emailStage === 'second' && (
            <>
              <Box mt='5'>
                <Content
                  fontSize='sm'
                  fontWeight='normal'
                  showHeading={false}
                  values={tempEmail}
                  handleChange={handleChange}
                  error={error}
                  isAutoresponder
                />
              </Box>
              <Box mt='5'>
                <Button variant='info' onClick={() => setEmailStage('first')}>
                  Previous
                </Button>
                <Button variant='info' onClick={handleSave} ml='2'>
                  Done
                </Button>
              </Box>
            </>
          )}
        </Box>
      </Box>
    </>
  );
};

export default SendEmail;
