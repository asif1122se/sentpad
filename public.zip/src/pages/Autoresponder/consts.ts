export enum AutoresponderSettings {
  SUBSCRIBE_TRIGGER = 1,
  SEND_MESSAGE_ACTION,
  SUBSCRIBE_ACTION,
  UNSUBSCRIBE_ACTION,
  WAIT_TIMING,
  SUBMITS_A_FORM_TRIGGER,
}

export const duration = ['minutes', 'hours', 'days'];

export const days = [
  {
    label: 'Sun',
    value: 'sunday',
  },
  {
    label: 'Mon',
    value: 'monday',
  },
  {
    label: 'Tue',
    value: 'tuesday',
  },
  {
    label: 'Wed',
    value: 'wednesday',
  },
  {
    label: 'Thu',
    value: 'thursday',
  },
  {
    label: 'Fri',
    value: 'friday',
  },
  {
    label: 'Sat',
    value: 'saturday',
  },
];
