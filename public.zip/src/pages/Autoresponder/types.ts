import { GetForm } from 'pages/Forms/types';
import { BroadcastFormType, Wait } from 'redux/model/autoresponder';

type ListItem = {
  created_at: string;
  deleted_at: string;
  description: string | null;
  id: number;
  is_active: '0' | '1';
  no_of_contacts: number;
  sender_profile_id: number | null;
  title: string;
  updated_at: string;
  user_id: number;
};

type AutoresponderSettingsFlowItem = {
  ar_id: number;
  list_ids: string;
  lists: ListItem[];
  forms: GetForm[];
};

export type Autorespond = {
  id: number;
  name: string;
  user_id: number;
  audience: number;
  scheduled_time: string;
  status: string;
  email_clicked: number;
  email_opened: number;
  email_sent: number;
  settings_flow: AutoresponderSettingsFlowItem[];
  unique_email_opened: number;
  created_at: string;
  deleted_at: string | null;
  updated_at: string;
};

export type Email = {
  ar_id: number;
  body_content: string | null;
  campaign_id: number | null;
  created_at: '2023-01-12T11:31:40.000000Z';
  id: 1249;
  name: string | null;
  pre_header: string | null;
  sender_profile: string | null;
  sender_profile_id: number | null;
  subject: string | null;
  updated_at: string;
  user_temp_id: number | null;
};

export type GetSingleAutoresponder = {
  id: number;
  name: string;
  audience: number;
  email_sent: string;
  scheduled_time: string;
  status: string;
  created_at: string;
  settings_flow: AutoresponderSettingsFlowItem[];
  email: Email[];
};

export type AutorespondListing = Autorespond[];

export type AutoresponderSetting<T> = {
  id: number;
  name: string;
  description: string | null;
  type: T;
  is_active: 0 | 1;
};

export type AutoresponderSettingsType = {
  actions?: Array<AutoresponderSetting<'action'>>;
  timing?: Array<AutoresponderSetting<'timing'>>;
  triggers?: Array<AutoresponderSetting<'trigger'>>;
};

export type CreateAutoresponder = {
  ar_id: string;
  name: string;
  status: 'draft' | 'active' | 'inactive';
  list_ids?: string;
  form_ids?: string;
  time_scheduled?: string;
  settings?: string;
  subscribe_action?: Array<{ list_ids: string | undefined }>;
  unsubscribe_action?: Array<{ list_ids: string | undefined }>;
  email?: Array<BroadcastFormType | undefined>;
  wait_action?: Array<Wait | undefined>;
};
