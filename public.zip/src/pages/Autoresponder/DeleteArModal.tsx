import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  Flex,
  Box,
  Image,
} from '@chakra-ui/react';
import AlertIcon from 'assets/icons/alert.svg';
import { useStoreActions, useStoreState } from 'redux';

type DeleteArModalTypes = {
  isOpen: boolean;
  onClose: () => void;
  isTrigger?: boolean;
};

const DeleteArModal = ({ isOpen, onClose, isTrigger = false }: DeleteArModalTypes) => {
  const { activeSetting } = useStoreState((state) => state.autoresponder.autoresponderObj);
  const { deleteTrigger, deleteAction, onOpenLeftPanel } = useStoreActions(
    (actions) => actions.autoresponder,
  );

  const handleDelete = () => {
    if (activeSetting?.index !== undefined) {
      if (isTrigger) {
        deleteTrigger(activeSetting.index);
      } else {
        deleteAction(activeSetting.index);
      }
      onClose();
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered size='md'>
      <ModalOverlay />
      <ModalContent p='32px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='17px' fontWeight='bold'>
            Delete {isTrigger ? 'Trigger' : 'Action'}
          </Text>
        </ModalHeader>
        <ModalCloseButton mt='13px' />
        <ModalBody px='0' pt='3'>
          <Flex fontSize='15px' alignItems='flex-start'>
            <Box maxWidth='38px'>
              <Image src={AlertIcon} alt='Alert' height='40px' width='100px' />
            </Box>
            <Flex px='4' py='1' justifyContent='flex-start' alignItems='start'>
              <Text whiteSpace='pre-line'>
                Are you sure you want to delete {'\n'} this {isTrigger ? 'trigger' : 'action'}?
              </Text>
            </Flex>
          </Flex>
        </ModalBody>

        <ModalFooter justifyContent='flex-start' pb='0' px='0'>
          <Button variant='danger' mr={2} onClick={handleDelete}>
            Delete
          </Button>
          <Button
            onClick={() => {
              onClose();
              onOpenLeftPanel();
            }}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeleteArModal;
