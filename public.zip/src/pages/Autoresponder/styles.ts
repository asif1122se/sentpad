import { Box, Button, Flex, HStack, Switch, Text } from '@chakra-ui/react';
import TimePicker from 'react-time-picker';
import styled from '@emotion/styled';

export const AutoresponderName = styled(Text)`
  font-size: 20px;
  line-height: 24px;
  font-weight: bold;
`;

export const AutoresponderContent = styled(Flex)`
  padding-top: 70px;
  min-width: 500px;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;

export const TriggerList = styled(HStack)``;

export const TriggerItem = styled(Box)`
  min-height: 170px;
  position: relative;

  &:only-child {
    &:before {
      display: none;
    }
  }

  &:first-child {
    &:before {
      left: 50%;
    }
  }

  &:last-child {
    &:before {
      right: 50%;
    }
  }

  &::before {
    height: 1px;
    bottom: 0;
    width: calc(100% + 0.5rem);
    background-color: var(--chakra-colors-gray-500);
    content: '';
    position: absolute;
  }

  &::after {
    height: 100%;
    left: 0;
    margin: auto;
    right: 0;
    bottom: 0;
    width: 1px;
    background-color: var(--chakra-colors-gray-500);
    color: var(--chakra-colors-gray-900);
    content: '';
    position: absolute;
    z-index: -1;
  }
`;

export const Card = styled(Flex)`
  padding: 0 0.25rem;
  width: 350px;
  min-height: 131px;
  border: 1px solid var(--chakra-colors-gray-500);
  border-radius: 6px;
  justify-content: center;
  color: var(--chakra-colors-gray-900);
  background-color: white;

  &:focus,
  &:hover {
    background-color: var(--chakra-colors-gray-200);
    cursor: pointer;
    border: 1px solid var(--chakra-colors-gray-200);
  }
`;

export const TreeBranch = styled(Box)``;

export const Tree = styled(Box)``;

export const TreeContent = styled(Box)``;

export const AddWrapper = styled(Flex)<{ empty?: boolean }>`
  position: relative;
  padding: 24px 0;
  align-items: center;
  justify-content: center;
  ${({ empty }) => empty && 'padding-bottom: 0;'}

  &::before {
    position: absolute;
    content: '';
    top: 0;
    left: calc(50% - 0.5px);
    z-index: -1;
    height: 100%;
    width: 1px;
    background-color: var(--chakra-colors-gray-500);
  }
`;

export const StyledSwitch = styled(Switch)`
  .chakra-switch__track {
    background: var(--chakra-colors-red-700);
    &[data-checked] {
      background: var(--chakra-colors-teal-700);
    }
  }
`;

export const OptionBox = styled(Flex)`
  padding: 0.5rem;
  margin-bottom: 0.75rem;
  width: 100%;
  border-width: 1px;
  border-radius: 6px;
  border-color: var(--chakra-colors-gray-400);
  &:hover {
    border-color: var(--chakra-colors-gray-500);
    opacity: 1;
    transition-delay: 0.18s;
  }
  cursor: pointer;
`;

export const OptionContainer = styled(Flex)`
  justify-content: center;
  width: 100%;
  padding: 0 1rem;
  margin-top: 2px;
`;

export const PlusButton = styled(Button)`
  padding: 0;
  border-radius: 100%;
  min-width: 36px;
  width: 36px;
  height: 36px;
  padding: 0;
  margin-bottom: 0;
`;

export const TimeSelect = styled.select({
  paddingLeft: '8px',
  marginRight: '-10px',
  paddingRight: '10px',
  background: 'transparent',
  outline: 'none',
  WebkitAppearance: 'none',
  fontSize: '13px',
  width: '44px',
  cursor: 'pointer',
});

export const TimeOption = styled.option({});

export const StyledTimePicker = styled(TimePicker)`
  width: 142px%;
  font-weight: normal;
  font-size: 14px;

  .react-time-picker__wrapper {
    border-radius: 5px;
    padding: 5px 3px;
    height: 40px;
  }
`;
