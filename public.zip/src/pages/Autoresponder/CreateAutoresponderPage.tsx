import { Box, Flex, Text, useDisclosure, Image, Button } from '@chakra-ui/react';
import PlusIcon from 'assets/icons/plus.svg';
import { useEffect, useState } from 'react';
import {
  AddWrapper,
  AutoresponderContent,
  AutoresponderName,
  Card,
  PlusButton,
  StyledSwitch,
  Tree,
  TreeBranch,
  TreeContent,
  TriggerItem,
  TriggerList,
} from './styles';
import EditIcon from 'assets/icons/edit.svg';
import ArrowBackIcon from 'assets/icons/arrow-back.svg';
import { useNavigate } from 'react-router-dom';
import SubscribeToListCard from './components/SubscribeToListCard';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { CreateAutoresponder, GetSingleAutoresponder } from './types';
import { useMutation } from 'hooks/useMutation';
import { useStoreActions, useStoreState } from 'redux';
import { AutoresponderSettings } from './consts';
import EmailCard from './components/EmailCard';
import { InputField } from 'components';
import LeftPanel from './components/LeftPanel';
import { ActiveSetting } from 'redux/model/autoresponder';
import WaitTimingCard from './components/WaitTimingCard';
import { CheckIcon, SmallCloseIcon } from '@chakra-ui/icons';
import { useQueryClient } from '@tanstack/react-query';
import { getTimeString } from 'utils';
import SubmitsFormCard from './components/SubmitsFormCard';
import { ROUTE_PATHS } from 'router';
import { GetForm } from 'pages/Forms/types';
import { TrueOrFalse } from 'types';

export type EmailStats = {
  emails_sent?: string;
  open_rate?: string;
  emails_opened?: string;
  click_rate?: string;
  emails_clicked?: string;
};

const MAX_TRIGGERS = 2;

const CreateAutoresponderPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { isOpen } = useDisclosure();
  const [isRedirect, setIsRediect] = useState(true);
  const [isActive, setIsActive] = useState<any>('draft');
  const [arName, setArName] = useState<string>('');
  const [isEdit, setIsEdit] = useState<boolean>(false);
  const { mutate, isLoading: isSaveLoading } = useMutation<CreateAutoresponder>({
    url: 'save-auto-responder',
    onSuccess: () => {
      queryClient.invalidateQueries([QUERY_KEYS.AUTORESPONDER_BY_ID]),
        navigate(`/${ROUTE_PATHS.AUTORESPONDER}`);
    },
  });

  const { mutate: EeditArName, isLoading: isEditArName } = useMutation<any>({
    url: 'save-auto-responder-name',
    onSuccess: (data) => {
      setArName(data?.records?.name),
        setTimeout(() => {
          queryClient.invalidateQueries([QUERY_KEYS.AUTORESPONDER_LIST]);
        }, 1000);
    },
  });

  const arId = window?.location?.search?.split('?id=')[1];

  const { data: getSingleAR, isLoading } = useQuery<GetSingleAutoresponder>({
    url: `get-auto-responder/${arId}`,
    queryKey: [QUERY_KEYS.AUTORESPONDER_BY_ID],
    enabled: arId ? true : false,
  });

  const { data: getArName } = useQuery<{ name: string }>({
    url: `get-auto-responder-name/${arId}`,
    queryKey: [QUERY_KEYS.AUTORESPONDER_NAME_BY_ID],
    onSuccess: (arNameData) => {
      setArName(`${arNameData?.name}`);
    },
    enabled: arId ? true : false,
    showToast: false,
  });

  const isOpenLeftPanel = useStoreState((state) => state?.autoresponder?.leftPanel?.isOpen);
  const isClearStore = useStoreState((state) => state?.autoresponder?.isClearStore);
  const {
    onOpenLeftPanel,
    onCloseLeftPanel,
    addAction,
    onClearStore,
    addSubscribeToListTriggerList,
    addSubmitsAFormTriggerList,
  } = useStoreActions((actions) => actions?.autoresponder);

  const { triggers, subscribeToListTriggerList, submitsAFormTriggerList, actions } = useStoreState(
    (state) => state?.autoresponder?.autoresponderObj,
  );

  const { setActiveSetting, addTrigger } = useStoreActions((actions) => actions?.autoresponder);
  const handleEmailAction = async (order: number, email_id: number, is_active: TrueOrFalse) => {
    const emailObj = getSingleAR?.email?.find((item) => item?.id == email_id);
    addAction({
      index: order,
      type: AutoresponderSettings.SEND_MESSAGE_ACTION,
      email: {
        id: email_id,
        body_content: emailObj?.body_content ?? '',
        email_name: emailObj?.name ?? '',
        is_active,
        pre_header: emailObj?.pre_header ?? '',
        sender_profile_id: emailObj?.sender_profile_id ?? 0,
        status: '',
        subject: emailObj?.subject ?? '',
        templateThumbnail: '',
      },
    });
  };

  const handleAddAction = async () => {
    getSingleAR?.status == 'active'
      ? setIsActive(true)
      : getSingleAR?.status == 'draft'
      ? setIsActive('draft')
      : false;
    getSingleAR &&
      getSingleAR?.settings_flow?.forEach((actionData: any, index) => {
        if (actionData?.trg_act_id === AutoresponderSettings.SUBSCRIBE_TRIGGER) {
          const listsById =
            actionData &&
            actionData?.lists?.map((item: any) => ({
              id: item?.id,
              name: `${item?.title}`,
            }));
          addSubscribeToListTriggerList(listsById);
          addTrigger(AutoresponderSettings.SUBSCRIBE_TRIGGER);
        }
        if (actionData?.trg_act_id === AutoresponderSettings.SUBMITS_A_FORM_TRIGGER) {
          const formsById =
            actionData &&
            actionData?.forms?.map((item: GetForm) => ({
              id: item?.id,
              name: `${item?.name}`,
            }));
          addSubmitsAFormTriggerList(formsById);
          addTrigger(AutoresponderSettings.SUBMITS_A_FORM_TRIGGER);
        }
        if (actionData?.trg_act_id == AutoresponderSettings.SEND_MESSAGE_ACTION) {
          handleEmailAction(index, actionData?.email_id, actionData?.is_active);
        }
        if (actionData?.trg_act_id == AutoresponderSettings.SUBSCRIBE_ACTION) {
          addAction({
            index,
            type: actionData?.trg_act_id,
            lists:
              actionData &&
              actionData?.lists?.map((sList: any) => ({ id: sList?.id, name: sList?.title })),
          });
        }
        if (actionData?.trg_act_id == AutoresponderSettings.UNSUBSCRIBE_ACTION) {
          addAction({
            index,
            type: actionData?.trg_act_id,
            unsubscribeList:
              actionData &&
              actionData?.lists?.map((sList: any) => ({
                id: sList?.id,
                name: sList?.title,
              })),
          });
        }
        if (actionData?.trg_act_id == AutoresponderSettings.WAIT_TIMING) {
          addAction({
            index,
            type: actionData?.trg_act_id,
            wait: {
              wait_type: actionData?.wait_type,
              wait_time: actionData?.wait_time,
              specific_time:
                actionData?.specific_time !== null
                  ? getTimeString(actionData?.specific_time)
                  : null,
              time_zone: actionData?.time_zone,
              specific_day: actionData?.specific_day,
            },
          });
        }
      });
  };

  const handleCardClick = (activeSetting: ActiveSetting) => {
    setActiveSetting(activeSetting);
    onOpenLeftPanel();
    onClearStore(false);
  };

  const saveAutomation = () => {
    const listIds =
      subscribeToListTriggerList && subscribeToListTriggerList?.map((item) => item?.id).toString();
    const formIds =
      submitsAFormTriggerList && submitsAFormTriggerList?.map((item) => item?.id).toString();
    const triggersAndActions = [
      ...triggers,
      actions?.map((action) => action?.type).toString(),
    ].toString();

    const subscribeToListActionListIds =
      actions &&
      actions
        .filter((action) => action?.type === AutoresponderSettings.SUBSCRIBE_ACTION)
        .map((act) => act?.lists)
        .map((item) => item?.map((x) => x.id))
        .map((ids) => ids?.join(','))
        .map((idString) => ({ list_ids: idString }));

    const unsubscribeToListActionListIds =
      actions &&
      actions
        .filter((action) => action?.type === AutoresponderSettings.UNSUBSCRIBE_ACTION)
        .map((act) => act?.unsubscribeList)
        .map((item) => item?.map((x) => x?.id))
        .map((ids) => ids?.join(','))
        .map((idString) => ({ list_ids: idString }));

    mutate({
      ar_id: arId,
      name: arName ? `${arName}` : `${getSingleAR?.name}`,
      status:
        atleastOneActionOneTrigger() && (isActive == 'draft' || !isActive)
          ? 'inactive'
          : atleastOneActionOneTrigger() && isActive == true
          ? 'active'
          : isActive,
      settings: triggersAndActions,
      time_scheduled: '2022-10-18 15:30',
      list_ids: listIds,
      form_ids: formIds,
      subscribe_action: subscribeToListActionListIds ?? [],
      unsubscribe_action: unsubscribeToListActionListIds ?? [],
      email:
        actions &&
        actions
          .filter((action) => action?.type === AutoresponderSettings.SEND_MESSAGE_ACTION)
          .map((act) => act?.email),
      wait_action:
        actions &&
        actions
          .filter((action) => action?.type === AutoresponderSettings.WAIT_TIMING)
          .map((act) => act?.wait),
    });
  };

  const editName = () => {
    setIsRediect(false);
    EeditArName({ ar_id: arId, name: arName });
  };

  useEffect(() => {
    !isClearStore && handleAddAction();
  }, [getSingleAR]);

  useEffect(() => {
    return () => {
      onClearStore(true);
    };
  }, []);

  const atleastOneActionOneTrigger = () => {
    const listActLength =
      actions &&
      actions?.filter(
        (item: any) =>
          item?.lists?.length > 0 && item?.type !== AutoresponderSettings.SEND_MESSAGE_ACTION,
      )?.length;
    const emailAct = actions?.find(
      (item: any) =>
        item?.email?.email_name && item?.type === AutoresponderSettings.SEND_MESSAGE_ACTION,
    );
    const unSubListActLength = actions?.find(
      (item: any) =>
        item?.unsubscribeList?.length > 0 &&
        item?.type === AutoresponderSettings.UNSUBSCRIBE_ACTION,
    );
    const triggerList = subscribeToListTriggerList?.length || submitsAFormTriggerList?.length;
    return (
      (triggerList > 0 && (listActLength > 0 || emailAct)) ||
      (triggerList > 0 && unSubListActLength)
    );
  };

  return (
    <Flex height='100%' m='0' p='0'>
      {/* <DeleteCardModal isOpen={isDeleteOpen} onClose={onDeleteClose} isTrigger={isTrigger} /> */}
      <LeftPanel isOpen={isOpenLeftPanel} onOpen={onOpenLeftPanel} onClose={onCloseLeftPanel} />
      <Box width='100%'>
        <Flex
          justifyContent='space-between'
          h='72px'
          alignItems='center'
          borderBottom='1px solid'
          borderColor='gray.400'
          px='8'>
          <Flex alignItems='center' gap='3'>
            <Image
              src={ArrowBackIcon}
              alt='Back'
              cursor='pointer'
              onClick={() => navigate(`/${ROUTE_PATHS.AUTORESPONDER}`)}
            />
            {isEdit ? (
              <InputField
                fontSize='sm'
                borderColor='gray.600'
                my='2'
                h='9'
                onChange={(e) => setArName(`${e.target.value}`)}
                value={arName}
                maxLength={50}
              />
            ) : (
              <AutoresponderName>{arName || getSingleAR?.name}</AutoresponderName>
            )}
            {!isEdit ? (
              <Image src={EditIcon} alt='Edit' cursor='pointer' onClick={() => setIsEdit(true)} />
            ) : (
              <>
                <CheckIcon
                  mx='3'
                  boxSize='4'
                  color='green.500'
                  cursor='pointer'
                  onClick={() => {
                    editName();
                    arName && setIsEdit(!isEdit);
                  }}
                />
                <SmallCloseIcon
                  boxSize='6'
                  color='red.700'
                  cursor='pointer'
                  onClick={() => {
                    setIsEdit(!isEdit);
                    queryClient.invalidateQueries([QUERY_KEYS.AUTORESPONDER_NAME_BY_ID]);
                  }}
                />
              </>
            )}
          </Flex>
          <Flex alignItems='center'>
            <Button
              isLoading={isSaveLoading}
              mr='5'
              isDisabled={atleastOneActionOneTrigger() ? false : true}
              variant={atleastOneActionOneTrigger() ? 'success' : 'default'}
              id='save-automation'
              onClick={saveAutomation}>
              Save
            </Button>
            {atleastOneActionOneTrigger() && (
              <Flex alignItems='center' width='130px' justifyContent={'right'}>
                <Text mr='1rem'>{isActive == true ? 'Active' : 'Inactive'}</Text>
                <StyledSwitch
                  size='lg'
                  onChange={() => setIsActive(!isActive)}
                  isChecked={isActive === true}
                />
              </Flex>
            )}
          </Flex>
        </Flex>
        <AutoresponderContent>
          <TriggerList>
            {triggers &&
              triggers.map((trigger, index) => {
                if (trigger === AutoresponderSettings.SUBSCRIBE_TRIGGER) {
                  return (
                    <TriggerItem
                      key={index}
                      onClick={() => handleCardClick({ type: trigger, index })}>
                      <SubscribeToListCard isTrigger lists={subscribeToListTriggerList} />
                    </TriggerItem>
                  );
                }

                if (trigger === AutoresponderSettings.SUBMITS_A_FORM_TRIGGER) {
                  return (
                    <TriggerItem
                      key={index}
                      onClick={() => handleCardClick({ type: trigger, index })}>
                      <SubmitsFormCard lists={submitsAFormTriggerList} />
                    </TriggerItem>
                  );
                }
              })}
            {actions && triggers?.length < MAX_TRIGGERS && (
              <TriggerItem>
                <Card onClick={() => handleCardClick({ type: 'triggers' })} tabIndex={0}>
                  <Flex alignItems='center'>+ Add Trigger</Flex>
                </Card>
              </TriggerItem>
            )}
          </TriggerList>
          <TreeBranch>
            <Tree>
              {actions &&
                actions?.map((action, index) => (
                  <Box key={index}>
                    <AddWrapper empty={actions?.length === 0}>
                      <PlusButton isActive={isOpen} variant='infoOutlined'>
                        <Image
                          src={PlusIcon}
                          alt='Add'
                          m='0'
                          boxSize='6'
                          onClick={() => handleCardClick({ type: 'actions', index })}
                        />
                      </PlusButton>
                    </AddWrapper>
                    {action?.type === AutoresponderSettings.SEND_MESSAGE_ACTION && (
                      <EmailCard
                        arId={arId}
                        email={action?.email}
                        onClick={() =>
                          handleCardClick({
                            type: AutoresponderSettings.SEND_MESSAGE_ACTION,
                            index,
                          })
                        }
                      />
                    )}
                    {action?.type === AutoresponderSettings.SUBSCRIBE_ACTION && (
                      <SubscribeToListCard
                        title='Subscribe to List'
                        lists={action?.lists ?? []}
                        onClick={() => {
                          handleCardClick({
                            type: AutoresponderSettings.SUBSCRIBE_ACTION,
                            index,
                          });
                        }}
                      />
                    )}
                    {action?.type === AutoresponderSettings.UNSUBSCRIBE_ACTION && (
                      <SubscribeToListCard
                        title='Unsubscribe from List'
                        lists={action?.unsubscribeList ?? []}
                        onClick={() => {
                          handleCardClick({
                            type: AutoresponderSettings.UNSUBSCRIBE_ACTION,
                            index,
                          });
                        }}
                      />
                    )}
                    {action?.type === AutoresponderSettings.WAIT_TIMING && (
                      <WaitTimingCard
                        wait={action?.wait}
                        onClick={() => {
                          handleCardClick({
                            type: AutoresponderSettings.WAIT_TIMING,
                            index,
                          });
                        }}
                      />
                    )}
                  </Box>
                ))}
              <TreeContent>
                <AddWrapper empty={true}>
                  <PlusButton isActive={isOpen} variant='infoOutlined'>
                    <Image
                      src={PlusIcon}
                      alt='Add'
                      m='0'
                      boxSize='6'
                      onClick={() => {
                        handleCardClick({ type: 'actions', index: actions?.length });
                      }}
                    />
                  </PlusButton>
                </AddWrapper>
              </TreeContent>
            </Tree>
          </TreeBranch>
        </AutoresponderContent>
      </Box>
    </Flex>
  );
};

export default CreateAutoresponderPage;
