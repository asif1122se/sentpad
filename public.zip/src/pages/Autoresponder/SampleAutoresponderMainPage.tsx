import { Badge, Box, Icon, Menu, MenuButton, MenuItem, MenuList } from '@chakra-ui/react';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { DataTable, PageHeader } from 'components';
import { FILTER_INDEX } from 'components/Filters/consts';
import { PageContainer } from 'components/Layout';
import { AUTORESPONDER } from 'consts';
import { useState } from 'react';
import { GoKebabVertical } from 'react-icons/go';
import { ColumnProps, StatusChange } from 'types';
import QUERY_KEYS from 'utils/queryKeys';
import NewAutoresponderModal from './components/NewAutoresponderModal';
import { Autorespond } from './types';
import { format } from 'date-fns';
import { useMutation } from 'hooks/useMutation';
import { useQueryClient } from '@tanstack/react-query';

const autoResponderList = [
  {
    audience: '10,273',
    created_at: '2022-08-04T12:22:58.000000Z',
    deleted_at: null,
    email_clicked: 0,
    email_opened: 0,
    email_sent: '10,273',
    id: 600,
    name: 'New AR Test 01',
    status: 'active',
    unique_email_opened: 0,
    updated_at: '2022-08-04T12:27:58.000000Z',
    user_id: 185,
  },
];

const AutoresponderPage = () => {
  const [searchedValue, setSearchedValue] = useState<string>('');
  const [values, setValues] = useState<any>();
  const queryClient = useQueryClient();

  const [showCreateModal, setShowCreateModal] = useState(false);

  const { mutate } = useMutation<StatusChange>({
    url: 'autoresponder-status',
    onSuccess: () => queryClient.invalidateQueries([QUERY_KEYS.AUTORESPONDER_LIST]),
  });

  const handleChangeStatus = (data: StatusChange) => {
    mutate(data);
  };

  const colProps: ColumnProps[] = [
    {
      align: 'left',
      width: '60%',
    },
    {
      align: 'left',
      width: '5%',
      paddingX: '1px',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'right',
    },
  ];

  const columnHelper = createColumnHelper<Autorespond>();
  const columns = [
    columnHelper.accessor('name', {
      cell: (info) => info.getValue(),
      header: 'Autoresponder Name',
    }),
    columnHelper.display({
      id: 'status',
      header: 'Status',
      cell: (props: CellContext<Autorespond, unknown>) => (
        <Badge
          variant={
            props.row.original.status === 'draft'
              ? 'draft'
              : props.row.original.status === 'active'
              ? 'completed'
              : 'pending'
          }
          textTransform='capitalize'
          fontSize='sm'
          fontWeight='normal'>
          {props.row.original.status}
        </Badge>
      ),
    }),

    columnHelper.accessor('email_sent', {
      cell: (info) => info.getValue(),
      header: 'Email Sent',
      meta: {
        isNumeric: true,
      },
    }),
    columnHelper.accessor('audience', {
      cell: (info) => info.getValue(),
      header: 'Audience',
      meta: {
        isNumeric: true,
      },
    }),
    columnHelper.display({
      header: 'Date Created',
      cell: (props: any) => <>{format(new Date(`${props.row.original.created_at}`), 'MM/dd/yy')}</>,
    }),

    columnHelper.display({
      id: 'actions',
      cell: (props: any) => (
        <Menu>
          <MenuButton>
            <Icon height='25px' color='gray.500' as={GoKebabVertical} />
          </MenuButton>
          <MenuList borderColor='gray.500' minWidth='110px' width='fit-content'>
            <MenuItem
              onClick={() => {
                window.location.href = `/autoresponder/${props.row.original.id}`;
              }}>
              View
            </MenuItem>
            <MenuItem>Duplicate</MenuItem>
            {props.row.original.status !== 'draft' && (
              <MenuItem
                onClick={() =>
                  handleChangeStatus({
                    id: props.row.original.id,
                    status: props.row.original.status === 'active' ? 'inactive' : 'active',
                  })
                }>
                {props.row.original.status === 'active'
                  ? 'Deactivate autoresponder'
                  : props.row.original.status === 'inactive'
                  ? 'Activate autoresponder'
                  : props.row.original.status}
              </MenuItem>
            )}
            <MenuItem>Delete</MenuItem>
          </MenuList>
        </Menu>
      ),
    }),
  ];

  const getValue = (value: string) => {
    setSearchedValue(value);
  };

  return (
    <>
      <PageContainer>
        <PageHeader
          title={AUTORESPONDER}
          buttonLabel='New Autoresponder'
          onClick={() => setShowCreateModal(true)}
        />
        <Box>
          <DataTable
            columns={columns}
            data={autoResponderList}
            getValue={getValue}
            filterIndex={FILTER_INDEX.Autorespond}
            colProps={colProps}
            emptyMessage={'No autoresponder(s) found'}
            values={values}
            setValues={setValues}
          />
        </Box>
      </PageContainer>
      <NewAutoresponderModal isOpen={showCreateModal} onClose={() => setShowCreateModal(false)} />
    </>
  );
};

export default AutoresponderPage;
