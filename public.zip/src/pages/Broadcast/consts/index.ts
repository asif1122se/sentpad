import { AUDIENCE, BROADCAST, CONTENT, SCHEDULE } from 'consts';

export const enum STEPS {
  Broadcast,
  Audience,
  Content,
  Schedule,
}

export const BroadcastSteps = [BROADCAST, AUDIENCE, CONTENT, SCHEDULE];

export const Status = ['Completed', 'Scheduled', 'Draft'];
