import { Flex, Text, Box, Image } from '@chakra-ui/react';
import styled from '@emotion/styled';

// Email Template Page
export const TemplateBox = styled(Flex)`
  min-width: 230px;
  min-height: 300px;
  background: var(--chakra-colors-gray-300);
  box-shadow: var(--chakra-shadows-md);
  justify-content: center;
  align-items: center;
  border-width: 1px;
  border-color: var(--chakra-colors-gray-300);
  border-radius: 3px;
  cursor: pointer;
`;

export const StyledImage = styled(Image)<{ isHover: boolean }>`
  ${({ isHover }) =>
    isHover &&
    'filter: brightness(90%); position: relative; z-index: 1; width: 100%; height: 100%;'};
`;
