import {
  Box,
  Button,
  Center,
  Flex,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Spinner,
  Text,
} from '@chakra-ui/react';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { SenderProfileFooter } from '../types';
import { useState } from 'react';

type PreviewEmailModal = {
  isOpen: boolean;
  onClose: () => void;
  emailPreview: any;
  profileID?: string;
};

const PreviewEmailModal = ({ isOpen, onClose, emailPreview, profileID }: PreviewEmailModal) => {
  const { data: senderProfile, isLoading: isSenderProfileLoading } = useQuery<SenderProfileFooter>({
    url: `senderProfile/get-email-footer/${profileID}`,
    queryKey: [QUERY_KEYS.SENDER_PROFILE_EMAIL_FOOTER],
  });

  const getAddress = (add: string) => {
    const str = add !== '' ? add + ', ' : '';
    return str;
  };

  const footer = () => {
    const str =
      getAddress(senderProfile?.street ?? '') +
      getAddress(senderProfile?.city ?? '') +
      getAddress(senderProfile?.state ?? '') +
      getAddress(senderProfile?.country ?? '') +
      getAddress(senderProfile?.zip ?? '');
    const address = str.substring(0, str.length - 2);
    return `
      <div style='width: 100%; text-align: center; margin-top: 20px'>
        <div style='text-align: center; color: #12284c'>
          <div style='margin-bottom: 18px'>${senderProfile?.sender_name ?? ''}</div>
          <div style='margin-bottom: 18px'>${senderProfile?.company_name ?? ''}</div>
          <div style='margin-bottom: 18px'>${address}</div>
<!--          <div><a href="https://app.qasendpad.tk/unsubscription/">Unsubscribe</a></div>-->
        </div>
      </div>
      `;
  };

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size='xl' isCentered>
        <ModalOverlay />
        <ModalContent
          p='32px'
          width='fit-content'
          minW='700px'
          minH='500px'
          maxH='80%'
          overflow='auto'>
          <ModalHeader p='0' pb='2'>
            <Text fontSize='18px' fontWeight='bold'>
              Preview Email
            </Text>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody p='0' m='0' mt='1rem' background='#F2F6F9 0% 0% no-repeat padding-box;'>
            {isSenderProfileLoading && (
              <Center h='100px'>
                <Spinner w='20px' h='20px' />
              </Center>
            )}
            {senderProfile && (
              <Box
                margin='0 auto'
                overflow='auto'
                minH='600px'
                my='-5%'
                width='fit-content'
                transform='scale(0.8,0.8)'
                display={'flex'}
                flexDirection='column'
                dangerouslySetInnerHTML={{
                  __html: emailPreview?.body_content + footer(),
                }}
              />
            )}
          </ModalBody>

          <ModalFooter justifyContent='flex-start' pb='0' px='0'>
            <Button onClick={onClose}>Close</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default PreviewEmailModal;
