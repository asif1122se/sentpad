import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { AUDIENCE, BROADCAST, CONTENT, SCHEDULE } from 'consts';

const Summary: React.FC = () => {
  return (
    <Flex direction='column' w='347px' mt='177px'>
      <Heading as='h5' size='h5' fontWeight='semibold' mb='12px'>
        Summary
      </Heading>
      <Box border='1px solid var(--chakra-colors-gray-400)' borderRadius='0.5rem'>
        <Box h='99px' borderBottom='1px solid var(--chakra-colors-gray-400)' py='1rem' px='1.5rem'>
          <Text fontWeight='semibold' textTransform='uppercase' color='gray.700'>
            {BROADCAST}
          </Text>
        </Box>
        <Box
          h='99px'
          borderBottom='1px solid var(--chakra-colors-gray-400)'
          py='1rem'
          px='1.5rem'
          fontWeight='semibold'>
          <Text fontWeight='semibold' textTransform='uppercase' color='gray.700'>
            {AUDIENCE}
          </Text>
        </Box>
        <Box
          h='99px'
          borderBottom='1px solid var(--chakra-colors-gray-400)'
          py='1rem'
          px='1.5rem'
          fontWeight='semibold'>
          <Text fontWeight='semibold' textTransform='uppercase' color='gray.700'>
            {CONTENT}
          </Text>
        </Box>
        <Box h='99px' py='1rem' px='1.5rem' fontWeight='semibold'>
          <Text fontWeight='semibold' textTransform='uppercase' color='gray.700'>
            {SCHEDULE}
          </Text>
        </Box>
      </Box>
    </Flex>
  );
};

export default Summary;
