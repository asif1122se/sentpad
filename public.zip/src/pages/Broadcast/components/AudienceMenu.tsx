import {
  Button,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Image,
  Box,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  Center,
  Spinner,
} from '@chakra-ui/react';
import { useState } from 'react';
import PlusIcon from 'assets/icons/plus.svg';
import { AudienceOption, SelectedItem } from './Audience';
import { InputField } from 'components';
import { ContactLists } from 'pages/Audience/Contacts/types';

type AudienceMenuProps = {
  options?: ContactLists;
  onOptionClick: (data: SelectedItem) => void;
  isLoading?: boolean;
};

const AudienceMenu: React.FC<AudienceMenuProps> = ({
  options,
  onOptionClick,
  isLoading,
}: AudienceMenuProps) => {
  const [search, setSearch] = useState<string>('');
  const [list] = useState<ContactLists | undefined>(options);

  const getListItems = (options?: ContactLists) => {
    return options
      ?.filter((item) =>
        search ? item?.title?.toLowerCase().includes(search.toLowerCase()) : item,
      )
      .map((item) => (
        <>
          <MenuItem
            key={item.id}
            fontSize='12px'
            color='gray.700'
            fontWeight='medium'
            py='1'
            onClick={() => onOptionClick({ id: item?.id, name: item?.title })}>
            {' '}
            {(item?.title?.toString().length ?? 0) > 50
              ? `${item?.title?.toString().substring(0, 50)}...`
              : item?.title}{' '}
          </MenuItem>
        </>
      ));
  };

  return (
    <Menu>
      {({ isOpen }) => (
        <>
          <MenuButton
            isActive={isOpen}
            as={Button}
            variant='infoOutlined'
            borderRadius='100%'
            minW='22px'
            w='22px'
            h='22px'
            p='0'
            mb='0'
            justifyContent='center'
            position='relative'
            zIndex='0'>
            <Image src={PlusIcon} alt='Add' m='0' boxSize='6' />
          </MenuButton>
          <MenuList p='8px' maxH='300px' overflow='auto' width='228px' borderColor='gray.400'>
            <Box mb='10px'>
              <form>
                <InputField
                  borderColor='gray.400'
                  type='search'
                  fontSize='sm'
                  placeholder='Enter to search'
                  size='sm'
                  onChange={(e) => setSearch(e.target.value)}
                  autoComplete='off'
                />
              </form>
            </Box>
            <Tabs isFitted variant='unstyled'>
              {isLoading && (
                <Center>
                  <Spinner />
                </Center>
              )}
              <TabPanels maxH='300px'>
                <TabPanel p='0'>{getListItems(options)}</TabPanel>
                <TabPanel p='0'>{getListItems(options)}</TabPanel>
              </TabPanels>
            </Tabs>
          </MenuList>
        </>
      )}
    </Menu>
  );
};

export default AudienceMenu;
