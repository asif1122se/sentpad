import { Badge, Box, Flex, Tab, TabList, TabPanel, TabPanels, Tabs, Text } from '@chakra-ui/react';
import { PageHeader } from 'components';
import { PageContainer } from 'components/Layout';

import { useParams } from 'react-router-dom';

const DetailsAnalyticsPage = () => {
  return (
    <>
      <PageContainer>
        <PageHeader
          title={'Broadcast Detail'}
          subtitle='Broadcast'
          buttonLabel='Preview Email'
          variant='blackOutlined'
        />
        <Flex mb='6' mt='-2'></Flex>

        <Tabs size='sm'>
          <TabList>
            <Tab
              fontWeight='bold'
              _selected={{ color: 'purple.700', borderBottomColor: 'purple.700' }}>
              Overview
            </Tab>
            <Tab isDisabled fontWeight='bold'>
              Sent
            </Tab>
            <Tab isDisabled fontWeight='bold'>
              Opened
            </Tab>
            <Tab isDisabled fontWeight='bold'>
              Clicked
            </Tab>
          </TabList>

          <TabPanels>
            <TabPanel paddingX={'0'}>
              <Box>
                <Text mb='4' fontSize='22px'>
                  Overview
                </Text>

                <Flex width='100%' gap='4'>
                  {/* Email Details */}
                  <Box
                    width='33%'
                    fontSize='sm'
                    padding='0.4rem 1.5rem'
                    borderWidth='1px'
                    borderColor='gray.400'
                    borderRadius='8px'>
                    <Box my='2'>
                      <Text fontWeight='bold'>Email Details</Text>
                    </Box>
                    <Box>
                      <Flex my='5'>
                        <Box width='50%'>
                          <Text color='gray.700'>Creation Date</Text>
                          <Text>
                            <span style={{ fontWeight: 'bold' }}>Dec 19, 2022</span> 08:38 AM
                          </Text>
                        </Box>
                        <Box width='50%'>
                          <Text color='gray.700'>Scheduled</Text>
                          <Text>
                            <Text>
                              <span style={{ fontWeight: 'bold' }}>Not scheduled</span>
                            </Text>
                          </Text>
                        </Box>
                      </Flex>
                      <Flex my='5'>
                        <Box width='50%'>
                          <Text color='gray.700'>Started</Text>
                          <Text>
                            <span style={{ fontWeight: 'bold' }}>Dec 19, 2022</span> 08:38 AM
                          </Text>
                        </Box>
                        <Box width='50%'>
                          <Text color='gray.700'>Completion Date</Text>
                          <Text>
                            <span style={{ fontWeight: 'bold' }}>Dec 19, 2022</span> 08:38 AM
                          </Text>
                        </Box>
                      </Flex>
                    </Box>
                  </Box>
                  {/* Included Recipients */}
                  <Box
                    fontSize='sm'
                    width='33%'
                    padding='0.4rem 1.5rem'
                    borderWidth='1px'
                    borderColor='gray.400'
                    borderRadius='8px'>
                    <Box my='2'>
                      <Text fontWeight='bold'>
                        <Text fontWeight='bold'>Lists</Text>
                      </Text>
                    </Box>
                    <Box>
                      <Badge variant='warning' textTransform='capitalize' mr='1' my='1'>
                        Primary List
                      </Badge>
                      {/* {data?.recipients?.map((item: any) => (
                        <>
                          <Badge variant='warning' textTransform='capitalize' mr='1' my='1'>
                            {item?.title}
                          </Badge>
                        </>
                      ))} */}
                    </Box>
                  </Box>

                  {/* Sender Profile */}
                  <Box
                    fontSize='sm'
                    width='33%'
                    padding='0.4rem 1.5rem'
                    borderWidth='1px'
                    borderColor='gray.400'
                    borderRadius='8px'>
                    <Box my='2'>
                      <Text fontWeight='bold'>Sender Profile</Text>
                    </Box>
                    <Box mb='4'>
                      <Text mt='2' color='gray.700'>
                        Sender name
                      </Text>
                      <Text fontWeight='bold'>SendPadUser</Text>
                      <Text mt='2' color='gray.700'>
                        From email
                      </Text>
                      <Text fontWeight='bold'>sendpadtech@domain.com</Text>
                      <Text mt='2' color='gray.700'>
                        Reply to
                      </Text>
                      <Text fontWeight='bold'>sendpadtech@domain.com</Text>
                    </Box>
                  </Box>
                </Flex>

                <Box fontSize='sm'>
                  <Text my='4' fontWeight='bold'>
                    Engagement
                  </Text>
                  <Flex fontSize='13px' gap={3} justifyContent='space-between' width='100%'>
                    {/* Opens */}
                    <Box
                      width='45%'
                      padding='0.6rem 1rem'
                      borderWidth='1px'
                      borderColor='gray.200'
                      borderRadius='8px'
                      background='gray.200'>
                      <Text fontWeight={'bold'}>Opens</Text>
                      <Flex my='2'>
                        <Box width='50%'>
                          <Text>Total</Text>
                          <Text fontSize='md' fontWeight={'bold'}>
                            152
                          </Text>
                          <Text mt='1' fontWeight='semibold'>
                            36.91%
                          </Text>
                        </Box>
                        <Box>
                          <Text>Unique</Text>
                          <Text fontSize='md' fontWeight={'bold'}>
                            120
                          </Text>
                          <Text mt='1' fontWeight='semibold'>
                            42.87%
                          </Text>
                        </Box>
                      </Flex>
                    </Box>
                    {/* Clicks */}
                    <Box
                      width='45%'
                      padding='0.6rem 1rem'
                      borderWidth='1px'
                      borderColor='gray.200'
                      borderRadius='8px'
                      background='gray.200'>
                      <Text fontWeight={'bold'}>Clicks</Text>
                      <Flex my='2'>
                        <Box width='50%'>
                          <Text>Total</Text>
                          <Text fontSize='md' fontWeight={'bold'}>
                            113
                          </Text>
                          <Text mt='1' fontWeight='semibold'>
                            35.32%
                          </Text>
                        </Box>
                        <Box>
                          <Text>Unique</Text>
                          <Text fontSize='md' fontWeight={'bold'}>
                            102
                          </Text>
                          <Text mt='1' fontWeight='semibold'>
                            32.7%
                          </Text>
                        </Box>
                      </Flex>
                    </Box>
                    {/* Deliverability */}
                    <Box
                      width='50%'
                      padding='0.6rem 1rem'
                      borderWidth='1px'
                      borderColor='gray.200'
                      borderRadius='8px'
                      background='gray.200'>
                      <Text fontWeight={'bold'}>Deliverability</Text>
                      <Flex my='2' gap='3'>
                        <Box width='40%'>
                          <Text>Unsubscribed</Text>
                          <Text fontSize='md' fontWeight={'bold'}>
                            3
                          </Text>
                          <Text mt='1' fontWeight='semibold'>
                            0.93%
                          </Text>
                        </Box>
                        <Box width='30%'>
                          <Text>Spam</Text>
                          <Text fontSize='md' fontWeight={'bold'}>
                            4
                          </Text>
                          <Text mt='1' fontWeight='semibold'>
                            1.81%
                          </Text>
                        </Box>
                        <Box width='30%'>
                          <Text>Bounces</Text>
                          <Text fontSize='md' fontWeight={'bold'}>
                            3
                          </Text>
                          <Text mt='1' fontWeight='semibold'>
                            1.49%
                          </Text>
                        </Box>
                      </Flex>
                    </Box>
                    {/* Clicks */}
                    <Box width='47.5%'></Box>
                  </Flex>
                </Box>
              </Box>
            </TabPanel>
            <TabPanel>
              <Text>Sent</Text>
            </TabPanel>
            <TabPanel>
              <Text>Opened</Text>
            </TabPanel>
            <TabPanel>
              <Text>Clicked</Text>
            </TabPanel>
          </TabPanels>
        </Tabs>
      </PageContainer>
    </>
  );
};

export default DetailsAnalyticsPage;
