import React, { useEffect, useRef, useState } from 'react';
import {
  Box,
  Flex,
  Text,
  DrawerBody,
  Spacer,
  Grid,
  GridItem,
  Divider,
  DrawerFooter,
  Button,
} from '@chakra-ui/react';
import Checkbox from 'components/Checkbox';
import { DateRangePicker } from 'components';
import { Status } from '../consts';
import AudienceList from './AudienceList';
import { useStoreActions, useStoreState } from 'redux';

const FilterContent = (props: any) => {
  const { getFilteredData, values, setValues, onClickFilter } = props;
  const filterAction = useStoreActions((actions) => actions.filter.add);
  const filterState = useStoreState((state) => state.filter.filterObj);
  const [isClicked, setIsClicked] = useState<boolean>(false);
  const [defaultValue, setDefaultValue] = useState<any>([]);
  const [isDateClear, setIsDateClear] = useState<boolean>(false);
  const [showDate, setShowDate] = useState<boolean>(true);

  const getList = (data: any) => {
    getFilteredData({ list: data });
  };

  const getDate = (data: any) => {
    getFilteredData({ date: data });
  };

  const handleStatusChange = (data: any) => {
    const refinedFilterState = values?.status;
    if (data?.status) {
      setValues({ ...values, status: refinedFilterState ? [...values?.status, data] : [data] });
      if (defaultValue?.length > 0) {
        setDefaultValue(values?.status?.map((item: any) => item?.value));
      } else {
        setDefaultValue([data?.value]);
      }
    } else {
      const refinedFilterState = values?.status;
      const filtredData = refinedFilterState?.filter((item: any) => item?.id !== data.id);
      setValues({ ...values, status: filtredData });
      setDefaultValue(filtredData?.map((item: any) => item?.value));
    }
  };
  const defaultVal = () => {
    setDefaultValue(values?.status ? values?.status?.map((item: any) => item?.value) : []);
  };
  useEffect(() => {
    defaultVal();
  }, [values?.status]);

  const handleFilter = () => {
    filterAction({
      isclicked: !isClicked,
    });
    setIsClicked(!isClicked);
    setValues({
      ...values,
      filterBtnLoading: true,
    });

    if (values?.date !== undefined) {
      if (!values?.date?.split(',')[1]) {
        const res = values?.date.substring(0);
        setValues({ ...values, date: `${values?.date}${res?.substring(0, res.length - 1)}` });
      }
    }

    onClickFilter();
  };

  return (
    <>
      <Box width='100%' mb='3'>
        <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
      </Box>
      <DrawerBody px='0'>
        <Box px='4'>
          <Flex>
            <Text fontSize='xs' color='gray.600' fontWeight='bolder'>
              DATE
            </Text>
            <Spacer />
            <Text
              fontSize='sm'
              color='blue.700'
              fontWeight='500'
              cursor='pointer'
              onClick={() => {
                filterAction({ ...filterState, date_filter: '' });
                setValues({ ...values, date: undefined });
                setIsDateClear(!isDateClear);
              }}>
              Clear
            </Text>
          </Flex>

          <Flex>
            <Box width='100%'>
              <Text fontWeight='500' mt='2'>
                Select Date
              </Text>
              <Flex justifyContent='space-evenly' alignItems='center'>
                <DateRangePicker
                  getDate={getDate}
                  value={values?.date}
                  isDateClear={isDateClear}
                  showDate={showDate}
                  setIsDateClear={setIsDateClear}
                />
              </Flex>
            </Box>
          </Flex>
        </Box>
        <Box width='99%' my='6'>
          <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
        </Box>
        <Box px='4'>
          <Flex>
            <Text fontSize='xs' color='gray.600' fontWeight='bolder'>
              STATUS
            </Text>
            <Spacer />
            <Text
              fontSize='sm'
              color='blue.700'
              fontWeight='500'
              cursor='pointer'
              onClick={() => {
                setValues({ ...values, status: [] });
                setDefaultValue([]);
              }}>
              Clear
            </Text>
          </Flex>
          <Flex>
            <Grid mt='5' gap={3} color='black' fontSize='sm' fontWeight='500'>
              {Status?.map((item: any, index) => (
                <>
                  <GridItem colSpan={18}>{item}</GridItem>
                  <GridItem colStart={23}>
                    <Checkbox
                      borderColor='gray.400'
                      value={item}
                      isChecked={defaultValue?.includes(item)}
                      onChange={(e) =>
                        handleStatusChange({
                          value: e.target.value,
                          status: e.target.checked,
                          id: index,
                        })
                      }
                    />
                  </GridItem>
                </>
              ))}
            </Grid>
          </Flex>
        </Box>
        <Box width='99%' my='6'>
          <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
        </Box>
        <Box px='4'>
          <Flex>
            <Text fontSize='xs' color='gray.600' fontWeight='bolder'>
              AUDIENCE
            </Text>
            <Spacer />
          </Flex>
          <Box color='black' fontSize='md'>
            <AudienceList getList={getList} headingText='' values={values} setValues={setValues} />
          </Box>
        </Box>
      </DrawerBody>
      <Box width='99%' my='1'>
        <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
      </Box>
      <DrawerFooter justifyContent='left'>
        <Button
          isLoading={values?.filterBtnLoading}
          variant='info'
          px='6'
          mr='3'
          cursor='pointer'
          onClick={handleFilter}>
          Filter
        </Button>
        <Button
          mr={3}
          onClick={() => {
            setValues({});
            setIsDateClear(!isDateClear);
            setShowDate(false);
          }}>
          Clear All
        </Button>
      </DrawerFooter>
    </>
  );
};

export default FilterContent;
