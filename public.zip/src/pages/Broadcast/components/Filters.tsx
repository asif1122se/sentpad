import React from 'react';
import {
  Box,
  Icon,
  Drawer,
  DrawerOverlay,
  DrawerCloseButton,
  DrawerHeader,
  DrawerContent,
  Text,
} from '@chakra-ui/react';
import { IoFunnelOutline } from 'react-icons/io5';
import FilterContent from './FilterContent';

const BroadcastFilters = ({ openDrawer, setOpenDrawer, values, setValues, onClickFilter }: any) => {
  const btnRef = React.useRef<HTMLButtonElement>(null);

  const getFilteredData = (data: any) => {
    data?.date && setValues({ ...values, date: data?.date });
    data?.list && setValues({ ...values, list: data?.list });
    // data?.status && setValues({...values, status : data?.status})
  };

  return (
    <Box>
      <Drawer
        isOpen={openDrawer}
        placement='right'
        onClose={() => setOpenDrawer(false)}
        finalFocusRef={btnRef}>
        <DrawerOverlay />
        <DrawerContent width='450px'>
          <DrawerCloseButton />
          <DrawerHeader
            fontSize='15'
            pr='10'
            fontWeight='bold'
            color='black'
            alignItems='center'
            display='inline-flex'
            justifyContent='flex-start'>
            <Icon boxSize='5' as={IoFunnelOutline} mr='2' />
            <Text>Filters</Text>
          </DrawerHeader>
          <FilterContent
            getFilteredData={getFilteredData}
            values={values}
            setValues={setValues}
            onClickFilter={onClickFilter}
          />
        </DrawerContent>
      </Drawer>
    </Box>
  );
};

export default BroadcastFilters;
