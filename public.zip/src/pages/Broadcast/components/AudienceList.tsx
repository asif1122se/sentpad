import AudienceMenu from './AudienceMenu';
import { Text, Flex, Badge, Box } from '@chakra-ui/react';
import { CloseIcon } from '@chakra-ui/icons';
import { useStoreActions, useStoreState } from 'redux';
import { useQuery } from 'hooks/useQuery';
import { ContactLists } from 'pages/Audience/Contacts/types';
import QUERY_KEYS from 'utils/queryKeys';

export type AudienceListItem = {
  id: number;
  name: string;
};

export type AudienceOption = {
  id: number;
  title: string;
};

type ListType = {
  getList?: any;
  headingText?: string;
  removeText?: string;
  values?: any;
  setValues?: any;
  showSelectAll?: boolean;
  customStyles?: object;
  keyIndex?: number;
};

const AudienceList = ({
  getList,
  headingText,
  removeText = 'Clear',
  values,
  setValues,
  showSelectAll,
  customStyles,
  keyIndex,
}: ListType) => {
  const filterAction = useStoreActions((actions) => actions.filter.add);
  const filterState = useStoreState((state) => state.filter.filterObj);

  const {
    data: audienceList,
    isLoading,
    isFetching,
  } = useQuery<ContactLists>({
    url: 'getContactLists',
    queryKey: [QUERY_KEYS.CONTACTS_LISTS],
  });

  const handleSelectedList = (data: AudienceListItem) => {
    setValues({
      ...values,
      list: values?.list ? [...values?.list, data] : [data],
    });
    getList(values?.list ? [...values?.list, data] : [data], keyIndex);
  };

  const removeAudienceItem = (id: number) => {
    const arr = values?.list;
    const index = arr.findIndex((o: { id: number }) => o.id == id);
    if (index !== -1) arr.splice(index, 1);
    getList([...arr]);
    filterAction({ ...filterState, lists_filter: [...arr] });
  };

  const styles =
    customStyles === undefined
      ? {
          minH: '40px',
          borderWidth: '1px',
          borderColor: 'gray.400',
          borderRadius: '5px',
          p: '16px',
        }
      : customStyles;
  return (
    <Box>
      <Flex justifyContent='space-between' alignItems='baseline'>
        <Text fontSize='md' fontWeight='medium' my='2'>
          {' '}
          {headingText}{' '}
        </Text>
        <Flex>
          {showSelectAll && (
            <Text mr='3' color='blue.700' fontSize='sm' cursor='pointer' fontWeight='500'>
              Select All
            </Text>
          )}
          <Text
            color='blue.700'
            fontSize='sm'
            cursor='pointer'
            fontWeight='500'
            onClick={() => {
              setValues({ ...values, list: [] });
            }}>
            {removeText}
          </Text>
        </Flex>
      </Flex>
      <Flex {...styles} alignItems='center' gap='8px' wrap='wrap'>
        {values &&
          values?.list?.map(
            (
              item: {
                name:
                  | string
                  | number
                  | boolean
                  | React.ReactElement<any, string | React.JSXElementConstructor<any>>
                  | React.ReactFragment
                  | React.ReactPortal
                  | null
                  | undefined;
                id: number;
              },
              index: React.Key | null | undefined,
            ) => (
              <Badge
                key={index}
                variant='warning'
                display='flex'
                alignItems='center'
                textTransform='capitalize'>
                {(item?.name?.toString().length ?? 0) > 20
                  ? `${item?.name?.toString().substring(0, 20)}...`
                  : item?.name}

                <CloseIcon
                  onClick={() => {
                    removeAudienceItem(item.id);
                  }}
                  w='8px'
                  h='8px'
                  ml='8px'
                  cursor='pointer'
                />
              </Badge>
            ),
          )}
        <AudienceMenu
          options={audienceList}
          onOptionClick={handleSelectedList}
          isLoading={isLoading || isFetching}
        />
      </Flex>
    </Box>
  );
};

export default AudienceList;
