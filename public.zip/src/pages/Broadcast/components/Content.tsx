import React, { useState } from 'react';
import {
  Box,
  Button,
  Flex,
  Heading,
  Text,
  Link,
  Image,
  useDisclosure,
  Stack,
} from '@chakra-ui/react';
import { InputField } from 'components';
import { CONTENT } from 'consts';
import { BroadcastCreationFormType } from 'pages/Broadcast/types';
import { useNavigate } from 'react-router-dom';
import { useStoreState, useStoreActions } from 'redux';
//hard codded as we need these from db
import Sample1 from 'assets/images/sample/Sample1.png';
import PreviewEmailModal from './PreviewEmailModal';

type BroadcastNameType = {
  values: BroadcastCreationFormType;
  error: boolean;
  showHeading?: boolean;
  fontSize?: string;
  fontWeight?: string;
};

const Content: React.FC<BroadcastNameType> = ({
  values,
  error,
  showHeading = true,
  fontSize,
  fontWeight = 'medium',
}: BroadcastNameType) => {
  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);
  const navigate = useNavigate();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [inputValues, setInputValues] = useState<any>({
    subject: broadcastState?.subject ? broadcastState?.subject : '',
    pre_header: broadcastState?.pre_header ? broadcastState?.pre_header : '',
  });

  const handleSubjectChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValues({ ...inputValues, subject: e.target.value });
    broadcastAction({
      ...broadcastState,
      subject: e.target.value,
    });
  };

  const handlePreHeaderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValues({ ...inputValues, pre_header: e.target.value });
    broadcastAction({
      ...broadcastState,
      pre_header: e.target.value,
    });
  };

  const [isShown, setIsShown] = React.useState(false);
  return (
    <>
      <PreviewEmailModal
        isOpen={isOpen}
        onClose={onClose}
        emailPreview={{ body_content: broadcastState?.body_content }}
        profileID={broadcastState?.senderProfile?.id}
      />
      <Box>
        {showHeading && (
          <>
            <Heading as='h1' size='h3' fontWeight='bold'>
              {CONTENT}
            </Heading>
            <Text color='gray.800' mb='18px' w='377px'>
              Choose broadcast setting such as subject, preheader and content.
            </Text>
          </>
        )}
        <InputField
          fontSize={'sm'}
          label='Subject'
          type='text'
          name='subject'
          onChange={handleSubjectChange}
          value={inputValues?.subject}
          placeholder='Enter email subject'
          formControlProps={{
            mb: '12px',
          }}
          errorText={
            !values?.subject && !broadcastState?.subject && error
              ? 'The subject field is required'
              : ''
          }
        />
        <InputField
          fontSize={'sm'}
          label='Preheader'
          type='text'
          name='pre_header'
          onChange={handlePreHeaderChange}
          value={inputValues?.pre_header}
          placeholder='Enter preheader'
          errorText={''}
        />
        <Flex flexDirection='column' mt='12px'>
          <Text fontWeight={fontWeight} fontSize={fontSize} mb='10px'>
            Content
          </Text>

          <Flex
            height='300px'
            bg='#F4F0F7'
            flexDirection='column'
            justifyContent='center'
            alignItems='center'
            borderRadius='4px'>
            <>
              {broadcastState.body_content && (
                <>
                  <Flex
                    justifyContent='center'
                    p='1'
                    background='transparent'
                    position='relative'
                    minH='200px'
                    width='fit-content'
                    minW={'200px'}
                    maxW='350px'
                    overflow='hidden'>
                    <Button
                      _hover={{ background: 'transparent' }}
                      background='transparent'
                      height='auto'
                      m='0'
                      mt='0.5rem'
                      p='0'
                      textAlign='left'
                      position='relative'
                      onMouseOver={() => setIsShown(true)}
                      onMouseLeave={() => setIsShown(false)}>
                      <Flex
                        __css={{ zoom: '0.2' }}
                        flexDirection='column'
                        justifyContent='flex-start'
                        alignItems='start'
                        //maxH='360px'
                        width='fit-content'
                        transform='scale(0.6, 0.6)'
                        dangerouslySetInnerHTML={{ __html: broadcastState?.body_content }}
                      />

                      {isShown && (
                        <Button variant='success' position='absolute' zIndex='3' onClick={onOpen}>
                          Preview Email
                        </Button>
                      )}
                    </Button>
                  </Flex>
                </>
              )}
              <Button
                mt='0.5rem'
                mb='1rem'
                p='3'
                variant='black'
                onClick={() =>
                  navigate(
                    broadcastState.body_content
                      ? `/broadcast/email-builder?isEdit=true`
                      : '/design-templates',
                  )
                }>
                {broadcastState.body_content ? 'Edit Email' : 'Design Email'}
              </Button>
              {!broadcastState.body_content && (
                <Text fontSize='14px' color='gray.800'>
                  No email design yet
                </Text>
              )}
            </>
          </Flex>
          {!broadcastState?.templateThumbnail && !broadcastState?.body_content && error && (
            <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
              Email content is required
            </Text>
          )}
        </Flex>
      </Box>
    </>
  );
};

export default Content;
