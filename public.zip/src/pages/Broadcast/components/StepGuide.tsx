import { Box, Flex } from '@chakra-ui/react';
import { StepBullet } from '.';
import { BroadcastSteps } from '../consts';

type StepGuideProps = {
  active: number;
};

const StepGuide: React.FC<StepGuideProps> = ({ active }: StepGuideProps) => {
  return (
    <Box mb='100px' w='468px'>
      <Flex>
        {BroadcastSteps.map((step, index) => (
          <StepBullet key={index} step={index + 1} label={step} active={active + 1} />
        ))}
      </Flex>
    </Box>
  );
};

export default StepGuide;
