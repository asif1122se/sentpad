import React, { useEffect, useState } from 'react';
import { Box, Heading, Link, Text, Stack, Flex, CheckboxGroup } from '@chakra-ui/react';
import { Checkbox, InputField } from 'components';
import { BroadcastCreationFormType } from 'pages/Broadcast/types';
import { useStoreState } from 'redux';
import AlertManager from 'components/Alerts/AlertManager';

type BroadcastNameType = {
  values: BroadcastCreationFormType;
  error: boolean;
  handleNameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
};

const BroadcastName: React.FC<BroadcastNameType> = ({
  values,
  error,
  handleNameChange,
}: BroadcastNameType) => {
  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);

  return (
    <Box>
      <AlertManager />
      <Heading as='h1' size='h3' fontWeight='bold'>
        Create Broadcast
      </Heading>
      <Text color='gray.800' mb='18px'>
        Name your Broadcast.
      </Text>

      <InputField
        autoFocus
        label='Broadcast name'
        type='text'
        name='subject'
        onChange={handleNameChange}
        value={broadcastState?.campaign_name}
        placeholder='Enter broadcast name'
        formControlProps={{
          mb: '12px',
        }}
        errorText={
          !values?.campaign_name && !broadcastState?.campaign_name && error
            ? 'Broadcast name is required'
            : ''
        }
      />
      {/* <Text fontSize='14px' mt='24px'>
        Create a broadcast and test multiple versions in a small portion of your audience to see
        which one performs best. Then send the winner to the rest of your contacts.{' '}
        <Link color='blue.700' href='#'>
          Learn more
        </Link>
      </Text> */}
    </Box>
  );
};

export default BroadcastName;
