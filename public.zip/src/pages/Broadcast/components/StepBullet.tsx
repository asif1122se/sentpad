import { Flex, VStack, Text, Box } from '@chakra-ui/react';
import { BroadcastSteps } from '../consts';

type StepBulletProps = {
  step: number;
  label: string;
  active: number;
};

const Line: React.FC = () => {
  return (
    <Box
      position='absolute'
      background='#E8EBEE'
      height='3px'
      width='100%'
      zIndex='-1'
      top='16.5px'
      left='50px'
    />
  );
};

const StepBullet: React.FC<StepBulletProps> = ({ step, label, active }: StepBulletProps) => {
  const getBg = () => {
    if (step === active) {
      return 'var(--chakra-colors-white)';
    } else if (step < active) {
      return 'var(--chakra-colors-blue-700)';
    } else {
      return '#E8EBEE';
    }
  };

  const getColor = () => {
    if (step === active) {
      return 'var(--chakra-colors-blue-700)';
    } else if (step < active) {
      return '#313F57';
    } else {
      return 'var(--chakra-colors-gray-700)';
    }
  };

  const getStepColor = () => {
    if (step === active) {
      return 'var(--chakra-colors-blue-700)';
    } else if (step < active) {
      return 'var(--chakra-colors-white)';
    } else {
      return 'var(--chakra-colors-gray-700)';
    }
  };

  return (
    <>
      <Box position='relative' width='100px'>
        <VStack gap='9px'>
          <Flex
            alignItems='center'
            justifyContent='center'
            h='36px'
            w='36px'
            border={step === active ? '1px solid var(--chakra-colors-blue-700)' : undefined}
            borderRadius='100%'
            background={getBg()}>
            <Text color={getStepColor()}>{step}</Text>
          </Flex>
          <Text marginTop='0px' color={getColor()} fontWeight='400'>
            {label}
          </Text>
        </VStack>
        {BroadcastSteps.length !== step && <Line />}
      </Box>
    </>
  );
};

export default StepBullet;
