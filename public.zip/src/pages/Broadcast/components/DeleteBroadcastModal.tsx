import {
  Box,
  Button,
  Flex,
  Image,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { useMutation } from 'hooks/useMutation';
import AlertIcon from 'assets/icons/alert.svg';
import { DELETE } from 'utils/constants';
import QUERY_KEYS from 'utils/queryKeys';

type DeleteBroadcastModal = {
  isOpen: boolean;
  onClose: () => void;
  broadcastID: number;
};

const DeleteBroadcastModal = ({ isOpen, onClose, broadcastID }: DeleteBroadcastModal) => {
  const queryClient = useQueryClient();
  const { isLoading, mutate } = useMutation<number>({
    method: DELETE,
    url: `deleteCampaign`,
    onSuccess: () => {
      onClose();
      queryClient.invalidateQueries([QUERY_KEYS.BROADCAST_LIST]);
    },
  });

  const handleDelete = () => mutate(broadcastID);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      size='xl'
      isCentered
      closeOnEsc={isLoading}
      closeOnOverlayClick={isLoading}>
      <ModalOverlay />
      <ModalContent p='32px' width='fit-content'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            Delete your broadcast
          </Text>
        </ModalHeader>
        <ModalCloseButton isDisabled={isLoading} />
        <ModalBody px='0' pt='5'>
          <Flex fontSize='md' justifyContent='flex-start' alignItems={'center'}>
            <Box width='fit-content'>
              <Image src={AlertIcon} alt='Alert' height='45px' width='45px' />
            </Box>
            <Box px='4'>
              <Text>Are you sure you want to delete this broadcast?</Text>
            </Box>
          </Flex>
        </ModalBody>

        <ModalFooter justifyContent='flex-start' pb='0' px='0'>
          <Button variant='danger' mr={2} onClick={handleDelete} isLoading={isLoading}>
            Delete
          </Button>
          <Button onClick={onClose} isDisabled={isLoading}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeleteBroadcastModal;
