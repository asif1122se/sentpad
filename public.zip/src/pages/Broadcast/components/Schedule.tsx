import React, { useState, useEffect } from 'react';
import { Box, Heading, Text, Stack } from '@chakra-ui/react';
import { BroadcastCreationFormType } from 'pages/Broadcast/types';
import { SCHEDULE, SCHEDULED } from 'consts';
import { useStoreState, useStoreActions } from 'easy-peasy';
import { DateTimePicker, Radio, RadioGroup } from 'components';
import { format, addMonths, differenceInMinutes } from 'date-fns';

type BroadcastNameType = {
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  values: BroadcastCreationFormType;
  error: boolean;
};

const Schedule: React.FC<BroadcastNameType> = ({ onChange, values, error }: BroadcastNameType) => {
  const broadcastState = useStoreState((state: any) => state.broadcast.broadcastObj);
  const broadcastAction = useStoreActions((actions: any) => actions.broadcast.add);
  const [startDate, setStartDate] = useState<Date | null | undefined>(
    broadcastState?.scheduleTime ? new Date(broadcastState?.scheduleTime) : new Date(),
  );

  const saveStatus = () => {
    broadcastAction({
      ...broadcastState,
      status: values.status,
      scheduled_time: values?.status == SCHEDULED ? startDate : '',
      time_zone:
        values?.status == SCHEDULED ? startDate?.toString().split('GMT')[1].split(' (')[0] : '',
    });
  };

  const handleDateChange = (date: Date) => {
    setStartDate(date);
    broadcastAction({
      ...broadcastState,
      scheduled_time: date,
      time_zone: date?.toString().split('GMT')[1].split(' (')[0],
    });
  };

  useEffect(() => {
    saveStatus();
  }, []);

  return (
    <Box>
      <Heading as='h1' size='h3' fontWeight='bold'>
        {SCHEDULE}
      </Heading>
      <Text color='gray.800' mb='18px' w='377px'>
        Select when to send your broadcast
      </Text>
      <RadioGroup value={values['status']} fontWeight='normal'>
        <Stack>
          <Radio name='status' onChange={onChange} value={'draft'}>
            Save as Draft
          </Radio>
          <Radio name='status' onChange={onChange} value={'immediate'}>
            Send Immediately
          </Radio>
          <Radio name='status' onChange={onChange} value={'scheduled'}>
            Schedule
          </Radio>
        </Stack>
      </RadioGroup>
      {values.status === 'scheduled' && (
        <Box mt='8px'>
          <DateTimePicker
            startDate={startDate}
            onChange={handleDateChange}
            minDate={new Date()}
            maxDate={addMonths(new Date(), 3)}
          />
        </Box>
      )}
      {values.status === 'scheduled' &&
        error &&
        differenceInMinutes(new Date(broadcastState?.scheduled_time), new Date()) <= -0 && (
          <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
            Please select a date after {startDate ? format(new Date(), 'dd-MM-yyyy hh:mm a') : ''}
          </Text>
        )}
    </Box>
  );
};

export default Schedule;
