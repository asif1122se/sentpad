import { Badge, Box, Flex, Text, useDisclosure } from '@chakra-ui/react';
import { PageHeader } from 'components';
import { PageContainer } from 'components/Layout';
import { useQuery } from 'hooks/useQuery';
import { useParams } from 'react-router-dom';
import QUERY_KEYS from 'utils/queryKeys';
import { format } from 'date-fns';
import { EmailDetails, BroadCastDeliverbilityStats } from '../types';
import { formatNumber, UTCtoLocalTimeConverter } from 'utils';
import PreviewEmailModal from './PreviewEmailModal';

const DetailsPage = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const { id } = useParams();

  const { data } = useQuery<EmailDetails>({
    queryKey: [QUERY_KEYS.EMAIL_DETAILS],
    url: `broadcast-email-details/${id}`,
  });

  const { data: totalOpens } = useQuery<any>({
    queryKey: [QUERY_KEYS.EMAIL_OPENS],
    url: `broadcast-analytics/${id}`,
  });

  const { data: deliverbilityStats } = useQuery<BroadCastDeliverbilityStats>({
    queryKey: [QUERY_KEYS.BROADCAST_DELIVERBILITY_STATS],
    url: `broadcast/deliverabilityStats/${id}`,
  });
  return (
    <>
      {data && (
        <PreviewEmailModal
          isOpen={isOpen}
          onClose={onClose}
          emailPreview={data?.email_preview}
          profileID={data?.sender_profile.id}
        />
      )}
      <PageContainer>
        <PageHeader
          title={totalOpens?.name}
          subtitle='Broadcast'
          buttonLabel='Preview Email'
          variant='blackOutlined'
          onClick={onOpen}
        />
        <Box>
          <Text mb='4' fontSize='22px'>
            Overview
          </Text>

          <Flex width='100%' gap='4'>
            {/* Email Details */}
            <Box
              width='33%'
              fontSize='sm'
              padding='0.4rem 1.5rem'
              borderWidth='1px'
              borderColor='gray.400'
              borderRadius='8px'>
              <Box my='2'>
                <Text fontWeight='bold'>Email Details</Text>
              </Box>
              <Box>
                <Flex my='5'>
                  <Box width='50%'>
                    <Text color='gray.700'>Creation Date</Text>
                    <Text>
                      <span style={{ fontWeight: 'bold' }}>
                        {data?.email_details?.creation_date
                          ? format(
                              new Date(
                                `${UTCtoLocalTimeConverter(data?.email_details?.creation_date)}`,
                              ),
                              'MMM d, yyyy',
                            )
                          : 'N/A'}
                      </span>{' '}
                      {data &&
                        format(
                          new Date(UTCtoLocalTimeConverter(data?.email_details?.creation_date)),
                          'hh:mm a',
                        )}
                    </Text>
                  </Box>
                  <Box width='50%'>
                    <Text color='gray.700'>Scheduled</Text>
                    <Text>
                      <span style={{ fontWeight: 'bold' }}>
                        {data?.email_details?.scheduled_date
                          ? format(
                              new Date(`${data?.email_details?.scheduled_date}`),
                              'MMM d, yyyy',
                            )
                          : 'Not scheduled'}
                      </span>{' '}
                      {data?.email_details?.scheduled_date &&
                        format(
                          new Date(
                            `${data?.email_details?.scheduled_date?.substring(
                              0,
                              data?.email_details?.scheduled_date.length - 1,
                            )}`,
                          ),
                          'hh:mm a',
                        )}
                    </Text>
                  </Box>
                </Flex>
                <Flex my='5'>
                  <Box width='50%'>
                    <Text color='gray.700'>Started</Text>
                    <Text>
                      <span style={{ fontWeight: 'bold' }}>
                        {data?.email_details?.started_date
                          ? format(
                              new Date(
                                `${UTCtoLocalTimeConverter(data?.email_details?.started_date)}`,
                              ),
                              'MMM d, yyyy',
                            )
                          : 'N/A'}
                      </span>{' '}
                      {data &&
                        format(
                          new Date(UTCtoLocalTimeConverter(data?.email_details?.started_date)),
                          'hh:mm a',
                        )}
                    </Text>
                  </Box>
                  <Box width='50%'>
                    <Text color='gray.700'>Completion Date</Text>
                    <Text>
                      <span style={{ fontWeight: 'bold' }}>
                        {data?.email_details?.completed_date
                          ? format(
                              new Date(
                                `${UTCtoLocalTimeConverter(data?.email_details?.completed_date)}`,
                              ),
                              'MMM d, yyyy',
                            )
                          : 'N/A'}
                      </span>{' '}
                      {data &&
                        format(
                          new Date(UTCtoLocalTimeConverter(data?.email_details?.completed_date)),
                          'hh:mm a',
                        )}
                    </Text>
                  </Box>
                </Flex>
              </Box>
            </Box>
            {/* Included Recipients */}
            <Box
              fontSize='sm'
              width='33%'
              padding='0.4rem 1.5rem'
              borderWidth='1px'
              borderColor='gray.400'
              borderRadius='8px'>
              <Box my='2'>
                <Text fontWeight='bold'>
                  <Text fontWeight='bold'>Lists</Text>
                </Text>
              </Box>
              <Box>
                {data?.recipients?.map((item: any) => (
                  <>
                    <Badge variant='warning' textTransform='capitalize' mr='1' my='1'>
                      {item?.title.slice(0, 20) + '...'}
                    </Badge>
                  </>
                ))}
              </Box>
            </Box>

            {/* Sender Profile */}
            <Box
              fontSize='sm'
              width='33%'
              padding='0.4rem 1.5rem'
              borderWidth='1px'
              borderColor='gray.400'
              borderRadius='8px'>
              <Box my='2'>
                <Text fontWeight='bold'>Sender Profile</Text>
              </Box>
              <Box mb='4'>
                <Text mt='2' color='gray.700'>
                  Sender name
                </Text>
                <Text fontWeight='bold'>{data?.sender_profile?.sender_name}</Text>
                <Text mt='2' color='gray.700'>
                  From email
                </Text>
                <Text fontWeight='bold'>{data?.sender_profile?.from_email}</Text>
                <Text mt='2' color='gray.700'>
                  Reply to
                </Text>
                <Text fontWeight='bold'>{data?.sender_profile?.reply_to_email}</Text>
              </Box>
            </Box>
          </Flex>

          <Box fontSize='sm'>
            <Text my='4' fontWeight='bold'>
              Engagement
            </Text>
            <Flex fontSize='13px' gap={3} justifyContent='space-between' width='100%'>
              {/* Opens */}
              <Box
                width='45%'
                padding='0.6rem 1rem'
                borderWidth='1px'
                borderColor='gray.200'
                borderRadius='8px'
                background='gray.200'>
                <Text fontWeight={'bold'}>Opens</Text>
                <Flex my='2'>
                  <Box width='50%'>
                    <Text>Total</Text>
                    <Text fontSize='md' fontWeight={'bold'}>
                      {totalOpens?.opened_stats?.emails_opened}
                    </Text>
                    <Text mt='1' fontWeight='semibold'>
                      {totalOpens?.opened_stats?.open_rate}%
                    </Text>
                  </Box>
                  <Box>
                    <Text>Unique</Text>
                    <Text fontSize='md' fontWeight={'bold'}>
                      {totalOpens?.opened_stats?.unique_emails_opened}
                    </Text>
                    <Text mt='1' fontWeight='semibold'>
                      {totalOpens?.opened_stats?.unique_open_rate}%{' '}
                    </Text>
                  </Box>
                </Flex>
              </Box>
              {/* Clicks */}
              <Box
                width='45%'
                padding='0.6rem 1rem'
                borderWidth='1px'
                borderColor='gray.200'
                borderRadius='8px'
                background='gray.200'>
                <Text fontWeight={'bold'}>Clicks</Text>
                <Flex my='2'>
                  <Box width='50%'>
                    <Text>Total</Text>
                    <Text fontSize='md' fontWeight={'bold'}>
                      {totalOpens?.clicked_stats?.emails_clicked}
                    </Text>
                    <Text mt='1' fontWeight='semibold'>
                      {totalOpens?.clicked_stats?.click_rate}%
                    </Text>
                  </Box>
                  <Box>
                    <Text>Unique</Text>
                    <Text fontSize='md' fontWeight={'bold'}>
                      {totalOpens?.clicked_stats?.unique_emails_clicked}
                    </Text>
                    <Text mt='1' fontWeight='semibold'>
                      {totalOpens?.clicked_stats?.unique_click_rate}%{' '}
                    </Text>
                  </Box>
                </Flex>
              </Box>
              {/* Deliverability */}
              <Box
                width='50%'
                padding='0.6rem 1rem'
                borderWidth='1px'
                borderColor='gray.200'
                borderRadius='8px'
                background='gray.200'>
                <Text fontWeight={'bold'}>Deliverability</Text>
                <Flex my='2' gap='3'>
                  <Box width='40%'>
                    <Text>Unsubscribed</Text>
                    <Text fontSize='md' fontWeight={'bold'}>
                      {formatNumber(deliverbilityStats?.unsubscribed ?? 0)}
                    </Text>
                    <Text mt='1' fontWeight='semibold'>
                      {deliverbilityStats?.unsubscribed_rate}.00%
                    </Text>
                  </Box>
                  <Box width='30%'>
                    <Text>Spam</Text>
                    <Text fontSize='md' fontWeight={'bold'}>
                      {formatNumber(deliverbilityStats?.spam ?? 0)}
                    </Text>
                    <Text mt='1' fontWeight='semibold'>
                      {deliverbilityStats?.spam_rate}.00%
                    </Text>
                  </Box>
                  <Box width='30%'>
                    <Text>Bounces</Text>
                    <Text fontSize='md' fontWeight={'bold'}>
                      {formatNumber(deliverbilityStats?.bounced ?? 0)}
                    </Text>
                    <Text mt='1' fontWeight='semibold'>
                      {deliverbilityStats?.bounced_rate}.00%
                    </Text>
                  </Box>
                </Flex>
              </Box>
              {/* Clicks */}
              <Box width='47.5%'></Box>
            </Flex>
          </Box>
        </Box>
      </PageContainer>
    </>
  );
};

export default DetailsPage;
