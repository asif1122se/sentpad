import React, { useState } from 'react';
import {
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Box,
  Heading,
  Text,
  Button,
  Flex,
  Badge,
} from '@chakra-ui/react';
import { CloseIcon, TriangleDownIcon } from '@chakra-ui/icons';
import { AUDIENCE } from 'consts';
import { useStoreState, useStoreActions } from 'redux';
import AudienceMenu from './AudienceMenu';
import { useQuery } from 'hooks/useQuery';
import { ContactLists, SenderProfiles } from 'pages/Audience/Contacts/types';
import QUERY_KEYS from 'utils/queryKeys';

type BroadcastNameType = {
  error: boolean;
};

export type SelectedItem = {
  id: number;
  name: string;
};

export type AudienceOption = {
  id: number;
  title: string;
};

const Audience: React.FC<BroadcastNameType> = ({ error }: BroadcastNameType) => {
  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);
  const [selectedList, setSelectedList] = useState<SelectedItem[]>(
    broadcastState?.contactList ? broadcastState?.contactList : [],
  );

  const { data: contactList, isLoading: isListLoading } = useQuery<ContactLists>({
    url: 'getContactLists',
    queryKey: [QUERY_KEYS.CONTACTS_LISTS],
  });

  const { data: senderProfile } = useQuery<SenderProfiles>({
    queryKey: [QUERY_KEYS.SENDER_PROFILES],
    url: 'getSenderProfiles',
  });

  const handleSelectedList = (data: SelectedItem) => {
    setSelectedList([...selectedList, data]);
    broadcastAction({
      ...broadcastState,
      contactList: broadcastState?.contactList ? [...broadcastState?.contactList, data] : [data],
    });
  };

  const removeAudienceItem = (id: number) => {
    const arr = selectedList;
    const index = arr.findIndex((o) => o.id === id);
    if (index !== -1) arr.splice(index, 1);
    setSelectedList(arr);
    broadcastAction({ ...broadcastState, contactList: arr });
  };

  const handleSelectedProfile = (data: any) => {
    broadcastAction({ ...broadcastState, senderProfile: data });
  };

  return (
    <Box>
      <Heading as='h1' size='h3' fontWeight='bold'>
        {AUDIENCE}
      </Heading>
      <Text color='gray.800' mb='18px' w='377px'>
        Include and/or exclude contacts for this broadcast.
      </Text>
      <Flex justifyContent='space-between'>
        <Text fontWeight='medium'>Include</Text>
        {selectedList.length > 0 && (
          <Text
            color='blue.700'
            fontSize='14px'
            cursor='pointer'
            onClick={() => {
              setSelectedList([]);
              broadcastAction({ ...broadcastState, contactList: '' });
            }}>
            Remove All
          </Text>
        )}
      </Flex>
      <Flex
        minH='40px'
        borderWidth={
          (!broadcastState?.contactList || broadcastState?.contactList?.length == 0) && error
            ? '2px'
            : '1px'
        }
        borderStyle='solid'
        borderColor={
          (!broadcastState?.contactList || broadcastState?.contactList?.length == 0) && error
            ? 'red.700'
            : 'gray.600'
        }
        borderRadius='4px'
        p='16px'
        alignItems='center'
        gap='8px'
        wrap='wrap'>
        {selectedList?.map((item, index) => (
          <>
            {item?.name && (
              <Badge key={index} variant='warning' display='flex' alignItems='center'>
                {item?.name.length > 50 ? `${item?.name.substring(0, 50)}...` : item?.name}
                <CloseIcon
                  onClick={() => {
                    removeAudienceItem(item.id);
                  }}
                  w='8px'
                  h='8px'
                  ml='8px'
                  cursor='pointer'
                />
              </Badge>
            )}
          </>
        ))}
        <AudienceMenu options={contactList} onOptionClick={handleSelectedList} />
      </Flex>

      {(!broadcastState?.contactList || broadcastState?.contactList?.length == 0) && error && (
        <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
          Please include at least one list
        </Text>
      )}

      <Flex mt='12px' flexDir='column'>
        <Text fontWeight='medium'>Sender Profile</Text>
        <Box
          minH='100px'
          borderWidth={!broadcastState?.senderProfile && error ? '2px' : '1px'}
          borderStyle='solid'
          borderColor={!broadcastState?.senderProfile && error ? 'red.700' : 'gray.600'}
          borderRadius='4px'
          w='100%'
          position='relative'>
          <Menu matchWidth>
            {({ isOpen }) => (
              <>
                <MenuButton
                  isActive={isOpen}
                  as={Button}
                  rightIcon={<TriangleDownIcon color='gray.800' w='12px' h='8px' />}
                  background='white'
                  w='100%'
                  h='100px'>
                  <Flex direction='column' textAlign='left' gap='8px'>
                    <Text color='gray.800' fontWeight='semibold'>
                      {(broadcastState?.senderProfile && broadcastState?.senderProfile?.name) ||
                        broadcastState?.senderProfile?.company_name}
                    </Text>
                    <Text color='gray.800' fontWeight='semibold'>
                      <Text as='span' color='gray.800' fontWeight='normal'>
                        From
                      </Text>{' '}
                      {(broadcastState?.senderProfile && broadcastState?.senderProfile?.from) ||
                        broadcastState?.senderProfile?.from_email}
                    </Text>
                    <Text color='gray.800' fontWeight='semibold'>
                      <Text as='span' color='gray.800' fontWeight='normal'>
                        Reply to
                      </Text>{' '}
                      {(broadcastState?.senderProfile && broadcastState?.senderProfile?.to) ||
                        broadcastState?.senderProfile?.reply_to_email}
                    </Text>
                  </Flex>
                </MenuButton>
                {isOpen && (
                  <MenuList
                    w='100.4%'
                    maxH='300px'
                    overflowY='scroll'
                    position='absolute'
                    top='-109px'
                    left='-1px'
                    border='1px solid var(--chakra-colors-gray-600)'
                    borderRadius='4px'>
                    {senderProfile?.map((item) => (
                      <MenuItem
                        key={item?.id}
                        onClick={() =>
                          handleSelectedProfile({
                            id: item?.id,
                            name: item?.sender_name,
                            from: item?.from_email,
                            to: item?.reply_to_email,
                          })
                        }>
                        <Flex direction='column' textAlign='left' gap='8px'>
                          <Text color='gray.800' fontWeight='semibold'>
                            {item?.sender_name}
                          </Text>
                          <Text color='gray.800' fontWeight='semibold'>
                            <Text as='span' color='gray.800' fontWeight='normal'>
                              From
                            </Text>{' '}
                            {item.from_email}
                          </Text>
                          <Text color='gray.800' fontWeight='semibold'>
                            <Text as='span' color='gray.800' fontWeight='normal'>
                              Reply to
                            </Text>{' '}
                            {item.reply_to_email}
                          </Text>
                        </Flex>
                      </MenuItem>
                    ))}
                  </MenuList>
                )}
              </>
            )}
          </Menu>
        </Box>
        {!broadcastState?.senderProfile && error && (
          <Text color='red.700' mt='8px' fontSize='14px' fontWeight='medium'>
            Please select a sender profile
          </Text>
        )}
      </Flex>
    </Box>
  );
};

export default Audience;
