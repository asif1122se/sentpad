import EmailBuilder from 'components/EmailBuilder';
import { footer } from 'components/EmailBuilder/templates/consts';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useStoreActions, useStoreState } from 'redux';

const EmailBuilderPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const isAutoresponder = searchParams.get('type') === 'autoresponder';
  const isEdit = searchParams.get('isEdit') === 'true';

  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);
  const { tempEmail } = useStoreState((state) => state.autoresponder.autoresponderObj);
  const { addTempEmail } = useStoreActions((state) => state.autoresponder);

  const navigate = useNavigate();

  const email = isAutoresponder ? tempEmail : broadcastState;

  const handleTemplateSave = (content = '') => {
    if (isAutoresponder) {
      addTempEmail({
        ...tempEmail,
        body_content: content,
      });
    } else {
      broadcastAction({ ...broadcastState, body_content: content, step: 2 });
    }

    navigate(isEdit ? -1 : -2);
  };

  return (
    <EmailBuilder
      isAutoresponder={isAutoresponder}
      content={email?.body_content}
      onSave={handleTemplateSave}
    />
  );
};

export default EmailBuilderPage;
