import React, { useState } from 'react';
import {
  Badge,
  Icon,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Text,
  useDisclosure,
} from '@chakra-ui/react';
import { PageHeader, AlertHandler, PaginatedDataTable } from 'components';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { PageContainer } from 'components/Layout';
import { BROADCASTS } from 'consts';
import { useNavigate } from 'react-router-dom';
import { ROUTE_PATHS } from 'router';
import { GoKebabVertical } from 'react-icons/go';
import { useStoreActions } from 'redux';
import { Broadcast } from './types';
import { ColumnProps } from 'types/general';
import { FILTER_INDEX } from 'components/Filters/consts';
import QUERY_KEYS from 'utils/queryKeys';
import { DRAFT, SCHEDULED } from 'pages/Forms/consts';
import { DeleteBroadcastModal } from './components';

const broadcastColProps: ColumnProps[] = [
  {
    align: 'left',
  },
  {
    align: 'left',
  },
  {
    align: 'center',
  },
  {
    align: 'center',
  },
  {
    align: 'center',
  },
  {
    align: 'center',
  },
  {
    align: 'right',
  },
];

const BroadcastPage: React.FC = () => {
  const modalAction = useStoreActions((actions) => actions.modal.add);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);
  const [values, setValues] = useState<any>();
  const navigate = useNavigate();

  const [selectedID, setSelectedID] = useState<number>(0);

  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();

  const columnHelper = createColumnHelper<Broadcast>();
  const columns = [
    columnHelper.display({
      header: 'Broadcast Name',
      cell: (props: CellContext<Broadcast, unknown>) => (
        <>
          {props.row.original.sent_status == 1 ? (
            <Text
              onClick={() => navigate(`/broadcast/details/${props.row.original.id}`)}
              cursor='pointer'
              fontWeight='semibold'
              _hover={{ textDecoration: 'underline', color: 'blue.600' }}
              title='Click to view details'>
              {props.row.original.campaign_name.length > 50
                ? `${props.row.original.campaign_name.substring(0, 50)}...`
                : props.row.original.campaign_name}
            </Text>
          ) : props.row.original.campaign_name.length > 50 ? (
            `${props.row.original.campaign_name.substring(0, 50)}...`
          ) : (
            props.row.original.campaign_name
          )}
        </>
      ),
    }),
    columnHelper.display({
      id: 'status',
      header: 'Status',
      cell: (props: CellContext<Broadcast, unknown>) => (
        <Badge
          variant={props.row.original.sent_status == 1 ? 'completed' : props.row.original.status}
          textTransform='capitalize'
          fontSize='sm'
          fontWeight='normal'>
          {props.row.original.sent_status == 1 || props.row.original.status == 'immediate'
            ? 'Completed'
            : props.row.original.status}
        </Badge>
      ),
    }),
    columnHelper.accessor('audience', {
      cell: (info) => info.getValue(),
      header: 'Audience',
      meta: {
        isNumeric: true,
      },
    }),
    columnHelper.accessor('open_rate', {
      cell: (info) => `${info.getValue()}%`,
      header: 'Open Rate',
      meta: {
        isNumeric: true,
      },
    }),
    columnHelper.accessor('click_rate', {
      cell: (info) => `${info.getValue()}%`,
      header: 'Click Rate',
      meta: {
        isNumeric: true,
      },
    }),
    columnHelper.display({
      id: 'actions',
      cell: (props: CellContext<Broadcast, unknown>) => {
        return (
          <Menu>
            <MenuButton>
              <Icon height='25px' color='gray.500' as={GoKebabVertical} />
            </MenuButton>
            <MenuList borderColor='gray.500' minWidth='110px' width='fit-content'>
              {props.row.original.sent_status !== 1 && (
                <MenuItem
                  onClick={() => {
                    broadcastAction({ campaign_id: props.row.original?.id });
                    navigate(`/broadcast/new?id=${props.row.original?.id}`);
                  }}>
                  Edit
                </MenuItem>
              )}

              <MenuItem
                onClick={() =>
                  modalAction({
                    action: 'confirm_duplicate',
                    id: props.row.original.id,
                    header: 'Duplicate your broadcast',
                    description: 'Please provide a name.',
                    name: props.row.original?.campaign_name,
                  })
                }>
                Duplicate
              </MenuItem>

              {props.row.original?.status === DRAFT && (
                <MenuItem
                  onClick={() => {
                    setSelectedID(props.row.original.id);
                    onDeleteOpen();
                  }}>
                  Delete
                </MenuItem>
              )}
            </MenuList>
          </Menu>
        );
      },
    }),
  ];

  const statusFilter = values?.status
    ?.map((item: any) => item?.value)
    ?.toString()
    ?.toLowerCase();
  const audienceList = values?.list?.map((item: any) => item.id)?.toString();

  return (
    <PageContainer>
      <AlertHandler />
      <DeleteBroadcastModal
        isOpen={isDeleteOpen}
        onClose={onDeleteClose}
        broadcastID={selectedID}
      />
      <PageHeader
        title={BROADCASTS}
        buttonLabel='Create Broadcast'
        onClick={() => {
          navigate(`${ROUTE_PATHS.NEW}`);
          broadcastAction({});
        }}
      />
      <PaginatedDataTable
        endpoint='getCampaignsListPaginated'
        queryKey={[QUERY_KEYS.BROADCAST_LIST]}
        params={{
          isclicked: '',
          status_filter: statusFilter,
          lists_filter: audienceList,
          date_filter: values?.date,
        }}
        columns={columns}
        filterIndex={FILTER_INDEX.Broadcast}
        colProps={broadcastColProps}
        emptyMessage='No broadcast(s) found'
        showPageSizeMenu
        values={values}
        setValues={setValues}
        showFilters
        showSearch
      />
    </PageContainer>
  );
};

export default BroadcastPage;
