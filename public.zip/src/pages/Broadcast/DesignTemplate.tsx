import React from 'react';
import { Box, Text, Stack, Flex, Button } from '@chakra-ui/react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useStoreState, useStoreActions } from 'redux';
//hard codded as we need these from db
import { blankContent, notifyTemplateContent } from 'components/EmailBuilder/templates/consts';
import { StyledImage, TemplateBox } from './styles';
import { CloseIcon } from '@chakra-ui/icons';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { SenderProfileFooter } from './types';

const DesignTemplates = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const type = searchParams.get('type');
  const isAutoresponder = type === 'autoresponder';

  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);
  const { tempEmail } = useStoreState((state) => state.autoresponder.autoresponderObj);
  const { addTempEmail } = useStoreActions((state) => state.autoresponder);

  const handleTemplateChange = (name: string, templateContent: string) => {
    if (isAutoresponder) {
      addTempEmail({
        ...tempEmail,
        templateThumbnail: name,
        body_content: templateContent,
      });
    } else {
      broadcastAction({
        ...broadcastState,
        templateThumbnail: name,
        body_content: templateContent,
        step: 2,
      });
    }
  };

  const [isShown, setIsShown] = React.useState(false);
  return (
    <>
      <Box p='16px'>
        <Flex
          gap='6'
          p='2'
          flexDirection={['column', 'row']}
          justifyContent={'center'}
          flexWrap='wrap'>
          <Stack width='60%'>
            <Box width='100%'>
              <Flex justifyContent={'space-between'} width='100%' alignItems='center'>
                <Text fontSize='32px' fontWeight='bold' my='5'>
                  Email Design - Choose Template
                </Text>
                <CloseIcon onClick={() => history.back()} cursor='pointer' />
              </Flex>
              <Text my='2' fontWeight='700' color='gray.800' lineHeight='30px'>
                Select templates
              </Text>
            </Box>
            <Flex
              gap='6'
              flexDirection={['column', 'row']}
              justifyContent={'flex-start'}
              alignItems='center'
              flexWrap='wrap'>
              <Flex height='100%'>
                <Stack p='1'>
                  <TemplateBox
                    onClick={() => {
                      handleTemplateChange(blankContent.thumbnail, blankContent.content);
                      navigate(`/broadcast/email-builder${type ? `?type=${type}` : ''}`);
                    }}>
                    <Button
                      width='100%'
                      minHeight='300px'
                      m='0'
                      p='1'
                      _focus={{ filter: 'brightness(80%)' }}
                      color='gray.500'
                      letterSpacing='3px'
                      fontWeight='semibold'
                      _hover={{
                        color: 'gray.700',
                      }}>
                      BLANK
                    </Button>
                  </TemplateBox>
                  <Text color='gray.900' fontSize='md' fontWeight='600'>
                    Blank Page
                  </Text>
                </Stack>
              </Flex>
              <Flex height='100%'>
                <Stack p='1'>
                  <Button
                    height='100%'
                    m='0'
                    p='1'
                    position='relative'
                    onMouseOver={() => setIsShown(true)}
                    onMouseLeave={() => setIsShown(false)}>
                    {isShown && (
                      <Button
                        variant='success'
                        position='absolute'
                        zIndex='2'
                        onClick={() => {
                          handleTemplateChange(
                            notifyTemplateContent.thumbnail,
                            notifyTemplateContent.content,
                          );
                          navigate(`/broadcast/email-builder${type ? `?type=${type}` : ''}`);
                        }}>
                        Use Template
                      </Button>
                    )}
                    <StyledImage
                      isHover={isShown}
                      objectFit='cover'
                      src={notifyTemplateContent.thumbnail}
                    />
                  </Button>
                  <Text color='gray.900' fontSize='md' fontWeight='600'>
                    Portfolio Starter
                  </Text>
                  <Text color='gray.600' fontSize='sm' fontWeight='600'>
                    Preset
                  </Text>
                </Stack>
              </Flex>
            </Flex>
          </Stack>
        </Flex>
      </Box>
    </>
  );
};
export default DesignTemplates;
