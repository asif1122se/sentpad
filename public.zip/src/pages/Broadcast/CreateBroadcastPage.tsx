import React, { useState, useEffect } from 'react';
import { Box, Button, Flex, useToast } from '@chakra-ui/react';
import { useFormik } from 'formik';
import { BroadcastName, Audience, Content, Schedule, StepGuide } from 'pages/Broadcast/components';
import { BroadcastSteps, STEPS } from './consts';
import { BroadcastCreationFormType } from './types';
import { performGetSingleBroadcastApi, performSaveBroadcastApi } from 'services/apis/broadcast';
import { useNavigate } from 'react-router-dom';
import { PageContainer } from 'components/Layout';
import { format, differenceInMinutes } from 'date-fns';
import AlertManager from 'components/Alerts/AlertManager';
import { SCHEDULED } from 'consts';
import { useStoreActions, useStoreState } from 'redux';

type ContactItem = {
  id: number;
  title: string;
};

const CreateBroadcastPage: React.FC = () => {
  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);

  const [error, setError] = useState<boolean>(false);
  const [step, setStep] = useState(broadcastState.step ? broadcastState.step : STEPS.Broadcast);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const navigate = useNavigate();
  const toast = useToast();
  const [urlId, setUrlId] = useState(
    location.search.split('?id=')[1] ? location.search.split('?id=')[1] : '',
  );

  const { handleChange, handleSubmit, values } = useFormik<BroadcastCreationFormType>({
    enableReinitialize: true,
    initialValues: {
      campaign_name: `${
        broadcastState?.campaign_name && broadcastState?.campaign_name !== ''
          ? broadcastState?.campaign_name
          : ''
      }`,
      subject: `${broadcastState?.subject ? broadcastState?.subject : ''}`,
      pre_header: `${broadcastState?.pre_header ? broadcastState?.pre_header : ''}`,
      status: `${broadcastState?.status ? broadcastState?.status : 'draft'}`,
    },
    onSubmit: (values) => {
      const handleSubmitFormData = async () => {
        setBtnLoading(true);
        const uniqueList = [
          ...new Set(broadcastState?.contactList?.map((item: ContactItem) => item.id)),
        ];
        try {
          const broadcastCreationResult = await performSaveBroadcastApi({
            ...values,
            list_ids: uniqueList?.toString(),
            sender_profile_id: broadcastState?.senderProfile?.id,
            step: (step + 1).toString(),
            scheduled_time:
              values.status == SCHEDULED
                ? format(new Date(broadcastState?.scheduled_time), 'yyyy-MM-dd HH:mm')
                : '',
            time_zone: broadcastState?.time_zone,
            body_content: broadcastState?.body_content,
            campaign_id: urlId,
            subject: broadcastState?.subject,
            pre_header: broadcastState?.pre_header,
            campaign_name: broadcastState?.campaign_name,
          });
          if (broadcastCreationResult?.errors?.length === 0) {
            setBtnLoading(false);
            broadcastAction({});
            toast({
              title: `${broadcastCreationResult?._metadata?.message}`,
              status: 'success',
              isClosable: true,
              position: 'top-right',
            });
            navigate('/broadcast');
          } else {
            setBtnLoading(false);
            toast({
              title: 'Something went wrong',
              status: 'error',
              isClosable: true,
              position: 'top-right',
            });
          }
        } catch (err) {
          console.log(err);
        }
      };
      if (
        values.status == SCHEDULED &&
        differenceInMinutes(new Date(broadcastState?.scheduled_time), new Date()) > 0
      ) {
        handleSubmitFormData();
      } else if (values.status !== SCHEDULED) {
        handleSubmitFormData();
      } else {
        setError(true);
      }
    },
  });

  const handleStepChange = (name: string) => {
    setError(true);
    if (name === 'prev') {
      setStep(step - 1);
    } else if (
      name === 'next' &&
      step == 0 &&
      (values.campaign_name || broadcastState?.campaign_name)
    ) {
      broadcastAction({
        ...broadcastState,
        step: step + 1,
      });
      setError(false);
      setStep(step + 1);
    } else if (
      name === 'next' &&
      step == 1 &&
      broadcastState?.contactList?.length > 0 &&
      broadcastState?.senderProfile
    ) {
      setError(false);
      broadcastAction({ ...broadcastState, step: step + 1 });
      setStep(step + 1);
    } else if (
      name === 'next' &&
      step == 2 &&
      (values.subject || broadcastState?.subject) &&
      (broadcastState?.templateThumbnail || broadcastState?.body_content)
    ) {
      broadcastAction({
        ...broadcastState,
        step: step + 1,
        status: '',
      });
      setError(false);
      setStep(step + 1);
    }
  };

  const getSingleBroadcast = async () => {
    try {
      const getSingleBroadcastRes = await performGetSingleBroadcastApi(urlId);
      if (getSingleBroadcastRes?.errors?.length === 0) {
        broadcastAction({
          ...broadcastState,
          campaign_name: getSingleBroadcastRes?.records?.campaign_name,
          contactList: getSingleBroadcastRes?.records?.list_ids
            ?.filter((item: ContactItem) => item !== null)
            .map((item: ContactItem) => ({
              name: item?.title,
              id: item?.id,
            })),
          senderProfile: broadcastState?.senderProfile?.id
            ? broadcastState?.senderProfile
            : getSingleBroadcastRes?.records?.sender_profile_id,
          subject: broadcastState?.subject
            ? broadcastState?.subject
            : getSingleBroadcastRes?.records?.emailData?.subject,
          pre_header: broadcastState?.pre_header
            ? broadcastState?.pre_header
            : getSingleBroadcastRes?.records?.emailData?.pre_header,
          status: getSingleBroadcastRes?.records?.status,
          body_content: broadcastState?.body_content
            ? broadcastState?.body_content
            : getSingleBroadcastRes?.records?.emailData?.body_content,
          scheduleTime: getSingleBroadcastRes?.records?.scheduled_time,
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    broadcastAction({
      ...broadcastState,
      campaign_name: e.target.value,
    });
  };

  useEffect(() => {
    urlId && getSingleBroadcast();
  }, []);

  const handleKeyDown = (event: any, callback: any) => {
    if (event.key === 'Enter' && event.shiftKey === false) {
      event.preventDefault();
    }
  };

  return (
    <PageContainer>
      <AlertManager />
      <form
        onSubmit={handleSubmit}
        onKeyDown={(e) => {
          handleKeyDown(e, handleSubmit);
        }}>
        <Flex gap='50px'>
          <Box w='468px'>
            <StepGuide active={step} />
            {step === STEPS.Broadcast && (
              <BroadcastName values={values} error={error} handleNameChange={handleNameChange} />
            )}
            {step === STEPS.Audience && <Audience error={error} />}
            {step === STEPS.Content && <Content values={values} error={error} />}
            {step === STEPS.Schedule && (
              <Schedule onChange={handleChange} values={values} error={error} />
            )}
            <Box display='flex' mt='28px'>
              {step > STEPS.Broadcast && (
                <Button variant='outlined' mr='0.5rem' onClick={() => handleStepChange('prev')}>
                  Prev: {BroadcastSteps[step - 1]}
                </Button>
              )}
              {step < BroadcastSteps.length - 1 && (
                <Button variant='info' onClick={() => handleStepChange('next')}>
                  Next: {BroadcastSteps[step + 1]}
                </Button>
              )}
              {step === BroadcastSteps.length - 1 && (
                <Button isLoading={btnLoading} id='saveBroadcast' variant='success' type={'submit'}>
                  {values.status == 'draft'
                    ? 'Save Broadcast'
                    : values.status == 'immediate'
                    ? 'Send Broadcast'
                    : 'Schedule Broadcast'}
                </Button>
              )}
            </Box>
          </Box>
        </Flex>
      </form>
    </PageContainer>
  );
};

export default CreateBroadcastPage;
