import React, { useState, useEffect } from 'react';
import {
  Box,
  Badge,
  Icon,
  useToast,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Center,
  Spinner,
  Text,
} from '@chakra-ui/react';
import { PageHeader, AlertHandler, DataTable } from 'components';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { PageContainer } from 'components/Layout';
import { BROADCASTS } from 'consts';
import { useNavigate } from 'react-router-dom';
import { ROUTE_PATHS } from 'router';
import { GoKebabVertical } from 'react-icons/go';
import { performGetBroadcastApi, performDeleteCompaignApi } from 'services/apis/broadcast';
import { useStoreState, useStoreActions } from 'redux';
import { Broadcast, BroadcastListing } from './types';
import { useDebounce } from 'hooks/useDebounce';
import { ColumnProps } from 'types/general';
import { FILTER_INDEX } from 'components/Filters/consts';
import config from 'config';

const BroadcastAnalyticPage: React.FC = () => {
  const filterState = useStoreState((state) => state.filter.filterObj);
  const modalState = useStoreState((state) => state.modal.selectedModal);
  const modalAction = useStoreActions((actions) => actions.modal.add);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);
  const [data, setData] = useState<BroadcastListing>();
  const [searchedValue, setSearchedValue] = useState<string>('');
  const [values, setValues] = useState<any>();
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const navigate = useNavigate();
  const toast = useToast();
  const debouncedSearchTerm = useDebounce(searchedValue, 200);

  const detailLink =
    localStorage.getItem('email') === config.demoUser
      ? `/broadcast/details-analytics`
      : `/broadcast/details`;

  enum Status {
    DRAFT,
    SENT,
  }

  const broadcastColProps: ColumnProps[] = [
    {
      align: 'left',
    },
    {
      align: 'left',
    },
    {
      align: 'center',
    },
    {
      align: 'center',
    },
    {
      align: 'center',
    },
    {
      align: 'center',
    },
    {
      align: 'right',
    },
  ];

  const getBroadcastListing = async () => {
    setValues({ ...values, filterBtnLoading: true });
    setIsLoading(true);
    const statusFilter = values?.status
      ?.map((item: any) => item?.value)
      ?.toString()
      ?.toLowerCase();
    const audienceList = values?.list?.map((item: any) => item.id)?.toString();
    const filtredObj = {
      isclicked: '',
      status_filter: statusFilter,
      lists_filter: audienceList,
      date_filter: values?.date,
    };
    try {
      const broadcastListingRes = await performGetBroadcastApi(
        searchedValue ? searchedValue : '',
        filtredObj,
      );
      if (broadcastListingRes?.errors?.length === 0) {
        setData(broadcastListingRes?.records);
        setIsLoading(false);
        setValues({ ...values, filterBtnLoading: false });
      }
    } catch (err) {
      console.log(err);
      setIsLoading(false);
      setValues({ ...values, filterBtnLoading: false });
    }
  };

  const arrData = [
    {
      id: 1,
      campaign_name: 'Broadcast 1 (12/22/2022)',
      sent_status: 1,
      audience: '10,264',
      open_rate: 23.74,
      click_rate: 1.88,
    },
    {
      id: 2,
      campaign_name: 'Broadcast 2 (12/21/2022)',
      sent_status: 1,
      audience: '10,211',
      open_rate: 29.56,
      click_rate: 2.07,
    },
    {
      id: 3,
      campaign_name: 'Broadcast 1 (12/21/2022)',
      sent_status: 1,
      audience: '10,180',
      open_rate: 31.44,
      click_rate: 1.45,
    },
    {
      id: 4,
      campaign_name: 'Broadcast 2 (12/20/2022)',
      sent_status: 1,
      audience: '10,143',
      open_rate: 30.98,
      click_rate: 1.94,
    },
    {
      id: 5,
      campaign_name: 'Broadcast 1 (12/20/2022)',
      sent_status: 1,
      audience: '10,127',
      open_rate: 33.86,
      click_rate: 1.79,
    },
    {
      id: 6,
      campaign_name: 'Broadcast 2 (12/19/2022)',
      sent_status: 1,
      audience: '10,099',
      open_rate: 34.52,
      click_rate: 2.36,
    },
    {
      id: 7,
      campaign_name: 'Broadcast 1 (12/19/2022)',
      sent_status: 1,
      audience: '10,062',
      open_rate: 35.83,
      click_rate: 1.54,
    },
    {
      id: 8,
      campaign_name: 'Broadcast 2 (12/18/2022)',
      sent_status: 1,
      audience: '10,013',
      open_rate: 34.61,
      click_rate: 1.92,
    },
    {
      id: 9,
      campaign_name: 'Broadcast 1 (12/18/2022)',
      sent_status: 1,
      audience: '9,987',
      open_rate: 36.74,
      click_rate: 1.72,
    },
    {
      id: 10,
      campaign_name: 'Broadcast 2 (12/17/2022)',
      sent_status: 1,
      audience: '9,972',
      open_rate: 39.12,
      click_rate: 2.14,
    },
  ];

  const handleDeleteCampaign = async () => {
    try {
      if (modalState.id) {
        const deleteCampaignApiRes = await performDeleteCompaignApi(modalState?.id);
        modalAction({});
        if (deleteCampaignApiRes?.errors?.length === 0) {
          const filtredData = data?.filter((items: any) => items?.id !== modalState?.id);
          setData(filtredData);
          toast({
            title: `${deleteCampaignApiRes?._metadata?.message}`,
            status: 'success',
            isClosable: true,
            position: 'top-right',
          });
        }
      }
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getBroadcastListing();
  }, [debouncedSearchTerm, modalState, filterState.isclicked]);

  useEffect(() => {
    modalState?.isDelete && handleDeleteCampaign();
  }, [modalState]);

  const columnHelper = createColumnHelper<Broadcast>();
  const columns = [
    columnHelper.display({
      header: 'Broadcast Name',
      cell: (props: CellContext<Broadcast, unknown>) => (
        <>
          {props.row.original.sent_status == 1 ? (
            <Text
              onClick={() => navigate(`${detailLink}/${props.row.original.id}`)}
              cursor='pointer'
              fontWeight='semibold'
              _hover={{ textDecoration: 'underline', color: 'blue.600' }}
              title='Click to view details'>
              {props.row.original.campaign_name}
            </Text>
          ) : (
            props.row.original.campaign_name
          )}
        </>
      ),
    }),
    columnHelper.display({
      id: 'status',
      header: 'Status',
      cell: (props: CellContext<Broadcast, unknown>) => (
        <Badge
          variant={props.row.original.sent_status == 1 ? 'completed' : props.row.original.status}
          textTransform='capitalize'
          fontSize='sm'
          fontWeight='normal'>
          {props.row.original.sent_status == 1 || props.row.original.status == 'immediate'
            ? 'Completed'
            : props.row.original.status}
        </Badge>
      ),
    }),
    columnHelper.accessor('audience', {
      cell: (info) => info.getValue(),
      header: 'Audience',
      //  meta: {
      //    isNumeric: true,
      //  },
    }),
    columnHelper.accessor('open_rate', {
      cell: (info) => `${info.getValue()}%`,
      header: 'Open Rate',
      meta: {
        isNumeric: true,
      },
    }),
    columnHelper.accessor('click_rate', {
      cell: (info) => `${info.getValue()}%`,
      header: 'Click Rate',
      meta: {
        isNumeric: true,
      },
    }),
    columnHelper.display({
      id: 'actions',
      cell: (props: CellContext<Broadcast, unknown>) => (
        <Menu>
          <MenuButton>
            <Icon height='25px' color='gray.500' as={GoKebabVertical} />
          </MenuButton>
          <MenuList borderColor='gray.500' minWidth='110px' width='fit-content'>
            {props.row.original?.sent_status == Status.DRAFT && (
              <MenuItem
                onClick={() => {
                  broadcastAction({ campaign_id: props.row.original?.id });
                  navigate(`/broadcast/new?id=${props.row.original?.id}`);
                }}>
                Edit
              </MenuItem>
            )}

            <MenuItem
              onClick={() =>
                modalAction({
                  action: 'confirm_duplicate',
                  id: props.row.original.id,
                  header: 'Duplicate your broadcast',
                  description: 'Please provide a name.',
                  name: props.row.original?.campaign_name,
                })
              }>
              Duplicate
            </MenuItem>

            {props.row.original?.sent_status == Status.DRAFT && (
              <MenuItem
                onClick={() =>
                  modalAction({
                    action: 'confirm_delete',
                    id: props.row.original.id,
                    header: 'Delete your broadcast',
                    description: 'Are you sure you want to delete this broadcast?',
                  })
                }>
                Delete
              </MenuItem>
            )}
          </MenuList>
        </Menu>
      ),
    }),
  ];

  const getValue = (value: string) => {
    setSearchedValue(value);
  };

  return (
    <PageContainer>
      <AlertHandler />
      <PageHeader
        title={BROADCASTS}
        buttonLabel='Create Broadcast'
        onClick={() => {
          navigate(`${ROUTE_PATHS.NEW}`);
          broadcastAction({});
        }}
      />
      <Box mt='1rem'>
        {!data ? (
          <Center>
            <Spinner />
          </Center>
        ) : (
          <DataTable
            columns={columns}
            data={arrData}
            getValue={getValue}
            filterIndex={FILTER_INDEX.Broadcast}
            colProps={broadcastColProps}
            emptyMessage={'No broadcast(s) found'}
            showPageSizeMenu
            values={values}
            setValues={setValues}
          />
        )}
      </Box>
    </PageContainer>
  );
};

export default BroadcastAnalyticPage;
