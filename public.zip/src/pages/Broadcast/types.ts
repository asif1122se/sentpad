export type BroadcastCreationFormType = {
  campaign_name: string;
  subject: string;
  pre_header: string;
  status: string;
};

export type AudienceFormType = {
  include: [];
  from: string;
  to: string;
};

export type Broadcast = {
  id: number;
  audience: number;
  campaign_name: string;
  click_rate: number;
  convert_rate: number;
  created_at: string;
  deleted_at: string;
  email: string;
  list_ids: number[];
  open_rate: number;
  scheduled_time: string;
  segment_ids: number;
  sender_profile_id: number;
  sent_status: number;
  status: string;
  step: string;
  tag_ids: number[];
  time_zone: string;
  updated_at: string;
  user_id: number;
};

export type BroadcastListing = Broadcast[];

export type EmailDetailDates = {
  completed_date?: string;
  creation_date?: string;
  scheduled_date?: string;
  started_date?: string;
};

export type Recipients = {
  id: number;
  description?: string;
  title?: string;
};
export type SenderProfile = {
  id: string;
  sender_name: string;
  from_email: string;
  reply_to_email: string;
  street?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
};

export type EmailPreview = {
  id: number;
  subject: string;
  pre_header: string;
  body_content: string;
  campaign_id: number;
};

export type EmailFooter = {
  sender_name?: string;
  company_name?: string;
  street?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
};

export type EmailDetails = {
  email_details?: EmailDetailDates;
  recipients: Recipients[];
  sender_profile: SenderProfile;
  email_preview: EmailPreview;
  email_footer: EmailFooter;
};

export type BroadCastDeliverbilityStats = {
  bounced: number;
  bounced_rate: number;
  spam: number;
  spam_rate: number;
  unsubscribed: number;
  unsubscribed_rate: number;
};

export type SenderProfileFooter = {
  city?: string;
  company_name?: string;
  country?: string;
  sender_name?: string;
  state?: string;
  street?: string;
  zip?: string;
};
