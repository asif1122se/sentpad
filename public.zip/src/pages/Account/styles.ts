import { Button, Switch } from '@chakra-ui/react';
import styled from '@emotion/styled';
import { Link } from 'react-router-dom';

export const NavItem = styled(Link)<{ active: boolean }>`
  display: flex;
  align-items: center;
  font-size: 14px;
  font-weight: 500;
  color: ${({ active }) =>
    active ? 'var(--chakra-colors-black)' : 'var(--chakra-colors-gray-800)'};
  height: 36px;
  cursor: pointer;
  gap: 12px;
  border-left: 4px solid transparent;
  ${({ active }) => active && `border-color: var(--chakra-colors-purple-700);`}
  padding-left: 8px;
`;

export const StyledSwitch = styled(Switch)`
  .chakra-switch__track {
    background: var(--chakra-colors-red-700);
    &[data-checked] {
      background: var(--chakra-colors-teal-700);
    }
  }
`;

export const HelpButton = styled(Button)`
  width: fit-content;
  height: fit-content;
  padding: 0;
  margin: 0 0;
  font-weight: normal;
`;
