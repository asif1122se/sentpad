import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  chakra,
  Image,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { useMutation } from 'hooks/useMutation';
import { Note, NoteText } from 'pages/Audience/Contacts/styles';
import { DELETE } from 'utils/constants';
import QUERY_KEYS from 'utils/queryKeys';
import { DomainSetup } from '../types';
import Info from 'assets/icons/info.svg';
import { InputField } from 'components';
import { useState } from 'react';

type DeleteDomainModalProps = {
  isOpen: boolean;
  onClose: () => void;
  selectedRow?: DomainSetup;
};

const DeleteDomainModal = ({ isOpen, onClose, selectedRow }: DeleteDomainModalProps) => {
  const queryClient = useQueryClient();
  const [isDelete, setIsDelete] = useState<boolean>(false);
  const [confirmDELETE, setConfirmDELETE] = useState<string>('');
  const { isLoading, mutate } = useMutation<number>({
    method: DELETE,
    url: 'domains/delete',
    onSuccess: () => {
      setIsDelete(false);
      setConfirmDELETE('');
      queryClient.invalidateQueries([QUERY_KEYS.DOMAIN_SETUP]);
      onClose();
    },
    successMessage: 'Domain deleted successfully',
  });

  const handleDelete = () => {
    if (confirmDELETE === 'DELETE') {
      mutate(selectedRow?.id ?? 0);
      setIsDelete(false);
    }
  };

  const handleChange = (value: string) => {
    setConfirmDELETE(value);
    if (value === 'DELETE') {
      setIsDelete(true);
    } else setIsDelete(false);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        setConfirmDELETE('');
        setIsDelete(false);
        onClose();
      }}
      size='lg'
      closeOnEsc={isLoading}
      closeOnOverlayClick={isLoading}
      isCentered>
      <ModalOverlay />
      <ModalContent p='32px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            Delete Domain
          </Text>
        </ModalHeader>
        <ModalCloseButton isDisabled={isLoading} />
        <ModalBody px='0' pt='1rem'>
          <Note>
            <Image src={Info} boxSize='24px' mt='4px' />
            <NoteText>
              <Text fontSize='sm' fontWeight='500'>
                By clicking DELETE DOMAIN, you will permanently delete this DOMAIN from your
                account.
              </Text>
              <Text mt='1rem' fontSize='sm' fontWeight='500'>
                This action cannot be undone.
              </Text>
            </NoteText>
          </Note>
          <Text mt='1rem'>
            Please type{' '}
            <chakra.span my='1' fontWeight='bold'>
              DELETE
            </chakra.span>{' '}
            to continue.
          </Text>
          <InputField
            my='0.6rem'
            maxLength={40}
            onChange={(e) => handleChange(e.target.value)}></InputField>
        </ModalBody>
        <ModalFooter justifyContent='flex-start' pb='0' px='0'>
          <Button
            variant='danger'
            mr={2}
            onClick={handleDelete}
            isLoading={isLoading}
            isDisabled={!isDelete && confirmDELETE !== 'DELETE'}>
            Delete Domain
          </Button>
          <Button
            onClick={() => {
              setConfirmDELETE('');
              setIsDelete(false);
              onClose();
            }}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeleteDomainModal;
