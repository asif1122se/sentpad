import {
  Box,
  Button,
  Flex,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
} from '@chakra-ui/react';
import { InputField } from 'components';

import { useFormik } from 'formik';
import { useMutation } from 'hooks/useMutation';
import { POST } from 'utils/constants';
import { NewDomainType } from '../types';
import { domainSchema } from '../schema';
import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import QUERY_KEYS from 'utils/queryKeys';

type AddDomainModalProps = {
  isOpen: boolean;
  onClose: () => void;
};
const AddDomainModal = ({ isOpen, onClose }: AddDomainModalProps) => {
  const queryClient = useQueryClient();
  const [showSampleDomain, setShowSampleDomain] = useState<boolean>(true);
  const [validateDomain, setValidateDomain] = useState<string>('');
  const { handleSubmit, handleChange, handleReset, values, errors, touched } =
    useFormik<NewDomainType>({
      initialValues: { domain_name: '', sending_domain: '' },
      validationSchema: domainSchema,
      enableReinitialize: true,
      onSubmit: (values) =>
        mutate({
          domain_name: values.domain_name,
          sending_domain: values.sending_domain,
        }),
    });

  const { isLoading, mutate } = useMutation<NewDomainType>({
    method: POST,
    url: 'domains/create',
    onSuccess: () => {
      queryClient.invalidateQueries([QUERY_KEYS.DOMAIN_SETUP]);
      handleReset(null);
      onClose();
    },
    onError: (data) => {
      //Display Message if Domain already Existed
      if (data.errors.length > 0) setValidateDomain(data.errors[0] ?? '');
    },
    successMessage: 'Domain added successfully',
  });

  useEffect(() => {
    if (values.domain_name) {
      setValidateDomain('');
    }
    if (values.sending_domain) {
      setShowSampleDomain(values.sending_domain.length > 31 ? false : true);
    }
  }, [values.domain_name, values.sending_domain]);
  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        handleReset(null);
        setValidateDomain('');
        onClose();
      }}
      closeOnEsc={false}
      isCentered
      closeOnOverlayClick={false}>
      <ModalOverlay />
      <ModalContent maxW='540px' px='0.5rem'>
        <form onSubmit={handleSubmit}>
          <ModalHeader fontWeight='bold' color='black' fontSize='18px' lineHeight='32px'>
            Sending Domain Authentication
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Flex flexDirection='column' gap='1rem'>
              <Box>
                <InputField
                  name='domain_name'
                  size='md'
                  label='Domain Name *'
                  type='text'
                  value={values.domain_name}
                  onChange={handleChange}
                  errorText={
                    validateDomain !== ''
                      ? validateDomain
                      : touched['domain_name'] && errors['domain_name']
                      ? errors['domain_name']
                      : undefined
                  }
                  maxLength={50}
                />
                <Text mt='5px' color='gray.700' fontSize='12px'>
                  {`The name that was purchased or registered for your business. For instance, the
                  domain name for name@company.com is "company.com".`}
                </Text>
              </Box>
              <Box>
                <InputField
                  name='sending_domain'
                  size='md'
                  label='Sending Domain'
                  type='text'
                  value={values.sending_domain}
                  onChange={handleChange}
                  errorText={
                    touched['sending_domain'] && errors['sending_domain']
                      ? errors['sending_domain']
                      : undefined
                  }
                  maxLength={50}
                  icon={
                    <>
                      {showSampleDomain && (
                        <Box
                          textAlign='right'
                          minW='100px'
                          maxW='200px'
                          position='absolute'
                          right='10px'>
                          {values.domain_name && !errors['sending_domain'] && (
                            <Text color='gray.700' fontWeight='500' fontSize='sm'>
                              .{values.domain_name}
                            </Text>
                          )}
                        </Box>
                      )}
                    </>
                  }
                />
                <Text mt='5px' color='gray.700' fontSize='12px'>
                  {`The sending domain is the domain that appears in your email's "From" field. It is
                  also linked to your reputation and is used in authentication mechanisms like SPF,
                  DKIM or DMARC. In the Sending Domain field, specify the subdomain you created for
                  sending your email broadcasts.`}
                </Text>
              </Box>

              {/* <Flex>
                <Box width='50%'>
                  <InputField
                    name='from_email'
                    label='From Email *'
                    size='md'
                    type='text'
                    textAlign='right'
                    placeholder={!errors['from_email'] ? 'sample' : ''}
                    pr={!errors['from_email'] ? '' : '2rem'}
                    value={values.from_email}
                    onChange={handleChange}
                    errorText={
                      touched['from_email'] && errors['from_email']
                        ? errors['from_email']
                        : undefined
                    }
                    maxLength={50}
                  />
                </Box>

                <Flex alignItems='flex-start' pt='2.5rem' pl='0.5rem'>
                  {values.sending_domain && (
                    <Text color='gray.700' fontWeight='500' fontSize='sm'>
                      @{values.sending_domain}
                    </Text>
                  )}
                  {values.domain_name && !errors['sending_domain'] && (
                    <Text color='gray.700' fontWeight='500' fontSize='sm'>
                      .{values.domain_name}
                    </Text>
                  )}
                </Flex>
              </Flex> */}
            </Flex>
          </ModalBody>

          <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
            <Button
              type='submit'
              variant='success'
              mr='8px'
              isLoading={isLoading}
              isDisabled={!values.domain_name || validateDomain !== ''}>
              Save
            </Button>
            <Button
              onClick={() => {
                handleReset(null);
                setValidateDomain('');
                onClose();
              }}>
              Cancel
            </Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default AddDomainModal;
