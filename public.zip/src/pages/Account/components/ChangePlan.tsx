import {
  Box,
  Flex,
  Slider,
  SliderFilledTrack,
  SliderMark,
  SliderThumb,
  SliderTrack,
  Tooltip,
  Image,
  Button,
  Text,
  Badge,
  Center,
  Spinner,
} from '@chakra-ui/react';
import CheckBulletIcon from 'assets/icons/check-bullet.svg';
import { useQuery } from 'hooks/useQuery';
import { PlanContainer, PlanFooter } from 'pages/Auth/Subscription/styles';
import { AllPlans, GetAllPlans } from 'pages/Auth/Subscription/types';
import { useState } from 'react';
import { MdGraphicEq } from 'react-icons/md';
import { useNavigate } from 'react-router-dom';
import QUERY_KEYS from 'utils/queryKeys';

const formatter = Intl.NumberFormat('en-US');

type SelectedTier = {
  selected?: AllPlans;
  index: number;
};

const getButtonLabel = (currentIndex: number, selectedIndex: number) => {
  if (currentIndex === selectedIndex) {
    return 'Already Subscribed';
  }
  if (currentIndex < selectedIndex) {
    return 'Upgrade Plan';
  }
  if (currentIndex > selectedIndex) {
    return 'Downgrade Plan';
  }
};

const ChangePlan = () => {
  const [selectedTier, setSelectedTier] = useState<SelectedTier>();
  const [currentPlanIndex, setCurrentPlanIndex] = useState(0);

  const { data, isLoading, isFetching } = useQuery<GetAllPlans>({
    url: `plans/get-all-plans?auth_token=${localStorage.getItem('jwtToken')}`,
    queryKey: [QUERY_KEYS.PAYMENT_PLAN],
    onSuccess: (data) => {
      const currentPlanIndex = data?.all_plan?.findIndex((tier) =>
        data?.plan.plan_type === 'year'
          ? tier.annual_plan_id === data?.plan.id
          : tier.monthly_plan_id === data?.plan.id,
      );

      setCurrentPlanIndex(currentPlanIndex ?? 0);
      setSelectedTier({
        selected: data?.all_plan[currentPlanIndex ?? 0] ?? undefined,
        index: currentPlanIndex ?? 0,
      });
    },
  });

  const navigate = useNavigate();

  const handleSliderChange = (value: number) => {
    setSelectedTier({ selected: data?.all_plan[value] ?? undefined, index: value });
  };

  return (
    <Box p='0 4rem 4rem' width='100%'>
      {(isLoading || isFetching) && (
        <Center>
          <Spinner w='200px' h='200px' />
        </Center>
      )}
      {!isLoading && !isFetching && (
        <>
          <Text fontWeight='bold' mb='8px'>
            Billing
          </Text>
          <Text>
            Your current plan is:{' '}
            <strong>
              {formatter.format(data?.plan.subscribers ?? 0)} Contacts, $
              {formatter.format(parseFloat(data?.plan.cost ?? '0'))}/
              {data?.plan.plan_type === 'year' ? 'yr' : 'mo'}
            </strong>
          </Text>
          <Box w='700px' mt='88px'>
            <Slider
              id='slider'
              min={0}
              max={data?.all_plan ? data.all_plan.length - 1 : 0}
              value={selectedTier?.index ?? 0}
              onChange={handleSliderChange}>
              <SliderMark
                value={0}
                mt='4'
                ml='-2.0'
                fontSize='12px'
                color='gray.600'
                fontWeight='500'>
                {formatter.format(data?.all_plan[0]?.subscribers ?? 0)} Contacts
              </SliderMark>
              <SliderMark
                value={data?.all_plan?.length ?? 1}
                mt='4'
                ml='-140'
                fontSize='12px'
                color='gray.600'
                fontWeight='500'
                whiteSpace='nowrap'>
                {formatter.format(data?.all_plan[data?.all_plan?.length - 1]?.subscribers ?? 1)}{' '}
                Contacts
              </SliderMark>
              <SliderTrack height='10px' borderRadius='100px' boxShadow='inset 0px 1px 1px #B2B9C3'>
                <SliderFilledTrack background='#635AC7' />
              </SliderTrack>
              <Tooltip
                hasArrow
                bg='gray.900'
                color='white'
                placement='top'
                isOpen={true}
                label={`${formatter.format(selectedTier?.selected?.subscribers ?? 0)}`}
                gutter={12}
                fontSize='12px'
                borderRadius='4px'>
                <SliderThumb boxSize={6}>
                  <Box color='purple.700' as={MdGraphicEq} />
                </SliderThumb>
              </Tooltip>
            </Slider>
            <Flex gap='34px' mt='48px'>
              <PlanContainer borderColor='black'>
                <Box>
                  <Text fontSize='20px' fontWeight='bold'>
                    Monthly
                  </Text>
                  <Text fontSize='32px' fontWeight='bold'>
                    ${formatter.format(parseFloat(selectedTier?.selected?.monthly ?? '0'))}
                  </Text>
                  <Flex mt='24px' flexDirection='column' gap='8px'>
                    <Flex>
                      <Image src={CheckBulletIcon} mr='8px' />
                      <Text>
                        {formatter.format(selectedTier?.selected?.subscribers ?? 0)} Contacts
                      </Text>
                    </Flex>
                    <Flex>
                      <Image src={CheckBulletIcon} mr='8px' />
                      <Text>Enterprise Support</Text>
                    </Flex>
                  </Flex>
                </Box>
                <PlanFooter>
                  <Button
                    variant='black'
                    width='100%'
                    isDisabled={currentPlanIndex === selectedTier?.index}
                    onClick={() =>
                      navigate(
                        `/payment?type=monthly&id=${
                          selectedTier?.selected?.monthly_plan_id
                        }&plan=${formatter.format(
                          parseFloat(selectedTier?.selected?.monthly ?? '0'),
                        )}`,
                      )
                    }>
                    {getButtonLabel(currentPlanIndex, selectedTier?.index ?? 0)}
                  </Button>
                </PlanFooter>
              </PlanContainer>
              <PlanContainer borderColor='teal.700'>
                <Box>
                  <Flex justifyContent='space-between'>
                    <Box>
                      <Text fontSize='20px' fontWeight='bold'>
                        Annual
                      </Text>
                      <Text fontSize='32px' fontWeight='bold'>
                        ${formatter.format(parseFloat(selectedTier?.selected?.annual ?? '0'))}
                      </Text>
                    </Box>
                    <Badge variant='success' textTransform='capitalize'>
                      2 Months Free
                    </Badge>
                  </Flex>
                  <Flex mt='24px' flexDirection='column' gap='8px'>
                    <Flex>
                      <Image src={CheckBulletIcon} mr='8px' />
                      <Text>Billed Annually</Text>
                    </Flex>
                    <Flex>
                      <Image src={CheckBulletIcon} mr='8px' />
                      <Text>
                        {formatter.format(selectedTier?.selected?.subscribers ?? 0)} Contacts
                      </Text>
                    </Flex>
                    <Flex>
                      <Image src={CheckBulletIcon} mr='8px' />
                      <Text>Enterprise Support</Text>
                    </Flex>
                  </Flex>
                </Box>
                <PlanFooter>
                  <Button
                    variant='success'
                    width='100%'
                    isDisabled={currentPlanIndex === selectedTier?.index}
                    onClick={() =>
                      navigate(
                        `/payment?type=yearly&id=${
                          selectedTier?.selected?.annual_plan_id
                        }&plan=${formatter.format(
                          parseFloat(selectedTier?.selected?.annual ?? '0'),
                        )}`,
                      )
                    }>
                    {getButtonLabel(currentPlanIndex, selectedTier?.index ?? 0)}
                  </Button>
                </PlanFooter>
              </PlanContainer>
            </Flex>
          </Box>
        </>
      )}
    </Box>
  );
};

export default ChangePlan;
