import {
  Box,
  Button,
  Flex,
  Image,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  useToast,
  Text,
  chakra,
  Center,
  Spinner,
} from '@chakra-ui/react';
import { useRef, useState } from 'react';
import CopyIcon from 'assets/icons/copy.svg';
import { DNSResponse, DomainConfig, DomainSetup, SPFResponse, VerifyResponse } from '../types';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { useQueryClient } from '@tanstack/react-query';

type SetupDomainModalProps = {
  isOpen: boolean;
  onClose: () => void;
  selectedRow?: DomainSetup;
  dns?: DomainConfig;
  isSPF?: boolean;
};

const SetupDomainModal = ({
  isOpen,
  onClose,
  selectedRow,
  dns,
  isSPF = false,
}: SetupDomainModalProps) => {
  const [enable, setEnable] = useState<boolean>(false);
  const [enableVerifySPF, setEnableVerifySPF] = useState<boolean>(false);
  const htmlText = useRef<HTMLDivElement | null>(null);
  const toast = useToast();
  const queryClient = useQueryClient();
  const handleCopy = (copyText: React.MutableRefObject<HTMLDivElement | null>) => {
    navigator.clipboard.writeText(copyText?.current?.textContent ?? '');
    toast({
      position: 'top-right',
      title: 'Successfully copied',
      status: 'success',
      duration: 5000,
      isClosable: true,
    });
  };

  const { data } = useQuery<DNSResponse>({
    queryKey: [QUERY_KEYS.DOMAIN_SETUP_DNS],
    url: 'domains/verify/dns-entry/' + selectedRow?.id,
    enabled: enable,
    onSuccess: (data) => {
      if (data?.message !== undefined)
        toast({
          position: 'top-right',
          title: data?.message,
          status: 'success',
          duration: 5000,
          isClosable: true,
        });
      setEnable(false);
      queryClient.invalidateQueries([QUERY_KEYS.DOMAIN_SETUP]);
      onClose();
    },
  });

  const { data: dataSPF, isFetching } = useQuery<SPFResponse>({
    queryKey: [QUERY_KEYS.DOMAIN_SETUP_SPF],
    url: `domains/spf-config/${selectedRow?.id}`,
    enabled: isSPF,
  });

  const { data: dataVerify } = useQuery<VerifyResponse>({
    queryKey: [QUERY_KEYS.DOMAIN_SETUP_VERIFY],
    url: `domains/verify-spf/${selectedRow?.id}`,
    enabled: enableVerifySPF,
    onSuccess: (data) => {
      if (data?.message === undefined)
        toast({
          position: 'top-right',
          title: 'Unable to verify SPF',
          status: 'error',
          duration: 5000,
          isClosable: true,
        });
      else
        toast({
          position: 'top-right',
          title: 'SPF successfully verified.',
          status: 'success',
          duration: 5000,
          isClosable: true,
        });

      setEnableVerifySPF(false);
      queryClient.invalidateQueries([QUERY_KEYS.DOMAIN_SETUP]);
      onClose();
    },
  });
  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        setEnableVerifySPF(false);
        setEnable(false);
        onClose();
      }}
      closeOnEsc={false}
      isCentered
      closeOnOverlayClick={false}>
      <ModalOverlay />
      <ModalContent maxW='640px' px='0.5rem'>
        <ModalHeader pb='0' fontWeight='bold' color='black' fontSize='18px' lineHeight='32px'>
          Verify {!isSPF ? 'DNS Entry' : 'SPF'}
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          {isFetching ? (
            <Center>
              <Spinner />
            </Center>
          ) : (
            <>
              <Text my='5px'>
                {!isSPF ? (
                  <>
                    Create the following DNS entry for{' '}
                    <chakra.span fontWeight='bold'>{selectedRow?.domain_name}</chakra.span>
                    <Text mb='5px'>
                      Name field:{' '}
                      <chakra.span fontWeight='bold'>{dns?.selector}._domainkey</chakra.span>
                    </Text>
                  </>
                ) : (
                  <>
                    <Text>{dataSPF?.message}</Text>
                    <Text>Name Field: {dataSPF?.name_field}</Text>
                    <Text>Type: {dataSPF?.type_field}</Text>
                  </>
                )}
              </Text>
              {!(isSPF && dataSPF?.spf_text === undefined) && (
                <>
                  <Flex position='relative'>
                    <Box
                      ref={htmlText}
                      borderRadius='4px'
                      border='1px solid'
                      borderColor='gray.600'
                      fontSize='14px'
                      padding='18px 32px 24px 24px'
                      position='relative'
                      color='black'
                      maxH='250px'
                      width='100%'
                      overflow='auto'>
                      {!isSPF ? dns?.dns_entry : dataSPF?.spf_text}
                    </Box>
                    <Image
                      onClick={() => handleCopy(htmlText)}
                      cursor='pointer'
                      zIndex={1}
                      position='absolute'
                      right='10px'
                      top='5px'
                      src={CopyIcon}
                      alt='Copy Icon'
                    />
                  </Flex>
                  {/* {dataSPF?.updated_spf_text && (
                    <Text>The SPF record should look like this when updated:</Text>
                  )}
                  <Text>{dataSPF?.updated_spf_text}</Text> */}
                </>
              )}
            </>
          )}
        </ModalBody>
        <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
          <Button
            variant='success'
            mr='8px'
            isDisabled={isSPF && dataSPF?.spf_text === undefined}
            onClick={() => {
              !isSPF ? setEnable(true) : setEnableVerifySPF(true);
            }}>
            Verify
          </Button>
          <Button
            onClick={() => {
              onClose();
            }}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default SetupDomainModal;
