import {
  Box,
  Center,
  chakra,
  Flex,
  ListItem,
  Spinner,
  Text,
  UnorderedList,
} from '@chakra-ui/react';
import { useState } from 'react';
import { StyledSwitch } from '../styles';
import { POST } from 'utils/constants';
import { useMutation } from 'hooks/useMutation';
import { OptInSettings } from '../types';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';

const OptInSettingsPage = () => {
  const [isActive, setIsActive] = useState<boolean>();
  const {
    data,
    isLoading: OptInLoading,
    isFetching,
  } = useQuery<OptInSettings>({
    url: 'get-optin-setting',
    queryKey: [QUERY_KEYS.OPT_IN_SETTINGS],
    onSuccess: (data) => {
      setIsActive(data?.optin_setting === 1);
    },
  });

  const { isLoading, mutate: handleSwitch } = useMutation<{ optin_setting: number }>({
    method: POST,
    url: 'save-optin-setting',
  });

  return (
    <Box width='100%'>
      <Box p='0' width='90%' maxW='1000px'>
        <Text fontSize='20px' fontWeight='bold'>
          Opt in Settings
        </Text>
        <Flex my='30px' gap='1rem' justifyContent='space-between' alignItems='center'>
          {data === null || data === undefined ? (
            <Center width='100%' mt='4rem'>
              <Spinner w='200px' h='200px' />
            </Center>
          ) : (
            <>
              <Box pr='3rem'>
                <Text fontWeight='bold'>Double Opt in</Text>
                <Text fontSize='sm'>
                  Configure how contacts will be subscribed to a list. This applies to manual entry,
                  bulk upload, and form submissions.
                </Text>
                <UnorderedList
                  pl='1rem'
                  fontWeight='normal'
                  color='#000000'
                  my='1rem'
                  spacing='1rem'
                  fontSize='sm'
                  textAlign='justify'>
                  <ListItem>
                    <chakra.span fontWeight='semibold'>Active: Double opt in</chakra.span> - Send a
                    subscription confirmation email to the contact after they are added to Sendpad.
                    The contact will need to click the confirm button on the email to become
                    subscribed.
                  </ListItem>
                  <ListItem>
                    <chakra.span fontWeight='semibold'>Inactive: Single opt in </chakra.span>-
                    Contact is immediately subscribed to the selected list. For manual entry and
                    bulk upload, assumes that confirmation to subscribe has already been secured
                    before adding the contact. For form submission, the submit action serves as the
                    confirmation to subscribe.
                  </ListItem>
                </UnorderedList>
              </Box>

              <Flex
                minW='150px'
                width='30%'
                alignItems='center'
                gap='0.5rem'
                justifyContent='right'>
                {isLoading ? (
                  <Center width='100%'>
                    <Spinner w='20px' h='20px' />
                  </Center>
                ) : (
                  <>
                    <Text fontWeight='500'>{isActive ? 'Active' : 'Inactive'}</Text>
                    <StyledSwitch
                      size='lg'
                      onChange={(e) => {
                        handleSwitch({ optin_setting: e.target.checked ? 1 : 0 });
                        setIsActive(!isActive);
                      }}
                      isChecked={isActive}
                    />
                  </>
                )}
              </Flex>
            </>
          )}
        </Flex>
      </Box>
    </Box>
  );
};

export default OptInSettingsPage;
