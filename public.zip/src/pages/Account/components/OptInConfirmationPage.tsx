import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import Info from 'assets/icons/info-green.svg';
import { chakra, Flex, Image, Text } from '@chakra-ui/react';

const OptInConfirmationPage = () => {
  return (
    <>
      <Flex m='1rem' justifyContent='center'>
        <Flex mt='3%' width='fit-content' flexDirection='column' gap='3rem'>
          <Image src={SendpadLogInLogo} width='230px' />
          <Flex
            border='1px solid #00BF9C'
            borderRadius='4px'
            p='10px 1rem'
            gap='1.5rem'
            alignItems='center'>
            <Image src={Info} />
            <Text fontSize='sm' color='#00BF9C'>
              <chakra.span fontWeight='bold'> Thank you for confirming.</chakra.span> You will now
              receive our emails.
            </Text>
          </Flex>
        </Flex>
      </Flex>
    </>
  );
};

export default OptInConfirmationPage;
