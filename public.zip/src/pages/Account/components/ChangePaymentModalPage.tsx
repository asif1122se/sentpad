import {
  Box,
  Button,
  Divider,
  Flex,
  Image,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalHeader,
  ModalOverlay,
  Text,
} from '@chakra-ui/react';
import { Field, Form, Formik } from 'formik';
import Stripe from 'assets/icons/stripe.png';
import CardIcon from 'assets/icons/card-small.png';
import CalendarIcon from 'assets/icons/calendar-small.png';
import InfoIcon from 'assets/icons/info-square-small.png';
import { InputField, Select } from 'components';
import { useMemo } from 'react';
import countryList from 'react-select-country-list';

type Props = {
  isOpen: boolean;
  onClose: () => void;
};
const ChangePaymentModalPage = ({ isOpen, onClose }: Props) => {
  const countries: Array<{ label: string; value: string }> = useMemo(
    () => countryList().getData(),
    [],
  );
  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered size='lg'>
      <ModalOverlay />
      <ModalContent p='30px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            Billing Information
          </Text>
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody px='0'>
          <Formik
            initialValues={{
              card_name: '',
              card_no: '',
            }}
            onSubmit={() => alert('save')}>
            <Form>
              <Flex flexDirection='column' gap='0.5rem'>
                <Box mt='0.8rem'>
                  <Field
                    as={InputField}
                    size='md'
                    label='Card Number'
                    placeholder='0000 0000 0000 0000'
                    name='card_no'
                    icon={<Image src={CardIcon} alt='Card' />}
                  />
                </Box>
                <Box mt='1rem'>
                  <Field
                    as={InputField}
                    size='md'
                    label='Card Holder Name'
                    placeholder='Enter card holder’s name'
                    name='card_name'
                  />
                </Box>
                <Flex gap='1rem' my='1rem'>
                  <Box width='65%'>
                    <Field
                      as={InputField}
                      size='md'
                      label='Expiry Date'
                      placeholder='MM'
                      name='expiry_date'
                      icon={<Image src={CalendarIcon} alt='Calendar' />}
                    />
                  </Box>
                  <Box width='35%'>
                    <Field
                      as={InputField}
                      size='md'
                      label='CVV'
                      type='text'
                      placeholder='000'
                      name='cvv'
                      icon={<Image src={InfoIcon} alt='Info' />}
                    />
                  </Box>
                </Flex>
                <Box mb='1rem'>
                  <Field
                    as={InputField}
                    label='Address'
                    type='text'
                    placeholder='Enter address'
                    name='address'
                    size='md'
                  />
                </Box>
                <Flex gap='1rem' mb='1rem'>
                  <Field
                    as={InputField}
                    label='City'
                    type='text'
                    placeholder='Enter city'
                    name='city'
                    size='md'
                  />
                  <Field
                    as={InputField}
                    label='Zip Code'
                    type='text'
                    placeholder='Enter zip code'
                    name='zip'
                    size='md'
                  />
                  <Field
                    as={InputField}
                    label='State'
                    type='text'
                    placeholder='Enter state'
                    name='state'
                    size='md'
                  />
                </Flex>
                <Flex gap='1rem' mb='1rem' width='100%'>
                  <Box width='100%'>
                    <Select name='country' label='Country' size='md'>
                      <option value=''>Select country</option>
                      {countries.map(({ label, value }) => (
                        <option key={value} value={label}>
                          {label}
                        </option>
                      ))}
                    </Select>
                  </Box>
                </Flex>
                <Box>
                  <Flex gap='2' justifyContent='center' alignItems='center' my='3'>
                    <Text fontSize='12px'>Powered by</Text>
                    <Image src={Stripe} width='60px' />
                  </Flex>
                  <Button width='100%' variant='success' type='submit' mt='1'>
                    Update
                  </Button>
                </Box>
              </Flex>
            </Form>
          </Formik>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default ChangePaymentModalPage;
