import { Badge, Box, Button, Flex, Image, Progress, Text, useDisclosure } from '@chakra-ui/react';
import { DataTable } from 'components';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import Download from 'assets/icons/download.svg';
import CreditCard from 'assets/icons/credit-card.svg';
import Check from 'assets/icons/check-success-small.png';
import { Invoices, InvoiceList, AmemberBillingTypes } from '../types';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { ColumnProps } from 'types';
import { useState } from 'react';
import { format } from 'date-fns';
import ChangePaymentModalPage from './ChangePaymentModalPage';
import { useNavigate } from 'react-router-dom';
import { ROUTE_PATHS } from 'router';
import { amemberBillingApi } from 'services/apis/subscription';

const BillingPage = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const columnHelper = createColumnHelper<Invoices>();
  const [searchedValue, setSearchedValue] = useState<string>('');
  const [rowSelection, setRowSelection] = useState<{ [key: number]: boolean }>({});
  const [amemberBillingData, setAmemberBillingData] = useState<AmemberBillingTypes>();
  const [progressValue, setProgressValue] = useState<number>(0);
  const { data, isLoading, isFetching } = useQuery<InvoiceList>({
    url: 'plans/billing-page',
    queryKey: [QUERY_KEYS.INVOICES],
    onSuccess: (data) => {
      data?.plan_id && getAmemberData(data);
    },
  });

  const navigate = useNavigate();

  const contactColProps: ColumnProps[] = [
    {
      align: 'left',
      paddingX: '4px',
      paddingLeft: '2%',
    },
    {
      align: 'left',
      paddingX: '3px',
    },
    {
      align: 'left',
      paddingX: '3px',
    },
    {
      align: 'left',
      paddingX: '3px',
    },
    {
      align: 'right',
      paddingX: '5px',
    },
  ];

  const columns = [
    columnHelper.display({
      id: 'plan',
      header: 'Plan name',
      cell: () => (
        <>
          <Flex>
            <Text fontSize='sm' fontWeight='semibold'>
              {data?.invoices[0]?.plan_name?.split(' (')[0]}
            </Text>
            <Text ml='1'>{`(${data?.invoices[0]?.plan_name?.split(' (')[1]}`}</Text>
          </Flex>
        </>
      ),
    }),
    columnHelper.display({
      id: 'date',
      header: 'Date',
      cell: () => (
        <Text fontSize='sm'>
          {data?.invoices[0]?.date &&
            format(new Date(`${data?.invoices[0]?.date}`), 'MMM d, yyyy h:mm:a')}
        </Text>
      ),
    }),

    columnHelper.display({
      id: 'amount',
      header: 'Amount',
      cell: () => <Text fontSize='sm'>${data?.invoices[0]?.amount ?? 0}</Text>,
    }),

    columnHelper.display({
      id: 'status',
      header: 'Status',
      cell: () => (
        <>
          <Flex alignItems='center' fontSize='sm'>
            <Image src={Check} /> {data?.invoices[0]?.status}
          </Flex>
        </>
      ),
    }),

    columnHelper.display({
      id: 'action',
      cell: () => <Image src={Download} boxSize='5' color='gray.500' cursor='pointer' />,
    }),
  ];

  const handleGetSearchValue = (data: string) => {
    setSearchedValue(data);
  };

  const getAmemberData = async (billingRes: any) => {
    const result = await amemberBillingApi(billingRes?.plan_id);
    if (result?.msg === 'found') {
      setAmemberBillingData(result?.payload);
      if (billingRes?.used_contacts > 0) {
        const barvalue1 = billingRes?.used_contacts / 1000;
        const barvalue2 = barvalue1 * 100;
        setProgressValue(barvalue2);
      } else {
        setProgressValue(100);
      }
    }
  };

  return (
    <Box p='0 4rem 4rem 0' width='100%'>
      <ChangePaymentModalPage isOpen={isOpen} onClose={onClose} />
      <Text fontSize='lg' fontWeight='bold' mb='5'>
        Subscription Plan
      </Text>
      <Box>
        <Flex alignItems='flex-start' gap='1rem'>
          <Box p='3' width='100%' border='1px solid #D2D8DE' borderRadius='8px' fontSize='14px'>
            <Flex justifyContent='space-between'>
              <Flex gap='3'>
                <Text fontWeight='bold' mt='2.5px'>
                  Plan Details
                </Text>
                {/* <Badge variant='dangerOutlined' textTransform='capitalize' fontSize='12px'>
                  Inactive Plan
                </Badge> */}
                <Badge variant='successOutlined' textTransform='capitalize' fontSize='12px'>
                  Active Plan
                </Badge>
              </Flex>
              {/* <Flex gap='2'>
                <Button variant='default' size='sm' fontSize='12px'>
                  Cancel Plan
                </Button>
                <Button
                  variant='success'
                  size='sm'
                  fontSize='12px'
                  onClick={() =>
                    navigate(`${ROUTE_PATHS.ACCOUNT_SETTINGS}/${ROUTE_PATHS.CHANGE_PLAN}`)
                  }>
                  Change Plan
                </Button>
              </Flex> */}
            </Flex>
            <Flex my='3' gap='9rem'>
              <Box mt='3'>
                <Text fontSize='11px' color='gray.700' fontWeight='semibold'>
                  COST
                </Text>
                <Text fontWeight='bold'>
                  ${amemberBillingData?.price}/{amemberBillingData?.price_tag}
                </Text>
              </Box>
              <Box mt='3' ml='-2'>
                <Text fontSize='11px' color='gray.700' fontWeight='semibold'>
                  TIER
                </Text>
                <Text fontWeight='500'>{amemberBillingData?.contacts}</Text>
              </Box>
              <Box mt='3' ml='-5'>
                <Text fontSize='11px' color='gray.700' fontWeight='semibold'>
                  ACTIVATED ON
                </Text>
                <Text fontWeight='500'>
                  {data?.activation_on && format(new Date(`${data?.activation_on}`), 'MMM d, yyyy')}
                </Text>
              </Box>
            </Flex>
            <Box mt='8'>
              <Flex alignItems='center' gap='2' mb='1'>
                <Text fontWeight='bold' lineHeight='16px'>
                  Current Plan
                </Text>
                <Text fontSize='11px' color='gray.700'>
                  {data?.used_contacts} / {amemberBillingData?.subscribers}
                </Text>
              </Flex>
              <Box width='100%' background='#E8EBEE'>
                <Progress
                  colorScheme='green'
                  size='md'
                  value={100 - progressValue === 0 ? 100 : 100 - progressValue}
                />
              </Box>
            </Box>
          </Box>
          {/* <Box p='3' fontSize='14px' minWidth='260px' border='1px solid #008CE3' borderRadius='8px'>
            <Flex alignItems='center' mb='3' gap='2'>
              <Image src={CreditCard} boxSize='20px' />
              <Text fontWeight='bold'>Credit Card</Text> 
            </Flex> */}
          {/* <Text fontWeight='semibold'>•••• •••• •••• 8323</Text> */}
          {/* <Flex gap='3' color='gray.900'>
              <Text>••••</Text> <Text>••••</Text>
              <Text>••••</Text> {data?.cardLast4 ?? '0000'}
            </Flex>
            <Text fontSize='12px' color='gray.700'>
              Added:{' '}
              {data?.activation_on && format(new Date(`${data?.activation_on}`), 'MMM d, yyyy')}
            </Text>
            <Button fontSize='12px' mt='5' variant='infoOutlined' size='sm' onClick={onOpen}>
              Change Method
            </Button>
          </Box> */}
        </Flex>

        {/* <Box mt='8' alignItems='flex-start'>
          <Text fontSize='lg' fontWeight='bold' float='left'>
            Invoices
          </Text>
          <DataTable
            columns={columns}
            data={data?.invoices}
            getValue={handleGetSearchValue}
            showFilters={false}
            showSearch={false}
            colProps={contactColProps}
            rowSelection={rowSelection}
            setRowSelection={setRowSelection}
            emptyMessage={'No invoice(s) found'}
            rightToolbar={<Box height='35px' />}
          />
        </Box> */}
      </Box>
    </Box>
  );
};

export default BillingPage;
