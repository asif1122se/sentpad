import { Button } from '@chakra-ui/button';
import { Box, Center, Flex, Text } from '@chakra-ui/layout';
import { DataTable } from 'components';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { DKIMResponse, DomainConfig, DomainSetup, DomainSetupList, DomainType } from '../types';
import CheckSuccess from 'assets/icons/check-success-small.png';
import XFailed from 'assets/icons/x-small.png';
import Garbage from 'assets/icons/trash.svg';
import { ColumnProps } from 'types';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { Image } from '@chakra-ui/image';
import { useState } from 'react';
import { chakra, Link, Spinner, useDisclosure, useToast } from '@chakra-ui/react';
import AddDomainModal from './AddDomainModal';
import DeleteDomainModal from './DeleteDomainModal';
import SetupDomainModal from './SetupDomainModal';
import { useQueryClient } from '@tanstack/react-query';
import InfoIcon from 'assets/icons/info.svg';
import { SmallCloseIcon } from '@chakra-ui/icons';
import { HelpButton } from '../styles';

const DomainSetupPage = () => {
  const [dkimID, setDKIMID] = useState<number>(0);
  const {
    isOpen: isAddDomainOpen,
    onOpen: onAddDomainOpen,
    onClose: onAddDomainClose,
  } = useDisclosure();
  const {
    isOpen: isDeleteDomainOpen,
    onOpen: onDeleteDomainOpen,
    onClose: onDeleteDomainClose,
  } = useDisclosure();
  const {
    isOpen: isSetupDomainOpen,
    onOpen: onSetupDomainOpen,
    onClose: onSetupDomainClose,
  } = useDisclosure();
  const {
    isOpen: isSenderDomainOpen,
    onOpen: onSenderDomainOpen,
    onClose: onSenderDomainClose,
  } = useDisclosure();
  const columnHelper = createColumnHelper<DomainSetup>();
  const [selectedRow, setSelectedRow] = useState<DomainSetup>();
  const [isSPF, setIsSPF] = useState<boolean>(false);
  const queryClient = useQueryClient();
  const toast = useToast();

  const { data, isLoading, isFetching } = useQuery<DomainSetupList>({
    url: 'domains/list',
    queryKey: [QUERY_KEYS.DOMAIN_SETUP],
  });

  const { data: dataCONFIG } = useQuery<DomainConfig>({
    queryKey: [QUERY_KEYS.DOMAIN_SETUP_CONFIG],
    url: 'domains/get/domain-config',
  });

  const { data: dataDKIM } = useQuery<DKIMResponse>({
    queryKey: [QUERY_KEYS.DOMAIN_SETUP_DKIM],
    url: 'domains/create-dkim/' + dkimID,
    enabled: dkimID === 0 ? false : true,
    onSuccess: (data) => {
      toast({
        position: 'top-right',
        title: data?.message,
        status: 'success',
        duration: 5000,
        isClosable: true,
      });
      setDKIMID(0);
      queryClient.invalidateQueries([QUERY_KEYS.DOMAIN_SETUP]);
    },
  });

  const ColProps: ColumnProps[] = [
    {
      align: 'left',
    },
    {
      align: 'left',
    },
    {
      align: 'center',
    },
    {
      align: 'center',
    },
    {
      align: 'left',
      paddingX: '3px',
    },
  ];

  const columns = [
    columnHelper.display({
      id: 'domain_name',
      header: 'Root Domain',
      cell: (props: CellContext<DomainSetup, unknown>) => (
        <Text fontWeight='semibold'>{props.row?.original.domain_name}</Text>
      ),
    }),
    columnHelper.display({
      id: 'sending_domain',
      header: 'Sending Domain',
      cell: (props: CellContext<DomainSetup, unknown>) => (
        <Text fontWeight='500'>{props.row?.original.sending_domain}</Text>
      ),
    }),
    columnHelper.display({
      header: 'Setup Status',
      cell: (props: CellContext<DomainSetup, unknown>) => (
        <Flex fontWeight='500' alignItems='center' flexWrap='nowrap' width='fit-content'>
          <Flex width='120px' justifyContent='center'>
            {!props.row?.original.is_dns_entry_verified ? (
              <Button
                variant='dangerOutlined'
                size='sm'
                fontWeight='500'
                fontSize='12px'
                onClick={() => {
                  setSelectedRow(props.row.original);
                  onSetupDomainOpen();
                }}>
                Verify DNS
              </Button>
            ) : (
              <>
                <Image
                  src={props.row?.original.is_dns_entry_verified ? CheckSuccess : XFailed}
                  boxSize='5'
                />
                <Text color={props.row?.original.is_dns_entry_verified ? '#000000' : '#929BA8'}>
                  DNS Verified
                </Text>
              </>
            )}
          </Flex>
          <Flex width='130px' justifyContent='center'>
            {props.row?.original.is_dns_entry_verified && !props.row?.original.is_dkim_created ? (
              <Button
                variant='dangerOutlined'
                size='sm'
                fontWeight='500'
                fontSize='12px'
                onClick={() => {
                  setDKIMID(props.row.original.id);
                }}>
                Create DKIM
              </Button>
            ) : (
              <>
                <Image
                  src={props.row?.original.is_dkim_created ? CheckSuccess : XFailed}
                  boxSize='5'
                />
                <Text color={props.row?.original.is_dkim_created ? '#000000' : '#929BA8'}>
                  DKIM Created
                </Text>
              </>
            )}
          </Flex>
          <Flex width='120px' justifyContent='center'>
            {props.row?.original.is_dns_entry_verified &&
            props.row?.original.is_dkim_created &&
            !props.row?.original.is_spf_verified ? (
              <Button
                variant='dangerOutlined'
                size='sm'
                fontWeight='500'
                fontSize='12px'
                onClick={() => {
                  setSelectedRow(props.row.original);
                  setIsSPF(true);
                  onSetupDomainOpen();
                }}>
                Verify SPF
              </Button>
            ) : (
              <>
                <Image
                  src={props.row?.original.is_spf_verified ? CheckSuccess : XFailed}
                  boxSize='5'
                />
                <Text color={props.row?.original.is_spf_verified ? '#000000' : '#929BA8'}>
                  SPF Verified
                </Text>
              </>
            )}
          </Flex>
        </Flex>
      ),
    }),
    columnHelper.display({
      header: () => {
        return (
          <Flex
            width='fit-content'
            flexWrap='nowrap'
            gap='3px'
            title='Shows if a domain is currently used in a sender profile.'
            cursor='default'>
            <chakra.span whiteSpace='pre' m='0'>
              Linked to Profile
            </chakra.span>{' '}
            <Image boxSize='4' src={InfoIcon} />
          </Flex>
        );
      },
      id: 'action',
      cell: (props: CellContext<DomainSetup, unknown>) => (
        <Flex justifyContent='center'>
          {!!!props.row.original.can_delete ? (
            <Image src={CheckSuccess} />
          ) : (
            <SmallCloseIcon ml='-3px' boxSize='5' color='red.700' />
          )}
        </Flex>
      ),
    }),
    columnHelper.display({
      id: 'action',
      cell: (props: CellContext<DomainSetup, unknown>) => (
        <Image
          mr='1rem'
          filter={props.row.original.can_delete ? 'none' : 'opacity(30%)'}
          src={Garbage}
          boxSize='5'
          cursor={props.row.original.can_delete ? 'pointer' : 'default'}
          title={
            props.row.original.can_delete ? 'Delete domain?' : 'You cannot delete this domain.'
          }
          onClick={() => {
            setSelectedRow(props.row.original);
            props.row.original.can_delete ? onDeleteDomainOpen() : null;
          }}
        />
      ),
    }),
  ];
  return (
    <Box p='0' m='0' width='100%'>
      <AddDomainModal isOpen={isAddDomainOpen} onClose={onAddDomainClose} />
      <DeleteDomainModal
        isOpen={isDeleteDomainOpen}
        onClose={onDeleteDomainClose}
        selectedRow={selectedRow}
      />
      <SetupDomainModal
        isOpen={isSetupDomainOpen}
        onClose={() => {
          onSetupDomainClose();
          setIsSPF(false);
        }}
        selectedRow={selectedRow}
        dns={dataCONFIG}
        isSPF={isSPF}
      />
      {isLoading || isFetching ? (
        <Center width='100vh'>
          <Spinner boxSize='20' />
        </Center>
      ) : (
        <>
          <Flex justifyContent='space-between' alignItems='center' mb='1rem'>
            <Text fontSize='20px' fontWeight='bold'>
              Domain Setup
            </Text>

            <Button variant='black' onClick={onAddDomainOpen}>
              Add Domain
            </Button>
          </Flex>
          <Box>
            <DataTable
              columns={columns}
              getValue={() => null}
              data={data}
              showFilters={false}
              showSearch={false}
              showPagination={false}
              colProps={ColProps}
              emptyMessage={'No domain(s) found'}
            />
          </Box>
          {/* <Flex flexDirection='column' my='3rem'>
            <Text fontSize='20px' fontWeight='bold' mb='0.5rem'>
              Help Documents
            </Text>
            <Link color='blue.700' my='0'>
              <HelpButton
                variant='none'
                onClick={() =>
                  window.open(
                    'https://docs.google.com/document/d/1gM6W0_T49kHuSlA0jTnqlCleCBtFqqtsI5y6xvbIRgs/edit',
                    '_blank',
                  )
                }>
                Configuring GoDaddy domains in SendPad
              </HelpButton>
            </Link>
            <Link color='blue.700' my='0'>
              <HelpButton
                variant='none'
                onClick={() =>
                  window.open(
                    'https://docs.google.com/document/d/1LFL2xfIVKMrv9NCStoAjrqmetM_xVfWYv1x3n8I5Xho/edit',
                    '_blank',
                  )
                }>
                Configuring Float Hosting domains in SendPad
              </HelpButton>
            </Link>
          </Flex> */}
        </>
      )}
    </Box>
  );
};

export default DomainSetupPage;
