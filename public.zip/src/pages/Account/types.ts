import { TrueOrFalse } from 'types';

export type Invoices = {
  amount: string;
  created_at: string;
  date: string;
  id: number;
  invoice_stripe_id: string;
  plan_name: string;
  status: string;
  updated_at: string;
  user_id: number;
};

export type SelectedPlan = {
  cost: string;
  tier: string;
  activation_on: string;
  user_contacts: string;
  cardLast4: string;
};

export type InvoiceList = {
  invoices: Invoices[];
  cost: number;
  tier: number;
  activation_on: string;
  used_contacts: number;
  cardLast4: string;
  plan_type: string;
  plan_id: string;
};

export type NewDomainType = {
  domain_name: string;
  sending_domain: string;
};

export type DomainSetup = {
  id: number;
  domain_name: string;
  sending_domain: string;
  from_email: string;
  is_dkim_created: TrueOrFalse;
  is_dns_entry_verified: TrueOrFalse;
  is_mx_record_exists: TrueOrFalse;
  is_spf_verified: TrueOrFalse;
  is_sender_enabled: TrueOrFalse;
  can_delete: boolean;
};

export type DomainSetupList = DomainSetup[];

export type DomainConfig = {
  dns_entry: string;
  selector: string;
};

export type DomainType = {
  domains: DomainSetupList;
  domain_configs: DomainConfig;
};

export type DNSResponse = {
  message: string;
};
export type DKIMResponse = {
  message: string;
};

export type SPFResponse = {
  domain: string;
  current_spf_settings: string;
  message: string;
  spf_text: string;
  name_field: string;
  type_field: string;
  updated_spf_text: string;
};

export type VerifyResponse = {
  message: string;
};

export type AmemberBillingTypes = {
  price: string;
  contacts: string;
  subscribers: number;
  price_tag: string;
};

export type OptInSettings = {
  id: number;
  optin_setting: number;
};
