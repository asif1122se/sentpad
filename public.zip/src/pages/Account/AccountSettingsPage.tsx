import { Box, Flex, Text, Image } from '@chakra-ui/react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import BackArrowIcon from 'assets/icons/arrow-back.svg';
import { NavItem } from './styles';
import BillingIcon from 'assets/icons/navigation/billing.svg';
import DomainSetupIcon from 'assets/icons/navigation/domain-setup.svg';
import UsersIcon from 'assets/icons/navigation/users.svg';

import BillingActiveIcon from 'assets/icons/navigation/billing-active.svg';
import DomainSetupActiveIcon from 'assets/icons/navigation/domain-setup-active.svg';
import UsersActiveIcon from 'assets/icons/navigation/users-active.svg';

import { ROUTE_PATHS } from 'router';

const AccountSettingsPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const path = location.pathname.split('/account-settings/');

  const GENERAL = [
    {
      icon: BillingIcon,
      iconActive: BillingActiveIcon,
      label: 'Billing',
      url: ROUTE_PATHS.BILLING,
      active: [ROUTE_PATHS.BILLING, ROUTE_PATHS.CHANGE_PLAN].indexOf(path[1]) >= 0,
    },
    {
      icon: DomainSetupIcon,
      iconActive: DomainSetupActiveIcon,
      label: 'Domain Setup',
      url: ROUTE_PATHS.DOMAIN_SETUP,
      active: [ROUTE_PATHS.DOMAIN_SETUP].indexOf(path[1]) >= 0,
    },
    {
      icon: UsersIcon,
      iconActive: UsersActiveIcon,
      label: 'Opt in Settings',
      url: ROUTE_PATHS.OPT_IN,
      active: [ROUTE_PATHS.OPT_IN].indexOf(path[1]) >= 0,
    },
  ];

  return (
    <Box p='48px'>
      <Flex flexDir='column' gap='4rem'>
        <Flex>
          <Image
            src={BackArrowIcon}
            width='36px'
            onClick={() => navigate(-1)}
            cursor='pointer'
            mr='12px'
          />
          <Text fontSize='24px' fontWeight='bold'>
            My Account
          </Text>
        </Flex>
        <Flex gap='0'>
          <Flex flexDir='column' width='226px'>
            <Flex flexDir='column'>
              {GENERAL.map(({ active, icon, iconActive, label, url }, index) => (
                <NavItem key={index} active={active} to={url}>
                  <Image src={active ? iconActive : icon} alt={label} />
                  {label}
                </NavItem>
              ))}
            </Flex>
          </Flex>
          <Outlet />
        </Flex>
      </Flex>
    </Box>
  );
};

export default AccountSettingsPage;
