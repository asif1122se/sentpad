import * as Yup from 'yup';
export const domainSchema = Yup.object().shape({
  domain_name: Yup.string()
    .required('Domain name is required.')
    .nullable()
    .max(50, 'Domain name must not exceed 50 characters'),
  sending_domain: Yup.string().nullable().max(50, 'Sending domain must not exceed 50 characters'),
});
