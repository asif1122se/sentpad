import { Box, Flex, Image, Text } from '@chakra-ui/react';
import SendPadLogo from 'assets/images/sendpad-logo.svg';

const MaintenancePage = () => {
  return (
    <Flex justifyContent='center'>
      <Flex
        flexDirection='column'
        p='3rem'
        mt='10%'
        borderRadius='12px'
        width='fit-content'
        textAlign='center'>
        <Flex alignItems='center' justifyContent='center' flexDirection='column' gap='2rem'>
          <Image src={SendPadLogo} alt='SendPad Logo' height='80px' />
          <Text fontSize='56px' fontWeight='semibold' whiteSpace='pre-line'>
            {`The SendPad web app is currently \ndown for maintenance.`}
          </Text>
          <Text fontSize='30px' fontWeight='semibold'>
            We will be back shortly.
          </Text>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default MaintenancePage;
