import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { PageContainer } from 'components/Layout';
import { ContactInsights, ContactSummary, DailyInsights, EmailSummary } from './components';
import { format } from 'date-fns';
import { displayGreeting } from 'utils';
import { useState } from 'react';
import { TIME_PERIOD } from './consts';

const DashboardTestPage = () => {
  const currentDate = new Date();
  const [type, setTypes] = useState<string>(TIME_PERIOD[0].value);
  return (
    <Box position='relative'>
      <PageContainer pb='100px'>
        <Flex justifyContent='space-between'>
          <Box>
            <Text>{format(currentDate, 'EEEE, MMMM d')}</Text>
            {/* <Heading as='h3' size='h3' fontWeight='bold'>
              {displayGreeting(currentDate)}, {localStorage.getItem('email')}
            </Heading> */}
          </Box>
        </Flex>
        <DailyInsights type={type} />
        <ContactSummary />
        <ContactInsights setTypes={setTypes} />
        <EmailSummary />
      </PageContainer>
    </Box>
  );
};

export default DashboardTestPage;
