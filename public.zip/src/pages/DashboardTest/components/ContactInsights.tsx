import { Flex, Text, Grid, Box, Select, Spinner } from '@chakra-ui/react';
import { BlockTitle, ContactInsight, ContactInsightsBlock, SectionTitle } from '../styles';
import GrowthGraph from '../components/GrowthGraph';
import OpensAndClicksGraph from '../components/OpensAndClicksGraph';
import { useState } from 'react';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { GrowthDataList, ContactInsightsNumbers, OpensClicksDataList } from '../types';
import { TIME_PERIOD } from '../consts';

type Prop = {
  setTypes: React.Dispatch<React.SetStateAction<string>>;
};

const ContactInsights = ({ setTypes }: Prop) => {
  const [insightTypes, setInsightTypes] = useState<string>(TIME_PERIOD[0].value);
  const arrIndex = insightTypes as unknown as number;
  setTypes(insightTypes);
  const opensclicksData = [
    [
      { subscribed_date: '2022-12-12', total: 180, opens: 93, clicks: 87 },
      { subscribed_date: '2022-12-13', total: 131, opens: 121, clicks: 110 },
      { subscribed_date: '2022-12-14', total: 120, opens: 105, clicks: 97 },
      { subscribed_date: '2022-12-15', total: 167, opens: 138, clicks: 103 },
      { subscribed_date: '2022-12-16', total: 105, opens: 71, clicks: 30 },
      { subscribed_date: '2022-12-17', total: 113, opens: 102, clicks: 95 },
      { subscribed_date: '2022-12-18', total: 150, opens: 147, clicks: 131 },
    ],
    [
      { subscribed_date: '2022-11-21', total: 1121, opens: 1053, clicks: 1007 },
      { subscribed_date: '2022-11-28', total: 1230, opens: 1219, clicks: 1033 },
      { subscribed_date: '2022-12-05', total: 1322, opens: 1211, clicks: 1051 },
      { subscribed_date: '2022-12-12', total: 1448, opens: 1333, clicks: 1106 },
    ],
    [
      { subscribed_date: '2022-10-01', total: 12501, opens: 11938, clicks: 11080 },
      { subscribed_date: '2022-11-01', total: 13017, opens: 12501, clicks: 12013 },
      { subscribed_date: '2022-12-01', total: 14801, opens: 13105, clicks: 12091 },
    ],
  ];

  const growthData = [
    [
      {
        date: '2022-12-12',
        subscribe: 1431,
      },
      {
        date: '2022-12-13',
        subscribe: 1359,
      },
      {
        date: '2022-12-14',
        subscribe: 2800,
      },
      {
        date: '2022-12-15',
        subscribe: 1341,
      },
      {
        date: '2022-12-16',
        subscribe: 1290,
      },
      {
        date: '2022-12-17',
        subscribe: 1102,
      },
      {
        date: '2022-12-18',
        subscribe: 1304,
      },
    ],
    [
      {
        date: '2022-11-21',
        subscribe: 1012,
      },
      {
        date: '2022-11-28',
        subscribe: 1913,
      },
      {
        date: '2022-12-05',
        subscribe: 2077,
      },
      {
        date: '2022-12-12',
        subscribe: 2802,
      },
    ],
    [
      {
        date: '2022-10-12',
        subscribe: 1303,
      },
      {
        date: '2022-11-13',
        subscribe: 1701,
      },
      {
        date: '2022-12-14',
        subscribe: 2808,
      },
    ],
  ];

  const numbersData = [
    {
      overall: { open_rate: '31.28', click_rate: '1.89' },
      broadcast: { open_rate: '34.73', click_rate: '1.93' },
      autoresponder: { open_rate: '29.64', click_rate: '1.91' },
    },
    {
      overall: { open_rate: '31.96', click_rate: '1.79' },
      broadcast: { open_rate: '35.22', click_rate: '1.81' },
      autoresponder: { open_rate: '30.11', click_rate: '1.95' },
    },
    {
      overall: { open_rate: '32.07', click_rate: '2.13' },
      broadcast: { open_rate: '35.79', click_rate: '2.06' },
      autoresponder: { open_rate: '32.49', click_rate: '2.24' },
    },
  ];

  return (
    <Box my='2rem'>
      <Flex justifyContent='space-between'>
        <SectionTitle>Contact Insights</SectionTitle>
        <Select
          id='time_period'
          width='fit-content'
          borderColor='gray.500'
          mb='16px'
          onChange={(e) => {
            setInsightTypes(e.target.value);
          }}>
          {TIME_PERIOD.map(({ label, value }) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </Select>
      </Flex>
      <Grid templateColumns='1fr 1fr 226px 226px 226px' gap={6}>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <GrowthGraph data={growthData[arrIndex]} type={insightTypes} isLoading={false} />
        </Box>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <OpensAndClicksGraph
            data={opensclicksData[arrIndex]}
            type={insightTypes}
            isLoading={false}
          />
        </Box>
        <ContactInsightsBlock
          borderRadius='8px'
          background='transparent linear-gradient(134deg, #FDEDD0 0%, #D1D6FD 100%) 0% 0% no-repeat padding-box'>
          <BlockTitle>Overall Health</BlockTitle>
          <ContactInsight>
            <Text>{numbersData[arrIndex].overall.open_rate}%</Text>
            <Text>Average Open Rate</Text>
          </ContactInsight>
          <ContactInsight>
            <Text>{numbersData[arrIndex].overall.click_rate}%</Text>

            <Text>Average Click Rate</Text>
          </ContactInsight>
        </ContactInsightsBlock>
        <ContactInsightsBlock
          borderRadius='8px'
          background='transparent linear-gradient(134deg, #C7F9EF 0%, #86C9EF 100%) 0% 0% no-repeat padding-box'>
          <BlockTitle>Broadcast</BlockTitle>
          <ContactInsight>
            <Text>{numbersData[arrIndex].broadcast.open_rate}%</Text>

            <Text>Average Open Rate</Text>
          </ContactInsight>
          <ContactInsight>
            <Text>{numbersData[arrIndex].broadcast.click_rate}%</Text>
            <Text>Average Click Rate</Text>
          </ContactInsight>
        </ContactInsightsBlock>
        <ContactInsightsBlock
          borderRadius='8px'
          background='transparent linear-gradient(134deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
          <BlockTitle>Autoresponder</BlockTitle>
          <ContactInsight>
            <Text>{numbersData[arrIndex].autoresponder.open_rate}%</Text>
            <Text>Average Open Rate</Text>
          </ContactInsight>
          <ContactInsight>
            <Text>{numbersData[arrIndex].autoresponder.click_rate}%</Text>
            <Text>Average Click Rate</Text>
          </ContactInsight>
        </ContactInsightsBlock>
      </Grid>
    </Box>
  );
};

export default ContactInsights;
