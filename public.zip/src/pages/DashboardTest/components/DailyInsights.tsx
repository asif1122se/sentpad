import { Flex, Grid, Text, Image, Box } from '@chakra-ui/react';
import { formatNumber } from 'utils';
import {
  BlockTitle,
  ContactActivityItem,
  DailyInsightsBlock,
  DailyInsightsPlanInfo,
  InsightsItem,
  SectionTitle,
} from '../styles';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { DailyInsightsTypes, ContactInsight } from '../types';

type Prop = {
  type?: string;
};

const DailyInsights = ({ type }: Prop) => {
  const arrIndex = type as unknown as number;
  const contactActivity = [
    {
      subscribe: 712,
      unsubscribe: 21,
      emailOpenCount: 44873,
      emailClickCount: 2674,
    },
    {
      subscribe: 2851,
      unsubscribe: 78,
      emailOpenCount: 182117,
      emailClickCount: 10970,
    },
    {
      subscribe: 4273,
      unsubscribe: 191,
      emailOpenCount: 466372,
      emailClickCount: 27219,
    },
  ];

  return (
    <>
      <SectionTitle mt='33px'>Daily Insights</SectionTitle>
      <Grid templateColumns='repeat(3, 1fr)' gap={6}>
        <InsightsItem>
          <BlockTitle mb='18px'>Since Yesterday</BlockTitle>
          <Flex flexDirection='column' gap='16px'>
            <Flex gap='16px'>
              <DailyInsightsBlock>
                <Text>Broadcast</Text>
                <Text>20,528</Text>
                <Text>Emails Sent</Text>
              </DailyInsightsBlock>
              <DailyInsightsBlock>
                <Text>Autoresponder</Text>
                <Text>63</Text>
                <Text>Emails Sent</Text>
              </DailyInsightsBlock>
            </Flex>
            <DailyInsightsBlock width='100%'>
              <Text>Account growth</Text>
              <Text display='flex'>0.6%</Text>
              <Text>increase</Text>
            </DailyInsightsBlock>
          </Flex>
        </InsightsItem>
        <InsightsItem>
          <BlockTitle mb='18px'>Contact Activity</BlockTitle>
          <Flex flexDirection='column' gap='16px'>
            <Flex gap='16px'>
              <ContactActivityItem background='transparent linear-gradient(118deg, #FDEDD0 0%, #D1D6FD 100%) 0% 0% no-repeat padding-box'>
                <Text>{contactActivity[arrIndex].subscribe}</Text>
                <Text>New Email Contacts</Text>
              </ContactActivityItem>
              <ContactActivityItem background='transparent linear-gradient(117deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
                <Text>{contactActivity[arrIndex].unsubscribe}</Text>
                <Text>Unsubscribed</Text>
              </ContactActivityItem>
            </Flex>
            <Flex gap='16px'>
              <ContactActivityItem background='transparent linear-gradient(117deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
                <Text>{contactActivity[arrIndex].emailOpenCount}</Text>
                <Text>Emails Opens</Text>
              </ContactActivityItem>
              <ContactActivityItem background='transparent linear-gradient(116deg, #C7F9EF 0%, #86C9EF 100%) 0% 0% no-repeat padding-box'>
                <Text>{contactActivity[arrIndex].emailClickCount}</Text>
                <Text>Emails Clicks</Text>
              </ContactActivityItem>
            </Flex>
          </Flex>
        </InsightsItem>
        <InsightsItem>
          <BlockTitle mb='18px'>Plan Information</BlockTitle>
          <Flex flexDirection='column' gap='16px'>
            <Flex gap='16px'>
              <DailyInsightsBlock>
                <Text>Current Plan</Text>
                <Text>20,000</Text>
                <Text>Contacts Limit</Text>
              </DailyInsightsBlock>
              <DailyInsightsBlock>
                <Text>Cost</Text>
                <Text>$329/mo</Text>
                <Text whiteSpace='pre'> </Text>
              </DailyInsightsBlock>
            </Flex>

            <DailyInsightsPlanInfo>
              <Box>
                <DailyInsightsBlock>
                  <Text>Contacts Added</Text>
                  <Text fontWeight='bold'>10,273</Text>
                </DailyInsightsBlock>
              </Box>
              <Box>
                <DailyInsightsBlock>
                  <Text>Remaining Contacts</Text>
                  <Text fontWeight='bold'>9,727</Text>
                </DailyInsightsBlock>
              </Box>
            </DailyInsightsPlanInfo>
          </Flex>
        </InsightsItem>
      </Grid>
    </>
  );
};

export default DailyInsights;
