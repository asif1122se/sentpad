import { Flex, Text, Grid, Box, Select } from '@chakra-ui/react';
import { BlockTitle, ContactInsight, SectionTitle } from '../styles';
import BroadcastsSentGraph from '../components/BroadcastsSentGraph';
import AutorespondersSentGraph from '../components/AutorespondersSentGraph';
import DeliverabilityChart from '../components/DeliverabilityChart';
import { TIME_PERIOD } from '../consts';
import { useState } from 'react';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { AutoresponderBroadcastSentGraph, EmailSummaryHealthAndDeliverbility } from '../types';
import { formatNumber } from 'utils';

const EmailSummary = () => {
  const [insightTypes, setInsightTypes] = useState<string>(TIME_PERIOD[0].value);
  const arrIndex = insightTypes as unknown as number;

  const data = [
    {
      autoresponder_sent: [
        {
          date: '2022-12-12',
          name: '',
          sent: 411,
        },
        {
          date: '2022-12-13',
          name: '',
          sent: 304,
        },
        {
          date: '2022-12-14',
          name: '',
          sent: 355,
        },
        {
          date: '2022-12-15',
          name: '',
          sent: 619,
        },
        {
          date: '2022-12-16',
          name: '',
          sent: 549,
        },
        {
          date: '2022-12-17',
          name: '',
          sent: 323,
        },
        {
          date: '2022-12-18',
          name: '',
          sent: 491,
        },
      ],
      broadcast_sent: [
        {
          date: '2022-12-12',
          name: '',
          sent: 553,
        },
        {
          date: '2022-12-13',
          name: '',
          sent: 337,
        },
        {
          date: '2022-12-14',
          name: '',
          sent: 524,
        },
        {
          date: '2022-12-15',
          name: '',
          sent: 366,
        },
        {
          date: '2022-12-16',
          name: '',
          sent: 632,
        },
        {
          date: '2022-12-17',
          name: '',
          sent: 328,
        },
        {
          date: '2022-12-18',
          name: '',
          sent: 417,
        },
      ],
    },
    {
      autoresponder_sent: [
        {
          date: '2022-12-12',
          name: '',
          sent: 2511,
        },
        {
          date: '2022-12-13',
          name: '',
          sent: 2939,
        },
        {
          date: '2022-12-14',
          name: '',
          sent: 3355,
        },
        {
          date: '2022-12-15',
          name: '',
          sent: 4228,
        },
      ],
      broadcast_sent: [
        {
          date: '2022-12-12',
          name: '',
          sent: 3152,
        },
        {
          date: '2022-12-13',
          name: '',
          sent: 3232,
        },
        {
          date: '2022-12-14',
          name: '',
          sent: 3833,
        },
        {
          date: '2022-12-15',
          name: '',
          sent: 4020,
        },
      ],
    },
    {
      autoresponder_sent: [
        {
          date: '2022-10-01',
          name: '',
          sent: 12216,
        },
        {
          date: '2022-11-01',
          name: '',
          sent: 15530,
        },
        {
          date: '2022-12-01',
          name: '',
          sent: 16353,
        },
      ],
      broadcast_sent: [
        {
          date: '2022-10-01',
          name: '',
          sent: 13459,
        },
        {
          date: '2022-11-01',
          name: '',
          sent: 14733,
        },
        {
          date: '2022-12-01',
          name: '',
          sent: 16785,
        },
      ],
    },
  ];

  const healthAndDeliverbility = [
    {
      health: { spam_reports: 0, emails_bounced: 12, unsubscribes: 21 },
      deliverability: {
        autoresponder: { delivered: 428, not_delivered: 3 },
        broadcast: { delivered: 139674, not_delivered: 7 },
        overall: { delivered: 140102, not_delivered: 10 },
      },
    },
    {
      health: { spam_reports: 1, emails_bounced: 53, unsubscribes: 78 },
      deliverability: {
        autoresponder: { delivered: 1807, not_delivered: 13 },
        broadcast: { delivered: 588497, not_delivered: 12 },
        overall: { delivered: 590304, not_delivered: 25 },
      },
    },
    {
      health: { spam_reports: 4, emails_bounced: 117, unsubscribes: 191 },
      deliverability: {
        autoresponder: { delivered: 5133, not_delivered: 26 },
        broadcast: { delivered: 1563520, not_delivered: 28 },
        overall: { delivered: 1568653, not_delivered: 54 },
      },
    },
  ];

  return (
    <Box>
      <Flex justifyContent='space-between'>
        <SectionTitle>Email Summary</SectionTitle>
        <Select
          width='fit-content'
          borderColor='gray.500'
          mb='16px'
          onChange={(e) => setInsightTypes(e.target.value)}>
          {TIME_PERIOD.map(({ label, value }) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </Select>
      </Flex>
      <Grid templateColumns='repeat(4, 1fr)' h='229px' gap={6}>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <BroadcastsSentGraph
            data={data[arrIndex].broadcast_sent}
            type={insightTypes}
            isLoading={false}
          />
        </Box>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <AutorespondersSentGraph
            data={data[arrIndex].autoresponder_sent}
            type={insightTypes}
            isLoading={false}
          />
        </Box>
        <Flex
          borderWidth='1px'
          borderColor='gray.400'
          borderRadius='8px'
          flexDirection='column'
          p='24px'>
          <BlockTitle mb='20px'>Health</BlockTitle>
          <Flex mb='38px'>
            <ContactInsight mr='78px'>
              <Text>{formatNumber(healthAndDeliverbility[arrIndex].health.spam_reports ?? 0)}</Text>
              <Text>Spam Reports</Text>
            </ContactInsight>
            <ContactInsight>
              <Text>
                {formatNumber(healthAndDeliverbility[arrIndex].health.emails_bounced ?? 0)}
              </Text>
              <Text>Bounces</Text>
            </ContactInsight>
          </Flex>
          <ContactInsight>
            <Text>{formatNumber(healthAndDeliverbility[arrIndex].health.unsubscribes ?? 0)}</Text>
            <Text>Unsubscribes</Text>
          </ContactInsight>
        </Flex>
        <Flex border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <DeliverabilityChart deliverability={healthAndDeliverbility[arrIndex].deliverability} />
        </Flex>
      </Grid>
    </Box>
  );
};

export default EmailSummary;
