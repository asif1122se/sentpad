import { Box, Spinner, Text, Center } from '@chakra-ui/react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from 'recharts';
import { formatDate, getChartTickCount } from 'utils';
import { Dashbox } from '../styles';
import { SentGraph } from '../types';

type AutorespondersSentGraphProps = {
  data?: SentGraph;
  type: string;
  isLoading?: boolean;
};

const AutorespondersSentGraph = ({ data, type, isLoading }: AutorespondersSentGraphProps) => {
  return (
    <Dashbox>
      <Text my='4' ml='3' fontSize='md' fontWeight='bold'>
        Autoresponders Sent
      </Text>
      <Box my='4' p='0'>
        {isLoading && (
          <Center h='100px'>
            <Spinner w='50px' h='50px' />
          </Center>
        )}
        {data && (
          <ResponsiveContainer width='100%' height='100%' aspect={2}>
            <BarChart data={data} margin={{ left: -20, top: 10, bottom: 0, right: 10 }}>
              <CartesianGrid stroke='#D2D8DE' strokeWidth='0.5' vertical={false} />
              <Tooltip
                cursor={false}
                labelStyle={{ fontSize: '12px' }}
                contentStyle={{ fontSize: '12px' }}
              />
              <Bar dataKey='sent' fill='#0071E7' />
              <XAxis
                dataKey='date'
                strokeWidth='0'
                fontSize='10px'
                stroke='#929BA8'
                padding={{ left: 0 }}
                tickSize={15}
                tickCount={4}
                tickFormatter={(value) => formatDate(value, type === '2' ? 'three_month' : type)}
              />
              <YAxis
                strokeWidth='0'
                fontSize='10px'
                stroke='#929BA8'
                tickCount={getChartTickCount(data.map((item) => item.sent))}
              />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Box>
    </Dashbox>
  );
};

export default AutorespondersSentGraph;
