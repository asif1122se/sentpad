import { Grid, Spinner, Text } from '@chakra-ui/react';
import { useQuery } from 'hooks/useQuery';
import { formatNumber } from 'utils';
import QUERY_KEYS from 'utils/queryKeys';
import { DailyInsightsBlock, SectionTitle } from '../styles';
import { ContactSummaryType } from '../types';

const ContactSummary = () => {
  return (
    <>
      <SectionTitle mt='24px'>Contact Summary</SectionTitle>
      <Grid templateColumns='repeat(3, 1fr)' h='102px' gap={4}>
        <DailyInsightsBlock width='100%'>
          <Text>Total</Text>
          <Text>10,273</Text>
        </DailyInsightsBlock>
        <DailyInsightsBlock width='100%'>
          <Text>Subscribed</Text>
          <Text>9,748</Text>
        </DailyInsightsBlock>
        <DailyInsightsBlock width='100%'>
          <Text>Unsubscribed</Text>
          <Text>525</Text>
        </DailyInsightsBlock>
      </Grid>
    </>
  );
};

export default ContactSummary;
