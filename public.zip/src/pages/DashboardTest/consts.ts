export const TIME_PERIOD = [
  { label: '7 Days', value: '0' },
  { label: '1 Month', value: '1' },
  { label: '3 Months', value: '2' },
];

export const ASPECT = window.innerHeight % window.innerWidth > 900 ? 2 : 1;
