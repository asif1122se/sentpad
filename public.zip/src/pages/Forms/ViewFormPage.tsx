import { Box, Button, Center, Flex, Spinner, Text } from '@chakra-ui/react';
import { InputField } from 'components';
import { Field, Form, Formik } from 'formik';
import { useMutation } from 'hooks/useMutation';
import { useQuery } from 'hooks/useQuery';
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { POST } from 'utils/constants';
import QUERY_KEYS from 'utils/queryKeys';
import { GetForm, SubscribeForm } from './types';

const ViewFormPage = () => {
  const { id } = useParams();
  const urlParams = window.location.search.split('?token=');

  const [isSubmit, setIsSubmit] = useState<boolean>(false);

  const { data, isLoading, isFetching } = useQuery<GetForm>({
    url: `get-form-for-subscribers/${id}?token=` + urlParams[1],
    queryKey: [QUERY_KEYS.FORM_BY_ID, id],
  });

  const link1 = data?.general_settings?.thank_page_url ?? '';
  const link2 = data?.general_settings?.already_subscribe_page_url ?? '';
  const isDefaultTy = data?.general_settings?.is_default_thank_page;
  const isDefaultSubscribed = data?.general_settings?.is_default_already_subscribe_page;
  const isNewWindow = data?.general_settings?.is_new_window_enabled;

  const handleNav = (link: string) => {
    setIsSubmit(false);
    window.open(link, isNewWindow ? '_blank' : '_top');
  };

  const { mutate, isLoading: isSubmitLoading } = useMutation<SubscribeForm>({
    method: POST,
    url: 'forms/subscribe',
    showToast: false,
    onSuccess: (data) => {
      const isNew = data?.records?.isNew === 1;
      const link = isNew
        ? isDefaultTy
          ? `/thank-you` + (isNewWindow ? `?blank=1` : ``)
          : link1
        : isDefaultSubscribed
        ? `/already-subscribed` + (isNewWindow ? `?blank=1` : ``)
        : link2;

      handleNav(link);
    },
  });

  return (
    <>
      {isLoading && isFetching && (
        <Center height='100%'>
          <Spinner w='100px' height='100px' />
        </Center>
      )}

      {!isLoading && !isFetching && !isSubmit && (
        <>
          {data?.status === 'published' ? (
            <Flex width='100%'>
              <Formik<SubscribeForm>
                enableReinitialize={true}
                initialValues={{
                  name: '',
                  email: '',
                  phone: '',
                  form_key: data?.form_key ?? '',
                  isNew: 1,
                }}
                onSubmit={(values) => mutate(values)}>
                {({ values }) => (
                  <Form style={{ width: '100%', padding: '10px' }}>
                    <Box
                      borderRadius='16px'
                      borderWidth='1px'
                      padding='42px'
                      borderColor='gray.500'
                      height='fit-content'
                      width='100%'>
                      <Box mb='4'>
                        {data?.display_settings?.is_header_enabled === 1 && (
                          <Text fontSize={'32px'} fontWeight='bold'>
                            {data?.display_settings?.header_text}
                          </Text>
                        )}
                        {data?.display_settings?.is_description_enabled === 1 && (
                          <Text fontSize={'12px'} lineHeight='22px'>
                            {data?.display_settings?.description_text}
                          </Text>
                        )}
                      </Box>
                      <Box>
                        {data?.display_settings?.is_name_label_enabled === 1 && (
                          <Field
                            as={InputField}
                            name='name'
                            fontSize={'sm'}
                            label={`${data?.display_settings?.name_label_text} ${
                              data?.display_settings?.name_label_text &&
                              data?.display_settings?.is_name_label_required === 1
                                ? '*'
                                : ''
                            }`}
                            size={'md'}
                            mb='4'
                            borderColor='gray.500'
                            formLabelProps={{ fontWeight: 'bold' }}
                            value={values.name}
                          />
                        )}
                        <Field
                          as={InputField}
                          fontSize={'sm'}
                          name='email'
                          label={`${
                            data?.display_settings?.email_label_text !== ''
                              ? `${data?.display_settings?.email_label_text} *`
                              : ' '
                          }`}
                          size={'md'}
                          mb='4'
                          borderColor='gray.500'
                          formLabelProps={{ fontWeight: 'bold' }}
                          value={values.email}
                        />
                        {data?.display_settings?.is_phone_label_enabled === 1 && (
                          <Field
                            as={InputField}
                            name='phone'
                            fontSize={'sm'}
                            label={`${data?.display_settings?.phone_label_text} ${
                              data?.display_settings?.phone_label_text &&
                              data?.display_settings?.is_phone_label_required === 1
                                ? '*'
                                : ''
                            }`}
                            size={'md'}
                            mb='4'
                            borderColor='gray.500'
                            formLabelProps={{ fontWeight: 'bold' }}
                            value={values.phone}
                          />
                        )}
                      </Box>
                      <Button
                        variant='primary'
                        width='100%'
                        type='submit'
                        bgColor={data?.display_settings?.button_color ?? 'purple.700'}
                        _hover={{
                          bgColor: data?.display_settings?.button_color ?? 'purple.800',
                        }}
                        isLoading={isSubmitLoading}
                        isDisabled={isSubmitLoading}>
                        {data?.display_settings?.button_label_text}
                      </Button>
                    </Box>
                  </Form>
                )}
              </Formik>
            </Flex>
          ) : null}
        </>
      )}
    </>
  );
};

export default ViewFormPage;
