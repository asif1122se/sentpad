import { Icon, Menu, MenuButton, MenuItem, MenuList, useDisclosure, Text } from '@chakra-ui/react';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { PageHeader, PaginatedDataTable } from 'components';
import { PageContainer } from 'components/Layout';
import { FORMS } from 'consts';
import { useQuery } from 'hooks/useQuery';
import { useState } from 'react';
import QUERY_KEYS from 'utils/queryKeys';
import { EmbedCode, Form } from './types';
import { GoKebabVertical } from 'react-icons/go';
import { ColumnProps } from 'types';
import { NewFormModal } from './components';
import { format } from 'date-fns';
import DeleteFormModal from './components/DeleteFormModal';
import { useNavigate } from 'react-router-dom';
import PublishModal from './components/PublishModal';

const FormsPage = () => {
  const [values, setValues] = useState<any>();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedID, setSelectedID] = useState<number | string>(0);

  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const {
    isOpen: isEmbedCodeOpen,
    onOpen: onEmbedCodeOpen,
    onClose: onEmbedCodeClose,
  } = useDisclosure();

  const navigate = useNavigate();

  const { data: embedCode, isFetching: isEmbedCodeLoading } = useQuery<EmbedCode>({
    queryKey: [QUERY_KEYS.EMBED_CODE, selectedID],
    url: `forms/get-embeded-code/${selectedID}`,
    enabled: selectedID !== 0,
  });

  const colProps: ColumnProps[] = [
    {
      align: 'left',
      width: '30%',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'center',
      paddingX: '1px',
    },
    {
      align: 'right',
    },
  ];

  const columnHelper = createColumnHelper<Form>();
  const columns = [
    columnHelper.accessor('name', {
      cell: (info) => info.getValue(),
      header: 'Form Name',
    }),
    columnHelper.accessor('submissions', {
      cell: (info) => info.getValue(),
      header: 'Submissions',
    }),
    columnHelper.display({
      id: 'autoresponder',
      header: 'In Autoresponder',
      cell: ({ row }: CellContext<Form, unknown>) =>
        row.original.is_auto_responder.length > 0 ? 'Yes' : 'No',
    }),
    columnHelper.display({
      header: 'Date Created',
      cell: ({ row }: CellContext<Form, unknown>) => (
        <>{row.original.created_at && format(new Date(`${row.original.created_at}`), 'MM/dd/yy')}</>
      ),
    }),
    columnHelper.display({
      id: 'status',
      header: 'Status',
      cell: ({ row }: CellContext<Form, unknown>) => (
        <Text textTransform='capitalize'>{row.original.status}</Text>
      ),
    }),
    columnHelper.display({
      id: 'actions',
      cell: ({ row }: CellContext<Form, unknown>) => (
        <Menu>
          <MenuButton>
            <Icon height='25px' color='gray.500' as={GoKebabVertical} />
          </MenuButton>
          <MenuList borderColor='gray.500' minWidth='110px' width='fit-content'>
            <MenuItem onClick={() => navigate(`/forms/${row.original.id}`)}>Edit</MenuItem>
            {row.original.status === 'published' && (
              <MenuItem
                onClick={() => {
                  setSelectedID(row.original.form_key);
                  onEmbedCodeOpen();
                }}>
                Embed Code
              </MenuItem>
            )}
            <MenuItem
              onClick={() => {
                setSelectedID(row.original.id);
                onDeleteOpen();
              }}>
              Delete
            </MenuItem>
          </MenuList>
        </Menu>
      ),
    }),
  ];

  return (
    <>
      <NewFormModal isOpen={showCreateModal} onClose={() => setShowCreateModal(false)} />
      <DeleteFormModal
        isOpen={isDeleteOpen}
        onClose={onDeleteClose}
        formID={selectedID as number}
      />
      <PublishModal
        isOpen={isEmbedCodeOpen}
        onClose={onEmbedCodeClose}
        embedCode={embedCode}
        isLoading={isEmbedCodeLoading}
        id={selectedID.toString()}
      />
      <PageContainer>
        <PageHeader
          title={FORMS}
          buttonLabel='Create Form'
          onClick={() => setShowCreateModal(true)}
        />
        <PaginatedDataTable
          endpoint='get-forms-paginated'
          queryKey={[QUERY_KEYS.FORMS_LIST]}
          columns={columns}
          showFilters={false}
          colProps={colProps}
          emptyMessage={'No form(s) found'}
          values={values}
          setValues={setValues}
        />
      </PageContainer>
    </>
  );
};

export default FormsPage;
