import { Box, Flex, Image, Stack, Text } from '@chakra-ui/react';
import { Check } from './styles';
import { CheckIcon } from '@chakra-ui/icons';
import { PREVIEW_INFO } from './consts';
import { useNavigate } from 'react-router-dom';
import SendPadLogo from 'assets/images/sendpad-logo.svg';

const AlreadySubscribedPage = () => {
  const navigate = useNavigate();
  const isNewTab = window.location.search.split('?blank=')[1] ?? '';
  return (
    <Flex justifyContent='center' m='1rem'>
      <Stack width='fit-content'>
        <Flex
          borderWidth='1px'
          borderColor='gray.600'
          borderRadius='16px'
          justifyContent='center'
          padding='10% 3rem'
          m='0'>
          <Box textAlign={'center'} width='100%'>
            <Check>
              <CheckIcon boxSize='40px' color='#00BF9C' />
            </Check>
            <Text mt='3' fontSize='20px' fontWeight='bold' whiteSpace='pre-line'>
              {PREVIEW_INFO[1].desc}
            </Text>
            <Text my='3' fontSize='sm' whiteSpace='pre-line'>
              {PREVIEW_INFO[1].message}
            </Text>
            {!isNewTab && (
              <Text
                mt='5'
                fontSize='sm'
                color='blue.700'
                onClick={() => navigate(-1)}
                cursor='pointer'>
                Return to the last page
              </Text>
            )}
          </Box>
        </Flex>
        <Flex pt='5' justifyContent='center' alignItems='center'>
          <Text fontSize='12px' fontWeight='bold' mr='2'>
            Powered by
          </Text>
          <Image src={SendPadLogo} alt='SendPad Logo' />
        </Flex>
      </Stack>
    </Flex>
  );
};

export default AlreadySubscribedPage;
