import * as Yup from 'yup';

export const formSchema = Yup.object().shape({
  is_header_enabled: Yup.number(),
  header_text: Yup.string().when('is_header_enabled', {
    is: 1,
    then: Yup.string().required('Header is required'),
  }),
  is_description_enabled: Yup.number(),
  description_text: Yup.string().when('is_description_enabled', {
    is: 1,
    then: Yup.string().required('Description is required'),
  }),
  is_name_label_enabled: Yup.number(),
  name_label_text: Yup.string().when('is_name_label_enabled', {
    is: 1,
    then: Yup.string().required('Name label is required'),
  }),
  is_name_label_required: Yup.number(),
  email_label_text: Yup.string().required('Email label is always required'),
  is_phone_label_required: Yup.number(),
  is_phone_label_enabled: Yup.number(),
  phone_label_text: Yup.string().when('is_phone_label_enabled', {
    is: 1,
    then: Yup.string().required('Phone label is required'),
  }),
  button_label_text: Yup.string().required('Button label is always required'),
  name: Yup.string().required('Form name is required'),
  list_id: Yup.number().test('list_id', 'Subscription List is required', (value) => value !== 0),
  is_default_thank_page: Yup.number(),
  thank_page_url: Yup.string().when('is_default_thank_page', {
    is: 0,
    then: Yup.string().required('Thank You Custom Page URL is required'),
  }),
  is_default_already_subscribe_page: Yup.number(),
  already_subscribe_page_url: Yup.string().when('is_default_already_subscribe_page', {
    is: 0,
    then: Yup.string().required('Already Subscribed Custom Page URL is required'),
  }),
  is_new_window_enabled: Yup.number(),
});
