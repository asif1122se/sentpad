import { Box, Circle, Flex, MenuButton, MenuItem } from '@chakra-ui/react';
import styled from '@emotion/styled';

export const SettingTab = styled(Flex)`
  height: 100%;
  width: 60px;
  align-items: center;
  justify-content: center;
  border-right: 1px solid;
  border-color: var(--chakra-colors-purple-700);
  cursor: pointer;
`;

export const ContainerBox = styled(Flex)({
  marginTop: '20px',
  padding: '7% 7% 5%',
  background: 'var(--chakra-colors-gray-200)',
  justifyContent: 'center',
  alignItems: 'center',
});

export const CenterBox = styled(Flex)({
  borderWidth: '1px',
  borderColor: 'var(--chakra-colors-gray-600)',
  borderRadius: '16px',
  background: 'white',
  justifyContent: 'center',
  padding: '10% 5%',
});

export const Check = styled(Circle)({
  margin: 'auto',
  width: '90px',
  height: '90px',
  background: 'transparent',
  borderWidth: '5px',
  borderColor: '#00BF9C',
});

export const SelectMenu = styled(MenuButton)({
  color: 'white',
  background: 'var(--chakra-colors-purple-800)',
  textAlign: 'left',
  fontSize: '12px',
  fontWeight: 'medium',
  marginBottom: '1rem',
  height: '32px',
});

export const SelectMenuItem = styled(MenuItem)({
  height: '32px',
  background: 'var(--chakra-colors-purple-800)',
  color: 'white',
  fontSize: '12px',
});

export const ScreenBox = styled(Box)({
  width: '100%',
  padding: '1px 8px 8px 8px',
  background: 'var(--chakra-colors-gray-300)',
  borderRadius: '12px',
});

export const Dots = styled(Box)({
  margin: '0 3px',
  width: '12px',
  height: '12px',
  borderRadius: '50%',
  background: 'var(--chakra-colors-gray-500)',
});

export const Header = styled(Flex)({
  padding: '0 8px',
  height: '45px',
  alignItems: 'center',
  justifyContent: 'space-between',
  width: '100%',
});

export const AddressBar = styled(Flex)({
  maxWidth: '280px',
  minWidth: '220px',
  height: '25px',
  borderRadius: '4px',
  background: 'white',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: '0 4px',
});

export const ScreenForm = styled(Flex)({
  width: '100%',
  height: '100%',
  borderRadius: '8px',
  margin: '5%',
  justifyContent: 'center',
  alignItems: 'center',
});
