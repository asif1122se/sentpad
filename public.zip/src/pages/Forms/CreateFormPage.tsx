import { Box, Center, Flex, Spinner, useDisclosure } from '@chakra-ui/react';
import {
  DisplayFormHeader,
  DisplayFormSection,
  DisplaySettingsPanel,
  GeneralSettingsPanel,
  SettingsTabs,
} from './components';
import { useEffect, useState } from 'react';
import {
  ALREADY_SUBSCRIBED_OPTIONS,
  DISPLAY_SETTINGS_FIELDS,
  DISPLAY_SETTINGS_TAB,
  GENERAL_SETTINGS_FIELDS,
  GENERAL_SETTINGS_TAB,
  PUBLISH,
  SAVE,
  THANK_YOU_MESSAGE_OPTIONS,
} from './consts';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { useNavigate, useParams } from 'react-router-dom';
import { Form, Formik, FormikErrors } from 'formik';
import { CreateForm, Dimensions, EmbedCode, GetForm } from './types';
import { formSchema } from './schema';
import { ContactLists } from 'pages/Audience/Contacts/types';
import PublishModal from './components/PublishModal';
import { useMutation } from 'hooks/useMutation';
import { ROUTE_PATHS } from 'router';
import { PUT } from 'utils/constants';
import { TrueOrFalse } from 'types';
import { useQueryClient } from '@tanstack/react-query';

const CreateFormPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const queryClient = useQueryClient();
  const { isOpen, onOpen, onClose } = useDisclosure();

  const [action, setAction] = useState('');
  const [formDimensions, setFormDimensions] = useState<Dimensions>({ width: 0, height: 0 });

  const { data, isLoading } = useQuery<GetForm>({
    url: `get-form/${id}`,
    queryKey: [QUERY_KEYS.FORM_BY_ID, id],
  });

  const { data: contactList, isLoading: isContactListLoading } = useQuery<ContactLists>({
    queryKey: [QUERY_KEYS.CONTACTS_LISTS],
    url: 'getContactLists',
  });

  const {
    data: embedCode,
    isLoading: isEmbedCodeLoading,
    isFetching: isEmbedCodeFetching,
  } = useQuery<EmbedCode>({
    queryKey: [QUERY_KEYS.EMBED_CODE, id, isOpen],
    url: `forms/get-embeded-code/${data?.form_key}`,
    enabled: isOpen,
  });

  const { mutate: saveForm, isLoading: isSaveLoading } = useMutation<
    CreateForm & Dimensions,
    GetForm
  >({
    url: `forms/update/${id}`,
    method: PUT,
  });

  const [activeSettingTab, setActiveSettingTab] = useState<number>(DISPLAY_SETTINGS_TAB);

  const onChangeActiveSetting = (active: number) => setActiveSettingTab(active);

  const getSelectedList = () => {
    if (contactList && contactList.length > 0) {
      if (data?.list_id) {
        const index = contactList.findIndex((contact) => contact.id === data.list_id);
        return contactList[index > -1 ? index : 0].id;
      }

      return contactList[0].id;
    }

    return 0;
  };

  const initialValues: CreateForm = {
    header_text: data?.display_settings?.header_text ?? 'Get Free Email Update',
    is_header_enabled: data?.display_settings?.is_header_enabled ?? 1,
    description_text:
      data?.display_settings?.description_text ?? 'Join us for FREE to get instant email update',
    is_description_enabled: data?.display_settings?.is_description_enabled ?? 1,
    name_label_text: data?.display_settings?.name_label_text ?? 'Name',
    is_name_label_enabled: data?.display_settings?.is_name_label_enabled ?? 1,
    is_name_label_required: data?.display_settings?.is_name_label_required ?? 0,
    email_label_text: data?.display_settings?.email_label_text ?? 'Email',
    phone_label_text: data?.display_settings?.phone_label_text ?? 'Phone',
    is_phone_label_enabled: data?.display_settings?.is_phone_label_enabled ?? 1,
    is_phone_label_required: data?.display_settings?.is_phone_label_required ?? 0,
    button_label_text: data?.display_settings?.button_label_text ?? 'Submit',
    name: data?.name ?? '',
    list_id: getSelectedList(),
    is_default_thank_page:
      data?.general_settings && !!!data?.general_settings?.is_default_thank_page
        ? (THANK_YOU_MESSAGE_OPTIONS[1].value as TrueOrFalse)
        : (THANK_YOU_MESSAGE_OPTIONS[0].value as TrueOrFalse),
    thank_page_url: data?.general_settings?.thank_page_url ?? '',
    is_default_already_subscribe_page:
      data?.general_settings && !!!data?.general_settings?.is_default_already_subscribe_page
        ? (ALREADY_SUBSCRIBED_OPTIONS[1].value as TrueOrFalse)
        : (ALREADY_SUBSCRIBED_OPTIONS[0].value as TrueOrFalse),
    already_subscribe_page_url: data?.general_settings?.already_subscribe_page_url ?? '',
    is_new_window_enabled: data?.general_settings?.is_new_window_enabled ?? 1,
    button_color: data?.display_settings?.button_color ?? '#735AC7',
  };

  const handleSubmitSuccess = () => {
    if (action === SAVE) {
      navigate(`/${ROUTE_PATHS.FORMS}`);
    }

    if (action === PUBLISH) {
      queryClient.invalidateQueries([QUERY_KEYS.FORM_BY_ID]);
      queryClient.invalidateQueries([QUERY_KEYS.EMBED_CODE]);
      onOpen();
    }
  };

  const handleSubmit = (values: CreateForm) => {
    saveForm(
      { ...values, ...formDimensions },
      {
        onSuccess: () => handleSubmitSuccess(),
      },
    );
  };

  const redirectToTabWithError = (isSubmitting: boolean, errors: FormikErrors<CreateForm>) => {
    if (isSubmitting) {
      const errorKeys = Object.keys(errors);
      if (errorKeys.some((error) => DISPLAY_SETTINGS_FIELDS.includes(error))) {
        setActiveSettingTab(DISPLAY_SETTINGS_TAB);
      } else if (errorKeys.some((error) => GENERAL_SETTINGS_FIELDS.includes(error))) {
        setActiveSettingTab(GENERAL_SETTINGS_TAB);
      }
    }
  };

  useEffect(
    () => () => queryClient.removeQueries({ queryKey: [QUERY_KEYS.FORM_BY_ID, id], exact: true }),
    [],
  );
     
  return (
    <>
      {(isLoading || isContactListLoading) && (
        <Center height='800px'>
          <Spinner w='200px' height='200px' />
        </Center>
      )}
      {!isLoading && (
        <Flex
          minW='800px'
          width='100%'
          height='100%'
          justifyContent='space-between'
          overflow={'hidden'}>
          <PublishModal
            isOpen={isOpen}
            onClose={onClose}
            embedCode={embedCode}
            isLoading={isEmbedCodeLoading || isEmbedCodeFetching}
            id={data?.form_key ?? ''}
          />
          <Formik
            enableReinitialize={true}
            initialValues={initialValues}
            validationSchema={formSchema}
            onSubmit={handleSubmit}>
            {({ errors, isSubmitting }) => {
              redirectToTabWithError(isSubmitting, errors);
              return (
                <Form style={{ width: '100%' }}>
                  <Flex
                    width='100%'
                    height='100%'
                    justifyContent='space-between'
                    overflow={'hidden'}>
                    <Box width='100%' height='100%'>
                      <DisplayFormHeader
                        setAction={setAction}
                        isPublishLoading={action === PUBLISH && isSaveLoading}
                        isSaveLoading={action === SAVE && isSaveLoading}
                      />
                      <DisplayFormSection
                        getFormDimensions={(dimensions) => setFormDimensions(dimensions)}
                      />
                    </Box>
                    <Box width='320px' background='purple.700'>
                      <SettingsTabs
                        active={activeSettingTab}
                        onChangeActiveSetting={onChangeActiveSetting}
                      />
                      {activeSettingTab === DISPLAY_SETTINGS_TAB && <DisplaySettingsPanel />}
                      {activeSettingTab === GENERAL_SETTINGS_TAB && (
                        <GeneralSettingsPanel contactList={contactList} />
                      )}
                    </Box>
                  </Flex>
                </Form>
              );
            }}
          </Formik>
        </Flex>
      )}
    </>
  );
};

export default CreateFormPage;
