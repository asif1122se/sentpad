import { Box, Button, Flex, Image, Text } from '@chakra-ui/react';
import { InputField } from 'components';
import Bookmark from 'assets/icons/bookmark.svg';
import LeftArrow from 'assets/icons/left-arrow.svg';
import RightArrow from 'assets/icons/right-arrow.svg';
import Reload from 'assets/icons/reload.svg';
import Lock from 'assets/icons/lock.svg';
import Chain from 'assets/icons/chain.svg';
import Download from 'assets/icons/download.svg';
import Add from 'assets/icons/add.svg';
import { useFormikContext } from 'formik';
import { CreateForm, Dimensions } from '../types';
import { AddressBar, Dots, Header, ScreenBox, ScreenForm } from '../styles';
import { useEffect, useRef } from 'react';
import { FORM_WIDTH } from '../consts';

type DisplayFormSectionProps = {
  getFormDimensions: (dimensions: Dimensions) => void;
};

const DisplayFormSection = ({ getFormDimensions }: DisplayFormSectionProps) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    getFormDimensions({
      width: FORM_WIDTH,
      height: `${ref?.current && ref?.current?.clientHeight + 22}px`,
    });
  }, [ref?.current?.clientHeight]);

  const { values } = useFormikContext<CreateForm>();

  return (
    <Flex alignItems='center' height='100%' minWidth='800px'>
      <Flex
        justifyContent='center'
        alignItems='flex-start'
        marginTop='3%'
        height='100%'
        width='100%'>
        <Box height='auto' maxHeight='100%' position='absolute' width='65%' minW='700'>
          <ScreenBox>
            <Box background='transparent' width='100%'>
              <Header>
                <Flex minWidth='210px' alignItems='center' gap='12px'>
                  <Flex>
                    <Dots /> <Dots /> <Dots />
                  </Flex>
                  <Image boxSize={'20px'} src={Bookmark} />
                  <Image boxSize={'20px'} src={LeftArrow} />
                  <Image boxSize={'20px'} src={RightArrow} />
                  <Image boxSize={'20px'} src={Reload} />
                </Flex>
                <Flex justifyContent='center'>
                  <AddressBar>
                    <Flex alignItems='center'>
                      <Image src={Lock} />
                      <Text ml='5px' fontSize='12px' color='gray.500'>
                        www.sendpad.com
                      </Text>
                    </Flex>
                    <Image src={Chain} />
                  </AddressBar>
                </Flex>
                <Flex minWidth='210px' justifyContent='right' gap='12px'>
                  <Image boxSize={'20px'} src={Download} />
                  <Image boxSize={'20px'} src={Add} />
                </Flex>
              </Header>
            </Box>
            <Flex width='100%' height='100%' background='white' borderRadius='8px'>
              <ScreenForm>
                <Box
                  ref={ref}
                  borderRadius='16px'
                  borderWidth='1px'
                  padding='42px'
                  borderColor='gray.500'
                  width={FORM_WIDTH}>
                  <Box mb='4'>
                    {values.is_header_enabled === 1 && (
                      <Text fontSize={'32px'} fontWeight='bold'>
                        {values.header_text}
                      </Text>
                    )}
                    {values.is_description_enabled === 1 && (
                      <Text fontSize={'12px'} lineHeight='22px'>
                        {values.description_text}
                      </Text>
                    )}
                  </Box>
                  <Box>
                    {values.is_name_label_enabled === 1 && (
                      <InputField
                        fontSize={'sm'}
                        label={`${values.name_label_text} ${
                          values.name_label_text && values.is_name_label_required === 1 ? '*' : ''
                        }`}
                        size={'md'}
                        mb='4'
                        borderColor='gray.500'
                        formLabelProps={{ fontWeight: 'bold' }}
                      />
                    )}
                    <InputField
                      fontSize={'sm'}
                      label={`${
                        values.email_label_text !== '' ? `${values.email_label_text} *` : ' '
                      }`}
                      size={'md'}
                      mb='4'
                      borderColor='gray.500'
                      formLabelProps={{ fontWeight: 'bold' }}
                    />
                    {values.is_phone_label_enabled === 1 && (
                      <InputField
                        fontSize={'sm'}
                        label={`${values.phone_label_text} ${
                          values.phone_label_text && values.is_phone_label_required === 1 ? '*' : ''
                        }`}
                        size={'md'}
                        mb='4'
                        borderColor='gray.500'
                        formLabelProps={{ fontWeight: 'bold' }}
                      />
                    )}
                  </Box>
                  <Button variant='primary' w='100%' bgColor={values.button_color}>
                    {values.button_label_text}
                  </Button>
                </Box>
              </ScreenForm>
            </Flex>
          </ScreenBox>
        </Box>
      </Flex>
    </Flex>
  );
};

export default DisplayFormSection;
