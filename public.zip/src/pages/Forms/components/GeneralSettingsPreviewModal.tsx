import { CheckIcon } from '@chakra-ui/icons';
import {
  Box,
  Button,
  Flex,
  Image,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay,
  Stack,
  Text,
} from '@chakra-ui/react';
import SendPadLogo from 'assets/images/sendpad-logo.svg';
import { PREVIEW_INFO } from '../consts';
import { CenterBox, Check, ContainerBox } from '../styles';

type PreviewModalProps = {
  isOpen: boolean;
  onClose: () => void;
  info: number;
};

const GeneralSettingsPreviewModal = ({ isOpen, onClose, info }: PreviewModalProps) => {
  return (
    <>
      <Modal
        isCentered
        isOpen={isOpen}
        onClose={onClose}
        closeOnEsc={false}
        closeOnOverlayClick={false}>
        <ModalOverlay />
        <ModalContent maxW='880px'>
          <ModalCloseButton color='gray.600' />
          <ModalBody p='0'>
            <Box p='28px'>
              <Text fontSize='18px' lineHeight='32px' fontWeight='bold' mb='3'>
                {PREVIEW_INFO[info].title}
              </Text>
              <Button variant='outlined' fontSize='12px'>
                Mobile
              </Button>
              <Button ml='3' variant='info' fontSize='12px'>
                Desktop
              </Button>
              <ContainerBox>
                <Stack width='70%'>
                  <CenterBox>
                    <Box textAlign={'center'} width='100%'>
                      <Check>
                        <CheckIcon boxSize='40px' color='#00BF9C' />
                      </Check>
                      <Text mt='3' fontSize='22px' fontWeight='bold' whiteSpace='pre-line'>
                        {PREVIEW_INFO[info].desc}
                      </Text>
                      <Text my='3' fontSize='sm' whiteSpace='pre-line'>
                        {PREVIEW_INFO[info].message}
                      </Text>
                      <Text mt='5' fontSize='sm' color='blue.700'>
                        Return to the last page
                      </Text>
                    </Box>
                  </CenterBox>
                  <Flex pt='10' justifyContent='center' alignItems='center'>
                    <Text fontSize='12px' fontWeight='bold' mr='2'>
                      Powered by
                    </Text>
                    <Image src={SendPadLogo} alt='SendPad Logo' />
                  </Flex>
                </Stack>
              </ContainerBox>
            </Box>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  );
};

export default GeneralSettingsPreviewModal;
