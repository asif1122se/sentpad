import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
} from '@chakra-ui/react';
import { InputField } from 'components';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from 'hooks/useMutation';
import { Field, Form, Formik } from 'formik';
import { Form as FormType } from '../types';

type NewFormModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

const NewFormModal = ({ isOpen, onClose }: NewFormModalProps) => {
  const navigate = useNavigate();

  const [existsError, setExistsError] = useState(false);

  const { mutate, isLoading } = useMutation<{ name: string }, FormType>({
    url: 'save-form',
    onSuccess: (data) => navigate(`/forms/${data?.records.id}`),
    onError: () => setExistsError(true),
    showToast: false,
  });

  const handleClose = () => {
    setExistsError(false);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} isCentered>
      <ModalOverlay />
      <ModalContent minW='540px'>
        <Formik
          initialValues={{
            name: '',
          }}
          onSubmit={(name) => mutate(name)}>
          {({ values }) => (
            <Form>
              <ModalHeader color='black' fontSize='18px' fontWeight='bold' p='2rem 2rem 1rem'>
                Create New Form
              </ModalHeader>
              <ModalCloseButton />
              <ModalBody p='0 2rem'>
                <Field
                  as={InputField}
                  autoFocus
                  name='name'
                  label='Form Name'
                  placeholder='Enter Form Name'
                  maxLength={50}
                  value={values.name}
                  errorText={existsError && 'Form already exists. Please select another name.'}
                />
              </ModalBody>

              <ModalFooter display='flex' justifyContent='flex-start' p='1.5rem 2rem 2rem'>
                <Button
                  isLoading={isLoading}
                  isDisabled={!values.name}
                  variant={values.name ? 'success' : 'default'}
                  mr={3}
                  type='submit'>
                  Create
                </Button>
                <Button onClick={handleClose}>Cancel</Button>
              </ModalFooter>
            </Form>
          )}
        </Formik>
      </ModalContent>
    </Modal>
  );
};

export default NewFormModal;
