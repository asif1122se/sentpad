import { Button, Flex } from '@chakra-ui/react';
import SendpadBuilderLogo from 'assets/icons/sendpad-email-builder.svg';
import { PUBLISH, SAVE } from '../consts';

type DisplayFormHeaderProps = {
  setAction: (action: string) => void;
  isSaveLoading: boolean;
  isPublishLoading?: boolean;
};

const DisplayFormHeader = ({
  setAction,
  isSaveLoading = false,
  isPublishLoading = false,
}: DisplayFormHeaderProps) => {
  return (
    <Flex
      height='40px'
      background='purple.700'
      paddingX='8px'
      alignItems='center'
      justifyContent='space-between'>
      <img src={SendpadBuilderLogo} alt='Logo' />
      <Flex gap='8px'>
        <Button
          type='submit'
          onClick={() => setAction(SAVE)}
          fontWeight='semibold'
          h='28px'
          fontSize='12px'
          bgColor='white'
          color='purple.800'
          isLoading={isSaveLoading}
          isDisabled={isSaveLoading === true || isPublishLoading === true}>
          Save & Exit
        </Button>
        <Button
          type='submit'
          onClick={() => setAction(PUBLISH)}
          fontWeight='semibold'
          h='28px'
          fontSize='12px'
          variant='success'
          isLoading={isPublishLoading}
          isDisabled={isSaveLoading === true || isPublishLoading === true}
          whiteSpace='pre'>
          Publish
        </Button>
      </Flex>
    </Flex>
  );
};

export default DisplayFormHeader;
