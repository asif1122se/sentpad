import {
  Box,
  Flex,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay,
  Text,
  Image,
  useToast,
  Center,
  Spinner,
} from '@chakra-ui/react';
import CheckIcon from 'assets/icons/check.svg';
import CopyIcon from 'assets/icons/copy.svg';
import config from 'config';
import { useRef } from 'react';
import { EmbedCode } from '../types';

type PublishModalProps = {
  isOpen: boolean;
  onClose: () => void;
  embedCode?: EmbedCode;
  isLoading?: boolean;
  id: string;
};
const PublishModal = ({ isOpen, onClose, embedCode, isLoading }: PublishModalProps) => {
  const htmlText = useRef<HTMLDivElement | null>(null);
  const toast = useToast();

  const handleCopy = (copyText: React.MutableRefObject<HTMLDivElement | null>) => {
    navigator.clipboard.writeText(copyText?.current?.textContent ?? '');
    toast({
      position: 'top',
      title: 'Code successfully copied',
      description: 'You can now paste this to your website.',
      status: 'success',
      duration: 5000,
      isClosable: true,
    });
  };
  return (
    <Modal isOpen={isOpen} onClose={onClose} size='2xl' isCentered>
      <ModalOverlay />
      <ModalContent>
        <ModalCloseButton />
        <ModalBody padding='64px 32px 32px'>
          {isLoading && (
            <Center h='534px'>
              <Spinner w='200px' h='200px' />
            </Center>
          )}
          {!isLoading && (
            <>
              <Flex alignItems='center' flexDirection='column'>
                <Image src={CheckIcon} alt='Check Icon' mb='20px' />
                <Text fontSize='24px' lineHeight='32px' fontWeight='bold'>
                  Your form is ready to go!
                </Text>
                <Text textAlign='center' color='gray.800' mb='30px' w='408px'>
                  Paste the code snippet below into the header of your site to start displaying your
                  form.
                </Text>
              </Flex>
              <Box position='relative'>
                <Text color='gray.800' mb='12px'>
                  Include the code below in your website.
                </Text>
                <Image
                  onClick={() => handleCopy(htmlText)}
                  cursor='pointer'
                  zIndex={1}
                  position='absolute'
                  right='16px'
                  top='56px'
                  src={CopyIcon}
                  alt='Copy Icon'
                />
              </Box>
              <Box
                ref={htmlText}
                borderRadius='4px'
                border='1px solid'
                borderColor='gray.600'
                fontSize='14px'
                padding='18px 32px 24px 24px'
                position='relative'
                color='black'
                maxH='150px'
                overflow='auto'>
                {embedCode?.response}
              </Box>
            </>
          )}
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default PublishModal;
