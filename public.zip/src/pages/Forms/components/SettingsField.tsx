import {
  Flex,
  SwitchProps,
  Text,
  Textarea,
  TextareaProps,
  FormControl,
  FormLabel,
} from '@chakra-ui/react';
import { InputField } from 'components';
import { InputProps } from 'components/InputField';
import { StyledSwitch } from 'pages/Autoresponder/styles';

type SettingsFieldProps = InputProps &
  TextareaProps & {
    withSwitch?: boolean;
    switchProps?: SwitchProps;
    isTextarea?: boolean;
  };

const SettingsField = ({ isTextarea, ...restProps }: SettingsFieldProps) => {
  return isTextarea ? (
    <FormControl {...restProps.formControlProps}>
      <Flex justifyContent='space-between'>
        <FormLabel color='white' fontWeight='medium' fontSize='12px' {...restProps.formLabelProps}>
          {restProps.label}
        </FormLabel>
        {restProps.switchProps && <StyledSwitch {...restProps.switchProps} />}
      </Flex>
      <Textarea
        minH='69px'
        background='purple.800'
        borderWidth={restProps.errorText ? '2px' : 0}
        borderColor={restProps.errorText && 'red.700'}
        fontSize='12px'
        color='white'
        {...restProps}
      />
      {restProps.errorText && (
        <>
          <Text color='red.700' mt='8px' fontSize='12px' fontWeight='medium'>
            {restProps.errorText}
          </Text>
        </>
      )}
    </FormControl>
  ) : (
    <InputField
      formLabelProps={{
        color: 'white',
        fontWeight: 'medium',
        fontSize: '12px',
      }}
      height='32px'
      fontSize='12px'
      background='purple.800'
      border='none'
      color='white'
      size='sm'
      {...restProps}
    />
  );
};

export default SettingsField;
