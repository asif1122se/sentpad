import { Flex } from '@chakra-ui/react';
import StylesIcon from 'assets/icons/email-builder/styles.svg';
import SettingsIcon from 'assets/icons/email-builder/settings.svg';
import { DISPLAY_SETTINGS_TAB, GENERAL_SETTINGS_TAB } from '../consts';
import { SettingTab } from '../styles';

type SettingsTabsProps = {
  active: number;
  onChangeActiveSetting: (active: number) => void;
};

const SettingsTabs = ({ active, onChangeActiveSetting }: SettingsTabsProps) => {
  return (
    <Flex height='40px' background='purple.800'>
      <SettingTab
        backgroundColor={active === DISPLAY_SETTINGS_TAB ? 'purple.700' : undefined}
        onClick={() => onChangeActiveSetting(DISPLAY_SETTINGS_TAB)}>
        <img src={StylesIcon} alt='Styles' width='24px' height='24px' />
      </SettingTab>
      <SettingTab
        backgroundColor={active === GENERAL_SETTINGS_TAB ? 'purple.700' : undefined}
        onClick={() => onChangeActiveSetting(GENERAL_SETTINGS_TAB)}>
        <img src={SettingsIcon} alt='Settings' width='24px' height='24px' />
      </SettingTab>
    </Flex>
  );
};

export default SettingsTabs;
