import { Box, Flex, Text, useDisclosure } from '@chakra-ui/react';
import { Checkbox } from 'components';
import { Field, useFormikContext } from 'formik';
import { ContactLists } from 'pages/Audience/Contacts/types';
import { useState } from 'react';
import {
  ALREADY_SUBSCRIBED_OPTIONS,
  PREVIEW_SUBSCRIBED,
  PREVIEW_TY,
  THANK_YOU_MESSAGE_OPTIONS,
} from '../consts';
import { CreateForm } from '../types';
import GeneralSettingsPreviewModal from './GeneralSettingsPreviewModal';
import SettingsField from './SettingsField';
import SettingsSelect from './SettingsSelect';

type GeneralSettingsPanelProps = {
  contactList: ContactLists | undefined;
};

const GeneralSettingsPanel = ({ contactList }: GeneralSettingsPanelProps) => {
  const { values, setFieldValue, errors } = useFormikContext<CreateForm>();

  const [previewInfo, setPreviewInfo] = useState<number>(PREVIEW_TY);

  const { isOpen: isPreviewOpen, onOpen: onPreviewOpen, onClose: onPreviewClose } = useDisclosure();

  return (
    <>
      <GeneralSettingsPreviewModal
        isOpen={isPreviewOpen}
        onClose={onPreviewClose}
        info={previewInfo}
      />
      <Flex flexDirection='column' width='100%' padding='14px 10px'>
        <Box>
          <Text color='white' fontSize='12px' fontWeight='600' mb='18px'>
            GENERAL SETTINGS
          </Text>
        </Box>
        <Flex width='100%' flexDirection='column'>
          <Field
            as={SettingsField}
            label='Form Name'
            placeholder='Contact Us'
            formControlProps={{ mb: '1rem' }}
            name='name'
            value={values.name}
            errorText={errors.name}
            maxLength={50}
          />
          <SettingsSelect
            label='Subscription List'
            options={contactList?.map(({ title, id }) => ({
              label: title.length > 30 ? `${title.substring(0, 30)}...` : title,
              value: id,
            }))}
            onChange={(value) => setFieldValue('list_id', value)}
            value={values.list_id}
            errorText={errors.list_id}
          />
          <SettingsSelect
            label='Thank You Message'
            buttonLabel={values.is_default_thank_page ? 'PREVIEW' : undefined}
            onClickButton={() => {
              setPreviewInfo(PREVIEW_TY);
              onPreviewOpen();
            }}
            options={THANK_YOU_MESSAGE_OPTIONS}
            onChange={(value) => setFieldValue('is_default_thank_page', value)}
            value={values.is_default_thank_page}
          />
          {values.is_default_thank_page === 0 && (
            <Field
              as={SettingsField}
              label='Custom Page URL'
              name='thank_page_url'
              placeholder='eg. https://google.com'
              formControlProps={{ mb: '1rem' }}
              value={values.thank_page_url}
              errorText={errors.thank_page_url}
              maxLength={120}
            />
          )}
          <SettingsSelect
            label='Already Subscribed Page'
            buttonLabel={values.is_default_already_subscribe_page ? 'PREVIEW' : undefined}
            onClickButton={() => {
              setPreviewInfo(PREVIEW_SUBSCRIBED);
              onPreviewOpen();
            }}
            options={ALREADY_SUBSCRIBED_OPTIONS}
            onChange={(value) => setFieldValue('is_default_already_subscribe_page', value)}
            value={values.is_default_already_subscribe_page}
          />
          {!values.is_default_already_subscribe_page && (
            <Field
              as={SettingsField}
              label='Custom Page URL'
              name='already_subscribe_page_url'
              placeholder='eg. https://google.com'
              value={values.already_subscribe_page_url}
              errorText={errors.already_subscribe_page_url}
              maxLength={120}
              formControlProps={{ mb: '1rem' }}
            />
          )}
          <Flex mb='16px'>
            <Field
              as={Checkbox}
              name='is_new_window_enabled'
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFieldValue('is_new_window_enabled', e.target.checked ? 1 : 0)
              }
              isChecked={values.is_new_window_enabled === 1}
            />{' '}
            <Text ml='8px' fontSize='12px' color='white'>
              Open in new window
            </Text>
          </Flex>
        </Flex>
      </Flex>
    </>
  );
};

export default GeneralSettingsPanel;
