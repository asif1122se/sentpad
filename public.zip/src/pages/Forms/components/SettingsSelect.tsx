import { ChevronDownIcon } from '@chakra-ui/icons';
import { Button, Flex, FormLabel, Menu, MenuList, MenuProps, Text } from '@chakra-ui/react';
import { useState } from 'react';
import { SelectMenu, SelectMenuItem } from '../styles';

type Option = {
  label: string;
  value: number;
};

type SettingsSelectProps = Omit<MenuProps, 'children'> & {
  label: string;
  buttonLabel?: string;
  onClickButton?: () => void;
  options?: Array<Option>;
  onChange: (value: string | number) => void;
  value: number;
  errorText?: string;
};

const SettingsSelect = ({
  label,
  buttonLabel,
  onClickButton,
  options,
  onChange,
  value,
  errorText,
  ...restProps
}: SettingsSelectProps) => {
  const [active, setActive] = useState<Option>(
    options
      ? options.find((option) => option.value === value) ?? options[0]
      : {
          label: 'Loading...',
          value: -1,
        },
  );

  return (
    <Flex flexDirection='column'>
      <Flex justifyContent='space-between' alignItems='center' mb='12px'>
        {label && (
          <FormLabel color='white' fontSize='12px' mb='0'>
            {label}
          </FormLabel>
        )}
        {buttonLabel && (
          <Button
            variant='link'
            color='white'
            height='12px'
            fontSize='10px'
            fontWeight='600'
            onClick={onClickButton}>
            {buttonLabel}
          </Button>
        )}
      </Flex>
      <Menu matchWidth gutter={1} {...restProps}>
        <SelectMenu
          _hover={{
            bg: 'purple.900',
          }}
          as={Button}
          rightIcon={<ChevronDownIcon />}
          mb={errorText ? '8px !important' : undefined}
          border={errorText ? '1px solid var(--chakra-colors-red-700)' : undefined}>
          {active?.label}
        </SelectMenu>
        <MenuList background='purple.800' border='none' zIndex='5'>
          {options?.map(({ label, value }) => (
            <SelectMenuItem
              key={value}
              onClick={() => {
                setActive({ label, value });
                onChange(value);
              }}
              _hover={{
                bg: 'purple.900',
              }}
              _focus={{
                bg: 'purple.900',
              }}>
              {label}
            </SelectMenuItem>
          ))}
        </MenuList>
      </Menu>
      {errorText && (
        <Text color='red.700' mb='1rem' fontSize='12px' fontWeight='medium'>
          {errorText}
        </Text>
      )}
    </Flex>
  );
};

export default SettingsSelect;
