import { ChevronDownIcon } from '@chakra-ui/icons';
import { Box, Flex, FormLabel, useOutsideClick } from '@chakra-ui/react';
import { InputField } from 'components';
import { useRef, useState } from 'react';
import { ColorResult, SketchPicker } from 'react-color';

type ColorPickerProps = {
  label: string;
  onChange: (color: string) => void;
  value: string;
};

const ColorPicker = ({ label, onChange, value }: ColorPickerProps) => {
  const ref = useRef<HTMLDivElement | null>(null);
  const [showPicker, setShowPicker] = useState(false);
  const [color, setColor] = useState(value ?? '#735AC7');

  useOutsideClick({
    ref: ref,
    handler: () => setShowPicker(false),
  });

  const handleChangeColor = (color: ColorResult) => {
    setColor(color.hex.toUpperCase());
    onChange(color.hex.toUpperCase());
  };
  return (
    <>
      {showPicker && (
        <Box position='absolute' bottom='100px' right='300px' ref={ref}>
          <SketchPicker color={color} onChange={handleChangeColor} disableAlpha />
        </Box>
      )}
      <Flex flexDirection='column'>
        <FormLabel color='white' fontWeight='medium' fontSize='12px'>
          {label}
        </FormLabel>
        <Flex gap='0.5rem'>
          <Flex
            bg='purple.800'
            w='55px'
            h='32px'
            p='6px'
            alignItems='center'
            justifyContent='space-between'
            borderRadius='3px'
            cursor='pointer'
            onClick={() => setShowPicker(!showPicker)}>
            <Box w='20px' h='20px' bg={color} p='8px' borderRadius='3px' />
            <ChevronDownIcon color='white' />
          </Flex>
          <InputField
            formLabelProps={{
              color: 'white',
              fontWeight: 'medium',
              fontSize: '12px',
            }}
            height='32px'
            fontSize='12px'
            background='purple.800'
            border='none'
            color='white'
            size='sm'
            width='80px'
            value={color}
          />
        </Flex>
      </Flex>
    </>
  );
};

export default ColorPicker;
