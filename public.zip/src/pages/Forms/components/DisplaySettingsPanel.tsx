import { Box, Flex, Text } from '@chakra-ui/react';
import { Checkbox } from 'components';
import { useFormikContext } from 'formik';
import { CreateForm } from '../types';
import SettingsField from './SettingsField';
import { ColorPicker } from '.';

const DisplaySettingsPanel = () => {
  const { values, handleChange, setFieldValue, errors } = useFormikContext<CreateForm>();
  return (
    <Flex flexDirection='column' width='100%' padding='14px 10px' height='100%' overflow='auto'>
      <Box>
        <Text color='white' fontSize='12px' fontWeight='600' mb='18px'>
          DISPLAY SETTINGS
        </Text>
      </Box>
      <Flex width='100%' flexDirection='column'>
        <SettingsField
          name='header_text'
          onChange={handleChange}
          label='Header'
          placeholder='Enter Header'
          value={values.header_text}
          switchProps={{
            name: 'is_header_enabled',
            onChange: (e) => setFieldValue('is_header_enabled', e.target.checked ? 1 : 0),
            isChecked: values.is_header_enabled === 1,
          }}
          errorText={errors.header_text}
          formControlProps={{ mb: '1rem' }}
          maxLength={254}
        />
        <SettingsField
          name='description_text'
          onChange={handleChange}
          label='Description'
          placeholder='Enter Description'
          value={values.description_text}
          switchProps={{
            name: 'is_description_enabled',
            onChange: (e) => setFieldValue('is_description_enabled', e.target.checked ? 1 : 0),
            isChecked: values.is_description_enabled === 1,
          }}
          errorText={errors.description_text}
          size='sm'
          isTextarea
          formControlProps={{ mb: '1rem' }}
          maxLength={354}
        />
        <SettingsField
          name='name_label_text'
          onChange={handleChange}
          label='Name Label'
          placeholder='Enter Name Label'
          value={values.name_label_text}
          switchProps={{
            name: 'is_name_label_enabled',
            onChange: (e) => setFieldValue('is_name_label_enabled', e.target.checked ? 1 : 0),
            isChecked: values.is_name_label_enabled === 1,
          }}
          errorText={errors.name_label_text}
          maxLength={75}
        />
        <Flex mt='12px' mb='16px'>
          <Checkbox
            name='is_name_label_required'
            onChange={(e) => setFieldValue('is_name_label_required', e.target.checked ? 1 : 0)}
            isChecked={values.is_name_label_required === 1}
            isDisabled={values.is_name_label_enabled === 0}
          />{' '}
          <Text ml='8px' fontSize='12px' color='white'>
            Required
          </Text>
        </Flex>
        <SettingsField
          name='email_label_text'
          onChange={handleChange}
          placeholder='Enter Email Label'
          label='Email Label'
          value={values.email_label_text}
          errorText={errors.email_label_text}
          maxLength={75}
        />
        <Text mt='8px' mb='16px' fontSize='12px' color='white' fontStyle='italic'>
          Always required
        </Text>
        <SettingsField
          name='phone_label_text'
          placeholder='Enter Phone Label'
          label='Phone Label'
          onChange={handleChange}
          value={values.phone_label_text}
          switchProps={{
            name: 'is_phone_label_enabled',
            onChange: (e) => setFieldValue('is_phone_label_enabled', e.target.checked ? 1 : 0),
            isChecked: values.is_phone_label_enabled === 1,
          }}
          errorText={errors.phone_label_text}
          maxLength={75}
        />
        <Flex mt='12px' mb='16px'>
          <Checkbox
            name='is_phone_label_required'
            onChange={(e) => setFieldValue('is_phone_label_required', e.target.checked ? 1 : 0)}
            isChecked={values.is_phone_label_required === 1}
            isDisabled={values.is_phone_label_enabled === 0}
          />{' '}
          <Text ml='8px' fontSize='12px' color='white'>
            Required
          </Text>
        </Flex>
        <SettingsField
          name='button_label_text'
          placeholder='Enter Button Label'
          onChange={handleChange}
          label='Button Label'
          value={values.button_label_text}
          errorText={errors.button_label_text}
          maxLength={75}
        />
        <Text fontSize='12px' mt='8px' color='white' fontStyle='italic'>
          Always required
        </Text>

        <Box mt='1rem'>
          <ColorPicker
            label='Button Color'
            onChange={(color) => setFieldValue('button_color', color)}
            value={values.button_color}
          />
        </Box>
      </Flex>
    </Flex>
  );
};

export default DisplaySettingsPanel;
