export const DISPLAY_SETTINGS_TAB = 0;
export const GENERAL_SETTINGS_TAB = 1;

export const PREVIEW_TY = 0;
export const PREVIEW_SUBSCRIBED = 1;

export const DRAFT = 'draft';
export const PUBLISH = 'publish';
export const SAVE = 'save';
export const SCHEDULED = 'Scheduled';
export const COMPLETED = 'Completed';

export const PREVIEW_INFO = [
  {
    title: 'Default Thank You',
    desc: `Your request has been sent \n successfully`,
    message: `Thanks for signing up. You will now \n receive our emails.`,
  },
  {
    title: 'Default Subscribed Message',
    desc: `You're already subscribed and set \n up to receive our emails.`,
    message: `If you're having trouble locating them, please \n check your spam folder.`,
  },
];

export const THANK_YOU_MESSAGE_OPTIONS = [
  {
    label: 'Default Thank You Page',
    value: 1,
  },
  {
    label: 'Custom Page URL',
    value: 0,
  },
];

export const ALREADY_SUBSCRIBED_OPTIONS = [
  {
    label: 'Default Already Subscribed Page',
    value: 1,
  },
  {
    label: 'Custom Page URL',
    value: 0,
  },
];

export const DISPLAY_SETTINGS_FIELDS = [
  'header_text',
  'description_text',
  'name_label_text',
  'email_label_text',
  'phone_label_text',
  'button_label_text',
];

export const GENERAL_SETTINGS_FIELDS = [
  'name',
  'list_id',
  'thank_page_url',
  'already_subscribe_page_url',
];

export const FORM_WIDTH = '580px';
