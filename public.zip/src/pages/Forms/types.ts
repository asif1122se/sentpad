import { TrueOrFalse } from 'types';

export type EmailLogs = {
  id: number;
  form_id: number;
  customer_id: number;
  is_submited: number;
  impressions: number;
};

export type Form = {
  id: number;
  form_key: string;
  user_id: number;
  name: string;
  is_auto_responder: number[];
  submissions: number;
  impressions: number;
  status: string;
  created_at: string;
  updated_at?: string;
};

export type FormsListing = Form[];

export type CreateForm = {
  header_text: string;
  is_header_enabled: TrueOrFalse;
  description_text: string;
  is_description_enabled: TrueOrFalse;
  name_label_text: string;
  is_name_label_enabled: TrueOrFalse;
  is_name_label_required: TrueOrFalse;
  email_label_text: string;
  phone_label_text?: string;
  is_phone_label_enabled: TrueOrFalse;
  is_phone_label_required: TrueOrFalse;
  button_label_text: string;
  name: string;
  list_id: number;
  is_default_thank_page: TrueOrFalse;
  thank_page_url: string;
  is_default_already_subscribe_page: TrueOrFalse;
  already_subscribe_page_url: string;
  is_new_window_enabled: TrueOrFalse;
  button_color: string;
};

export type Dimensions = {
  height: string | number;
  width: string | number;
};

export type GetForm = {
  id: number;
  ar_id: number;
  created_at?: string;
  deleted_at?: string;
  description_text: string;
  header_name?: string;
  fields?: string;
  form_key: string;
  name: string;
  status: string;
  user_id: number;
  updated_at?: string;
  body_content: string | null;
  display_settings: {
    is_header_enabled: TrueOrFalse;
    header_text: string;
    is_description_enabled: TrueOrFalse;
    description_text: string;
    is_name_label_enabled: TrueOrFalse;
    name_label_text: string;
    is_name_label_required: TrueOrFalse;
    email_label_text: string;
    is_phone_label_enabled: TrueOrFalse;
    phone_label_text: string;
    is_phone_label_required: TrueOrFalse;
    button_label_text: string;
    button_color: string;
  } | null;
  general_settings: {
    is_default_thank_page: TrueOrFalse;
    thank_page_url: string;
    is_default_already_subscribe_page: TrueOrFalse;
    already_subscribe_page_url: string;
    is_new_window_enabled: TrueOrFalse;
  } | null;
  impressions: number;
  list_id: number;
  submissions: number;
};

export type EditForm = {
  id: number;
  ar_id: number;
  created_at?: string;
  deleted_at?: string;
  description: string;
  header_name?: string;
  fields?: string;
  form_key: string;
  name: string;
  status: string;
  user_id: number;
  updated_at?: string;
  body_content: string | null;
  is_header_enabled: TrueOrFalse;
  header_text: string;
  is_description_enabled: TrueOrFalse;
  description_text: string;
  is_name_label_enabled: TrueOrFalse;
  name_label_text: string;
  is_name_label_required: TrueOrFalse;
  email_label_text: string;
  is_phone_label_enabled: TrueOrFalse;
  phone_label_text: string;
  is_phone_label_required: TrueOrFalse;
  button_label_text: string;
  is_default_thank_page: TrueOrFalse;
  thank_page_url: string;
  is_default_already_subscribe_page: TrueOrFalse;
  already_subscribe_page_url: string;
  impressions: number;
  list_id: number;
  submissions: number;
  is_new_window_enabled: TrueOrFalse;
};

export type EmbedCode = {
  response: string;
  style: string;
};

export type SubscribeForm = {
  name: string;
  email: string;
  phone: string;
  form_key: string;
  isNew: number;
};
