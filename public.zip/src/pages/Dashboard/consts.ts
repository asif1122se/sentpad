export const TIME_PERIOD = [
  { label: '7 Days', value: 'daily' },
  { label: '1 Month', value: 'month' },
  { label: '3 Months', value: 'three_month' },
];

export const ASPECT = window.innerHeight % window.innerWidth > 900 ? 2 : 1;
