type ClickAndOpenRate = {
  click_rate: string;
  open_rate: string;
};

type ContactSummaryCount = {
  subscribed_count: number;
  total_count: number;
  unsubscribed_count: number;
};

export type GrowthData = {
  date: string;
  subscribe: number;
};
export type GrowthDataList = GrowthData[];

export type OpensClicksData = {
  subscribed_date: string;
  total: number;
  opens: number;
  clicks: number;
};

export type ContactInsightsNumbers = {
  autoresponder?: ClickAndOpenRate;
  broadcast?: ClickAndOpenRate;
  overall?: ClickAndOpenRate;
};

export type OpensClicksDataList = OpensClicksData[];

export type ARYesterdayCount = {
  created_at?: string;
  dayname?: string;
  id?: number;
  total?: number | null;
};
export type BroadCastEmailSent = {
  created_at?: string;
  dayname?: string;
  id?: number;
  total?: number | null;
};

export type PlanInformation = {
  contacts_added: number;
  cost: string;
  current_plan: string;
  plan_type: string;
  remaining_contacts: string;
  renewal_date: string;
};

export type DailyInsightsTypes = {
  account_gowth_count?: number | undefined;
  autoresponder_yesterday_count?: ARYesterdayCount[];
  broadcast_yesterday_count?: BroadCastEmailSent[];
  plan_information?: PlanInformation;
};

export type EmailClickCount = {
  created_at: string;
  dayname: string;
  id: number;
  total: number | null;
};

export type ContactInsight = {
  subscribe?: EmailClickCount[];
  unsubscribe?: EmailClickCount[];
  emailClickCount?: EmailClickCount[];
  emailOpenCount?: EmailClickCount[];
};

export type ContactSummaryType = {
  'Overall Count'?: ContactSummaryCount;
  'Today Count'?: ContactSummaryCount;
};

export type SentGraph = Array<{
  date: string;
  name: string;
  sent: number;
}>;

export type AutoresponderBroadcastSentGraph = {
  autoresponder_sent: SentGraph;
  broadcast_sent: SentGraph;
};

export type emailSummaryHealth = {
  emails_bounced: number;
  spam_reports: number;
  unsubscribes: number;
};

export type AutoResponderDeliverbility = {
  delivered?: number;
  not_delivered?: number;
};
export type emailSummaryDeliverbility = {
  autoresponder?: AutoResponderDeliverbility;
  broadcast?: AutoResponderDeliverbility;
  overall?: AutoResponderDeliverbility;
};

export type EmailSummaryHealthAndDeliverbility = {
  health: emailSummaryHealth;
  deliverability?: emailSummaryDeliverbility;
};

export type EmailSummaryDeliverbility = {
  deliverability?: emailSummaryDeliverbility;
};
