import { Box, Flex, GridItem, Text } from '@chakra-ui/react';
import styled from '@emotion/styled';

export const SectionTitle = styled(Text)`
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 16px;
`;

export const BlockTitle = styled(Text)`
  color: var(--chakra-colors-black);
  font-size: 16px;
  line-height: 20px;
  font-weight: bold;
`;

export const InsightsItem = styled(GridItem)`
  width: 100%;
  border-radius: 8px;
  border: 1px solid var(--chakra-colors-gray-400);
  box-shadow: 0px 10px 16px #11213c1a;
  padding: 24px;
`;

export const DailyInsightsBlock = styled(Flex)`
  flex-direction: column;
  justify-content: center;
  background: var(--chakra-colors-gray-200);
  border-radius: 8px;
  width: 100%;
  padding: 16px;
  gap: 6px;

  & > p {
    font-size: 14px;
    line-height: 17px;

    &:first-child {
      color: var(--chakra-colors-black);
    }

    &:nth-child(2) {
      font-size: 20px;
      line-height: 24px;
      font-weight: bold;
    }

    &:nth-child(3) {
      color: var(--chakra-colors-gray-800);
    }
  }
`;

export const ContactActivityItem = styled(Flex)`
  flex-direction: column;
  padding: 24px;
  border-radius: 8px;
  width: 100%;

  & > p {
    font-size: 14px;
    line-height: 17px;
    color: var(--chakra-colors-gray-800);

    &:first-child {
      font-weight: bold;
      font-size: 30px;
      line-height: 36px;
      color: var(--chakra-colors-black);
    }
  }
`;

export const DailyInsightsPlanInfo = styled(Flex)`
  align-items: start;
  gap: 1.5rem;
  background: var(--chakra-colors-gray-200);
  border-radius: 8px;
  padding: 8px 0;
  min-height: 102px;
`;

export const ContactSummaryItem = styled(GridItem)`
  padding: 28px 24px;
  background: var(--chakra-colors-gray-200);
  border-radius: 8px;
`;

export const ContactInsightsBlock = styled(Flex)`
  flex-direction: column;
  padding: 24px;
  border-radius: 8px;
  gap: 24px;
`;

export const ContactInsight = styled(Flex)`
  flex-direction: column;

  & > p {
    &:first-child {
      font-weight: bold;
      font-size: 20px;
      line-height: 24px;
    }

    &:last-child {
      color: var(--chakra-colors-gray-800);
      font-size: 14px;
      font-weight: medium;
      line-height: 17px;
    }
  }
`;

export const Dashbox = styled(Box)({
  width: '100%',
  padding: '0px 0.75rem 0px 0.75rem',
});
