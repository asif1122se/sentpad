import { useState } from 'react';
import { Flex, Grid, Text, Image, Box } from '@chakra-ui/react';
import { formatNumber, numberWithCommas } from 'utils';
import {
  BlockTitle,
  ContactActivityItem,
  DailyInsightsBlock,
  DailyInsightsPlanInfo,
  InsightsItem,
  SectionTitle,
} from '../styles';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { DailyInsightsTypes, ContactInsight } from '../types';
import { amemberBillingApi } from 'services/apis/subscription';
import { InvoiceList, AmemberBillingTypes } from '../../../pages/Account/types';

const DailyInsights = () => {
  const [amemberBillingData, setAmemberBillingData] = useState<AmemberBillingTypes>();
  const { data } = useQuery<DailyInsightsTypes>({
    queryKey: [QUERY_KEYS.DAILY_INSIGHTS],
    url: 'daily-insight-stats',
  });

  const { data: contactInsights } = useQuery<ContactInsight>({
    queryKey: [QUERY_KEYS.CONTACT_INSIGHTS],
    url: 'contact-activity-stats',
  });

  const {
    data: billingData,
    isLoading,
    isFetching,
  } = useQuery<InvoiceList>({
    url: 'plans/billing-page',
    queryKey: [QUERY_KEYS.INVOICES],
    onSuccess: (data) => {
      data?.plan_id && getAmemberData(data);
    },
  });

  const getAmemberData = async (billingRes: any) => {
    const result = await amemberBillingApi(billingRes?.plan_id);
    if (result?.msg === 'found') {
      setAmemberBillingData(result?.payload);
    }
  };

  return (
    <>
      <SectionTitle mt='33px'>Daily Insights</SectionTitle>
      <Grid templateColumns='repeat(3, 1fr)' gap={6}>
        <InsightsItem>
          <BlockTitle mb='18px'>Since Yesterday</BlockTitle>
          <Flex flexDirection='column' gap='16px'>
            <Flex gap='16px'>
              <DailyInsightsBlock>
                <Text>Broadcast</Text>
                <Text>
                  {data?.broadcast_yesterday_count
                    ? formatNumber(data.broadcast_yesterday_count[0]?.total ?? 0)
                    : 0}
                </Text>
                <Text>Emails Sent</Text>
              </DailyInsightsBlock>
              <DailyInsightsBlock>
                <Text>Autoresponder</Text>
                <Text>
                  {data?.autoresponder_yesterday_count
                    ? formatNumber(data.autoresponder_yesterday_count[0]?.total ?? 0)
                    : 0}
                </Text>
                <Text>Emails Sent</Text>
              </DailyInsightsBlock>
            </Flex>
            <DailyInsightsBlock width='100%'>
              <Text>Account growth</Text>
              <Text display='flex'>{data?.account_gowth_count}%</Text>
              <Text>increase</Text>
            </DailyInsightsBlock>
          </Flex>
        </InsightsItem>
        <InsightsItem>
          <BlockTitle mb='18px'>Contact Activity</BlockTitle>
          <Flex flexDirection='column' gap='16px'>
            <Flex gap='16px'>
              <ContactActivityItem background='transparent linear-gradient(118deg, #FDEDD0 0%, #D1D6FD 100%) 0% 0% no-repeat padding-box'>
                <Text>
                  {contactInsights?.subscribe &&
                    formatNumber(contactInsights.subscribe[0]?.total ?? 0)}
                </Text>
                <Text>New Email Contacts</Text>
              </ContactActivityItem>
              <ContactActivityItem background='transparent linear-gradient(117deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
                <Text>
                  {contactInsights?.unsubscribe &&
                    formatNumber(contactInsights.unsubscribe[0]?.total ?? 0)}
                </Text>
                <Text>Unsubscribed</Text>
              </ContactActivityItem>
            </Flex>
            <Flex gap='16px'>
              <ContactActivityItem background='transparent linear-gradient(117deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
                <Text>
                  {contactInsights?.emailOpenCount
                    ? formatNumber(contactInsights.emailOpenCount[0]?.total ?? 0)
                    : 0}
                </Text>
                <Text>Emails Opens</Text>
              </ContactActivityItem>
              <ContactActivityItem background='transparent linear-gradient(116deg, #C7F9EF 0%, #86C9EF 100%) 0% 0% no-repeat padding-box'>
                <Text>
                  {contactInsights?.emailClickCount
                    ? formatNumber(contactInsights.emailClickCount[0]?.total ?? 0)
                    : 0}
                </Text>
                <Text>Emails Clicks</Text>
              </ContactActivityItem>
            </Flex>
          </Flex>
        </InsightsItem>
        <InsightsItem>
          <BlockTitle mb='18px'>Plan Information</BlockTitle>
          <Flex flexDirection='column' gap='16px'>
            <Flex gap='16px'>
              <DailyInsightsBlock>
                <Text>Current Plan</Text>
                <Text>{numberWithCommas(`${amemberBillingData?.subscribers ?? 0}`)}</Text>
                <Text>Contacts Limit</Text>
              </DailyInsightsBlock>
              <DailyInsightsBlock>
                <Text>Cost</Text>
                <Text>
                  ${numberWithCommas(`${amemberBillingData?.price ?? 0}`)}/
                  {amemberBillingData?.price_tag}
                </Text>
                <Text whiteSpace='pre'> </Text>
              </DailyInsightsBlock>
            </Flex>

            <DailyInsightsPlanInfo>
              <Box>
                <DailyInsightsBlock>
                  <Text>Contacts Added</Text>
                  <Text fontWeight='bold'>{billingData?.used_contacts ?? 0}</Text>
                </DailyInsightsBlock>
              </Box>
              <Box>
                <DailyInsightsBlock>
                  <Text>Remaining Contacts</Text>
                  {amemberBillingData?.subscribers && billingData?.used_contacts ? (
                    <Text fontWeight='bold'>
                      {numberWithCommas(
                        `${amemberBillingData?.subscribers - billingData?.used_contacts ?? 0}`,
                      )}
                    </Text>
                  ) : (
                    <Text fontWeight='bold'> {amemberBillingData?.contacts?.split(' ')[0]} </Text>
                  )}
                </DailyInsightsBlock>
              </Box>
            </DailyInsightsPlanInfo>
          </Flex>
        </InsightsItem>
      </Grid>
    </>
  );
};

export default DailyInsights;
