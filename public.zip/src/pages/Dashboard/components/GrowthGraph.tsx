import { Box, Center, Flex, Spinner, Text } from '@chakra-ui/react';
import {
  XAxis,
  YAxis,
  Line,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Tooltip,
} from 'recharts';
import { formatDate, getDomain } from 'utils';
import { ASPECT } from '../consts';
import { Dashbox } from '../styles';
import { GrowthDataList } from '../types';

type Prop = {
  data?: GrowthDataList;
  type?: string;
  isLoading?: boolean;
};

const GrowthGraph = ({ data = [], type, isLoading }: Prop) => {
  return (
    <Dashbox>
      <Text mt={3 + ASPECT} ml='3' fontSize='md' fontWeight='bold'>
        Growth
      </Text>
      {isLoading ? (
        <Center h='100px'>
          <Spinner w='50px' h='50px' />
        </Center>
      ) : (
        data && (
          <Flex alignItems={'end'} ml='-1' mt='2' pt={ASPECT}>
            <ResponsiveContainer aspect={ASPECT}>
              <LineChart data={data} margin={{ left: -20, top: 12, bottom: 10, right: 10 }}>
                <CartesianGrid stroke='#D2D8DE' strokeWidth='0.5' vertical={false} />
                <XAxis
                  dataKey='date'
                  strokeWidth='0'
                  fontSize='10px'
                  stroke='#929BA8'
                  padding={{ left: 10, right: 10 }}
                  tickMargin={8}
                  tickFormatter={(value) => formatDate(value, type)}
                  interval='preserveEnd'
                />
                <YAxis
                  strokeWidth='0'
                  fontSize='10px'
                  stroke='#929BA8'
                  type='number'
                  domain={getDomain(data.map((item) => item.subscribe))}
                  tickCount={4}
                  interval='preserveEnd'
                  padding={{ top: 1, bottom: 1 }}
                />
                <Tooltip labelStyle={{ fontSize: '12px' }} contentStyle={{ fontSize: '12px' }} />
                <Line type='monotone' dataKey='subscribe' stroke='#F27372' dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </Flex>
        )
      )}
    </Dashbox>
  );
};

export default GrowthGraph;
