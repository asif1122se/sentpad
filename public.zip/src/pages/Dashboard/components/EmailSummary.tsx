import { Flex, Text, Grid, Box, Select } from '@chakra-ui/react';
import { BlockTitle, ContactInsight, SectionTitle } from '../styles';
import BroadcastsSentGraph from '../components/BroadcastsSentGraph';
import AutorespondersSentGraph from '../components/AutorespondersSentGraph';
import DeliverabilityChart from '../components/DeliverabilityChart';
import { TIME_PERIOD } from '../consts';
import { useState } from 'react';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { AutoresponderBroadcastSentGraph, EmailSummaryHealthAndDeliverbility } from '../types';
import { formatNumber } from 'utils';

const EmailSummary = () => {
  const [insightTypes, setInsightTypes] = useState<string>(TIME_PERIOD[0].value);
  const { data, isLoading } = useQuery<AutoresponderBroadcastSentGraph>({
    queryKey: [QUERY_KEYS.AUTORESPONDER_BROADCAST_SENT_GRAPH, insightTypes],
    url: `autorespnder-broadcast-sent-graph?type=${insightTypes}`,
  });

  const { data: healthAndDeliverbility } = useQuery<EmailSummaryHealthAndDeliverbility>({
    queryKey: [QUERY_KEYS.EMAIL_SUMMARY_HEALTH, insightTypes],
    url: `dashboard-email-summary?type=${insightTypes}`,
  });

  return (
    <Box>
      <Flex justifyContent='space-between'>
        <SectionTitle>Email Summary</SectionTitle>
        <Select
          width='fit-content'
          borderColor='gray.500'
          mb='16px'
          onChange={(e) => setInsightTypes(e.target.value)}>
          {TIME_PERIOD.map(({ label, value }) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </Select>
      </Flex>
      <Grid templateColumns='repeat(4, 1fr)' h='229px' gap={4}>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <BroadcastsSentGraph
            data={data?.broadcast_sent}
            type={insightTypes}
            isLoading={isLoading}
          />
        </Box>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <AutorespondersSentGraph
            data={data?.autoresponder_sent}
            type={insightTypes}
            isLoading={isLoading}
          />
        </Box>
        <Flex
          borderWidth='1px'
          borderColor='gray.400'
          borderRadius='8px'
          flexDirection='column'
          p='24px'>
          <BlockTitle mb='20px'>Health</BlockTitle>
          <Flex mb='38px'>
            <ContactInsight mr='78px'>
              <Text>{formatNumber(healthAndDeliverbility?.health?.spam_reports ?? 0)}</Text>
              <Text>Spam Reports</Text>
            </ContactInsight>
            <ContactInsight>
              <Text>{formatNumber(healthAndDeliverbility?.health?.emails_bounced ?? 0)}</Text>
              <Text>Bounces</Text>
            </ContactInsight>
          </Flex>
          <ContactInsight>
            <Text>{formatNumber(healthAndDeliverbility?.health?.unsubscribes ?? 0)}</Text>
            <Text>Unsubscribes</Text>
          </ContactInsight>
        </Flex>
        <Flex border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <DeliverabilityChart deliverability={healthAndDeliverbility?.deliverability} />
        </Flex>
      </Grid>
    </Box>
  );
};

export default EmailSummary;
