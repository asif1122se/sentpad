import { Grid, Spinner, Text } from '@chakra-ui/react';
import { useQuery } from 'hooks/useQuery';
import { formatNumber } from 'utils';
import QUERY_KEYS from 'utils/queryKeys';
import { DailyInsightsBlock, SectionTitle } from '../styles';
import { ContactSummaryType } from '../types';

const ContactSummary = () => {
  const { data, isLoading } = useQuery<ContactSummaryType>({
    queryKey: [QUERY_KEYS.DASHBOARD_CONTACT_SUMMARY],
    url: 'get-customers-count',
  });

  return (
    <>
      <SectionTitle mt='24px'>Contact Summary</SectionTitle>
      <Grid templateColumns='repeat(3, 1fr)' h='102px' gap={4}>
        <DailyInsightsBlock width='100%'>
          <Text>Total</Text>
          {isLoading ? (
            <Spinner />
          ) : (
            <Text>
              {data?.['Overall Count'] ? formatNumber(data?.['Overall Count'].total_count ?? 0) : 0}
            </Text>
          )}
        </DailyInsightsBlock>
        <DailyInsightsBlock width='100%'>
          <Text>Subscribed</Text>
          {isLoading ? (
            <Spinner />
          ) : (
            <Text>
              {data?.['Overall Count']
                ? formatNumber(data?.['Overall Count'].subscribed_count ?? 0)
                : 0}
            </Text>
          )}
        </DailyInsightsBlock>
        <DailyInsightsBlock width='100%'>
          <Text>Unsubscribed</Text>
          {isLoading ? (
            <Spinner />
          ) : (
            <Text>
              {data?.['Overall Count']
                ? formatNumber(data?.['Overall Count'].unsubscribed_count ?? 0)
                : 0}
            </Text>
          )}
        </DailyInsightsBlock>
      </Grid>
    </>
  );
};

export default ContactSummary;
