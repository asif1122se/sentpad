import { Box, Flex, Text } from '@chakra-ui/react';
import { ResponsiveContainer, PieChart, Pie, Legend, Tooltip, Cell } from 'recharts';
import { ASPECT } from '../consts';
import { Dashbox } from '../styles';
import { EmailSummaryDeliverbility } from '../types';
import { formatNumber } from 'utils';

const DeliverabilityChart = ({ deliverability }: EmailSummaryDeliverbility) => {
  const emailDeliveryData = [
    { name: 'Delivered', value: deliverability?.overall?.delivered },
    { name: 'Not Delivered', value: deliverability?.overall?.not_delivered },
  ];
  const COLORS = ['#635AC7', '#ED4758'];
  const renderLegend = () => {
    const legendMargin = ASPECT > 1 ? 10 : 0;
    return (
      <Flex justifyContent={'center'}>
        <Box mb={legendMargin}>
          {emailDeliveryData.map((entry, index) => (
            <Box key={`item-${index}`} fontSize='11px'>
              <Box
                style={{
                  marginRight: '8px',
                  height: '8px',
                  width: '8px',
                  backgroundColor: COLORS[index % COLORS.length],
                  display: 'inline-block',
                  borderRadius: '50%',
                }}
              />
              {entry.name}
            </Box>
          ))}
        </Box>
      </Flex>
    );
  };
  return (
    <Dashbox>
      <Text mt='4' ml='3' fontSize='md' fontWeight='bold'>
        Deliverability
      </Text>
      <Box mt='3' p='0'>
        <Flex alignItems='start' justifyContent={'space-between'} position='relative' height='100%'>
          <Box width='50%'>
            <ResponsiveContainer width='100%' height='100%' aspect={ASPECT > 1 ? 0.78 : 1}>
              <PieChart margin={{ left: 0, top: 10, bottom: 0, right: 0 }}>
                <Pie
                  data={emailDeliveryData}
                  cx='45%'
                  cy='40%'
                  innerRadius={20}
                  outerRadius={38}
                  dataKey='value'>
                  {emailDeliveryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Legend
                  content={renderLegend}
                  wrapperStyle={{
                    fontSize: '12px',
                    marginBottom: '3px',
                  }}
                />
                <Tooltip labelStyle={{ fontSize: '12px' }} contentStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </Box>
          <Box width='50%'>
            <Box my='2'>
              <Text fontSize='13px'>Broadcast</Text>
              <Text fontSize='18px' lineHeight='18px' fontWeight='bold'>
                {formatNumber(deliverability?.broadcast?.delivered ?? 0)}
              </Text>
              <Text fontSize='13px'>Emails Delivered</Text>
            </Box>
            <Box my='2' style={{ marginTop: '5px' }}>
              <Text fontSize='13px'>Autoresponder</Text>
              <Text fontSize='18px' lineHeight='18px' fontWeight='bold'>
                {formatNumber(deliverability?.autoresponder?.delivered ?? 0)}
              </Text>
              <Text fontSize='13px'>Emails Delivered</Text>
            </Box>
          </Box>
        </Flex>
      </Box>
    </Dashbox>
  );
};

export default DeliverabilityChart;
