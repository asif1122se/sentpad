import { Box, Image, Text } from '@chakra-ui/react';
import EmptyChart from 'assets/icons/empty-chart.svg';

const InsufficientData = () => {
  return (
    <Box textAlign={'center'} py='2'>
      <Image margin='auto' width={'13%'} src={EmptyChart} alt='Empty Chart' />
      <Text
        mt='4'
        mb='2'
        fontWeight={'bold'}
        lineHeight='22px'
        color='gray.700'
        opacity={0.7}
        fontSize={'16px'}>
        Insufficient data
      </Text>
      <Text
        color='gray.600'
        opacity={0.7}
        fontSize='14px'
        lineHeight={'20px'}
        whiteSpace={'pre-line'}>
        {`More data is required to \n display this graph`}
      </Text>
    </Box>
  );
};

export default InsufficientData;
