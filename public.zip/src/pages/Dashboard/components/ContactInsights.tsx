import { Flex, Text, Grid, Box, Select, Spinner } from '@chakra-ui/react';
import { BlockTitle, ContactInsight, ContactInsightsBlock, SectionTitle } from '../styles';
import GrowthGraph from '../components/GrowthGraph';
import OpensAndClicksGraph from '../components/OpensAndClicksGraph';
import { useState } from 'react';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { GrowthDataList, ContactInsightsNumbers, OpensClicksDataList } from '../types';
import { TIME_PERIOD } from '../consts';

const ContactInsights = () => {
  const [insightTypes, setInsightTypes] = useState<string>(TIME_PERIOD[0].value);

  const { data: opensclicksData, isLoading: isOpensClicksDataLoading } =
    useQuery<OpensClicksDataList>({
      queryKey: [QUERY_KEYS.DASHBOARD_CONTACT_INSIGHTS_OPENSCLICKS, insightTypes],
      url: `contact-open-click-graph?type=${insightTypes}`,
    });

  const { data: growthData, isLoading: isGrowthDataLoading } = useQuery<GrowthDataList>({
    queryKey: [QUERY_KEYS.DASHBOARD_CONTACT_INSIGHTS_GROWTH, insightTypes],
    url: `contact-growth-graph?type=${insightTypes}`,
  });

  const { data: numbersData, isLoading: isNumbersDataLoading } = useQuery<ContactInsightsNumbers>({
    queryKey: [QUERY_KEYS.DASHBOARD_CONTACT_INSIGHTS_NUMBERS, insightTypes],
    url: `open-click-rate?type=${insightTypes}`,
  });

  return (
    <Box my='2rem'>
      <Flex justifyContent='space-between'>
        <SectionTitle>Contact Insights</SectionTitle>
        <Select
          width='fit-content'
          borderColor='gray.500'
          mb='16px'
          onChange={(e) => setInsightTypes(e.target.value)}>
          {TIME_PERIOD.map(({ label, value }) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </Select>
      </Flex>
      <Grid templateColumns='1fr 1fr 226px 226px 226px' gap={6}>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <GrowthGraph data={growthData} type={insightTypes} isLoading={isGrowthDataLoading} />
        </Box>
        <Box w='100%' border='1px solid' borderColor='gray.400' borderRadius='8px'>
          <OpensAndClicksGraph
            data={opensclicksData}
            type={insightTypes}
            isLoading={isOpensClicksDataLoading}
          />
        </Box>
        <ContactInsightsBlock
          borderRadius='8px'
          background='transparent linear-gradient(134deg, #FDEDD0 0%, #D1D6FD 100%) 0% 0% no-repeat padding-box'>
          <BlockTitle>Overall Health</BlockTitle>
          <ContactInsight>
            {isNumbersDataLoading ? (
              <Spinner />
            ) : (
              <Text>{numbersData?.overall ? numbersData.overall.open_rate : 0}%</Text>
            )}
            <Text>Average Open Rate</Text>
          </ContactInsight>
          <ContactInsight>
            {isNumbersDataLoading ? (
              <Spinner />
            ) : (
              <Text>{numbersData?.overall ? numbersData.overall.click_rate : 0}%</Text>
            )}
            <Text>Average Click Rate</Text>
          </ContactInsight>
        </ContactInsightsBlock>
        <ContactInsightsBlock
          borderRadius='8px'
          background='transparent linear-gradient(134deg, #C7F9EF 0%, #86C9EF 100%) 0% 0% no-repeat padding-box'>
          <BlockTitle>Broadcast</BlockTitle>
          <ContactInsight>
            {isNumbersDataLoading ? (
              <Spinner />
            ) : (
              <Text>{numbersData?.broadcast ? numbersData.broadcast.open_rate : 0}%</Text>
            )}
            <Text>Average Open Rate</Text>
          </ContactInsight>
          <ContactInsight>
            {isNumbersDataLoading ? (
              <Spinner />
            ) : (
              <Text>{numbersData?.broadcast ? numbersData.broadcast.click_rate : 0}%</Text>
            )}
            <Text>Average Click Rate</Text>
          </ContactInsight>
        </ContactInsightsBlock>
        <ContactInsightsBlock
          borderRadius='8px'
          background='transparent linear-gradient(134deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
          <BlockTitle>Autoresponder</BlockTitle>
          <ContactInsight>
            {isNumbersDataLoading ? (
              <Spinner />
            ) : (
              <Text>{numbersData?.autoresponder ? numbersData.autoresponder.open_rate : 0}%</Text>
            )}
            <Text>Average Open Rate</Text>
          </ContactInsight>
          <ContactInsight>
            {isNumbersDataLoading ? (
              <Spinner />
            ) : (
              <Text>{numbersData?.autoresponder ? numbersData.autoresponder.click_rate : 0}%</Text>
            )}
            <Text>Average Click Rate</Text>
          </ContactInsight>
        </ContactInsightsBlock>
      </Grid>
    </Box>
  );
};

export default ContactInsights;
