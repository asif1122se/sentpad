import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { PageContainer } from 'components/Layout';
import { ContactInsights, ContactSummary, DailyInsights, EmailSummary } from './components';
import { format } from 'date-fns';
import { displayGreeting } from 'utils';

const DashboardPage = () => {
  const currentDate = new Date();

  return (
    <Box position='relative'>
      <PageContainer pb='100px'>
        <Flex justifyContent='space-between'>
          <Box>
            <Text>{format(currentDate, 'EEEE, MMMM d')}</Text>
            {/* <Heading as='h3' size='h3' fontWeight='bold'>
              {displayGreeting(currentDate)}, {localStorage.getItem('email')}
            </Heading> */}
          </Box>
        </Flex>
        <DailyInsights />
        <ContactSummary />
        <ContactInsights />
        <EmailSummary />
      </PageContainer>
    </Box>
  );
};

export default DashboardPage;
