type IEDetails = {
  attempted?: number;
  duplicated?: number;
  suppressed?: number;
};

export type IE = {
  id: number;
  status_id: number;
  summary: string;
  date_summary: string;
  details: IEDetails;
};

export type IEListItem = {
  id: number;
  title: string;
};

export type IEList = IE[];
export type IELists = IEListItem[];
