import { DownloadIcon } from '@chakra-ui/icons';
import { Center, Spinner, useDisclosure } from '@chakra-ui/react';
import { createColumnHelper } from '@tanstack/react-table';
import { DataTable, PageHeader, KebabMenu } from 'components';
import { PageContainer } from 'components/Layout';
import { useQuery } from 'hooks/useQuery';
import { useNavigate } from 'react-router-dom';
import { ColumnProps } from 'types/general';
import QUERY_KEYS from 'utils/queryKeys';
import ImportContact from './components/ImportContactModal';
import { IE, IEList, IELists } from './types';

const listColProps: ColumnProps[] = [
  {
    align: 'center',
  },
  {
    align: 'left',
  },
  {
    align: 'left',
  },
  {
    align: 'left',
  },

  {
    align: 'right',
    paddingX: '3px',
  },
];

const kebabMenu = [
  {
    label: 'Export CSV',
  },
];

const ImportExportPage = () => {
  const { isOpen: isImportOpen, onOpen: onImportOpen, onClose: onImportClose } = useDisclosure();

  const { data, isLoading, isFetching } = useQuery<IEList>({
    url: 'get-lists',
    queryKey: [QUERY_KEYS.CONTACTS_LISTS],
  });

  const columnHelper = createColumnHelper<IE>();
  const navigate = useNavigate();

  const columns = [
    columnHelper.display({
      id: 'status_id',
      header: 'Status',
      cell: () => <></>,
    }),
    columnHelper.display({
      id: 'summary',
      header: 'Summary',
      cell: () => <></>,
    }),
    columnHelper.display({
      id: 'details',
      header: 'Details',
      cell: () => <></>,
    }),
    columnHelper.display({
      id: 'action',
      cell: () => (
        <DownloadIcon
          boxSize='5'
          color='gray.500'
          cursor='pointer'
          onClick={() => navigate('/audience/lists')}
        />
      ),
    }),
  ];

  return (
    <PageContainer>
      <PageHeader
        title='Import & Export'
        subtitle='Audience'
        buttonLabel='Import Contact'
        onClick={onImportOpen}
      />
      <ImportContact isOpen={isImportOpen} onClose={onImportClose} />
      {isLoading || isFetching ? (
        <Center>
          <Spinner />
        </Center>
      ) : (
        <DataTable
          columns={columns}
          data={data}
          getValue={() => null}
          colProps={listColProps}
          showFilters={false}
          emptyMessage={'No list(s) found'}
          onRowClick={(row: IE) => console.log('row', row)}
          rightToolbar={<KebabMenu menu={kebabMenu} />}
        />
      )}
    </PageContainer>
  );
};

export default ImportExportPage;
