import {
  Box,
  Button,
  Checkbox,
  Flex,
  Grid,
  GridItem,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Stack,
  Text,
} from '@chakra-ui/react';
import { ContactList, ContactLists } from 'pages/Audience/Contacts/types';
import { useState } from 'react';
import { CSVLink } from 'react-csv';

type ExportProps = {
  isOpen: boolean;
  onClose: () => void;
  data: ContactList;
  lists?: ContactLists;
};

type ExportData = {
  email: string;
  first_name: string;
  last_name: string;
  phone_no?: string;
  country?: string;
  is_subscribed: 'Yes' | 'No';
};

const extraFields = [
  { key: 'address_one', label: 'Address 1' },
  { key: 'address_two', label: 'Address 2' },
  { key: 'city', label: 'City' },
  { key: 'zip_code', label: 'Zip' },
  { key: 'state', label: 'State' },
];

const headers = [
  {
    label: 'Email',
    key: 'email',
  },
  {
    label: 'First Name',
    key: 'first_name',
  },
  {
    label: 'Last Name',
    key: 'last_name',
  },
  {
    label: 'Phone',
    key: 'phone_no',
  },
  {
    label: 'Country',
    key: 'country',
  },
  {
    label: 'Subscribed Date',
    key: 'subscribe_date',
  },
  {
    label: 'Subscribed',
    key: 'is_subscribed',
  },
  {
    label: 'List',
    key: 'list',
  },
];

const ExportContact = ({ isOpen, onClose, data, lists }: ExportProps) => {
  const [checkedState, setCheckedState] = useState(new Array(extraFields.length).fill(false));

  const handleOnChange = (position: number) => {
    const updatedCheckedState = checkedState.map((item, index) =>
      index === position ? !item : item,
    );

    setCheckedState(updatedCheckedState);
  };

  const getHeaders = () => {
    const additionalFields = extraFields.filter((item, index) => checkedState[index]);
    return [...headers, ...additionalFields];
  };

  const formatExportData = (data: ContactList): ExportData[] =>
    data.map((contact) => ({
      ...contact,
      is_subscribed: contact.is_subscribed === 1 ? 'Yes' : 'No',
      list: lists?.find((item) => item.id === contact.list_id)?.title,
    }));

  const handleClose = () => {
    setCheckedState(new Array(extraFields.length).fill(false));
    onClose();
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={handleClose}
        closeOnEsc={false}
        isCentered
        closeOnOverlayClick={false}>
        <ModalOverlay />
        <ModalContent maxW='540px' px='2'>
          <ModalHeader>
            <Flex
              justifyContent='space-between'
              alignItems='center'
              fontSize='md'
              fontWeight='normal'>
              <Text fontWeight='bold' color='black' fontSize='18px' lineHeight='32px'>
                Export Contacts
              </Text>
            </Flex>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Stack justifyContent='flex-start' width='100%' fontSize='md'>
              <Text fontWeight='600'>Choose extra fields</Text>
              <Box borderColor='gray.300' borderWidth='1px' borderRadius='5px' p='5'>
                <Grid templateColumns='repeat(2, 1fr)' gap={4}>
                  {extraFields.map((fields, index) => {
                    return (
                      <GridItem key={fields.key} onChange={() => handleOnChange(index)}>
                        <Checkbox size='sm' borderColor='gray.400'>
                          {fields.label}
                        </Checkbox>
                      </GridItem>
                    );
                  })}
                </Grid>
              </Box>
            </Stack>
          </ModalBody>
          <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
            <Button variant='success' mr='8px'>
              <CSVLink
                data={formatExportData(data)}
                headers={getHeaders()}
                filename='sendpad_contacts'>
                Export
              </CSVLink>
            </Button>
            <Button onClick={handleClose}>Cancel</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default ExportContact;
