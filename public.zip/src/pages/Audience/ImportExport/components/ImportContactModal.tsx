import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogOverlay,
  Box,
  Button,
  Flex,
  Link,
  Modal,
  ModalBody,
  ModalContent,
  ModalHeader,
  ModalOverlay,
  Stack,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  useDisclosure,
} from '@chakra-ui/react';
import React, { useRef } from 'react';
import { SmallCloseIcon } from '@chakra-ui/icons';
import { Checkbox, InputField, Select } from 'components';
import { useMutation } from 'hooks/useMutation';
import { FileUploader } from 'react-drag-drop-files';
import config from 'config';
import { useQueryClient } from '@tanstack/react-query';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { ContactLists, NewContactType } from 'pages/Audience/Contacts/types';
import { INITIAL_CONTACT_VALUES, POST } from 'utils/constants';
import { Field, Form, Formik } from 'formik';
import { contactSchema } from 'pages/Audience/Contacts/schema';

type ImportProps = {
  isOpen: boolean;
  onClose: () => void;
};

const ImportContact = ({ isOpen, onClose }: ImportProps) => {
  const queryClient = useQueryClient();

  const { isOpen: isOpenDialog, onOpen: onOpenDialog, onClose: onCloseDialog } = useDisclosure();

  const cancelRef = useRef<HTMLDivElement>(null);

  const { data: contactList } = useQuery<ContactLists>({
    url: 'getContactLists',
    queryKey: [QUERY_KEYS.CONTACTS_LISTS],
  });

  const onSuccess = () => {
    onClose();
    queryClient.invalidateQueries([QUERY_KEYS.CONTACTS]);
  };

  const { mutate: addCustomerUsingCSV, isLoading: isAddCustomerUsingCSVLoading } = useMutation<{
    file: File;
    list_id: number;
  }>({
    url: 'add-customers-using-csv',
    isFormData: true,
    onSuccess,
  });

  const { isLoading: isAddCustomerLoading, mutate: addCustomer } = useMutation<NewContactType>({
    method: POST,
    url: 'add-customers',
    onSuccess,
  });

  return (
    <>
      <AlertDialog
        leastDestructiveRef={cancelRef}
        isOpen={isOpenDialog}
        isCentered
        onClose={onCloseDialog}>
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogBody>
              Are you sure you want to leave without adding or importing any contacts?
            </AlertDialogBody>
            <AlertDialogFooter justifyContent='center'>
              <Button variant='success' onClick={() => onCloseDialog()}>
                No
              </Button>
              <Button
                ml='5'
                variant='danger'
                onClick={() => {
                  onClose();
                  onCloseDialog();
                }}>
                Yes
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        closeOnEsc={false}
        isCentered
        closeOnOverlayClick={false}>
        <ModalOverlay />
        <ModalContent minH='540px' maxW='540px'>
          <ModalHeader>
            <Flex
              justifyContent='space-between'
              alignItems='center'
              fontSize='md'
              fontWeight='normal'>
              <Text fontWeight='bold' color='black' fontSize='18px'>
                Add Contact
              </Text>
              <SmallCloseIcon as='button' boxSize='6' onClick={onOpenDialog} />
            </Flex>
          </ModalHeader>
          <ModalBody p='0' mb='1'>
            <Tabs isFitted variant='line' px='1.5rem'>
              <TabList m='0'>
                <Tab fontWeight='500' _selected={{ color: 'purple.700', fontWeight: 'bold' }}>
                  Manual Add
                </Tab>
                <Tab fontWeight='500' _selected={{ color: 'purple.700', fontWeight: 'bold' }}>
                  Import Contact
                </Tab>
              </TabList>
              <TabPanels m='0' p='0'>
                <TabPanel m='0' p='0'>
                  <Formik
                    initialValues={INITIAL_CONTACT_VALUES}
                    validationSchema={contactSchema}
                    enableReinitialize={true}
                    onSubmit={(values) => addCustomer(values)}
                    validateOnBlur={false}
                    validateOnChange={false}>
                    {({ touched, errors }) => (
                      <Form>
                        <Flex flexDirection='column' gap='1.5rem' height='auto'>
                          <Field
                            as={Select}
                            name='list_id'
                            size='md'
                            label='Select List'
                            labelProps={{ mt: '1rem' }}
                            errorText={touched.list_id && errors.list_id}>
                            <option key={0} value={0}>
                              Please select a list
                            </option>
                            {contactList?.map(({ id, title }) => (
                              <option key={id} value={id}>
                                {title.length > 50 ? `${title.substring(0, 50)}...` : title}
                              </option>
                            ))}
                          </Field>
                          <Field
                            autoFocus
                            as={InputField}
                            name='email'
                            size='md'
                            placeholder='Enter email address'
                            label='Email'
                            errorText={touched.email && errors.email}
                          />
                          <Flex gap='1rem'>
                            <Field
                              as={InputField}
                              name='first_name'
                              size='md'
                              placeholder='Enter First Name'
                              label='First Name'
                              errorText={touched.first_name && errors.first_name}
                            />
                            <Field
                              as={InputField}
                              name='last_name'
                              size='md'
                              placeholder='Enter Last Name'
                              label='Last Name'
                              errorText={touched.last_name && errors.last_name}
                            />
                          </Flex>
                          <Field
                            as={InputField}
                            name='phone_no'
                            size='md'
                            placeholder='Enter Phone Number'
                            label='Phone Number'
                            type='number'
                            errorText={touched.phone_no && errors.phone_no}
                          />
                        </Flex>
                        <Flex justifyContent='flex-start' my='1rem'>
                          <Button
                            variant='black'
                            mr='8px'
                            type='submit'
                            isLoading={isAddCustomerLoading}>
                            Create
                          </Button>
                          <Button onClick={onClose} isDisabled={isAddCustomerLoading}>
                            Cancel
                          </Button>
                        </Flex>
                      </Form>
                    )}
                  </Formik>
                </TabPanel>
                <TabPanel m='0' p='0'>
                  <Formik
                    initialValues={{
                      file: null,
                      list_id: 0,
                      is_permitted: false,
                    }}
                    onSubmit={(values) => {
                      if (values.file !== null) {
                        addCustomerUsingCSV({
                          list_id: values.list_id,
                          file: values.file,
                        });
                      }
                    }}>
                    {({ values, errors, setFieldValue, setFieldError }) => (
                      <Form>
                        <Box height='auto'>
                          <Field
                            as={Select}
                            width='100%'
                            label='Select List'
                            mb='1rem'
                            size='md'
                            name='list_id'
                            labelProps={{
                              mt: '1rem',
                            }}
                            onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                              setFieldValue('list_id', parseInt(e.target.value))
                            }>
                            <option key={0} value={0}>
                              Please select a list
                            </option>
                            {contactList?.map(({ id, title }) => (
                              <option key={id} value={id}>
                                {title.length > 50 ? `${title.substring(0, 50)}...` : title}
                              </option>
                            ))}
                          </Field>
                          <FileUploader
                            handleChange={(file: File) => setFieldValue('file', file)}
                            name='file'
                            types={['csv']}
                            maxSize={100}
                            onTypeError={() =>
                              setFieldError(
                                'file',
                                'You are trying to upload an unsupported file. Please check again.',
                              )
                            }
                            onSizeError={() =>
                              setFieldError('file', 'File should not exceed 100 MB')
                            }>
                            <Stack
                              my='2'
                              py='16'
                              borderRadius='5'
                              background='gray.200'
                              justifyContent='center'
                              alignItems='center'>
                              <Button variant='black' fontSize='sm'>
                                Upload CSV{' '}
                              </Button>
                              {values.file && <Text>{values.file['name']}</Text>}
                              {!values.file && (
                                <>
                                  <Text>Click or drop file here to upload</Text>
                                  <Text>(max 100 MB)</Text>
                                </>
                              )}
                              {errors.file && (
                                <Text color='red.700' fontWeight='bold'>
                                  {errors.file}
                                </Text>
                              )}
                            </Stack>
                          </FileUploader>
                          <Link href={`${config.apiBaseUrl}/download-sample`}>
                            Download Sample CSV
                          </Link>
                          {values.file && (
                            <Box py='2'>
                              <Flex>
                                <Field as={Checkbox} mr='2' name='is_permitted' /> Contacts gave me
                                permission to be added to my list
                              </Flex>
                            </Box>
                          )}
                        </Box>
                        <Flex justifyContent='flex-start' my='1rem'>
                          <Button
                            variant='black'
                            mr='8px'
                            // onClick={handleSubmit}
                            isDisabled={values.is_permitted === false || values.list_id === 0}
                            isLoading={isAddCustomerUsingCSVLoading}
                            type='submit'>
                            Import
                          </Button>
                          <Button onClick={onClose} isDisabled={isAddCustomerUsingCSVLoading}>
                            Cancel
                          </Button>
                        </Flex>
                      </Form>
                    )}
                  </Formik>
                </TabPanel>
              </TabPanels>
            </Tabs>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  );
};

export default ImportContact;
