import * as Yup from 'yup';

export const senderProfileSchema = Yup.object().shape({
  sender_name: Yup.string().required('Sender name is required'),
  company_name: Yup.string().required('Company name is required'),
  sender_domain_id: Yup.number().test(
    'sender_domain_id',
    'Sender Domain is required',
    (value) => value !== 0,
  ),
  from_email: Yup.string().required('From email address is required'),
  reply_to_email: Yup.string().required('Reply email address is required'),
  street: Yup.string().nullable().required('Street address is required'),
  city: Yup.string().nullable().required('City is required'),
  state: Yup.string().nullable().required('State is required'),
  zip: Yup.string().nullable().required('Zip code is required'),
  country: Yup.string().nullable().required('Country is required'),
});
