import { ChevronRightIcon } from '@chakra-ui/icons';
import { Badge, useDisclosure } from '@chakra-ui/react';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { PageHeader, PaginatedDataTable } from 'components';
import { PageContainer } from 'components/Layout';
import { SENDER_PROFILE } from 'consts';
import { useState } from 'react';
import { ColumnProps } from 'types';
import QUERY_KEYS from 'utils/queryKeys';
import { SenderProfile } from '../Contacts/types';
import { NewSenderProfileModal, SenderProfileDetails } from './components';

const ColProps: ColumnProps[] = [
  {
    align: 'left',
  },
  {
    align: 'left',
    paddingX: '8px',
    wordBreak: 'break-word',
  },
  {
    align: 'left',
    paddingX: '8px',
    wordBreak: 'break-word',
  },
  {
    align: 'left',
  },
  {
    align: 'left',
    paddingX: '1px',
  },
  {
    align: 'left',
    width: '0.1%',
    paddingRight: '16px',
  },
];

export const EMPTY_SENDER_PROFILE: SenderProfile = {
  company_name: '',
  from_email: '',
  id: 0,
  sender_domain_id: 0,
  reply_to_email: '',
  sender_name: '',
  is_default: 0,
  state: null,
  street: null,
  city: null,
  zip: null,
  country: null,
};

const SenderProfilePage = () => {
  const { isOpen: isAddSPOpen, onOpen: onAddSPOpen, onClose: onAddSPClose } = useDisclosure();
  const { isOpen: isDetailsOpen, onOpen: onDetailsOpen, onClose: onDetailsClose } = useDisclosure();

  const [selectedProfile, setSelectedProfile] = useState<SenderProfile>(EMPTY_SENDER_PROFILE);

  const handleShowDetails = (profile: SenderProfile) => {
    setSelectedProfile(profile);
    onDetailsOpen();
  };

  const columnHelper = createColumnHelper<SenderProfile>();

  const columns = [
    columnHelper.display({
      header: 'Sender Name',
      cell: (props: CellContext<SenderProfile, unknown>) => (
        <>
          {props.row.original.sender_name}
          {props.row.original.is_default === 1 && (
            <Badge variant='info' ml='2' textTransform='capitalize'>
              Default
            </Badge>
          )}
        </>
      ),
    }),
    columnHelper.accessor('from_email', {
      header: 'From Email',
      cell: (info) => info.getValue(),
    }),
    columnHelper.accessor('reply_to_email', {
      header: 'Reply Email',
      cell: (info) => info.getValue(),
    }),
    columnHelper.accessor('company_name', {
      header: 'Company',
      cell: (info) => info.getValue(),
    }),
    columnHelper.display({
      header: 'Address',
      cell: ({ row }: CellContext<SenderProfile, unknown>) => {
        const { original } = row;
        const address = [original.street, original.city, original.state, original.zip];
        return address.filter((address) => address !== null).join(', ');
      },
    }),
    columnHelper.display({
      id: 'action',
      cell: (props: CellContext<SenderProfile, unknown>) => (
        <ChevronRightIcon
          boxSize='5'
          color='gray.500'
          cursor='pointer'
          onClick={() => handleShowDetails(props.row.original)}
        />
      ),
    }),
  ];

  return (
    <PageContainer>
      <PageHeader
        title={SENDER_PROFILE}
        subtitle='Audience'
        buttonLabel='Add Sender Profile'
        onClick={onAddSPOpen}
      />
      <NewSenderProfileModal isOpen={isAddSPOpen} onClose={onAddSPClose} />
      <SenderProfileDetails
        isOpen={isDetailsOpen}
        onClose={onDetailsClose}
        selectedProfile={selectedProfile}
      />
      <PaginatedDataTable
        endpoint='senderProfile/get-sender-profiles'
        queryKey={[QUERY_KEYS.SENDER_PROFILES]}
        columns={columns}
        showFilters={false}
        colProps={ColProps}
        emptyMessage={'No sender profile(s) found'}
      />
    </PageContainer>
  );
};

export default SenderProfilePage;
