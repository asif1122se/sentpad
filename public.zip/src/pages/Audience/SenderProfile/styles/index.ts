import { Text } from '@chakra-ui/react';
import styled from '@emotion/styled';

export const LabelInfo = styled(Text)({
  fontSize: 'var(--chakra-fontSizes-sm)',
  marginTop: '8px',
  marginBottom: '16px',
  color: 'var(--chakra-colors-gray-700)',
});
