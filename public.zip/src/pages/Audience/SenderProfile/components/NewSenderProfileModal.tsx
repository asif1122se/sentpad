import { InfoOutlineIcon } from '@chakra-ui/icons';
import {
  Button,
  Flex,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  Tooltip,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { InputField, Select } from 'components';
import { Field, Form, Formik } from 'formik';
import { useMutation } from 'hooks/useMutation';
import { useQuery } from 'hooks/useQuery';
import { DomainSetupList } from 'pages/Account/types';
import { SenderProfileForm } from 'pages/Audience/Contacts/types';
import { useMemo, useState } from 'react';
import countryList from 'react-select-country-list';
import { isDomainVerified } from 'utils';
import { POST } from 'utils/constants';
import QUERY_KEYS from 'utils/queryKeys';
import { senderProfileSchema } from '../schema';

type NewSPProps = {
  isOpen: boolean;
  onClose: () => void;
};

const ERROR_PROPS = {
  fontSize: '14px',
  marginTop: '4px',
};

const NewSenderProfileModal = ({ isOpen, onClose }: NewSPProps) => {
  const queryClient = useQueryClient();

  const countries: Array<{ label: string; value: string }> = useMemo(
    () => countryList().getData(),
    [],
  );

  const { data: domainList } = useQuery<DomainSetupList>({
    url: 'domains/list',
    queryKey: [QUERY_KEYS.DOMAIN_SETUP],
  });

  const { isLoading: isCreateLoading, mutate: createSenderProfile } = useMutation<
    SenderProfileForm & {
      sender_domain_id: number;
    }
  >({
    method: POST,
    url: 'senderProfile/save-sender-profile',
    onSuccess: () => {
      queryClient.invalidateQueries([QUERY_KEYS.SENDER_PROFILES]);
      onClose();
    },
    successMessage: 'Sender profile saved successfully',
  });

  const [domainName, setDomainName] = useState<string>('');

  const handleClose = () => {
    setDomainName('');
    onClose();
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={handleClose}
        isCentered
        closeOnEsc={false}
        closeOnOverlayClick={false}>
        <ModalOverlay />
        <ModalContent maxW='540px'>
          <Formik
            initialValues={{
              sender_name: '',
              company_name: '',
              sender_domain_id: 0,
              from_email: '',
              reply_to_email: '',
              street: '',
              city: '',
              state: '',
              zip: '',
              country: '',
            }}
            validationSchema={senderProfileSchema}
            onSubmit={({ from_email, reply_to_email, ...values }) =>
              createSenderProfile({
                from_email: `${from_email}@${domainName}`,
                reply_to_email: `${reply_to_email}@${domainName}`,
                ...values,
              })
            }>
            {({ errors, touched, setFieldValue }) => {
              return (
                <Form>
                  <ModalHeader color='black' fontSize='18px' fontWeight='bold' lineHeight='32px'>
                    Create Sender Profile
                  </ModalHeader>
                  <ModalCloseButton />
                  <ModalBody py='0' maxHeight='580px' overflow='auto'>
                    <Flex direction='column' gap='1rem'>
                      <Field
                        autoFocus
                        as={InputField}
                        name='sender_name'
                        size='md'
                        placeholder='Enter sender name'
                        label='Sender Name *'
                        errorText={touched.sender_name && errors.sender_name}
                        tooltip='This is the name used for email messages'
                        errorProps={ERROR_PROPS}
                      />
                      <Field
                        as={InputField}
                        name='company_name'
                        size='md'
                        placeholder='Enter company name'
                        label='Company Name *'
                        errorText={touched.company_name && errors.company_name}
                        tooltip='This will show in your email message footer'
                        errorProps={ERROR_PROPS}
                      />
                      <Field
                        as={Select}
                        name='sender_domain_id'
                        label='Sender Domain *'
                        size='md'
                        placeholder='Select sender domain'
                        errorText={touched.sender_domain_id && errors.sender_domain_id}
                        errorProps={ERROR_PROPS}
                        onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                          const value = parseInt(e.target.value);
                          setFieldValue('sender_domain_id', Number.isNaN(value) ? 0 : value);
                          const domain = domainList?.find((d) => d.id === value);
                          setDomainName(domain !== undefined ? domain.domain_name : '');
                        }}>
                        {domainList?.filter(isDomainVerified).map((domain) => (
                          <option key={domain.id} value={domain.id}>
                            {domain.domain_name}
                          </option>
                        ))}
                      </Field>
                      <Field
                        as={InputField}
                        name='from_email'
                        size='md'
                        placeholder='Enter email address'
                        label='From Email *'
                        errorText={touched.from_email && errors.from_email}
                        tooltip='This will show the "from" email field in an email message'
                        errorProps={ERROR_PROPS}
                        hasRightAddOn
                        rightAddOn={`${domainName !== '' ? `@${domainName}` : ''}`}
                      />
                      <Field
                        as={InputField}
                        name='reply_to_email'
                        size='md'
                        placeholder='Enter email address'
                        label='Reply to *'
                        errorText={touched.reply_to_email && errors.reply_to_email}
                        tooltip='This will show as the "reply" email field in an email message'
                        errorProps={ERROR_PROPS}
                        hasRightAddOn
                        rightAddOn={`${domainName !== '' ? `@${domainName}` : ''}`}
                      />
                    </Flex>
                    <Flex alignItems='center'>
                      <Text fontWeight='bold' my='1rem' mr='12px'>
                        Address
                      </Text>
                      <Tooltip
                        hasArrow
                        label='This will show in your email message footer'
                        bgColor='gray.800'
                        placement='right'>
                        <InfoOutlineIcon />
                      </Tooltip>
                    </Flex>
                    <Flex flexDirection='column' gap='1rem'>
                      <Field
                        as={InputField}
                        name='street'
                        size='md'
                        placeholder='Enter street address'
                        label='Street *'
                        mb='1'
                        errorText={touched.street && errors.street}
                        errorProps={ERROR_PROPS}
                      />
                      <Field
                        as={InputField}
                        name='city'
                        size='md'
                        placeholder='Enter city'
                        label='City *'
                        errorText={touched.city && errors.city}
                        errorProps={ERROR_PROPS}
                      />
                      <Flex gap='2'>
                        <Field
                          as={InputField}
                          name='state'
                          size='md'
                          placeholder='Enter state'
                          label='State *'
                          errorText={touched.state && errors.state}
                          errorProps={ERROR_PROPS}
                        />
                        <Field
                          as={InputField}
                          name='zip'
                          size='md'
                          placeholder='Enter zip'
                          label='Zip *'
                          errorText={touched.zip && errors.zip}
                          errorProps={ERROR_PROPS}
                        />
                      </Flex>

                      <Field
                        as={Select}
                        name='country'
                        label='Country *'
                        size='md'
                        placeholder='Select country'
                        errorText={touched.country && errors.country}
                        errorProps={ERROR_PROPS}>
                        {countries.map(({ label, value }) => (
                          <option key={value} value={label}>
                            {label}
                          </option>
                        ))}
                      </Field>
                    </Flex>
                  </ModalBody>
                  <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
                    <Button
                      type='submit'
                      variant='success'
                      mr='8px'
                      isLoading={isCreateLoading}
                      isDisabled={isCreateLoading}>
                      Create
                    </Button>
                    <Button onClick={handleClose} isDisabled={isCreateLoading}>
                      Cancel
                    </Button>
                  </ModalFooter>
                </Form>
              );
            }}
          </Formik>
        </ModalContent>
      </Modal>
    </>
  );
};

export default NewSenderProfileModal;
