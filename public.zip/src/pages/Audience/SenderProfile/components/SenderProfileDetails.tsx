import {
  Badge,
  Button,
  Drawer,
  DrawerBody,
  DrawerContent,
  DrawerHeader,
  DrawerOverlay,
  Flex,
  Text,
  useDisclosure,
} from '@chakra-ui/react';
import { DetailLabelValue, InputField, KebabMenu, Select } from 'components';
import { Field, Form, Formik } from 'formik';
import { useEffect, useMemo, useRef, useState } from 'react';
import DeleteSenderProfileModal from './DeleteSenderProfileModal';
import countryList from 'react-select-country-list';
import { SenderProfile, SenderProfileForm } from 'pages/Audience/Contacts/types';
import { useMutation } from 'hooks/useMutation';
import { PUT } from 'utils/constants';
import { useQueryClient } from '@tanstack/react-query';
import QUERY_KEYS from 'utils/queryKeys';
import { senderProfileSchema } from '../schema';
import { useQuery } from 'hooks/useQuery';
import { DomainSetupList } from 'pages/Account/types';
import { isDomainVerified } from 'utils';

type SenderProfileDetailsProps = {
  isOpen: boolean;
  onClose: () => void;
  selectedProfile: SenderProfile;
};

const SenderProfileDetails = ({ isOpen, onClose, selectedProfile }: SenderProfileDetailsProps) => {
  const {
    company_name,
    from_email,
    id,
    sender_domain_id,
    reply_to_email,
    sender_name,
    is_default,
    state,
    street,
    city,
    zip,
    country,
  } = selectedProfile;
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const btnRef = useRef<any>();

  const countries: Array<{ label: string; value: string }> = useMemo(
    () => countryList().getData(),
    [],
  );

  const [isEdit, setIsEdit] = useState(false);
  const [domainName, setDomainName] = useState('');

  const { data: domainList } = useQuery<DomainSetupList>({
    url: 'domains/list',
    queryKey: [QUERY_KEYS.DOMAIN_SETUP],
  });

  const queryClient = useQueryClient();

  const { isLoading: isSetDefaultLoading, mutate: setDefault } = useMutation<{ id: number }>({
    method: PUT,
    url: 'senderProfile/set-default-profile',
    onSuccess: () => {
      queryClient.invalidateQueries([QUERY_KEYS.SENDER_PROFILES]);
      handleOnDetailsClose();
    },
    successMessage: 'Sender profile set as default',
  });

  const { isLoading: isEditLoading, mutate: editProfile } = useMutation<SenderProfileForm>({
    method: PUT,
    url: `senderProfile/edit-sender-profile/${id}`,
    onSuccess: () => {
      queryClient.invalidateQueries([QUERY_KEYS.SENDER_PROFILES]);
      handleOnDetailsClose();
    },
    successMessage: 'Sender profile updated successfully',
  });

  const kebabMenu = [
    {
      label: 'Delete',
      onClick: onDeleteOpen,
    },
  ];

  const isDefault = is_default === 1;

  const handleOnDetailsClose = () => {
    onClose();
    setIsEdit(false);
  };

  const handleSetAsDefault = (id: number) => {
    setDefault({ id });
  };

  const handleCancel = () => {
    setIsEdit(false);
    setInitialDomainName();
  };

  const setInitialDomainName = () => {
    if (domainList) {
      const name = domainList?.find((d) => d.id === sender_domain_id)?.domain_name;
      setDomainName(name ?? '');
    }
  };

  useEffect(() => {
    setInitialDomainName();
  }, [id]);

  return (
    <>
      <DeleteSenderProfileModal
        isOpen={isDeleteOpen}
        onDrawerClose={handleOnDetailsClose}
        onDeleteClose={onDeleteClose}
        senderProfileID={selectedProfile.id}
        isDefault={isDefault}
      />
      <Drawer
        isOpen={isOpen}
        placement='right'
        onClose={handleOnDetailsClose}
        finalFocusRef={btnRef}
        size='md'
        closeOnEsc={!isSetDefaultLoading && !isEditLoading}
        closeOnOverlayClick={!isSetDefaultLoading && !isEditLoading}>
        <DrawerOverlay />
        <DrawerContent>
          <DrawerHeader
            borderBottom='1px solid'
            borderColor='gray.400'
            mb='1.5rem'
            display='flex'
            justifyContent='space-between'
            alignItems='center'>
            <Flex
              alignItems='center'
              gap='2'
              justifyContent={isDefault ? 'flex-start' : 'space-between'}
              w='100%'>
              <Text fontSize='20px' fontWeight='bold'>
                Sender Profile
              </Text>
              {isDefault ? (
                <Badge variant='info' textTransform='capitalize'>
                  Default
                </Badge>
              ) : (
                <Button
                  variant='infoOutlined'
                  mr='12px'
                  onClick={() => handleSetAsDefault(id)}
                  isLoading={isSetDefaultLoading}
                  isDisabled={isSetDefaultLoading}>
                  Set as Default
                </Button>
              )}
            </Flex>

            <KebabMenu menu={kebabMenu} width='24px' height='21px' transparent />
          </DrawerHeader>

          <DrawerBody>
            <Text fontWeight='bold'>Sender Profile Details</Text>
            <Formik
              initialValues={{
                sender_name,
                company_name,
                sender_domain_id,
                from_email: from_email.split('@')[0],
                reply_to_email: reply_to_email.split('@')[0],
                street,
                city,
                state,
                zip,
                country: countries.find((c) => c.label === country) ? country : '',
              }}
              onSubmit={(values) =>
                editProfile({
                  ...values,
                  from_email: `${values.from_email}@${domainName}`,
                  reply_to_email: `${values.reply_to_email}@${domainName}`,
                })
              }
              validationSchema={senderProfileSchema}>
              {({ errors, touched, setFieldValue }) => (
                <Form>
                  <Flex
                    border='1px solid'
                    borderColor='gray.400'
                    borderRadius='8px'
                    p='24px'
                    mt='1rem'
                    flexDirection='column'
                    gap='1rem'>
                    {isEdit ? (
                      <>
                        <Field
                          as={InputField}
                          size='md'
                          label='Sender Name'
                          placeholder='Enter Sender Name'
                          name='sender_name'
                          maxLength={30}
                          errorText={touched.sender_name && errors.sender_name}
                        />
                        <Field
                          as={InputField}
                          size='md'
                          label='Company Name'
                          placeholder='Enter Company Name'
                          name='company_name'
                          maxLength={30}
                          errorText={touched.company_name && errors.company_name}
                        />
                        <Field
                          as={Select}
                          name='sender_domain_id'
                          label='Sender Domain'
                          size='md'
                          placeholder='Select sender domain'
                          errorText={touched.sender_domain_id && errors.sender_domain_id}
                          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                            const value = parseInt(e.target.value);
                            setFieldValue('sender_domain_id', Number.isNaN(value) ? 0 : value);
                            const domain = domainList?.find((d) => d.id === value);
                            setDomainName(domain !== undefined ? domain.domain_name : '');
                          }}>
                          {domainList?.filter(isDomainVerified).map((domain) => (
                            <option key={domain.id} value={domain.id}>
                              {domain.domain_name}
                            </option>
                          ))}
                        </Field>
                        <Field
                          as={InputField}
                          size='md'
                          label='From Email'
                          placeholder='Enter From Email'
                          name='from_email'
                          maxLength={50}
                          errorText={touched.from_email && errors.from_email}
                          hasRightAddOn
                          rightAddOn={`${domainName !== '' ? `@${domainName}` : ''}`}
                        />
                        <Field
                          as={InputField}
                          size='md'
                          label='Reply Email'
                          placeholder='Enter Reply Email'
                          name='reply_to_email'
                          maxLength={50}
                          errorText={touched.reply_to_email && errors.reply_to_email}
                          hasRightAddOn
                          rightAddOn={`${domainName !== '' ? `@${domainName}` : ''}`}
                        />
                        <Field
                          as={InputField}
                          size='md'
                          label='Street Address'
                          placeholder='Enter Street Address'
                          name='street'
                          maxLength={50}
                          errorText={touched.street && errors.street}
                        />
                        <Field
                          as={InputField}
                          size='md'
                          label='City'
                          placeholder='Enter City'
                          name='city'
                          maxLength={30}
                          errorText={touched.city && errors.city}
                        />
                        <Flex justifyContent='space-between' gap='8px'>
                          <Field
                            as={InputField}
                            size='md'
                            label='State'
                            placeholder='Enter State'
                            name='state'
                            maxLength={30}
                            errorText={touched.state && errors.state}
                          />
                          <Field
                            as={InputField}
                            size='md'
                            label='Zip'
                            placeholder='Enter Zip Code'
                            name='zip'
                            maxLength={10}
                            errorText={touched.zip && errors.zip}
                          />
                        </Flex>
                        <Field
                          as={Select}
                          size='md'
                          placeholder='Select country'
                          label='Country'
                          name='country'
                          errorText={touched.country && errors.country}>
                          {countries.map(({ label, value }) => (
                            <option key={value} value={label}>
                              {label}
                            </option>
                          ))}
                        </Field>
                        <Flex gap='1rem'>
                          <Button
                            variant='success'
                            type='submit'
                            isLoading={isEditLoading}
                            isDisabled={isEditLoading}>
                            Save
                          </Button>
                          <Button onClick={handleCancel} isDisabled={isEditLoading}>
                            Cancel
                          </Button>
                        </Flex>
                      </>
                    ) : (
                      <>
                        <Button
                          variant='infoOutlined'
                          w='fit-content'
                          onClick={() => setIsEdit(true)}>
                          Edit Profile
                        </Button>
                        <DetailLabelValue
                          name='sender_name'
                          label='Sender Name'
                          value={sender_name}
                        />
                        <DetailLabelValue
                          name='company_name'
                          label='Company Name'
                          value={company_name}
                        />
                        <DetailLabelValue
                          name='sender_domain'
                          label='Sender Domain'
                          value={domainList?.find((d) => d.id === sender_domain_id)?.domain_name}
                        />
                        <DetailLabelValue name='from_email' label='From Email' value={from_email} />
                        <DetailLabelValue
                          name='reply_to_email'
                          label='Reply Email'
                          value={reply_to_email}
                        />
                        <DetailLabelValue name='street' label='Street Address' value={street} />
                        <DetailLabelValue name='city' label='City' value={city} />
                        <Flex>
                          <DetailLabelValue
                            name='state'
                            label='State'
                            value={state}
                            width='50%'
                            mr='1rem'
                          />
                          <DetailLabelValue name='zip' label='Zip' value={zip} />
                        </Flex>
                        <DetailLabelValue name='country' label='Country' value={country} />
                      </>
                    )}
                  </Flex>
                </Form>
              )}
            </Formik>
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </>
  );
};

export default SenderProfileDetails;
