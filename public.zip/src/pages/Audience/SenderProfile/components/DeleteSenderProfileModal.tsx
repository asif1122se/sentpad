import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  Flex,
  Box,
  Image,
  chakra,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { DELETE } from 'utils/constants';
import AlertIcon from 'assets/icons/alert.svg';
import { useMutation } from 'hooks/useMutation';
import QUERY_KEYS from 'utils/queryKeys';
import InfoIcon from 'assets/icons/info-orange.svg';

type DeleteSenderProfileModal = {
  isOpen: boolean;
  onDrawerClose: () => void;
  onDeleteClose: () => void;
  senderProfileID: number;
  isDefault: boolean;
};

const DeleteSenderProfileModal = ({
  isOpen,
  onDrawerClose,
  onDeleteClose,
  senderProfileID,
  isDefault,
}: DeleteSenderProfileModal) => {
  const queryClient = useQueryClient();

  const { isLoading, mutate } = useMutation<string | number>({
    method: DELETE,
    url: 'senderProfile/delete',
    onSuccess: () => {
      onDeleteClose();
      onDrawerClose();
      queryClient.invalidateQueries([QUERY_KEYS.SENDER_PROFILES]);
    },
    successMessage: 'Sender Profile deleted successfully',
  });

  const handleDelete = () => senderProfileID && mutate(senderProfileID);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onDeleteClose}
      isCentered
      size='lg'
      closeOnEsc={isLoading}
      closeOnOverlayClick={isLoading}>
      <ModalOverlay />
      <ModalContent px='32px' py='25px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            {isDefault ? 'Default Sender Profile' : 'Delete Profile'}
          </Text>
        </ModalHeader>
        <ModalCloseButton isDisabled={isLoading} mt='13px' />
        <ModalBody px='0' pt='2rem' pb='0'>
          {isDefault && (
            <Flex fontSize='md'>
              <Box w='40px' mr='1rem'>
                <Image src={AlertIcon} alt='Alert' w='100%' />
              </Box>
              <Text w='380px'>
                This is the default sender profile and cannot be deleted. Please select another
                sender profile as the default before deleting this one.
              </Text>
            </Flex>
          )}
          {!isDefault && (
            <Flex fontSize='md' flexDirection='column'>
              <Text>
                Are you sure you want to <chakra.span fontWeight='600'>delete</chakra.span> this
                sender profile?
              </Text>
              <Text>This action cannot be undone.</Text>
              <Flex
                bgColor='orange.200'
                border='1px solid'
                borderColor='orange.700'
                borderRadius='4px'
                p='1rem'
                mt='2rem'
                alignItems='flex-start'>
                <Image src={InfoIcon} alt='Info Icon' w='24px' mr='16px' mt='4px' />
                <Text color='orange.900' fontSize='14px'>
                  Warning: Sender profiles linked to (broadcasts, emails, etc) will have associated
                  events set to use your default sender profile after deletion.
                </Text>
              </Flex>
            </Flex>
          )}
        </ModalBody>

        <ModalFooter justifyContent='flex-start' pt='6' pb='0' px='0'>
          {isDefault ? (
            <Button variant='black' w='80px' mr={2} onClick={onDeleteClose}>
              OK
            </Button>
          ) : (
            <>
              <Button variant='danger' mr={2} onClick={handleDelete} isLoading={isLoading}>
                Delete Profile
              </Button>
              <Button onClick={onDeleteClose} isDisabled={isLoading}>
                Cancel
              </Button>
            </>
          )}
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeleteSenderProfileModal;
