import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  Flex,
  Box,
  Image,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { DELETE } from 'utils/constants';
import AlertIcon from 'assets/icons/alert.svg';
import { useMutation } from 'hooks/useMutation';
import { useNavigate } from 'react-router-dom';
import QUERY_KEYS from 'utils/queryKeys';
import { ROUTE_PATHS } from 'router';

type DeleteSegmentModal = {
  isOpen: boolean;
  onClose: () => void;
  segmentId?: string | number;
};

const DeleteSegmentModal = ({ isOpen, onClose, segmentId }: DeleteSegmentModal) => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { isLoading, mutate } = useMutation<string | number>({
    method: DELETE,
    url: `segment/delete-segment`,
    onSuccess: () => {
      onClose();
      queryClient.invalidateQueries([QUERY_KEYS.MAIN_SEGMENTS]);
      navigate(`/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.SEGMENTS}`);
    },
  });

  const handleDelete = () => segmentId && mutate(segmentId);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      isCentered
      size='lg'
      closeOnEsc={isLoading}
      closeOnOverlayClick={isLoading}>
      <ModalOverlay />
      <ModalContent px='32px' py='25px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            Delete Segment
          </Text>
        </ModalHeader>
        <ModalCloseButton isDisabled={isLoading} mt='13px' />
        <ModalBody px='0' pt='6'>
          <Flex fontSize='md'>
            <Box justifyContent='flex-start'>
              <Image src={AlertIcon} alt='Alert' height='50px' width='50px' />
            </Box>
            <Box px='4' py='1' mb='2'>
              <Text>Are you sure you want to delete this segment?</Text>
              <Text>This action cannot be undone.</Text>
            </Box>
          </Flex>
        </ModalBody>

        <ModalFooter justifyContent='flex-start' pb='0' px='0'>
          <Button variant='danger' mr={2} onClick={handleDelete} isLoading={isLoading}>
            Delete Segment
          </Button>
          <Button onClick={onClose} isDisabled={isLoading}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeleteSegmentModal;
