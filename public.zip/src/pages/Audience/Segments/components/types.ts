import { PaginatedTable, TrueOrFalse } from 'types';

export type Customer = {
  address_one: string | null;
  address_two: string | null;
  city: string | null;
  country: string | null;
  created_at: string;
  csv_bit: number;
  date_of_birth: string | null;
  deleted_at: string | null;
  email: string;
  first_name: string;
  id: number;
  is_email_valid: TrueOrFalse;
  is_subscribed: TrueOrFalse;
  is_supression: TrueOrFalse;
  last_name: string | null;
  list_id: number;
  phone_no: string | null;
  state: string | null;
  subscribe_date: string | null;
  subscription_status: TrueOrFalse;
  supressed_date: string | null;
  unsubscribe_date: string | null;
  updated_at: string;
  user_id: number;
  zip_code: null;
};

export type SegmentById = {
  id: number;
  name: string;
  processed_at: string;
  conditions: any;
  customers: PaginatedTable<Customer[]>;
  contacts: number;
  created_at: string;
  deleted_at: string | null;
  updated_at: string | null;
  user_id: number;
};

export type EditSegmentName = {
  id?: string;
  name: string;
};

export type segmentFilterType = {
  name: string;
  processed_at: string;
};
