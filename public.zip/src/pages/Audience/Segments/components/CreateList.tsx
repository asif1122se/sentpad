import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
} from '@chakra-ui/react';
import { InputField } from 'components';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from 'hooks/useMutation';

type CreateListProps = {
  isOpen: boolean;
  onClose: () => void;
  segmentContacts: any;
};

const CreateList = ({ isOpen, onClose, segmentContacts }: CreateListProps) => {
  const navigate = useNavigate();

  const [value, setValue] = useState<string>('');
  const { mutate, isLoading } = useMutation<any>({
    url: 'segment/add-segment-customers-to-list',
    onSuccess: (data) => onClose(),
  });

  const createListFunc = async () => {
    mutate({
      title: value,
      customer_ids: segmentContacts?.map((item: any) => item?.id)?.toString(),
    });
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} closeOnOverlayClick={value === ''} isCentered>
      <ModalOverlay />
      <ModalContent minW='540px'>
        <ModalHeader color='black' fontSize='18px' fontWeight='bold' p='2rem 2rem 1rem'>
          Create New List
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody p='0 2rem'>
          <InputField
            label='List Name'
            placeholder='Enter list name'
            maxLength={50}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            autoFocus
          />
        </ModalBody>

        <ModalFooter display='flex' justifyContent='flex-start' p='1.5rem 2rem 2rem'>
          <Button
            isLoading={isLoading}
            isDisabled={value ? false : true}
            variant={value ? 'success' : 'default'}
            mr={3}
            onClick={() => createListFunc()}>
            Create
          </Button>
          <Button
            onClick={() => {
              setValue('');
              onClose();
            }}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default CreateList;
