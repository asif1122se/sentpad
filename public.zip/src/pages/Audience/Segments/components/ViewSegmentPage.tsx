import {
  Box,
  Button,
  Flex,
  Heading,
  Image,
  Spinner,
  Text,
  useDisclosure,
  useToast,
} from '@chakra-ui/react';
import { InputField, Segments } from 'components';
import { PageContainer } from 'components/Layout';
import { DetailHeader } from 'pages/Audience/Lists/styles';
import PencilIcon from 'assets/icons/pencil.png';
import { useState } from 'react';
import { CheckIcon, ChevronRightIcon, SmallCloseIcon } from '@chakra-ui/icons';
import KebabMenu from 'components/KebabMenu';
import { ColumnProps } from 'types';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { Contact } from 'pages/Audience/Contacts/types';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import ArrowBackIcon from 'assets/icons/arrow-back.svg';
import { Router, useNavigate, useParams } from 'react-router-dom';
import { EditSegmentName, SegmentById, segmentFilterType } from './types';
import { useMutation } from 'hooks/useMutation';
import { useQueryClient } from '@tanstack/react-query';
import { utcToZonedTime, format } from 'date-fns-tz';
import { formatDistance } from 'date-fns';
import DeleteSegmentModal from './DeleteSegmentsModal';
import CreateList from './CreateList';
import SegmentContactsTable from './SegmentContactsTable';

const formatInTimeZone = (date: Date, formatTimeZone: string, timeZone: string) =>
  new Date(format(utcToZonedTime(date, timeZone), formatTimeZone, { timeZone }));

const ViewSegmentPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const queryClient = useQueryClient();
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const UTCTimeNow = formatInTimeZone(new Date(), 'yyyy-MM-dd kk:mm:ss', 'UTC');
  const [isEdit, setIsEdit] = useState<boolean>(false);
  const [rowSelection, setRowSelection] = useState<{ [key: number]: boolean }>({});
  const [segmentName, setSegmentName] = useState<string>('');
  const [conditionValues, setConditionValues] = useState<any>([]);
  const [segmentContacts, setSegmentContacts] = useState<any>([]);
  const [showError, setShowError] = useState<boolean>(false);
  const [isValid, setIsValid] = useState<boolean>(false);
  const toast = useToast();
  const {
    isOpen: isCreateListOpen,
    onOpen: onCreateListOpen,
    onClose: onCreateListClose,
  } = useDisclosure();

  const { data: getSegmentByIdData, isLoading: getSegmentByIdLoading } = useQuery<SegmentById>({
    url: `segment/get-segment/${id}`,
    queryKey: [QUERY_KEYS.GET_SEGMENTS],
    onSuccess: (data) => {
      setSegmentName(`${data?.name}`);
      setSegmentContacts(data?.customers?.data);
    },
  });

  const { data: segmentFilters, isLoading: segmentFiltersLoading } =
    useQuery<segmentFilterType | null>({
      url: 'segment/get-filters',
      queryKey: [QUERY_KEYS.SEGMENT_FILTERS],
    });

  const { mutate, isLoading: isLoadingEditSegName } = useMutation<EditSegmentName>({
    url: 'segment/save-segment',
    onSuccess: () => queryClient.invalidateQueries([QUERY_KEYS.GET_SEGMENTS]),
  });

  const saveArName = async () => {
    mutate({ name: segmentName, id: id });
  };

  const { mutate: saveSegment, isLoading: isLoadingSaveSegment } = useMutation<any>({
    url: 'segment/save-segment-filters',
    onSuccess: (data) => {
      setSegmentContacts(data?.records);
      setTimeout(() => {
        queryClient.invalidateQueries([QUERY_KEYS.GET_SEGMENTS]);
      }, 1000);
    },
  });

  const saveSegmentFunc = () => {
    if (isValid) {
      const obj = { segment_id: id, filter: conditionValues };
      saveSegment(obj);
    } else {
      toast({
        title: `Please fill up all the fields`,
        status: 'error',
        position: 'top-right',
        isClosable: true,
      });
    }
  };

  const getConditionsValues = (data: any, filterType: string) => {
    setConditionValues(data.flat(1));
    const formatedData = data.flat(1);
    for (let i = 0; i <= formatedData?.length - 1; i++) {
      if (!formatedData[i]?.filter_value && !formatedData[i]?.filter_condition) {
        setIsValid(false);
        {
          break;
        }
      } else if (
        formatedData[i]?.segment_filter_id == '3' &&
        (!formatedData[i]?.filter_condition || !formatedData[i]?.filter_value)
      ) {
        setIsValid(false);
        {
          break;
        }
      } else if (
        (formatedData[i]?.segment_filter_id == '4' || formatedData[i]?.segment_filter_id == '5') &&
        !formatedData[i]?.filter_value &&
        (formatedData[i]?.filter_condition == '13' ||
          formatedData[i]?.filter_condition == '14' ||
          formatedData[i]?.filter_condition == '15')
      ) {
        setIsValid(false);
        {
          break;
        }
      } else {
        setIsValid(true);
      }
    }
  };

  const columnHelper = createColumnHelper<Contact>();
  const columns = [
    columnHelper.display({
      id: 'name',
      header: 'Name',
      cell: (props: CellContext<Contact, unknown>) => (
        <>
          {props.row.original.first_name} {props.row.original.last_name}
        </>
      ),
    }),
    columnHelper.accessor('email', {
      cell: (info) => info.getValue(),
      header: 'Email',
    }),
    columnHelper.accessor('created_at', {
      cell: (info) => info.getValue(),
      header: 'Date Added',
    }),

    columnHelper.display({
      id: 'action',
      cell: () => <ChevronRightIcon boxSize='5' color='gray.500' cursor='pointer' />,
    }),
  ];

  const contactColProps: ColumnProps[] = [
    {
      align: 'left',
      paddingX: '16px',
    },
    {
      align: 'left',
      paddingX: '0px',
    },
    {
      align: 'left',
      paddingX: '3px',
    },
    {
      align: 'center',
      paddingX: '3px',
    },

    {
      align: 'right',
      paddingX: '3px',
    },
  ];

  const kebabMenu = [
    {
      label: 'Delete Segment',
      onClick: () => onDeleteOpen(),
    },
  ];

  return (
    <PageContainer>
      <DeleteSegmentModal isOpen={isDeleteOpen} segmentId={id} onClose={onDeleteClose} />
      <DetailHeader>
        <Heading as='h1' fontSize='2rem' lineHeight='2.438rem'>
          <Flex alignItems='center' justifyContent='flex-start' maxWidth='95%'>
            <Image
              src={ArrowBackIcon}
              alt='Back'
              cursor='pointer'
              onClick={() => navigate('/audience/segments')}
            />
            {isEdit ? (
              <InputField
                onChange={(e) => setSegmentName(e.target.value)}
                value={segmentName}
                autoFocus
                minWidth='300px'
                name='segment_name'
                size='md'
                borderColor='gray.400'
                color='black'
                placeholder='Enter segment name'
                fontWeight='normal'
                fontSize='md'
                maxLength={100}
              />
            ) : (
              <Flex alignItems='center'>
                <Text fontWeight='bold' textAlign='left' minWidth='600px'>
                  {getSegmentByIdLoading || isLoadingEditSegName ? (
                    <Spinner></Spinner>
                  ) : (
                    getSegmentByIdData?.name
                  )}
                  {!isEdit ? (
                    <Image
                      src={PencilIcon}
                      display='inline-block'
                      boxSize='6'
                      ml='3'
                      color='gray.500'
                      onClick={() => {
                        queryClient.invalidateQueries([QUERY_KEYS.GET_SEGMENTS]);
                        setIsEdit(!isEdit);
                      }}
                      cursor='pointer'
                    />
                  ) : (
                    ''
                  )}
                </Text>
              </Flex>
            )}

            {!isEdit ? (
              ''
            ) : (
              <>
                <CheckIcon
                  mx='3'
                  boxSize='4'
                  color='green.500'
                  cursor='pointer'
                  onClick={() => {
                    segmentName && setIsEdit(!isEdit);
                    segmentName && saveArName();
                  }}
                />
                <SmallCloseIcon
                  boxSize='6'
                  color='red.700'
                  cursor='pointer'
                  onClick={() => setIsEdit(!isEdit)}
                />
              </>
            )}
          </Flex>
          <Text ml='3px' fontSize='sm' color='gray.600'>
            Last processed{' '}
            {getSegmentByIdData?.processed_at &&
              formatDistance(new Date(`${getSegmentByIdData?.processed_at}`), UTCTimeNow, {
                addSuffix: true,
              })}
          </Text>
        </Heading>
        <Flex alignItems='flex-start' gap='10px'>
          <Button variant='success' onClick={saveSegmentFunc} isLoading={isLoadingSaveSegment}>
            Scan and Save
          </Button>
          <Button
            variant='black'
            onClick={onCreateListOpen}
            isDisabled={segmentContacts?.length == 0}>
            Create List
          </Button>
          <CreateList
            isOpen={isCreateListOpen}
            onClose={onCreateListClose}
            segmentContacts={segmentContacts}
          />
          <KebabMenu menu={kebabMenu} />
        </Flex>
      </DetailHeader>

      <Segments
        segmentFilters={segmentFilters}
        getConditionsValues={getConditionsValues}
        showError={showError}
        getSegmentByIdData={getSegmentByIdData?.conditions}
      />

      <Box p='2' mt='3'>
        <SegmentContactsTable
          title='Contacts'
          endpoint={`segment/get-segment/${id}`}
          columns={columns}
          showFilters={false}
          colProps={contactColProps}
          rowSelection={rowSelection}
          setRowSelection={setRowSelection}
          emptyMessage='No contact(s) found'
          id={parseInt(id ?? '0')}
        />
      </Box>
    </PageContainer>
  );
};

export default ViewSegmentPage;
