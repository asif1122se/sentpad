import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
} from '@chakra-ui/react';
import { InputField } from 'components';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from 'hooks/useMutation';

type AddNewSegmentModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

const AddNewSegmentModal = ({ isOpen, onClose }: AddNewSegmentModalProps) => {
  const navigate = useNavigate();

  const [value, setValue] = useState<string>('');
  const { mutate, isLoading } = useMutation<any>({
    url: 'segment/save-segment',
    onSuccess: (data) => (window.location.href = `/audience/view-segment/${data?.records?.id}`),
  });

  const saveArName = async () => {
    mutate({ name: value });
  };

  const resetSegmetName = () => {
    setValue('');
  };

  useEffect(() => {
    resetSegmetName();
  }, []);

  return (
    <Modal isOpen={isOpen} onClose={onClose} closeOnOverlayClick={value === ''} isCentered>
      <ModalOverlay />
      <ModalContent minW='540px'>
        <ModalHeader color='black' fontSize='18px' fontWeight='bold' p='2rem 2rem 1rem'>
          Create New Segment
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody p='0 2rem'>
          <InputField
            label='Segment Name'
            placeholder='Enter segment name'
            maxLength={50}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            autoFocus
          />
        </ModalBody>

        <ModalFooter display='flex' justifyContent='flex-start' p='1.5rem 2rem 2rem'>
          <Button
            isLoading={isLoading}
            isDisabled={value ? false : true}
            variant={value ? 'success' : 'default'}
            mr={3}
            onClick={() => saveArName()}>
            Create
          </Button>
          <Button
            onClick={() => {
              setValue('');
              onClose();
            }}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default AddNewSegmentModal;
