import { ChevronRightIcon } from '@chakra-ui/icons';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { PageHeader, PaginatedDataTable } from 'components';
import { PageContainer } from 'components/Layout';
import { useNavigate } from 'react-router-dom';
import { formatDistance } from 'date-fns';
import { ColumnProps } from 'types';
import { useDisclosure } from '@chakra-ui/react';
import AddNewSegmentModal from './components/AddNewSegmentModal';
import QUERY_KEYS from 'utils/queryKeys';
import { utcToZonedTime, format } from 'date-fns-tz';

type Segments = {
  id: number;
  name: string;
  contacts: number;
  created_at: string;
  deleted_at: null;
  processed_at: string;
  updated_at: string;
  user_id: number;
};

const segmentColProps: ColumnProps[] = [
  {
    align: 'left',
    paddingX: '20px',
    width: '60%',
  },
  {
    align: 'center',
  },
  {
    align: 'center',
  },
  {
    align: 'right',
    width: '0.1%',
    paddingRight: '20px',
  },
];

const formatInTimeZone = (date: Date, formatTimeZone: string, timeZone: string) =>
  new Date(format(utcToZonedTime(date, timeZone), formatTimeZone, { timeZone }));

const SegmentsPage = () => {
  const columnHelper = createColumnHelper<Segments>();
  const {
    isOpen: isAddSegmentOpen,
    onOpen: onAddSegmentOpen,
    onClose: onAddSegmentClose,
  } = useDisclosure();

  const UTCTimeNow = formatInTimeZone(new Date(), 'yyyy-MM-dd kk:mm:ss', 'UTC');

  const columns = [
    columnHelper.accessor('name', {
      cell: (info) => info.getValue(),
      header: 'Segment Name',
    }),
    columnHelper.display({
      header: 'Contacts',
      cell: (props: CellContext<Segments, unknown>) => (
        <>{Intl.NumberFormat('en-US').format(props.row.original.contacts)}</>
      ),
    }),
    columnHelper.display({
      header: 'Last Processed',
      cell: (props: CellContext<Segments, unknown>) => (
        <>
          {formatDistance(new Date(props.row.original.processed_at), UTCTimeNow, {
            addSuffix: true,
          })}
        </>
      ),
    }),

    columnHelper.display({
      id: 'action',
      cell: (props) => (
        <ChevronRightIcon
          boxSize='5'
          color='gray.500'
          cursor='pointer'
          onClick={() => (window.location.href = `/audience/view-segment/${props.row.original.id}`)}
        />
      ),
    }),
  ];

  return (
    <PageContainer>
      <PageHeader
        title='Segments'
        subtitle='Audience'
        buttonLabel='Add Segment'
        onClick={onAddSegmentOpen}
      />
      <AddNewSegmentModal isOpen={isAddSegmentOpen} onClose={onAddSegmentClose} />
      <PaginatedDataTable
        endpoint='segment/get-segments-paginated'
        queryKey={[QUERY_KEYS.MAIN_SEGMENTS]}
        columns={columns}
        colProps={segmentColProps}
        showFilters={false}
        emptyMessage='No segment(s) found'
      />
    </PageContainer>
  );
};

export default SegmentsPage;
