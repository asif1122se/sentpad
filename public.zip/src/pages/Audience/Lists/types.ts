export type List = {
  id: number;
  user_id: number;
  title: string;
  no_of_contacts: number | string;
  created_at: string;
};

export type ListListItem = {
  id: number;
  title: string;
};

export type ListList = List[];
export type ListLists = ListListItem[];

export type ListDetailGeneral = {
  subscribed: number;
  unsubscribed: number;
};
export type ListDetailHealth = {
  click_rate: number;
  growth_rate: number;
  open_rate: number;
  unsubscribed: number;
};

export type ListDetailAnalytics = {
  general: ListDetailGeneral;
  health: ListDetailHealth;
};

export type ListGrowthObj = {
  label_name: string;
  subscribed: number;
  unsubscribed: number;
};

export type ListGrowth = ListGrowthObj[];

export type SuppresedItem = {
  id: number;
  email: string;
  supressed_date: string;
};

export type SuppressedList = SuppresedItem[];
