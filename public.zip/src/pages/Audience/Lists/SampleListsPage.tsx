import { DataTable, PageHeader } from 'components';
import { PageContainer } from 'components/Layout';
import { ColumnProps } from 'types/general';
import KebabMenu from 'components/KebabMenu';
import { Badge, Button, useDisclosure } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { createColumnHelper } from '@tanstack/react-table';
import { List, ListList } from './types';
import { IndeterminateCheckbox } from 'components/Checkbox';
import { ChevronRightIcon } from '@chakra-ui/icons';
import { useEffect, useState } from 'react';
import AddNewListModal from './components/AddNewListModal';
import DeleteListModal from './components/DeleteListModal';
import { format } from 'date-fns';
import SuppressionList from './components/SuppressionList';
import config from 'config';

const allListings = [
  {
    created_at: '2022-08-04T12:41:07.000000Z',
    customers: [
      {
        no_of_contacts: '9,727',
      },
    ],
    deleted_at: null,
    description: null,
    id: 305,
    is_active: '1',
    no_of_contacts: 9727,
    sender_profile: null,
    sender_profile_id: null,
    title: 'Primary List',
    updated_at: '2022-08-04T12:41:07.000000Z',
    user_id: 185,
  },
];

const SampleListsPage = () => {
  const { isOpen: isAddListOpen, onOpen: onAddListOpen, onClose: onAddListClose } = useDisclosure();
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const detailLink =
    localStorage.getItem('email') === config.demoUser
      ? `/audience/list-details-analytics`
      : `/audience/list-details`;

  const listColProps: ColumnProps[] = [
    {
      align: 'center',
      paddingX: '2px',
      width: '3%',
    },
    {
      align: 'center',
      paddingX: '1px',
      width: '5.5%',
    },
    {
      align: 'left',
      paddingX: '1px',
    },
    {
      align: 'right',
      paddingX: '0px',
    },

    {
      align: 'left',
      width: '14%',
    },
    {
      align: 'right',
      width: '0.1%',
      paddingRight: '1px',
    },
  ];

  const [rowSelection, setRowSelection] = useState<{ [key: number]: boolean }>({});
  const [selectedLists, setSelectedLists] = useState<ListList>([]);
  const navigate = useNavigate();

  const columnHelper = createColumnHelper<List>();

  const columns = [
    columnHelper.display({
      id: 'select',
      header: ({ table }) => (
        <IndeterminateCheckbox
          {...{
            checked: table.getIsAllRowsSelected(),
            indeterminate: table.getIsSomeRowsSelected(),
            onChange: table.getToggleAllPageRowsSelectedHandler(),
          }}
        />
      ),
      cell: ({ row }) => {
        return (
          <IndeterminateCheckbox
            {...{
              checked: row.getIsSelected(),
              indeterminate: row.getIsSomeSelected(),
              onChange: row.getToggleSelectedHandler(),
            }}
          />
        );
      },
    }),
    columnHelper.accessor('id', {
      header: 'List ID',
      cell: (props: any) => (
        <>
          <Badge variant='default' fontSize='12px' fontWeight='600'>
            {props.row.original.id}
          </Badge>
        </>
      ),
    }),
    columnHelper.accessor('title', {
      cell: (info) => info.getValue(),
      header: 'List Name',
    }),
    columnHelper.display({
      header: 'Contacts',
      cell: (props: any) => (
        <>
          {props.row.original.customers?.length > 0
            ? props.row.original.customers[0]?.no_of_contacts
            : 0}
        </>
      ),
    }),
    columnHelper.display({
      header: 'Date Created',
      cell: (props: any) => <>{format(new Date(`${props.row.original.created_at}`), 'MM/dd/yy')}</>,
    }),

    columnHelper.display({
      id: 'action',
      cell: (props: any) => (
        <ChevronRightIcon
          boxSize='5'
          color='gray.500'
          cursor='pointer'
          onClick={() => navigate(`${detailLink}?id=${props.row.original.id}`)}
        />
      ),
    }),
  ];

  const kebabMenu = [
    {
      label: 'Export',
    },
    {
      label: 'Remove Unsubscribe',
    },
    {
      label: 'Delete',
      onClick: () => (selectedLists.length > 0 ? onDeleteOpen() : null),
      disabled: selectedLists.length === 0,
    },
  ];

  const handleResetSelectedRows = () => setRowSelection([]);

  useEffect(() => {
    const indeces = Object.keys(rowSelection).map((key) => parseInt(key));

    if (indeces && allListings) {
      setSelectedLists(allListings.filter((list, index) => indeces.includes(index)));
    }
  }, [rowSelection]);

  return (
    <PageContainer>
      <PageHeader
        title='Lists'
        subtitle='Audience'
        buttonLabel='Add List'
        onClick={onAddListOpen}
      />
      <DeleteListModal
        isOpen={isDeleteOpen}
        onClose={onDeleteClose}
        selectedRows={selectedLists}
        isBulk
        resetSelectedRows={handleResetSelectedRows}
      />
      <AddNewListModal isOpen={isAddListOpen} onClose={onAddListClose} />
      <DataTable
        columns={columns}
        data={allListings}
        getValue={() => null}
        colProps={listColProps}
        showFilters={false}
        rowSelection={rowSelection}
        setRowSelection={setRowSelection}
        emptyMessage={'No list(s) found'}
        rightToolbar={
          <>
            <SuppressionList />
            <Button h='10' variant='blackOutlined'>
              Merge
            </Button>
            <KebabMenu menu={kebabMenu} />
          </>
        }
      />
    </PageContainer>
  );
};

export default SampleListsPage;
