import { Flex, Stack, MenuButton, Box } from '@chakra-ui/react';
import styled from '@emotion/styled';

// Add New List Page
export const Option = styled(Stack)`
  width: 100%;
  font-size: 14px;
  border-width: 1px;
  border-color: #b2b9c3;
  border-radius: 5px;
  padding: 0.25rem 0.75rem;
  padding-left: 0.5rem;
`;

export const Select = styled(MenuButton)<{ $error?: boolean }>`
  margin-top: 0.25rem;
  width: 100%;
  height: 100%;
  border-width: ${({ $error }) => ($error ? '2px' : '1px')};
  border-color: ${({ $error }) =>
    $error ? 'var(--chakra-colors-red-700)' : 'var(--chakra-colors-gray-600)'};
  background: transparent;
  &:hover {
    background: transparent;
  }
  padding-left: 0.5rem;
  padding-right: 1rem;
`;

export const SelectBox = styled(Flex)`
  width: 100%;
  height: 48px;
  font-size: 14px;
  line-height: 22px;
  justify-content: space-between;
  align-items: center;
  margin-right: 1rem;
`;

export const DetailHeader = styled(Flex)`
  margin-bottom: 2rem;
  justify-content: space-between;
  alignitems: center;
`;

export const DetailBox = styled(Flex)`
  flex-direction: column;
  padding: 16px;
  border-radius: 8px;
  width: 100%;

  & > p {
    font-size: var(--chakra-fontSizes-sm);
    line-height: 16px;
    font-weight: 400;
    margin: 5px 0;
  }

  & .value {
    font-weight: bold;
    font-size: var(--chakra-fontSizes-lg);
  }

  & .green {
    color: var(--chakra-colors-teal-700);
  }

  & .red {
    color: var(--chakra-colors-red-700);
  }
`;

export const ListBox = styled(Box)({
  padding: '16px',
  margin: '8px',
  borderWidth: '1px',
  borderColor: 'var(--chakra-colors-gray-400)',
  borderRadius: '6px',
  width: '100%',
});

export const Legend = styled(Flex)`
  justify-content: center;
  gap: 15px;
  font-size: 12px;
  color: var(--chakra-colors-gray-700);
  font-weight: 500;
  margin: 10px 0 0;
`;

export const Dots = styled(Box)<{ health?: string; growth?: string }>`
  margin: 3px 8px 0 0;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--chakra-colors-gray-500);

  ${({ health }) =>
    health === 'excellent'
      ? 'background: var(--chakra-colors-teal-700);'
      : health === 'good'
      ? 'background: var(--chakra-colors-orange-700);'
      : health === 'poor' && 'background: var(--chakra-colors-red-700);'};

  ${({ growth }) =>
    growth === 'subscribed'
      ? 'background: #0071E7'
      : growth === 'unsubscribed' && 'background: #86C9EF'};
`;
