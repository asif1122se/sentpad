import { useState, useEffect } from 'react';
import {
  Box,
  Flex,
  Heading,
  Image,
  Select,
  Spinner,
  Text,
  useDisclosure,
  useToast,
} from '@chakra-ui/react';
import { DataTable, InputField } from 'components';
import { PageContainer } from 'components/Layout';
import { ColumnProps } from 'types';
import { DetailHeader, Dots, DetailBox, Legend, ListBox } from '../styles';
import SenderProfile from './SenderProfile';
import DeleteListModal from '../components/DeleteListModal';
import { ListList, ListDetailAnalytics, ListGrowth } from '../types';
import { AddListApi, GetListByIdApi } from 'services/apis/Lists';
import { useLocation, useNavigate } from 'react-router-dom';
import { CheckIcon, ChevronRightIcon, DeleteIcon, SmallCloseIcon } from '@chakra-ui/icons';
import { Contact } from 'pages/Audience/Contacts/types';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { format } from 'date-fns';
import { useDebounce } from 'hooks/useDebounce';
import PencilIcon from 'assets/icons/pencil.png';
import { ASPECT, TIME_PERIOD } from 'pages/Dashboard/consts';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { formatNumber } from 'utils';
import ArrowBackIcon from 'assets/icons/arrow-back.svg';

const Details = () => {
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const [selectedLists, setSelectedLists] = useState<ListList>([]);
  const [isEdit, setIsEdit] = useState<boolean>(false);
  const [isRefetch, setIsRefetch] = useState<boolean>(false);
  const [listName, setListName] = useState<any>();
  const [rowSelection, setRowSelection] = useState<{ [key: number]: boolean }>({});
  const [searchedValue, setSearchedValue] = useState<string>('');
  const [contactData, setContactData] = useState<any>();
  const debouncedSearchTerm = useDebounce(searchedValue, 200);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const columnHelper = createColumnHelper<Contact>();
  const navigate = useNavigate();
  const params = useLocation();
  const toast = useToast();

  const [insightTypes, setInsightTypes] = useState<string>(TIME_PERIOD[0].value);
  const { data: listDetail, isLoading: listDetailLoading } = useQuery<ListDetailAnalytics>({
    queryKey: [QUERY_KEYS.LIST_DETAIL_ANALYTICS, insightTypes],
    url: `list-detail-data/${window.location.search.split('?id=')[1]}?type=${insightTypes}`,
  });

  const [growthFilter, setGrowthFilter] = useState<string>(TIME_PERIOD[0].value);
  const { data: growthData, isLoading: listGrowthLoading } = useQuery<ListGrowth>({
    queryKey: [QUERY_KEYS.LIST_DETAIL_GROWTH, growthFilter],
    url: `list-detail-growth/${window.location.search.split('?id=')[1]}?type=${growthFilter}`,
  });

  const listGrowthFormatedData = growthData?.map((item: any) => ({
    day:
      growthFilter === TIME_PERIOD[1].value
        ? format(new Date(`${item?.label_name}`), 'd-MMM')
        : growthFilter === TIME_PERIOD[0].value
        ? format(new Date(`${item?.date}`), 'MM/d')
        : item?.label_name,
    subscribe: item?.subscribed,
    unsubscribe: item?.unsubscribed,
  }));

  const getSingleList = async () => {
    setIsLoading(true);
    try {
      const res = await GetListByIdApi(params?.search?.split('?id=')[1], searchedValue);
      if (res?.errors?.length === 0) {
        setSelectedLists([res?.records?.list_detail]);
        setListName(res?.records?.list_detail?.title);
        setContactData(res?.records?.customers);
        setIsLoading(false);
      } else {
        setIsLoading(false);
      }
    } catch (err) {
      setIsLoading(false);
      console.log(err);
    }
  };

  useEffect(() => {
    getSingleList();
  }, [isEdit, isRefetch, debouncedSearchTerm]);

  const handleSubmit = async () => {
    try {
      const data = { id: selectedLists[0]?.id, title: listName };
      const res = await AddListApi(data);
      if (res?.errors?.length === 0) {
        setIsEdit(!isEdit);
      } else {
        toast({
          title: `${res?.errors[0]}`,
          status: 'error',
          isClosable: true,
          position: 'top-right',
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  const contactColProps: ColumnProps[] = [
    {
      align: 'left',
      paddingX: '4px',
      paddingLeft: '10px',
    },
    {
      align: 'left',
      paddingX: '3px',
    },
    {
      align: 'center',
      paddingX: '3px',
    },
    {
      align: 'right',
      paddingX: '5px',
    },
  ];

  const columns = [
    columnHelper.display({
      id: 'name',
      header: 'Name',
      cell: (props: CellContext<Contact, unknown>) => (
        <>
          {props.row.original.first_name} {props.row.original.last_name}
        </>
      ),
    }),
    columnHelper.accessor('email', {
      cell: (info) => info.getValue(),
      header: 'Email',
    }),

    columnHelper.display({
      id: 'Date Added',
      header: 'Date Added',
      cell: (props: CellContext<Contact, unknown>) => (
        <>
          {props.row.original.created_at &&
            format(new Date(`${props.row.original.created_at}`), 'MM/dd/yy')}
        </>
      ),
    }),

    columnHelper.display({
      id: 'action',
      cell: () => <ChevronRightIcon boxSize='5' color='gray.500' cursor='pointer' />,
    }),
  ];

  const handleGetSearchValue = (data: string) => {
    setSearchedValue(data);
  };

  const aspect = ASPECT > 1 ? 1.63 : 1.3;

  return (
    <>
      <DeleteListModal
        isOpen={isDeleteOpen}
        onClose={onDeleteClose}
        selectedRows={selectedLists}
        isBulk={false}
      />
      <PageContainer>
        <DetailHeader>
          <Flex>
            <Image
              ml='-5px'
              src={ArrowBackIcon}
              alt='Back'
              cursor='pointer'
              onClick={() => navigate(-1)}
            />
            <Heading as='h1' fontSize='2rem' lineHeight='2.438rem'>
              <Flex alignItems='center' justifyContent='flex-start' maxWidth='95%'>
                {isEdit ? (
                  <InputField
                    autoFocus
                    minWidth='300px'
                    name='list_name'
                    size='md'
                    borderColor='gray.400'
                    color='black'
                    placeholder='Enter list name'
                    fontWeight='normal'
                    fontSize='md'
                    value={listName}
                    onChange={(e) => {
                      setListName(e.target.value);
                    }}
                    maxLength={100}
                  />
                ) : (
                  <Flex alignItems='center'>
                    <Text fontWeight='bold' textAlign='left' minWidth='600px'>
                      {selectedLists[0]?.title}
                      {!isEdit ? (
                        <Image
                          src={PencilIcon}
                          display='inline-block'
                          boxSize='6'
                          ml='3'
                          color='gray.500'
                          onClick={() => setIsEdit(!isEdit)}
                          cursor='pointer'
                        />
                      ) : (
                        ''
                      )}
                    </Text>
                  </Flex>
                )}

                {!isEdit ? (
                  ''
                ) : (
                  <>
                    <CheckIcon
                      mx='3'
                      boxSize='4'
                      color='green.500'
                      cursor='pointer'
                      onClick={handleSubmit}
                    />
                    <SmallCloseIcon
                      boxSize='6'
                      color='red.700'
                      cursor='pointer'
                      onClick={() => setIsEdit(!isEdit)}
                    />
                  </>
                )}
              </Flex>
            </Heading>
          </Flex>
          <Flex
            alignItems='center'
            backgroundColor='gray.300'
            width='38px'
            height='38px'
            justifyContent='center'
            borderRadius='3px'>
            <DeleteIcon m='1' boxSize='4' cursor='pointer' onClick={() => onDeleteOpen()} />
          </Flex>
        </DetailHeader>
        <Box mt='4' flexWrap='wrap'>
          <Flex justifyContent='space-evenly'>
            <Flex width='60%'>
              <ListBox>
                <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
                  General
                </Text>
                <Flex flexDirection='column' gap='16px'>
                  <DetailBox background='#F2F6F9 0% 0% no-repeat padding-box'>
                    <Text>Subscribed</Text>
                    <Text className='value'>
                      {formatNumber(listDetail?.general?.subscribed ?? 0)}
                    </Text>
                    <Text>Contacts</Text>
                  </DetailBox>
                  <DetailBox background='#F2F6F9 0% 0% no-repeat padding-box'>
                    <Text>Unsubscribed</Text>
                    <Text className='value'>
                      {formatNumber(listDetail?.general?.unsubscribed ?? 0)}
                    </Text>
                    <Text>Contacts</Text>
                  </DetailBox>
                </Flex>
              </ListBox>
            </Flex>

            <Flex width='100%'>
              <ListBox>
                <Flex justifyContent='space-between'>
                  <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
                    Health
                  </Text>
                  <Select
                    width='fit-content'
                    borderColor='gray.500'
                    mt='-5px'
                    fontSize='sm'
                    height='8'
                    onChange={(e) => setInsightTypes(e.target.value)}>
                    {TIME_PERIOD.map(({ label, value }) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </Select>
                </Flex>
                <Flex flexDirection='column' gap='16px'>
                  <Flex gap='10px'>
                    <DetailBox background='transparent linear-gradient(124deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
                      <Text>Average</Text>
                      {listDetailLoading ? (
                        <Spinner />
                      ) : (
                        <Text className='value'>
                          {listDetail?.health?.open_rate !== 0
                            ? formatNumber(listDetail?.health?.open_rate ?? 0)
                            : '0.00'}
                          %
                        </Text>
                      )}
                      <Text>Open Rate</Text>
                    </DetailBox>
                    <DetailBox background='transparent linear-gradient(124deg, #C7F9EF 0%, #86C9EF 100%) 0% 0% no-repeat padding-box'>
                      <Text>Average</Text>
                      {listDetailLoading ? (
                        <Spinner />
                      ) : (
                        <Text className='value'>
                          {listDetail?.health?.click_rate !== 0
                            ? formatNumber(listDetail?.health?.click_rate ?? 0)
                            : '0.00'}
                          %
                        </Text>
                      )}
                      <Text>Click Rate</Text>
                    </DetailBox>
                  </Flex>
                  <Flex gap='16px'>
                    <DetailBox background='transparent linear-gradient(122deg, #F9F1E9 0%, #F3A9B1 100%) 0% 0% no-repeat padding-box'>
                      <Text>List Growth</Text>
                      {listDetailLoading ? (
                        <Spinner />
                      ) : (
                        <Text className='value'>
                          {listDetail?.health?.growth_rate !== 0
                            ? formatNumber(listDetail?.health?.growth_rate ?? 0)
                            : '0.00'}
                          %
                        </Text>
                      )}
                      <Text>Increase</Text>
                    </DetailBox>
                    <DetailBox background='transparent linear-gradient(123deg, #FDEDD0 0%, #D0BCF0 100%) 0% 0% no-repeat padding-box'>
                      <Text>Unsubscribed</Text>
                      {listDetailLoading ? (
                        <Spinner />
                      ) : (
                        <Text className='value'>
                          {listDetail?.health?.unsubscribed !== 0
                            ? formatNumber(listDetail?.health?.unsubscribed ?? 0)
                            : '0.00'}
                        </Text>
                      )}
                      <Text>Contacts</Text>
                    </DetailBox>
                  </Flex>
                </Flex>
              </ListBox>
            </Flex>

            <Flex width='100%'>
              <ListBox>
                <Flex justifyContent='space-between'>
                  <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
                    Growth
                  </Text>
                  <Select
                    width='fit-content'
                    borderColor='gray.500'
                    mt='-5px'
                    fontSize='sm'
                    height='8'
                    onChange={(event) => setGrowthFilter(event.target.value)}>
                    {TIME_PERIOD.map(({ label, value }) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </Select>
                </Flex>
                <Flex alignItems='end' ml='-1' mt='2' pt={2}>
                  <ResponsiveContainer width='100%' height='100%' aspect={aspect}>
                    <BarChart
                      data={listGrowthFormatedData}
                      margin={{ left: -35, top: 10, bottom: 0, right: -7 }}>
                      <CartesianGrid stroke='#D2D8DE' strokeWidth='0.5' vertical={false} />
                      <XAxis
                        dataKey='day'
                        strokeWidth='0'
                        fontSize='10px'
                        stroke='#929BA8'
                        padding={{ left: 0, right: 5 }}
                        tickMargin={8}
                        interval='preserveEnd'
                      />
                      <YAxis
                        strokeWidth='0'
                        fontSize='10px'
                        stroke='#929BA8'
                        tickCount={4}
                        type='number'
                        interval='preserveEnd'
                        padding={{ top: 1, bottom: 1 }}
                      />
                      <Tooltip
                        cursor={false}
                        labelStyle={{ fontSize: '12px' }}
                        contentStyle={{ fontSize: '12px' }}
                      />
                      <Bar dataKey='subscribe' stackId='a' fill='#0071E7' />
                      <Bar dataKey='unsubscribe' stackId='a' fill='#86C9EF' />
                    </BarChart>
                  </ResponsiveContainer>
                </Flex>
                <Legend>
                  <Flex alignItems='flex-start'>
                    <Dots growth='subscribed' />
                    Subscribed
                  </Flex>
                  <Flex>
                    <Dots growth='unsubscribed' />
                    Unsubscribed
                  </Flex>
                </Legend>
              </ListBox>
            </Flex>

            <Flex width='90%' position='relative' zIndex='2'>
              <SenderProfile
                selectedLists={selectedLists}
                setIsRefetch={setIsRefetch}
                isRefetch={isRefetch}
              />
            </Flex>
          </Flex>
        </Box>

        <Box p='2' mt='3' position='relative' zIndex='1'>
          <Text fontSize='lg' fontWeight='bold' lineHeight='20px' float='left'>
            Contacts
          </Text>
          <DataTable
            columns={columns}
            data={contactData}
            getValue={handleGetSearchValue}
            showFilters={false}
            colProps={contactColProps}
            rowSelection={rowSelection}
            setRowSelection={setRowSelection}
            emptyMessage={'No contact(s) found'}
            onRowClick={({ id }: Contact) => navigate(`/audience/details/${id}`)}
            rightToolbar={<Box height='35px' />}
          />
        </Box>
      </PageContainer>
    </>
  );
};

export default Details;
