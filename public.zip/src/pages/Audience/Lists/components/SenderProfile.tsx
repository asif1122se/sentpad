import React, { useState } from 'react';
import { Box, Button, Container, Flex, Stack, Text, useToast } from '@chakra-ui/react';
import SenderProfileDropDown from './SenderProfileDropdown';
import { AddListApi } from 'services/apis/Lists';
import { InputField } from 'components';
import { ListBox } from '../styles';

const SenderProfile = ({ selectedLists, isRefetch, setIsRefetch }: any) => {
  const [showProfile, setShowProfile] = useState<boolean>(false);
  const [profileId, setProfileId] = useState<number>();
  const toast = useToast();

  const getId = (id: number) => {
    setProfileId(id);
  };

  const handleSubmit = async () => {
    try {
      const data = {
        sender_profile_id: profileId,
        title: selectedLists[0]?.title,
        id: selectedLists[0]?.id,
      };
      const res = await AddListApi(data);
      if (res?.errors?.length === 0) {
        setShowProfile(!showProfile);
        setIsRefetch(!isRefetch);
      } else {
        toast({
          title: `${res?.errors[0]}`,
          status: 'error',
          isClosable: true,
          position: 'top-right',
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <>
      <ListBox>
        <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
          Sender Profile
        </Text>
        {!showProfile ? (
          <Flex flexDirection='column' gap='15px'>
            <Box>
              <Text mb='1' fontSize='sm' lineHeight='17px' color='gray.700'>
                Name
              </Text>

              <Text fontSize='md' fontWeight='semibold' lineHeight='20px'>
                {selectedLists[0]?.sender_profile?.sender_name}
              </Text>
            </Box>
            <Box>
              <Text mb='1' fontSize='sm' lineHeight='17px' color='gray.700'>
                From
              </Text>
              <Text fontSize='md' fontWeight='semibold' lineHeight='20px'>
                {selectedLists[0]?.sender_profile?.from_email}
              </Text>
            </Box>
            <Box>
              <Text mb='1' fontSize='sm' lineHeight='17px' color='gray.700'>
                Reply to
              </Text>
              <Text fontSize='md' fontWeight='semibold' lineHeight='20px'>
                {selectedLists[0]?.sender_profile?.reply_to_email}
              </Text>
            </Box>
            <Box pt='4'>
              <Button
                variant='infoOutlined'
                onClick={() => setShowProfile(!showProfile)}
                cursor='pointer'>
                Change Profile
              </Button>
            </Box>
          </Flex>
        ) : (
          <Box width='100%' height='100%' m='0' pt='3' position='relative'>
            <SenderProfileDropDown width='100%' fontsize='sm' data={selectedLists} getId={getId} />
            <Flex mt='4'>
              <Button variant='success' onClick={handleSubmit} cursor='pointer'>
                Save
              </Button>
              <Button
                ml='4'
                variant='danger'
                onClick={() => setShowProfile(!showProfile)}
                cursor='pointer'>
                Cancel
              </Button>
            </Flex>
          </Box>
        )}
      </ListBox>
    </>
  );
};

export default SenderProfile;
