import { TriangleDownIcon } from '@chakra-ui/icons';
import {
  Box,
  Button,
  Flex,
  Menu,
  MenuItem,
  MenuList,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Stack,
  Text,
  useToast,
} from '@chakra-ui/react';
import { InputField } from 'components';
import { useState } from 'react';
import { Option, Select, SelectBox } from '../styles';
import { ContactLists } from '../../Contacts/types';
import { AddListApi } from 'services/apis/Lists';
import { useQuery } from 'hooks/useQuery';
import { useQueryClient } from '@tanstack/react-query';
import QUERY_KEYS from 'utils/queryKeys';

type AddNewListModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

const AddNewListModal = ({ isOpen, onClose }: AddNewListModalProps) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [listData, setListData] = useState<any>({ name: '' });
  const queryClient = useQueryClient();
  const { data: senderProfile } = useQuery<ContactLists>({
    queryKey: [QUERY_KEYS.SENDER_PROFILES],
    url: 'getSenderProfiles',
  });

  const toast = useToast();

  const handleSubmit = async () => {
    try {
      setIsLoading(true);
      const data = { title: listData?.name, sender_profile_id: listData?.profile?.id };
      const res = await AddListApi(data);
      if (res?.errors?.length === 0) {
        setIsLoading(false);
        toast({
          title: `${res?._metadata?.message}`,
          status: 'success',
          isClosable: true,
          position: 'top-right',
        });
        setListData({});
        queryClient.invalidateQueries([QUERY_KEYS.MAIN_LIST]);
        onClose();
      } else {
        toast({
          title: `${res?.errors[0]}`,
          status: 'error',
          isClosable: true,
          position: 'top-right',
        });
        setIsLoading(false);
      }
    } catch (error) {
      console.log(error);
      setIsLoading(false);
    }
  };

  const showSenderProfile = () => {
    return (
      <>
        <MenuItem width='100%'>
          <Option onClick={() => setListData({ ...listData, profile: '' })}>
            <Text textAlign='left' fontSize='md' color='gray.500' lineHeight='50px'>
              Select sender profile
            </Text>
          </Option>
        </MenuItem>
        {senderProfile?.map((item: any, i) => (
          <MenuItem width='100%' key={i}>
            <Option onClick={() => setListData({ ...listData, profile: item })}>
              <Flex width='100%'>
                <Text width='20%'>From</Text>
                <Text>{item?.from_email}</Text>
              </Flex>
              <Flex width='100%'>
                <Text width='20%'>Reply to</Text>
                <Text>{item?.reply_to_email}</Text>
              </Flex>
            </Option>
          </MenuItem>
        ))}
      </>
    );
  };
  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        setListData({});
        onClose();
      }}
      closeOnEsc={false}
      isCentered
      closeOnOverlayClick={false}>
      <ModalOverlay />
      <ModalContent maxW='540px'>
        <form>
          <ModalHeader fontWeight='bold' color='black' fontSize='18px' lineHeight='32px'>
            Create a new list
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Stack gap='1rem'>
              <Box gap='1rem'>
                <Text pb='2' fontSize='md' lineHeight='14px'>
                  List Name
                </Text>
                <InputField
                  autoFocus
                  name='list_name'
                  size='md'
                  placeholder='Enter list name'
                  fontWeight='normal'
                  value={listData?.name}
                  onChange={(e) => {
                    setListData({ ...listData, name: e.target.value });
                  }}
                  maxLength={100}
                />
              </Box>
              {/* <Box>
                <Menu>
                  <Text pb='1' fontSize='md' lineHeight='14px'>
                    Select Sender Profile
                  </Text>
                  <Select as={Button} py='1'>
                    <SelectBox>
                      <Box width='100%'>
                        {!listData?.profile ? (
                          <Text textAlign='left' fontSize='md' color='gray.500' lineHeight='50px'>
                            Click to select sender profile
                          </Text>
                        ) : (
                          <>
                            <Flex>
                              <Text width='20%' textAlign='left'>
                                From
                              </Text>
                              <Text>{listData?.profile?.from_email}</Text>
                            </Flex>
                            <Flex>
                              <Text width='20%' textAlign='left'>
                                Reply to
                              </Text>
                              <Text>{listData?.profile?.reply_to_email}</Text>
                            </Flex>
                          </>
                        )}
                      </Box>
                      <TriangleDownIcon boxSize='2' color='gray.900' />
                    </SelectBox>
                  </Select>
                  <MenuList width='174%'>
                    {showSenderProfile()}
                  </MenuList>
                </Menu>
              </Box> */}
            </Stack>
          </ModalBody>

          <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
            <Button
              isLoading={isLoading}
              onClick={handleSubmit}
              isDisabled={listData?.name ? false : true}
              variant={listData.name ? 'success' : 'default'}
              type={'submit'}
              mr='8px'>
              Create
            </Button>
            <Button
              onClick={() => {
                setListData({});
                onClose();
              }}>
              Cancel
            </Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default AddNewListModal;
