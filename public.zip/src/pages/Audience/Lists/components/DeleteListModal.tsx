import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  chakra,
  Flex,
  Box,
  Image,
  Center,
  Spinner,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { DELETE } from 'utils/constants';
import { ListList } from '../types';
import AlertIcon from 'assets/icons/alert.svg';
import { useMutation } from 'hooks/useMutation';
import { useNavigate } from 'react-router-dom';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';

type DeleteListModal = {
  isOpen: boolean;
  onClose: () => void;
  selectedRows: ListList;
  isBulk: boolean;
  resetSelectedRows?: () => void;
};

const DeleteListModal = ({
  isOpen,
  onClose,
  selectedRows,
  isBulk,
  resetSelectedRows,
}: DeleteListModal) => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { isLoading, mutate: deleteLists } = useMutation<string>({
    method: DELETE,
    url: 'delete-lists',
    onSuccess: () => {
      onClose();
      resetSelectedRows && resetSelectedRows();
      queryClient.invalidateQueries([QUERY_KEYS.MAIN_LIST]);
      navigate('/audience/lists');
    },
    successMessage: 'List(s) deleted successfully',
  });

  const listIds = selectedRows?.map((row) => row.id).toString();

  const {
    data,
    isLoading: isListWithFormsLoading,
    isFetching: isListWithFormsFetching,
  } = useQuery<{ form_list_ids: { [key: string]: number } }>({
    url: `form-lists/${listIds}`,
    queryKey: [QUERY_KEYS.FORMS_LIST_BY_ID],
    enabled: isOpen === true,
  });

  const handleDelete = () => deleteLists(listIds);

  const listIdsWithForms = Object.values(data?.form_list_ids ?? {}) ?? [];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      isCentered
      size='xl'
      closeOnEsc={isLoading}
      closeOnOverlayClick={isLoading}>
      <ModalOverlay />
      <ModalContent px='32px' py='25px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            {'Delete List'}
            {isBulk && '(s)'}
          </Text>
        </ModalHeader>
        <ModalCloseButton isDisabled={isLoading} mt='13px' />
        <ModalBody px='0' pt='6'>
          {isListWithFormsLoading || isListWithFormsFetching ? (
            <Center>
              <Spinner />
            </Center>
          ) : (
            <Flex fontSize='md'>
              <Box justifyContent='flex-start' width='50px'>
                <Image src={AlertIcon} alt='Alert' height='50px' width='50px' />
              </Box>
              <Box px='4' py='1' width='calc(100% - 50px)'>
                {listIdsWithForms.length > 0 ? (
                  <>
                    <Text>The following list(s) are currently used in a form: </Text>
                    <Text mb='2' fontWeight='bold'>
                      {listIdsWithForms.join(', ')}
                    </Text>
                    <Text>Lists that are currently used in a form cannot be deleted.</Text>
                  </>
                ) : (
                  <>
                    {!isBulk ? (
                      <Text mb='2'>
                        <Text>
                          {'You are about to delete 1 list containing '}
                          <chakra.span fontWeight='bold'>
                            {selectedRows.length > 0 ? selectedRows[0].no_of_contacts : 0}
                          </chakra.span>
                          {' contact(s). Are you sure you want to proceed?'}
                        </Text>
                      </Text>
                    ) : (
                      <>
                        <Text mb='2'>
                          You are about to delete{' '}
                          <chakra.span fontWeight='bold'>{selectedRows?.length}</chakra.span>{' '}
                          list(s). Are you sure you want to proceed?
                        </Text>
                      </>
                    )}
                    <Text mt='6'>
                      {`All data of the deleted lists will be deleted (including segments,
                      autoresponder triggers and actions, broadcast and autoresponder emails, and
                      contact profile data). This action cannot be undone.`}
                    </Text>
                  </>
                )}
              </Box>
            </Flex>
          )}
        </ModalBody>

        <ModalFooter justifyContent='flex-start' pb='0' px='0'>
          {!isListWithFormsLoading && !isListWithFormsFetching && (
            <>
              {listIdsWithForms.length > 0 ? (
                <Button onClick={onClose} variant='black' width='80px'>
                  OK
                </Button>
              ) : (
                <>
                  <Button variant='danger' mr={2} onClick={handleDelete} isLoading={isLoading}>
                    Delete List{isBulk && '(s)'}
                  </Button>
                  <Button onClick={onClose} isDisabled={isLoading}>
                    Cancel
                  </Button>
                </>
              )}
            </>
          )}
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeleteListModal;
