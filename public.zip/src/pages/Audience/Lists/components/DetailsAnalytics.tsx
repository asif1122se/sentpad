import { useState, useEffect } from 'react';
import {
  Box,
  Flex,
  Button,
  Heading,
  Image,
  Select,
  Text,
  useDisclosure,
  useToast,
} from '@chakra-ui/react';
import { DataTable, InputField } from 'components';
import { PageContainer } from 'components/Layout';
import { ColumnProps } from 'types';
import { DetailHeader, Dots, DetailBox, Legend, ListBox } from '../styles';
import SenderProfile from './SenderProfile';
import DeleteListModal from '../components/DeleteListModal';
import { ListList, ListDetailAnalytics, ListGrowth } from '../types';
import { AddListApi, GetListByIdApi } from 'services/apis/Lists';
import { useLocation, useNavigate } from 'react-router-dom';
import { CheckIcon, ChevronRightIcon, DeleteIcon, SmallCloseIcon } from '@chakra-ui/icons';
import { Contact } from 'pages/Audience/Contacts/types';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { format } from 'date-fns';
import { useDebounce } from 'hooks/useDebounce';
import PencilIcon from 'assets/icons/pencil.png';
import { ASPECT, TIME_PERIOD } from 'pages/DashboardTest/consts';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { formatNumber } from 'utils';
import SenderProfileDropDown from './SenderProfileDropdown';

const contacts = [
  {
    id: 50856,
    user_id: 5,
    first_name: 'shanze2',
    last_name: 'arshad1',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: 234,
    is_subscribed: 1,
    subscribe_date: '12/14/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [],
  },
  {
    id: 50855,
    user_id: 5,
    first_name: 'shanze2',
    last_name: 'arshad1',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: 234,
    is_subscribed: 1,
    subscribe_date: '12/14/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [],
  },
  {
    id: 50854,
    user_id: 5,
    first_name: 'shanze',
    last_name: 'shanze',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: null,
    is_subscribed: 1,
    subscribe_date: '12/14/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [],
  },
  {
    id: 50853,
    user_id: 5,
    first_name: 'shan',
    last_name: 'new',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: null,
    is_subscribed: 1,
    subscribe_date: '12/14/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [],
  },
  {
    id: 50852,
    user_id: 5,
    first_name: 'shan',
    last_name: 'new',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: null,
    is_subscribed: 1,
    subscribe_date: '12/14/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [],
  },
  {
    id: 50843,
    user_id: 5,
    first_name: null,
    last_name: null,
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: 269,
    is_subscribed: 1,
    subscribe_date: '12/14/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [
      {
        id: 269,
        user_id: 5,
        title: 'Sad list',
        description: null,
        no_of_contacts: 0,
        is_active: '1',
        created_at: '2022-12-09T09:52:39.000000Z',
        updated_at: '2022-12-14T05:46:46.000000Z',
        sender_profile_id: 1,
        deleted_at: null,
        pivot: {
          customer_id: 50843,
          list_id: 269,
        },
      },
    ],
  },
  {
    id: 50840,
    user_id: 5,
    first_name: null,
    last_name: null,
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: 272,
    is_subscribed: 1,
    subscribe_date: '12/13/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [
      {
        id: 272,
        user_id: 5,
        title: 'Demo 12/13 List A',
        description: null,
        no_of_contacts: 0,
        is_active: '1',
        created_at: '2022-12-13T13:21:40.000000Z',
        updated_at: '2022-12-13T14:36:20.000000Z',
        sender_profile_id: 1,
        deleted_at: null,
        pivot: {
          customer_id: 50840,
          list_id: 272,
        },
      },
    ],
  },
  {
    id: 38872,
    user_id: 5,
    first_name: 'Random',
    last_name: 'User Two',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: 272,
    is_subscribed: 1,
    subscribe_date: '12/13/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [
      {
        id: 272,
        user_id: 5,
        title: 'Demo 12/13 List A',
        description: null,
        no_of_contacts: 0,
        is_active: '1',
        created_at: '2022-12-13T13:21:40.000000Z',
        updated_at: '2022-12-13T14:36:20.000000Z',
        sender_profile_id: 1,
        deleted_at: null,
        pivot: {
          customer_id: 38872,
          list_id: 272,
        },
      },
    ],
  },
  {
    id: 38871,
    user_id: 5,
    first_name: 'Free',
    last_name: 'Dom',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: 272,
    is_subscribed: 1,
    subscribe_date: '12/13/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [
      {
        id: 272,
        user_id: 5,
        title: 'Demo 12/13 List A',
        description: null,
        no_of_contacts: 0,
        is_active: '1',
        created_at: '2022-12-13T13:21:40.000000Z',
        updated_at: '2022-12-13T14:36:20.000000Z',
        sender_profile_id: 1,
        deleted_at: null,
        pivot: {
          customer_id: 38871,
          list_id: 272,
        },
      },
    ],
  },
  {
    id: 34878,
    user_id: 5,
    first_name: 'hhtest',
    last_name: 'contact02',
    email: 'shan@mailinator.com',
    phone_no: null,
    list_id: 258,
    is_subscribed: 1,
    subscribe_date: '12/13/22',
    address_one: null,
    address_two: null,
    city: null,
    country: null,
    state: null,
    zip_code: null,
    created_at: '2022-12-09T09:52:39.000000Z',
    lists: [
      {
        id: 258,
        user_id: 5,
        title: 'Test List 01',
        description: null,
        no_of_contacts: 0,
        is_active: '1',
        created_at: '2022-11-30T06:17:34.000000Z',
        updated_at: '2022-12-14T10:18:51.000000Z',
        sender_profile_id: null,
        deleted_at: null,
        pivot: {
          customer_id: 34878,
          list_id: 258,
        },
      },
    ],
  },
];

const DetailsAnalytics = () => {
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const [selectedLists, setSelectedLists] = useState<ListList>([]);
  const [isEdit, setIsEdit] = useState<boolean>(false);
  const [isRefetch, setIsRefetch] = useState<boolean>(false);
  const [listName, setListName] = useState<any>();
  const [rowSelection, setRowSelection] = useState<{ [key: number]: boolean }>({});
  const [searchedValue, setSearchedValue] = useState<string>('');
  const [contactData, setContactData] = useState<any>();
  const debouncedSearchTerm = useDebounce(searchedValue, 200);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [showProfile, setShowProfile] = useState<boolean>(false);
  const [profileId, setProfileId] = useState<number>();

  const columnHelper = createColumnHelper<Contact>();
  const navigate = useNavigate();
  const params = useLocation();
  const toast = useToast();

  const [insightTypes, setInsightTypes] = useState<string>(TIME_PERIOD[0].value);
  const arrIndex = insightTypes as unknown as number;

  const [growthFilter, setGrowthFilter] = useState<string>(TIME_PERIOD[0].value);
  const arrGrowthIndex = growthFilter as unknown as number;
  //   const { data: growthData, isLoading: listGrowthLoading } = useQuery<ListGrowth>({
  //     queryKey: [QUERY_KEYS.LIST_DETAIL_GROWTH, growthFilter],
  //     url: `list-detail-growth/${window.location.search.split('?id=')[1]}?type=${growthFilter}`,
  //   });

  const growthData = [
    [
      {
        label_name: '12/12',
        subscribed: 211,
        unsubscribed: 3,
      },
      {
        label_name: '12/13',
        subscribed: 252,
        unsubscribed: 5,
      },
      {
        label_name: '12/14',
        subscribed: 287,
        unsubscribed: 6,
      },
      {
        label_name: '12/15',
        subscribed: 312,
        unsubscribed: 5,
      },
      {
        label_name: '12/16',
        subscribed: 298,
        unsubscribed: 11,
      },
      {
        label_name: '12/17',
        subscribed: 271,
        unsubscribed: 3,
      },
      {
        label_name: '12/18',
        subscribed: 266,
        unsubscribed: 6,
      },
    ],
    [
      {
        label_name: '11/21',
        subscribed: 607,
        unsubscribed: 3,
      },
      {
        label_name: '11/28',
        subscribed: 655,
        unsubscribed: 5,
      },
      {
        label_name: '12/05',
        subscribed: 731,
        unsubscribed: 5,
      },
      {
        label_name: '12/12',
        subscribed: 767,
        unsubscribed: 6,
      },
    ],
    [
      {
        label_name: 'Oct',
        subscribed: 1328,
        unsubscribed: 13,
      },
      {
        label_name: 'Nov',
        subscribed: 1450,
        unsubscribed: 15,
      },
      {
        label_name: 'Dec',
        subscribed: 1479,
        unsubscribed: 16,
      },
    ],
  ];

  const listDetail = [
    {
      general: { subscribed: 9748, unsubscribed: 525 },
      health: {
        click_rate: 33.91,
        growth_rate: 1.82,
        open_rate: 6.93,
        unsubscribed: 21,
      },
    },
    {
      general: { subscribed: 9748, unsubscribed: 525 },
      health: {
        click_rate: 34.12,
        growth_rate: 1.93,
        open_rate: 38.41,
        unsubscribed: 78,
      },
    },
    {
      general: { subscribed: 9748, unsubscribed: 525 },
      health: {
        click_rate: 34.63,
        growth_rate: 1.98,
        open_rate: 71.22,
        unsubscribed: 191,
      },
    },
  ];

  const listGrowthFormatedData = growthData[arrGrowthIndex]?.map((item: any) => ({
    //     day:
    //       growthFilter === TIME_PERIOD[1].value
    //         ? format(new Date(`${item?.label_name}`), 'd-MMM')
    //         : growthFilter === TIME_PERIOD[0].value
    //         ? format(new Date(`${item?.date}`), 'MM/d')
    //         : item?.label_name,
    day: item.label_name,
    subscribe: item.subscribed,
    unsubscribe: item.unsubscribed,
  }));

  const getSingleList = async () => {
    setIsLoading(true);
    try {
      const res = await GetListByIdApi(params?.search?.split('?id=')[1], searchedValue);
      if (res?.errors?.length === 0) {
        setSelectedLists([res?.records?.list_detail]);
        setListName(res?.records?.list_detail?.title);
        setContactData(res?.records?.customers);
        setIsLoading(false);
      } else {
        setIsLoading(false);
      }
    } catch (err) {
      setIsLoading(false);
      console.log(err);
    }
  };

  useEffect(() => {
    getSingleList();
  }, [isEdit, isRefetch, debouncedSearchTerm]);

  const handleSubmit = async () => {
    try {
      const data = { id: selectedLists[0]?.id, title: listName };
      const res = await AddListApi(data);
      if (res?.errors?.length === 0) {
        setIsEdit(!isEdit);
      } else {
        toast({
          title: `${res?.errors[0]}`,
          status: 'error',
          isClosable: true,
          position: 'top-right',
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  const contactColProps: ColumnProps[] = [
    {
      align: 'left',
      paddingX: '4px',
      paddingLeft: '10px',
    },
    {
      align: 'left',
      paddingX: '3px',
    },
    {
      align: 'center',
      paddingX: '3px',
    },
    {
      align: 'right',
      paddingX: '5px',
    },
  ];

  const columns = [
    columnHelper.display({
      id: 'name',
      header: 'Name',
      cell: (props: CellContext<Contact, unknown>) => (
        <>
          {props.row.original.first_name} {props.row.original.last_name}
        </>
      ),
    }),
    columnHelper.accessor('email', {
      cell: (info) => info.getValue(),
      header: 'Email',
    }),

    columnHelper.display({
      id: 'Date Added',
      header: 'Date Added',
      cell: (props: CellContext<Contact, unknown>) => (
        <>
          {props.row.original.created_at &&
            format(new Date(`${props.row.original.created_at}`), 'MM/dd/yy')}
        </>
      ),
    }),

    columnHelper.display({
      id: 'action',
      cell: () => <ChevronRightIcon boxSize='5' color='gray.500' cursor='pointer' />,
    }),
  ];

  const handleGetSearchValue = (data: string) => {
    setSearchedValue(data);
  };

  const aspect = ASPECT > 1 ? 1.63 : 1.3;

  return (
    <>
      <DeleteListModal
        isOpen={isDeleteOpen}
        onClose={onDeleteClose}
        selectedRows={selectedLists}
        isBulk={false}
      />
      <PageContainer>
        <DetailHeader>
          <Heading as='h1' fontSize='2rem' lineHeight='2.438rem'>
            <Flex alignItems='center' justifyContent='flex-start' maxWidth='95%'>
              {isEdit ? (
                <InputField
                  autoFocus
                  minWidth='300px'
                  name='list_name'
                  size='md'
                  borderColor='gray.400'
                  color='black'
                  placeholder='Enter list name'
                  fontWeight='normal'
                  fontSize='md'
                  value={listName}
                  onChange={(e) => {
                    setListName(e.target.value);
                  }}
                  maxLength={100}
                />
              ) : (
                <Flex alignItems='center'>
                  <Text fontWeight='bold' textAlign='left' minWidth='600px'>
                    {selectedLists[0]?.title}
                    {!isEdit ? (
                      <Image
                        src={PencilIcon}
                        display='inline-block'
                        boxSize='6'
                        ml='3'
                        color='gray.500'
                        onClick={() => setIsEdit(!isEdit)}
                        cursor='pointer'
                      />
                    ) : (
                      ''
                    )}
                  </Text>
                </Flex>
              )}

              {!isEdit ? (
                ''
              ) : (
                <>
                  <CheckIcon
                    mx='3'
                    boxSize='4'
                    color='green.500'
                    cursor='pointer'
                    onClick={handleSubmit}
                  />
                  <SmallCloseIcon
                    boxSize='6'
                    color='red.700'
                    cursor='pointer'
                    onClick={() => setIsEdit(!isEdit)}
                  />
                </>
              )}
            </Flex>
          </Heading>
          <Flex
            alignItems='center'
            backgroundColor='gray.300'
            width='38px'
            height='38px'
            justifyContent='center'
            borderRadius='3px'>
            <DeleteIcon m='1' boxSize='4' cursor='pointer' onClick={() => onDeleteOpen()} />
          </Flex>
        </DetailHeader>
        <Box mt='4' flexWrap='wrap'>
          <Flex justifyContent='space-evenly'>
            <Flex width='60%'>
              <ListBox>
                <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
                  General
                </Text>
                <Flex flexDirection='column' gap='16px'>
                  <DetailBox background='#F2F6F9 0% 0% no-repeat padding-box'>
                    <Text>Subscribed</Text>
                    <Text className='value'>
                      {formatNumber(listDetail[arrIndex].general.subscribed ?? 0)}
                    </Text>
                    <Text>Contacts</Text>
                  </DetailBox>
                  <DetailBox background='#F2F6F9 0% 0% no-repeat padding-box'>
                    <Text>Unsubscribed</Text>
                    <Text className='value'>
                      {formatNumber(listDetail[arrIndex].general.unsubscribed ?? 0)}
                    </Text>
                    <Text>Contacts</Text>
                  </DetailBox>
                </Flex>
              </ListBox>
            </Flex>

            <Flex width='100%'>
              <ListBox>
                <Flex justifyContent='space-between'>
                  <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
                    Health
                  </Text>
                  <Select
                    width='fit-content'
                    borderColor='gray.500'
                    mt='-5px'
                    fontSize='sm'
                    height='8'
                    onChange={(e) => setInsightTypes(e.target.value)}>
                    {TIME_PERIOD.map(({ label, value }) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </Select>
                </Flex>
                <Flex flexDirection='column' gap='16px'>
                  <Flex gap='10px'>
                    <DetailBox background='transparent linear-gradient(124deg, #FDEDD0 0%, #FEE1ED 100%) 0% 0% no-repeat padding-box'>
                      <Text>Average</Text>
                      <Text className='value'>
                        {formatNumber(listDetail[arrIndex].health?.open_rate)}%
                      </Text>
                      <Text>Open Rate</Text>
                    </DetailBox>
                    <DetailBox background='transparent linear-gradient(124deg, #C7F9EF 0%, #86C9EF 100%) 0% 0% no-repeat padding-box'>
                      <Text>Average</Text>
                      <Text className='value'>
                        {formatNumber(listDetail[arrIndex].health.click_rate)}%
                      </Text>
                      <Text>Click Rate</Text>
                    </DetailBox>
                  </Flex>
                  <Flex gap='16px'>
                    <DetailBox background='transparent linear-gradient(122deg, #F9F1E9 0%, #F3A9B1 100%) 0% 0% no-repeat padding-box'>
                      <Text>List Growth</Text>
                      <Text className='value'>
                        {formatNumber(listDetail[arrIndex].health.growth_rate)}%
                      </Text>
                      <Text>Increase</Text>
                    </DetailBox>
                    <DetailBox background='transparent linear-gradient(123deg, #FDEDD0 0%, #D0BCF0 100%) 0% 0% no-repeat padding-box'>
                      <Text>Unsubscribed</Text>
                      <Text className='value'>
                        {formatNumber(listDetail[arrIndex].health.unsubscribed)}
                      </Text>

                      <Text>Contacts</Text>
                    </DetailBox>
                  </Flex>
                </Flex>
              </ListBox>
            </Flex>

            <Flex width='100%'>
              <ListBox>
                <Flex justifyContent='space-between'>
                  <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
                    Growth
                  </Text>
                  <Select
                    width='fit-content'
                    borderColor='gray.500'
                    mt='-5px'
                    fontSize='sm'
                    height='8'
                    onChange={(event) => setGrowthFilter(event.target.value)}>
                    {TIME_PERIOD.map(({ label, value }) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </Select>
                </Flex>
                <Flex alignItems='end' ml='-1' mt='2' pt={2}>
                  <ResponsiveContainer width='100%' height='100%' aspect={aspect}>
                    <BarChart
                      data={listGrowthFormatedData}
                      margin={{ left: -25, top: 10, bottom: 0, right: -7 }}>
                      <CartesianGrid stroke='#D2D8DE' strokeWidth='0.5' vertical={false} />
                      <XAxis
                        dataKey='day'
                        strokeWidth='0'
                        fontSize='10px'
                        stroke='#929BA8'
                        padding={{ left: 0, right: 5 }}
                        tickMargin={8}
                        interval='preserveEnd'
                      />
                      <YAxis
                        strokeWidth='0'
                        fontSize='10px'
                        stroke='#929BA8'
                        tickCount={4}
                        type='number'
                        interval='preserveEnd'
                        padding={{ top: 1, bottom: 1 }}
                      />
                      <Tooltip
                        cursor={false}
                        labelStyle={{ fontSize: '12px' }}
                        contentStyle={{ fontSize: '12px' }}
                      />
                      <Bar dataKey='subscribe' stackId='a' fill='#0071E7' />
                      <Bar dataKey='unsubscribe' stackId='a' fill='#86C9EF' />
                    </BarChart>
                  </ResponsiveContainer>
                </Flex>
                <Legend>
                  <Flex alignItems='flex-start'>
                    <Dots growth='subscribed' />
                    Subscribed
                  </Flex>
                  <Flex>
                    <Dots growth='unsubscribed' />
                    Unsubscribed
                  </Flex>
                </Legend>
              </ListBox>
            </Flex>

            <Flex width='90%' position='relative' zIndex='2'>
              <ListBox>
                <Text fontSize='md' fontWeight='bold' lineHeight='20px' mb='4'>
                  Sender Profile
                </Text>
                {!showProfile ? (
                  <Flex flexDirection='column' gap='15px'>
                    <Box>
                      <Text mb='1' fontSize='sm' lineHeight='17px' color='gray.700'>
                        Name
                      </Text>

                      <Text fontSize='md' fontWeight='semibold' lineHeight='20px'>
                        Vaival User
                      </Text>
                    </Box>
                    <Box>
                      <Text mb='1' fontSize='sm' lineHeight='17px' color='gray.700'>
                        From
                      </Text>
                      <Text fontSize='md' fontWeight='semibold' lineHeight='20px'>
                        vaivaltech@gmail.com
                      </Text>
                    </Box>
                    <Box>
                      <Text mb='1' fontSize='sm' lineHeight='17px' color='gray.700'>
                        Reply to
                      </Text>
                      <Text fontSize='md' fontWeight='semibold' lineHeight='20px'>
                        vaivaltech@gmail.com
                      </Text>
                    </Box>
                    <Box pt='4'>
                      <Button
                        variant='infoOutlined'
                        onClick={() => setShowProfile(!showProfile)}
                        cursor='pointer'>
                        Change Profile
                      </Button>
                    </Box>
                  </Flex>
                ) : (
                  <Box width='100%' height='100%' m='0' pt='3' position='relative'>
                    <SenderProfileDropDown
                      width='100%'
                      fontsize='sm'
                      data={selectedLists}
                      getId={0}
                    />
                    <Flex mt='4'>
                      <Button variant='success' onClick={handleSubmit} cursor='pointer'>
                        Save
                      </Button>
                      <Button
                        ml='4'
                        variant='danger'
                        onClick={() => setShowProfile(!showProfile)}
                        cursor='pointer'>
                        Cancel
                      </Button>
                    </Flex>
                  </Box>
                )}
              </ListBox>
              {/* <SenderProfile
                selectedLists={selectedLists}
                setIsRefetch={setIsRefetch}
                isRefetch={isRefetch}
              /> */}
            </Flex>
          </Flex>
        </Box>

        <Box p='2' mt='3' position='relative' zIndex='1'>
          <Text fontSize='lg' fontWeight='bold' lineHeight='20px' float='left'>
            Contacts
          </Text>
          <DataTable
            columns={columns}
            data={contacts}
            getValue={handleGetSearchValue}
            showFilters={false}
            colProps={contactColProps}
            rowSelection={rowSelection}
            setRowSelection={setRowSelection}
            emptyMessage={'No contact(s) found'}
            onRowClick={({ id }: Contact) => navigate(`/audience/details-analytics/${id}`)}
            rightToolbar={<Box height='35px' />}
            maxLength='9,727'
          />
        </Box>
      </PageContainer>
    </>
  );
};

export default DetailsAnalytics;
