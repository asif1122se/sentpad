import { TriangleDownIcon } from '@chakra-ui/icons';
import { Box, Button, Flex, Menu, MenuItem, MenuList, Stack, Text } from '@chakra-ui/react';
import { useState } from 'react';
import { Option, Select, SelectBox } from '../styles';
import { ContactLists } from '../../Contacts/types';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';

type SenderProps = {
  fontsize?: string;
  title?: string;
  data: any;
  getId: any;
  width?: any;
};

const SenderProfileDropDown = ({
  fontsize = 'md',
  width = '174%',
  title = 'Select sender profile',
  data,
  getId,
}: SenderProps) => {
  const [listData, setListData] = useState<any>({
    name: '',
    profile: {
      from_email: data[0]?.sender_profile?.from_email,
      reply_to_email: data[0]?.sender_profile?.reply_to_email,
    },
  });
  const { data: senderProfile } = useQuery<ContactLists>({
    queryKey: [QUERY_KEYS.SENDER_PROFILES],
    url: 'getSenderProfiles',
  });

  const showSenderProfile = () => {
    return (
      <Box width='fit-content'>
        <MenuItem width='100%'>
          <Option
            onClick={() => {
              setListData({ ...listData, profile: '' });
              getId && getId('');
            }}>
            <Text textAlign='left' fontSize={fontsize} color='gray.500' lineHeight='48px'>
              Select sender profile
            </Text>
          </Option>
        </MenuItem>
        {senderProfile?.map((item: any, i) => (
          <MenuItem width='100%' key={i}>
            <Option
              onClick={() => {
                setListData({ ...listData, profile: item });
                getId && getId(item?.id);
              }}>
              <Flex width='100%' whiteSpace='nowrap'>
                <Box width='fit-content'>
                  <Text>From</Text>
                  <Text>Reply to</Text>
                </Box>
                <Box pl='3%' textAlign='left'>
                  <Text>{item?.from_email}</Text>
                  <Text>{item?.reply_to_email}</Text>
                </Box>
              </Flex>
            </Option>
          </MenuItem>
        ))}
      </Box>
    );
  };
  return (
    <form>
      <Stack gap='1rem' position='relative'>
        <Box>
          <Menu>
            <Text pb='1' fontSize={fontsize} lineHeight='14px'>
              {title}
            </Text>
            <Select as={Button} py='1'>
              {/* Render Selected Sender Profile Here */}
              <SelectBox>
                <Box width='100%'>
                  {!listData?.profile ? (
                    <Text textAlign='left' fontSize={fontsize} color='gray.500' lineHeight='48px'>
                      Click to select sender profile
                    </Text>
                  ) : (
                    <>
                      <Flex p='0'>
                        <Box width='fit-content'>
                          <Text fontSize={fontsize} textAlign='left'>
                            From
                          </Text>
                          <Text fontSize={fontsize} textAlign='left'>
                            Reply to
                          </Text>
                        </Box>
                        <Box pl='5%' textAlign='left' fontSize={fontsize}>
                          <Text>{listData?.profile?.from_email}</Text>
                          <Text>{listData?.profile?.reply_to_email}</Text>
                        </Box>
                      </Flex>
                      {/* <Flex>
                        <Text width='22%' fontSize={fontsize} textAlign='left'>
                          Reply to
                        </Text>
                        <Text fontSize={fontsize} pl='1'>
                          {listData?.profile?.reply_to_email}
                        </Text>
                      </Flex> */}
                    </>
                  )}
                </Box>
                <TriangleDownIcon boxSize='2' color='gray.900' />
              </SelectBox>
            </Select>
            <MenuList width={width}>
              {/* Render All Sender Profile Here */}
              {showSenderProfile()}
            </MenuList>
          </Menu>
        </Box>
      </Stack>
    </form>
  );
};

export default SenderProfileDropDown;
