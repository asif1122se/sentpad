import { useState } from 'react';
import {
  Box,
  Drawer,
  DrawerOverlay,
  DrawerHeader,
  DrawerContent,
  useDisclosure,
  Text,
  Divider,
  DrawerBody,
  Button,
  chakra,
  Flex,
} from '@chakra-ui/react';
import { DetailBox } from '../styles';
import { PaginatedDataTable } from 'components';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import { format } from 'date-fns';
import { ColumnProps, PaginatedTable } from 'types';
import QUERY_KEYS from 'utils/queryKeys';
import { SuppresedItem, SuppressedList } from '../types';

const contactColProps: ColumnProps[] = [
  {
    align: 'left',
    paddingX: '4px',
    paddingLeft: '10px',
  },
  {
    align: 'center',
    paddingX: '3px',
  },
  {
    align: 'right',
    paddingX: '5px',
  },
];

const SuppressionList = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const columnHelper = createColumnHelper<SuppresedItem>();
  const [suppressionListData, setSuppressionListData] =
    useState<PaginatedTable<SuppressedList> | null>(null);

  const columns = [
    columnHelper.display({
      id: 'email',
      header: 'Email',
      cell: (props: CellContext<SuppresedItem, unknown>) => (
        <Text maxW='350px'>{props.row.original.email}</Text>
      ),
    }),

    columnHelper.display({
      id: 'Date Added',
      header: 'Date Added',
      cell: (props: CellContext<SuppresedItem, unknown>) => (
        <Text>
          {props.row.original.supressed_date &&
            format(new Date(`${props.row.original.supressed_date}`), 'MMM d, yyyy')}
        </Text>
      ),
    }),
  ];

  return (
    <Box>
      <Button h='10' variant='blackOutlined' onClick={onOpen}>
        Suppression
      </Button>
      <Drawer isOpen={isOpen} placement='right' onClose={onClose} size='md'>
        <DrawerOverlay />
        <DrawerContent width='600px'>
          <DrawerHeader
            fontSize='15'
            pr='10'
            fontWeight='bold'
            color='black'
            alignItems='center'
            display='inline-flex'
            justifyContent='flex-start'>
            <Text fontWeight='bold' fontSize='lg'>
              Suppression List
              <chakra.span ml='2' fontWeight='500' fontSize='md'>
                ({suppressionListData?.total ?? 0})
              </chakra.span>
            </Text>
          </DrawerHeader>
          <Box width='100%' mb='3'>
            <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
          </Box>
          <DrawerBody px='0'>
            <Box px='5'>
              <Flex width='30%'>
                <DetailBox background='#F2F6F9 0% 0% no-repeat padding-box'>
                  <Text>Suppressed</Text>
                  <Text className='value'>{suppressionListData?.total ?? 0}</Text>
                  <Text>Email</Text>
                </DetailBox>
              </Flex>

              <Box mt='6'>
                {/* <Text fontSize='lg' fontWeight='bold' lineHeight='22px' float='left'>
                  Contacts
                </Text> */}
                <PaginatedDataTable
                  endpoint='contact/suppression-contact-list-paginated'
                  queryKey={[QUERY_KEYS.SUPPRESSION_LIST]}
                  title='Contacts'
                  columns={columns}
                  showFilters={false}
                  colProps={contactColProps}
                  getData={setSuppressionListData}
                  emptyMessage='No contact(s) found'
                  rightToolbar={<Box height='35px' />}
                />
              </Box>
            </Box>
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </Box>
  );
};

export default SuppressionList;
