import { PageHeader, PaginatedDataTable } from 'components';
import { PageContainer } from 'components/Layout';
import { ColumnProps } from 'types/general';
import KebabMenu from 'components/KebabMenu';
import { Badge, useDisclosure } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { createColumnHelper } from '@tanstack/react-table';
import { List, ListList } from './types';
import { IndeterminateCheckbox } from 'components/Checkbox';
import { ChevronRightIcon } from '@chakra-ui/icons';
import { useEffect, useState } from 'react';
import AddNewListModal from './components/AddNewListModal';
import DeleteListModal from './components/DeleteListModal';
import { format } from 'date-fns';
import QUERY_KEYS from 'utils/queryKeys';
import SuppressionList from './components/SuppressionList';
import config from 'config';

const listColProps: ColumnProps[] = [
  {
    align: 'center',
    paddingX: '2px',
    width: '3%',
  },
  {
    align: 'center',
    paddingX: '1px',
    width: '5.5%',
  },
  {
    align: 'left',
    paddingX: '1px',
  },
  {
    align: 'right',
    paddingX: '0px',
  },

  {
    align: 'left',
    width: '14%',
  },
  {
    align: 'right',
    width: '0.1%',
    paddingRight: '1px',
  },
];

const ListsPage = () => {
  const { isOpen: isAddListOpen, onOpen: onAddListOpen, onClose: onAddListClose } = useDisclosure();
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const detailLink =
    localStorage.getItem('email') === config.demoUser
      ? `/audience/list-details-analytics`
      : `/audience/list-details`;

  const [allLists, setAllLists] = useState<ListList>([]);
  const [selectedLists, setSelectedLists] = useState<ListList>([]);
  const [rowSelection, setRowSelection] = useState<{ [key: number]: boolean }>({});

  const navigate = useNavigate();

  const columnHelper = createColumnHelper<List>();

  const columns = [
    columnHelper.display({
      id: 'select',
      header: ({ table }) => (
        <IndeterminateCheckbox
          {...{
            checked: table.getIsAllRowsSelected(),
            indeterminate: table.getIsSomeRowsSelected(),
            onChange: table.getToggleAllPageRowsSelectedHandler(),
          }}
        />
      ),
      cell: ({ row }) => {
        return (
          <IndeterminateCheckbox
            {...{
              checked: row.getIsSelected(),
              indeterminate: row.getIsSomeSelected(),
              onChange: row.getToggleSelectedHandler(),
            }}
          />
        );
      },
    }),
    columnHelper.accessor('id', {
      header: 'List ID',
      cell: (props: any) => (
        <>
          <Badge variant='default' fontSize='12px' fontWeight='600'>
            {props.row.original.id}
          </Badge>
        </>
      ),
    }),
    columnHelper.accessor('title', {
      cell: (info) => info.getValue(),
      header: 'List Name',
    }),
    columnHelper.display({
      header: 'Contacts',
      cell: (props: any) => (
        <>
          {props.row.original.customers?.length > 0
            ? props.row.original.customers[0]?.no_of_contacts
            : 0}
        </>
      ),
    }),
    columnHelper.display({
      header: 'Date Created',
      cell: (props: any) => <>{format(new Date(`${props.row.original.created_at}`), 'MM/dd/yy')}</>,
    }),

    columnHelper.display({
      id: 'action',
      cell: (props: any) => (
        <ChevronRightIcon
          boxSize='5'
          color='gray.500'
          cursor='pointer'
          onClick={() => navigate(`${detailLink}?id=${props.row.original.id}`)}
        />
      ),
    }),
  ];

  const kebabMenu = [
    {
      label: 'Delete',
      onClick: () => (selectedLists.length > 0 ? onDeleteOpen() : null),
      disabled: selectedLists.length === 0,
    },
  ];

  const handleResetSelectedRows = () => setRowSelection([]);

  useEffect(() => {
    const indeces = Object.keys(rowSelection).map((key) => parseInt(key));

    if (indeces && allLists) {
      setSelectedLists(allLists.filter((list, index) => indeces.includes(index)));
    }
  }, [rowSelection]);

  return (
    <PageContainer>
      <PageHeader
        title='Lists'
        subtitle='Audience'
        buttonLabel='Add List'
        onClick={onAddListOpen}
      />
      <DeleteListModal
        isOpen={isDeleteOpen}
        onClose={onDeleteClose}
        selectedRows={selectedLists}
        isBulk
        resetSelectedRows={handleResetSelectedRows}
      />
      <AddNewListModal isOpen={isAddListOpen} onClose={onAddListClose} />
      <PaginatedDataTable
        endpoint='get-lists-paginated'
        queryKey={[QUERY_KEYS.MAIN_LIST]}
        columns={columns}
        colProps={listColProps}
        showFilters={false}
        rowSelection={rowSelection}
        setRowSelection={setRowSelection}
        getData={({ data }) => {
          setAllLists(data);
          setRowSelection([]);
        }}
        emptyMessage='No list(s) found'
        rightToolbar={
          <>
            <SuppressionList />
            <KebabMenu menu={kebabMenu} />
          </>
        }
      />
    </PageContainer>
  );
};

export default ListsPage;
