import { TrueOrFalse } from 'types';

export type NewContactType = {
  list_id: number;
  email: string;
  first_name: string;
  last_name: string;
  phone_no: string;
};

export type Contact = NewContactType & {
  id: number;
  user_id: number;
  subscribe_date: string;
  address_one?: string;
  address_two?: string;
  city?: string;
  state?: string;
  zip_code?: number;
  country?: string;
  created_at?: string;
  deleted_at?: string;
  date_of_birth?: string;
  is_subscribed: 0 | 1;
  is_active: 0 | 1;
  is_email_valid: 0 | 1;
  updated_at?: string;
  lists?: [];
};

export type ContactForm = NewContactType & {
  country?: string;
  address_one?: string;
  address_two?: string;
  city?: string;
  state?: string;
  zip_code?: number;
};

export type EditContact = Omit<ContactForm, 'list_id' | 'email'>;

export type ContactListItem = {
  id: number;
  title: string;
};

export type ContactDetailsGridProps = {
  label?: string;
  value?: string;
};

export type ContactList = Contact[];
export type ContactLists = ContactListItem[];

export type SenderProfile = {
  company_name: string;
  from_email: string;
  id: number;
  sender_domain_id: number;
  reply_to_email: string;
  sender_name: string;
  is_default: TrueOrFalse;
  state: string | null;
  street: string | null;
  city: string | null;
  zip: string | null;
  country: string | null;
};

export type SenderProfiles = SenderProfile[];

export type SubscribeContactsToList = {
  list_id: number;
  customer_ids: string;
};

export type UnsubscribeCustomers = {
  customers: string;
  list: string;
};

export type SenderProfileForm = {
  company_name: string;
  from_email: string;
  reply_to_email: string;
  sender_name: string;
  state: string | null;
  street: string | null;
  city: string | null;
  zip: string | null;
  country: string | null;
};
