import { Box, Container, Flex } from '@chakra-ui/react';
import { PageContainer } from 'components/Layout';
import { useQuery } from 'hooks/useQuery';
import { useParams } from 'react-router-dom';
import QUERY_KEYS from 'utils/queryKeys';
import { DetailProfile, DetailsHeader, DetailsLists } from './components';
import { Contact } from './types';

const Details = () => {
  const { id } = useParams();

  const { data, isLoading, isFetching } = useQuery<Contact>({
    queryKey: [QUERY_KEYS.CONTACT],
    url: `get-customer/${id}`,
  });

  return (
    <>
      <PageContainer loading={isLoading || isFetching}>
        <DetailsHeader id={id?.toString() ?? '0'} />
        <Flex justifyContent='space-between' mb='4'></Flex>
        <Flex mt='4' flexShrink='2'>
          <Flex justifyContent='left' alignItems='flex-start' width='100%'>
            <Box width={['50%', '50%', '60%', '75%']}>
              <DetailProfile details={data} />
            </Box>
            {/* REVENUE */}
            <Container
              width='100%'
              flexShrink='2'
              pl='8'
              fontSize={['12px', '14px', '16px', '18px', '20px']}>
              <Box>
                <DetailsLists data={data} />
              </Box>
            </Container>
          </Flex>
        </Flex>
      </PageContainer>
    </>
  );
};

export default Details;
