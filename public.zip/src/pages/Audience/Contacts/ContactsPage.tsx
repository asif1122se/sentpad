import { useDisclosure, Badge, Button } from '@chakra-ui/react';
import { PageHeader, PaginatedDataTable } from 'components';
import { PageContainer } from 'components/Layout';
import { useEffect, useState } from 'react';
import { CellContext, createColumnHelper } from '@tanstack/react-table';
import {
  DeleteContactModal,
  SubscribeContactToListModal,
  SuppressContactModal,
  UnsubscribeSelectedContactsModal,
} from './components';
import { Contact, ContactList, ContactLists } from './types';
import { ChevronRightIcon } from '@chakra-ui/icons';
import { IndeterminateCheckbox } from 'components/Checkbox';
import { ColumnProps, TrueOrFalse } from 'types/general';
import { useNavigate } from 'react-router-dom';
import KebabMenu from 'components/KebabMenu';
import ExportContact from '../ImportExport/components/ExportContactModal';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { FILTER_INDEX } from 'components/Filters/consts';
import { useQueryClient } from '@tanstack/react-query';
import { ApiResult } from 'hooks/useMutation';
import ImportContact from '../ImportExport/components/ImportContactModal';

enum CustomerStatus {
  UNSUBSCRIBED,
  SUBSCRIBED,
}

const maximumListsToBeDisplayed = 3;

const contactColProps: ColumnProps[] = [
  {
    align: 'center',
    paddingX: '5px',
  },
  {
    align: 'left',
    paddingX: '0px',
  },
  {
    align: 'left',
    paddingX: '3px',
  },
  {
    align: 'left',
    paddingX: '3px',
  },
  {
    align: 'center',
    whitespace: 'nowrap',
    paddingX: '0px',
  },
  {
    align: 'center',
    whitespace: 'nowrap',
    paddingX: '0px',
  },
  {
    align: 'left',
    paddingX: '0px',
    paddingRight: '0px',
    paddingLeft: '0px',
  },
  {
    align: 'left',
    paddingX: '0px',
  },
  {
    align: 'right',
    paddingX: '3px',
  },
];

const ContactsPage = () => {
  const {
    isOpen: isAddContactOpen,
    onOpen: onAddContactOpen,
    onClose: onAddContactClose,
  } = useDisclosure();
  const {
    isOpen: isSubscribeOpen,
    onOpen: onSubscribeOpen,
    onClose: onSubscribeClose,
  } = useDisclosure();
  const {
    isOpen: isUnsubscribeOpen,
    onOpen: onUnsubscribeOpen,
    onClose: onUnsubscribeClose,
  } = useDisclosure();
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const {
    isOpen: isSuppressOpen,
    onOpen: onSuppressOpen,
    onClose: onSuppressClose,
  } = useDisclosure();
  const { isOpen: isExportOpen, onOpen: onExportOpen, onClose: onExportClose } = useDisclosure();
  const {
    isOpen: isLimitReachedOpen,
    onOpen: onLimitReachedOpen,
    onClose: onLimitReachedClose,
  } = useDisclosure();

  const { data: contactList } = useQuery<ContactLists>({
    url: 'getContactLists',
    queryKey: [QUERY_KEYS.CONTACTS_LISTS],
  });

  const [allContacts, setAllContacts] = useState<ContactList>([]);
  const [selectedContacts, setSelectedContacts] = useState<ContactList>([]);
  const [rowSelection, setRowSelection] = useState<{ [key: number]: boolean }>({});

  const queryClient = useQueryClient();

  const subscriptionData: ApiResult<{ is_subscribe: TrueOrFalse }> | undefined =
    queryClient.getQueryData([QUERY_KEYS.CHECK_SUBSCRIPTION]);

  const columnHelper = createColumnHelper<Contact>();
  const navigate = useNavigate();

  const columns = [
    columnHelper.display({
      id: 'select',
      header: ({ table }) => (
        <IndeterminateCheckbox
          {...{
            checked: table.getIsAllRowsSelected(),
            indeterminate: table.getIsSomeRowsSelected(),
            onChange: table.getToggleAllPageRowsSelectedHandler(),
          }}
        />
      ),
      cell: ({ row }) => {
        return (
          <IndeterminateCheckbox
            {...{
              checked: row.getIsSelected(),
              indeterminate: row.getIsSomeSelected(),
              onChange: row.getToggleSelectedHandler(),
            }}
          />
        );
      },
    }),
    columnHelper.display({
      id: 'subscribed',
      header: 'Status',
      cell: (props: CellContext<Contact, unknown>) => (
        <Badge variant='default' fontSize='12px' fontWeight='600' textTransform='capitalize'>
          {props.row.original.is_subscribed === CustomerStatus.SUBSCRIBED
            ? 'Subscribed'
            : 'Unsubscribed'}
        </Badge>
      ),
    }),
    columnHelper.display({
      id: 'name',
      header: 'Name',
      cell: (props: CellContext<Contact, unknown>) => (
        <>
          {props.row.original.first_name} {props.row.original.last_name}
        </>
      ),
    }),
    columnHelper.accessor('email', {
      cell: (info) => info.getValue(),
      header: 'Email',
    }),
    columnHelper.accessor('subscribe_date', {
      cell: (info) => info.getValue(),
      header: 'Subscribe Date',
    }),

    columnHelper.display({
      id: 'lists',
      header: 'Lists',
      cell: (props: CellContext<Contact, unknown>) => {
        const row = props.row.original;
        const showOthers = (props.row.original.lists?.length ?? 0) - maximumListsToBeDisplayed;
        return (
          <>
            {row.is_subscribed === CustomerStatus.SUBSCRIBED &&
              row.lists?.slice(0, maximumListsToBeDisplayed).map(({ id, title = '' }) => (
                <Badge
                  key={id}
                  m='1px'
                  variant='warning'
                  fontSize='12px'
                  fontWeight='600'
                  textTransform='capitalize'>
                  {title.length > 30 ? `${title.substring(0, 30)}...` : title}
                </Badge>
              ))}
            {showOthers > 0 ? (
              <Badge m='1px' variant='warning' fontSize='12px' fontWeight='600'>
                +{showOthers}
              </Badge>
            ) : null}
          </>
        );
      },
    }),
    columnHelper.display({
      id: 'action',
      cell: (props: CellContext<Contact, unknown>) => (
        <ChevronRightIcon
          boxSize='5'
          color='gray.500'
          cursor='pointer'
          onClick={() => navigate(`/audience/details/${props.row.original.id}`)}
        />
      ),
    }),
  ];
  const kebabMenu = [
    {
      label: 'Subscribe',
      onClick: () => (selectedContacts.length > 0 ? onSubscribeOpen() : null),
      disabled: selectedContacts.length === 0,
    },
    {
      label: 'Unsubscribe',
      onClick: () => (selectedContacts.length > 0 ? onUnsubscribeOpen() : null),
      disabled:
        selectedContacts.length === 0 ||
        (selectedContacts.length === 1 && selectedContacts[0]?.lists?.length === 0),
    },
    {
      label: 'Delete',
      onClick: () => (selectedContacts.length > 0 ? onDeleteOpen() : null),
      disabled: selectedContacts.length === 0,
    },
  ];

  const handleResetSelectedRows = () => setRowSelection([]);

  useEffect(() => {
    const indeces = Object.keys(rowSelection).map((key) => parseInt(key));

    if (indeces && allContacts) {
      setSelectedContacts(allContacts.filter((contact, index) => indeces.includes(index)));
    }
  }, [rowSelection]);

  return (
    <PageContainer>
      <PageHeader
        title='Contacts'
        subtitle='Audience'
        buttonLabel='Add Contact'
        onClick={() =>
          subscriptionData?.records.is_subscribe === 1 ? onLimitReachedOpen() : onAddContactOpen()
        }
      />
      <DeleteContactModal
        isOpen={isDeleteOpen}
        onClose={onDeleteClose}
        selectedRows={selectedContacts}
        isBulk
        resetSelectedRows={handleResetSelectedRows}
      />
      <SuppressContactModal
        isOpen={isSuppressOpen}
        onClose={onSuppressClose}
        selectedRows={selectedContacts}
        isBulk
        resetSelectedRows={handleResetSelectedRows}
      />
      <ImportContact isOpen={isAddContactOpen} onClose={onAddContactClose} />
      <SubscribeContactToListModal
        isOpen={isSubscribeOpen}
        onClose={onSubscribeClose}
        customerIDs={selectedContacts?.map((row) => row.id)}
        resetSelectedRows={handleResetSelectedRows}
      />
      <UnsubscribeSelectedContactsModal
        customerIDs={selectedContacts?.map((row) => row.id).toString()}
        lists={selectedContacts[0]?.lists}
        isOpen={isUnsubscribeOpen}
        onClose={onUnsubscribeClose}
        resetSelectedRows={handleResetSelectedRows}
      />
      <ExportContact
        isOpen={isExportOpen}
        onClose={onExportClose}
        data={selectedContacts}
        lists={contactList}
      />
      <PaginatedDataTable
        endpoint='get-customers-paginated'
        queryKey={[QUERY_KEYS.CONTACTS]}
        columns={columns}
        filterIndex={FILTER_INDEX.Contact}
        colProps={contactColProps}
        rowSelection={rowSelection}
        setRowSelection={setRowSelection}
        getData={({ data }) => {
          setAllContacts(data);
          setRowSelection([]);
        }}
        emptyMessage={'No contact(s) found'}
        rightToolbar={
          <>
            <Button
              h='10'
              variant='blackOutlined'
              isDisabled={selectedContacts.length === 0}
              onClick={onSuppressOpen}>
              Suppress
            </Button>
            <Button
              h='10'
              variant='blackOutlined'
              isDisabled={selectedContacts.length === 0}
              onClick={() => onExportOpen()}>
              Export
            </Button>
            <KebabMenu menu={kebabMenu} />
          </>
        }
      />
    </PageContainer>
  );
};

export default ContactsPage;
