import * as Yup from 'yup';

export const contactSchema = Yup.object().shape({
  list_id: Yup.number().test('list_id', 'Subscription List is required', (value) => value !== 0),
  first_name: Yup.string().nullable().max(75, 'First name must not exceed 75 characters'),
  last_name: Yup.string().nullable().max(75, 'Last name must not exceed 75 characters'),
  email: Yup.string().email('Invalid email address').required('Email address is required'),
  phone_no: Yup.string().nullable(),
  address_one: Yup.string().nullable().max(100, 'Address 1 must not exceed 100 characters'),
  address_two: Yup.string().nullable().max(100, 'Address 2 must not exceed 100 characters'),
  city: Yup.string().nullable().max(50, 'City must not exceed 50 characters'),
  state: Yup.string().nullable().max(50, 'State must not exceed 50 characters'),
});
