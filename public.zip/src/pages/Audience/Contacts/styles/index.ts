import { Flex, Text, Box } from '@chakra-ui/react';
import styled from '@emotion/styled';

// Contact Add New
export const Note = styled(Flex)`
  align-items: flex-start;
  border: 1px solid #d6cedb;
  border-radius: 4px;
  padding: 18px;
  background-color: #f4f0f7;
`;

export const NoteText = styled(Text)`
  font-size: 14px;
  line-height: 20px;
  margin-left: 1rem;
`;

// Contact Details Header
export const ContactDetailHeader = styled(Flex)`
  margin-bottom: 2rem;
  justify-content: space-between;
  alignitems: center;
`;
export const ContactDetailHeaderDelete = styled(Flex)`
  background-color: #e8ebee;
  width: 38px;
  height: 38px;
  align-items: center;
  justify-content: center;
  border-radius: 3px;
`;

// Contact Details Profile
export const ProfileContainer = styled(Box)`
  width: 100%;
  padding: 0;
  border-radius: 8px;
  border: 1px solid var(--chakra-colors-gray-400);
  background: #ffffff 0% 0% no-repeat padding-box;
`;

export const ProfileHeader = styled(Flex)`
  justify-content: space-between;
  padding: 1rem;
  border-bottom: 1px;
  border-bottom-color: var(--chakra-colors-gray-400);
  border-bottom-width: 1px;
  width: 100%;
  height: 150px;
`;

// Contact Details Revenue, Contact Statistics
export const DetailBox = styled(Box)`
  border-radius: 8px;
  opacity: 1;
  background: #f2f6f9 0% 0% no-repeat padding-box;
  padding: 0.75rem;
`;

export const BoxLabel = styled(Text)`
  font-size: 14px;
  line-height: 17px;
  opacity: 1;
  margin: 0.2rem;
`;

export const BoxValue = styled(Text)`
  font-weight: bold;
  font-size: 15px;
  line-height: 20px;
  opacity: 1;
  margin: 0.2rem;
`;

// Contact Details Internal Notes
export const Header = styled(Text)`
  font-size: 16px;
  font-weight: bold;
  line-height: 20px;
`;

export const NoteBox = styled(Flex)`
  padding-bottom: 0.5rem;
  padding-right: 1.25rem;
  margin-bottom: 1.75rem;
  border-bottom-width: 1px;
  border-bottom-color: var(--chakra-colors-gray-400);
  justify-content: space-between;
`;

// Contact Details Timeline
export const TimelineBox = styled(Flex)`
  padding: 1.25rem;
  width: 100%;
  border-width: 1px;
  border-color: var(--chakra-colors-gray-400);
  border-radius: 8px;
  justify-content: space-between;
`;

export const TimelineLabel = styled(Text)`
  font-size: 16px;
  font-weight: bold;
  line-height: 20px;
`;

export const TimelineDate = styled(Text)`
  font-size: 14px;
  line-height: 17px;
  color: #929ba8;
`;

// Contact Unsubscribe List
export const Link = styled(Text)({
  fontSize: 'var(--chakra-fontSizes-sm)',
  cursor: 'pointer',
  color: 'var(--chakra-colors-blue-700)',
});

export const ListBox = styled(Box)({
  width: '100%',
  height: '115px',
  overflowY: 'scroll',
  gap: '5px',
  padding: '4px',
  borderWidth: '1px',
  borderRadius: '5px',
  borderColor: 'var(--chakra-colors-gray-400)',
});
