import {
  Box,
  Button,
  Image,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
} from '@chakra-ui/react';
import React from 'react';
import AlertIcon from 'assets/icons/alert.svg';

const SuppressModal = ({ openSuppress, setOpenSuppress }: any) => {
  return (
    <Modal isOpen={openSuppress} onClose={() => setOpenSuppress(false)}>
      <ModalOverlay />
      <ModalContent maxW='540px'>
        <ModalHeader color='black' fontSize='18px' fontWeight='bold' lineHeight='32px'>
          Suppress Contacts
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody display='flex' gap='3' mb='5'>
          <Box justifyContent='flex-start'>
            <Image src={AlertIcon} alt='Alert' height='60px' width='100px' m='0' />
          </Box>
          <Box>
            <Text fontSize='18px' fontWeight='500' mt='7px'>
              Are you sure you want to add john.smith@yahoo.com to the suppression list? They will
              no longer receive emails.
            </Text>
          </Box>
        </ModalBody>
        <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
          <Button variant='danger' mr='8px'>
            Suppress Contact
          </Button>
          <Button onClick={() => setOpenSuppress(false)}>Cancel</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default SuppressModal;
