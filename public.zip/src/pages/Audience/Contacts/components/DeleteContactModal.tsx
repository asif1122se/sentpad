import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  chakra,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { useMutation } from 'hooks/useMutation';
import { DELETE } from 'utils/constants';
import QUERY_KEYS from 'utils/queryKeys';
import { ContactList } from '../types';

type DeleteContactModal = {
  isOpen: boolean;
  onClose: () => void;
  selectedRows: ContactList;
  isBulk: boolean;
  resetSelectedRows: () => void;
};

const DeleteContactModal = ({
  isOpen,
  onClose,
  selectedRows,
  isBulk,
  resetSelectedRows,
}: DeleteContactModal) => {
  const queryClient = useQueryClient();
  const { isLoading, mutate } = useMutation<string>({
    method: DELETE,
    url: 'delete-customers',
    onSuccess: () => {
      onClose();
      resetSelectedRows();
      queryClient.invalidateQueries([QUERY_KEYS.CONTACTS]);
    },
    successMessage: 'Contact(s) deleted successfully',
  });

  const handleDelete = () => {
    const ids = selectedRows
      ?.map((row) => row.id?.toString())
      .reduce((prev, curr) => `${prev},${curr}`);

    if (ids) {
      mutate(ids);
    }
  };

  const isSingle = selectedRows.length === 1;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      size='lg'
      closeOnEsc={isLoading}
      closeOnOverlayClick={isLoading}
      isCentered>
      <ModalOverlay />
      <ModalContent p='32px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            {isBulk ? 'Delete Contact(s)' : 'Delete Contact'}
          </Text>
        </ModalHeader>
        <ModalCloseButton isDisabled={isLoading} />
        <ModalBody px='0'>
          {!isBulk && (
            <Text>
              {'Are you sure you want to remove contact(s)? '}
              <chakra.span my='1' fontWeight='bold'>
                {selectedRows[0]?.email}
              </chakra.span>
            </Text>
          )}
          {isBulk && (
            <Text>
              Are you sure you want to delete {isSingle ? 'this' : 'these'}{' '}
              {!isSingle && selectedRows.length} contact{!isSingle && 's'}?
            </Text>
          )}
        </ModalBody>

        <ModalFooter justifyContent='flex-start' pb='0' px='0'>
          <Button variant='danger' mr={2} onClick={handleDelete} isLoading={isLoading}>
            Delete
          </Button>
          <Button onClick={onClose} isDisabled={isLoading}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeleteContactModal;
