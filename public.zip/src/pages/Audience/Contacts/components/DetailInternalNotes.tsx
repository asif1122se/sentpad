import { DeleteIcon, EditIcon } from '@chakra-ui/icons';
import { Box, Button, Flex, Text } from '@chakra-ui/react';
import { Header, NoteBox } from '../styles';

type InternalNoteProps = {
  note?: string;
  date?: string;
};

const ShowNote = ({ note, date }: InternalNoteProps) => {
  return (
    <NoteBox>
      <Box>
        <Text>{note}</Text>
        <Text fontSize='14px' color='gray.600' lineHeight='32px'>
          {date}
        </Text>
      </Box>
      <Box>
        <EditIcon mr='3' boxSize='5' cursor='pointer' />
        <DeleteIcon boxSize='5' cursor='pointer' />
      </Box>
    </NoteBox>
  );
};

const InternalNotes = () => {
  return (
    <>
      <Flex my='8' justifyContent='space-between'>
        <Header>Internal Notes</Header>
        <Button variant='infoOutlined'>Add Note</Button>
      </Flex>
      <ShowNote note='Customer subscribed to our paid course' date='10 Jul, 2022' />
      <ShowNote note='Contact requesting more information about the course' date='18 Jul, 2022' />
    </>
  );
};

export default InternalNotes;
