import {
  Box,
  Flex,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalHeader,
  ModalOverlay,
  Stack,
} from '@chakra-ui/react';
import React from 'react';

const ProfileModal = ({ openProfile, setOpenProfile }: any) => {
  return (
    <Flex>
      <Modal isOpen={openProfile} onClose={() => setOpenProfile(false)}>
        <ModalOverlay />
        <ModalContent maxW='540px' height='100%' m='0' justifyContent='right'>
          <ModalHeader color='black' fontSize='18px' fontWeight='bold'></ModalHeader>
          <ModalCloseButton></ModalCloseButton>
          <ModalBody>
            <Stack gap='1rem' mb='5'></Stack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </Flex>
  );
};

export default ProfileModal;
