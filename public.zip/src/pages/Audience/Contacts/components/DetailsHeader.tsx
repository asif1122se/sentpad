import { DeleteIcon } from '@chakra-ui/icons';
import { Button, Flex, Heading, Image, useDisclosure } from '@chakra-ui/react';
import { ContactDetailHeader, ContactDetailHeaderDelete } from '../styles';
import UnsubscribeSelectedContactsModal from './UnsubscribeSelectedContactsModal';
import ArrowBackIcon from 'assets/icons/arrow-back.svg';
import { useNavigate } from 'react-router-dom';
type DetailProps = {
  id?: string;
};

export const DetailsHeader = ({ id = '' }: DetailProps) => {
  const {
    isOpen: isUnsubscribeOpen,
    onOpen: onUnsubscribeOpen,
    onClose: onUnsubscribeClose,
  } = useDisclosure();
  const navigate = useNavigate();
  return (
    <>
      <UnsubscribeSelectedContactsModal
        customerIDs={id}
        isOpen={isUnsubscribeOpen}
        onClose={onUnsubscribeClose}
      />

      <ContactDetailHeader>
        <Flex>
          <Image
            ml='-5px'
            src={ArrowBackIcon}
            alt='Back'
            cursor='pointer'
            onClick={() => navigate(-1)}
          />
          <Heading as='h1' fontSize='2rem' lineHeight='2.438rem'>
            Contact Details
          </Heading>
        </Flex>
        <Flex alignItems='center' hidden={true}>
          <Button mr='1.5' variant='black'>
            Suppress
          </Button>
          <Button mr='1.5' variant='black' onClick={onUnsubscribeOpen}>
            Unsubscribe
          </Button>
          <ContactDetailHeaderDelete>
            <DeleteIcon m='1' boxSize='4' cursor='pointer' />
          </ContactDetailHeaderDelete>
        </Flex>
      </ContactDetailHeader>
    </>
  );
};

export default DetailsHeader;
