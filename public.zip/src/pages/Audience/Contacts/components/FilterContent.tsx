import {
  Box,
  Button,
  Checkbox,
  CheckboxGroup,
  Divider,
  DrawerBody,
  DrawerFooter,
  Flex,
  Grid,
  GridItem,
  Spacer,
  Text,
} from '@chakra-ui/react';
import AudienceList from 'pages/Broadcast/components/AudienceList';
import { useState } from 'react';

const showTags = ['Fraudulent', 'Regular Users', 'Paid Subscribers', 'Banner Edge'];

const showStatus = ['Subscribed', 'Unsubscribed'];

const FilterContent = ({ onClose }: any) => {
  const [listsFilter, setListsFilter] = useState<any>({ lists_filter: '' });

  const getList = (data: any) => {
    const ids = data?.map((item: any) => item?.id);
    setListsFilter({ ...listsFilter, lists_filter: ids?.toString() });
  };
  return (
    <>
      <Box width='100%' mb='0'>
        <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
      </Box>
      <DrawerBody px='0'>
        <Box px='4'>
          {/* <Flex width={screen.width == window.innerWidth ? '97%' : '95%'}>
            <Text fontSize='xs' color='gray.600' fontWeight='bolder'>
              LISTS
            </Text>
            <Spacer />
            <Text fontSize='sm' color='blue.700' fontWeight='500' cursor='pointer'>
              Clear
            </Text>
          </Flex> */}
          <Box
            color='black'
            fontSize='md'
            width={screen.width == window.innerWidth ? '98%' : '98%'}>
            <AudienceList getList={getList} headingText='' />
          </Box>
        </Box>
        <Box width={screen.width == window.innerWidth ? '99%' : '99%'} my='6'>
          <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
        </Box>
        <Box px='4'>
          <Flex width={screen.width == window.innerWidth ? '98%' : '98%'}>
            <Text fontSize='xs' color='gray.600' fontWeight='semibold'>
              STATUS
            </Text>
            <Spacer />
            <Text fontSize='sm' color='blue.700' cursor='pointer' fontWeight='500'>
              Clear
            </Text>
          </Flex>
          <Flex>
            <Grid mt='5' gap={3} color='black' fontSize='sm' fontWeight='500'>
              {showStatus.map((item: any, index) => (
                <>
                  <GridItem colSpan={18}>{item}</GridItem>
                  <GridItem colStart={screen.width == window.innerWidth ? 23 : 23}>
                    <CheckboxGroup>
                      <Checkbox borderColor='gray.400' />
                    </CheckboxGroup>
                  </GridItem>
                </>
              ))}
            </Grid>
          </Flex>
        </Box>
      </DrawerBody>
      <Box width={screen.width == window.innerWidth ? '99%' : '99%'} my='1'>
        <Divider orientation='horizontal' borderWidth='1px' borderColor='gray.300' />
      </Box>
      <DrawerFooter justifyContent='left'>
        <Button variant='info' px='6' mr='3' cursor='pointer'>
          Filter
        </Button>
        <Button mr={3} onClick={onClose}>
          Clear All
        </Button>
      </DrawerFooter>
    </>
  );
};

export default FilterContent;
