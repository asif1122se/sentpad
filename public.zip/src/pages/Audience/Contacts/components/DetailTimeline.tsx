import { Badge, Box, Center, Circle, Divider, Flex, Icon, Text } from '@chakra-ui/react';
import { IoMailOutline } from 'react-icons/io5';
import { TimelineBox, TimelineDate, TimelineLabel } from '../styles';

const ShowDivider: React.FC = () => {
  return (
    <>
      <Center width='100px' height='20px'>
        <Divider orientation='vertical' borderWidth='1px' borderColor='gray.400' />
      </Center>
    </>
  );
};

type TimelineProps = {
  label?: string;
  value?: string;
  date?: string;
};

const ShowTimelineBox = ({ label, value, date }: TimelineProps) => {
  return (
    <>
      <TimelineBox>
        <Flex alignItems='center'>
          <Circle size='60px' bg='gray.300'>
            <Icon as={IoMailOutline} boxSize='7' color='gray.800' />
          </Circle>
          <Box ml='5'>
            <TimelineLabel color='black'>{label}</TimelineLabel>
            <Badge variant='warning' textTransform='capitalize' mt='1'>
              {value}
            </Badge>
          </Box>
        </Flex>
        <TimelineDate>{date}</TimelineDate>
      </TimelineBox>
      <ShowDivider />
    </>
  );
};

const Timeline = () => {
  return (
    <>
      <Box my='8' width='100%'>
        <TimelineLabel>Timeline</TimelineLabel>
        <Text fontSize='14px' color='gray.600' lineHeight='32px' mb='4'>
          Recent engagement for last 30 days
        </Text>
        <ShowTimelineBox
          label='Customer added new contacts'
          value='New Year Sale'
          date='Sun, Jan 02, 2023 05:01 AM'
        />
        <ShowTimelineBox
          label='Campaign Email Sent'
          value='Black Friday Sale'
          date='Tue, Jul 26, 2022 12:06 AM'
        />
        <Flex
          justifyContent='center'
          alignItems='center'
          w='137px'
          h='50px'
          borderWidth='1px'
          borderColor='gray.400'
          borderRadius='8px'>
          <Text fontSize='14px' lineHeight='17px' fontWeight='bold'>
            Beginning
          </Text>
        </Flex>
      </Box>
    </>
  );
};

export default Timeline;
