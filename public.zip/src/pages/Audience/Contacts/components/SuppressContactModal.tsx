import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  chakra,
  Flex,
  Image,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { useMutation } from 'hooks/useMutation';
import { PUT } from 'utils/constants';
import QUERY_KEYS from 'utils/queryKeys';
import { ContactList } from '../types';
import AlertIcon from 'assets/icons/alert-lg.svg';

type SuppressContactModal = {
  isOpen: boolean;
  onClose: () => void;
  selectedRows: ContactList;
  isBulk: boolean;
  resetSelectedRows: () => void;
};

const SuppressContactModal = ({
  isOpen,
  onClose,
  selectedRows,
  isBulk,
  resetSelectedRows,
}: SuppressContactModal) => {
  const queryClient = useQueryClient();
  const { isLoading, mutate } = useMutation<{ ids: string }>({
    method: PUT,
    url: 'contact/suppression-contact',
    onSuccess: () => {
      onClose();
      resetSelectedRows();
      queryClient.invalidateQueries([QUERY_KEYS.CONTACTS]);
    },
    successMessage: 'Contact(s) suppressed successfully',
  });

  const handleSuppress = () => {
    const ids = selectedRows
      ?.map((row) => row.id?.toString())
      .reduce((prev, curr) => `${prev},${curr}`);

    if (ids) {
      mutate({ ids });
    }
  };

  const isSingle = selectedRows.length === 1;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      size='lg'
      closeOnEsc={isLoading}
      closeOnOverlayClick={isLoading}
      isCentered>
      <ModalOverlay />
      <ModalContent p='32px'>
        <ModalHeader p='0' pb='2'>
          <Text fontSize='18px' fontWeight='bold'>
            {isBulk ? 'Suppress Contact(s)' : 'Suppress Contact'}
          </Text>
        </ModalHeader>
        <ModalCloseButton isDisabled={isLoading} />
        <ModalBody px='0'>
          <Flex gap='24px'>
            <Image src={AlertIcon} alt='Alert' w='32px' h='32px' mt='6px' />
            {!isBulk && (
              <Text>
                Are you sure you want to add “<strong>{selectedRows[0].email}</strong>” to the
                suppression list? They will no longer receive emails.
                <chakra.span my='1' fontWeight='bold'>
                  {selectedRows[0]?.email}
                </chakra.span>
              </Text>
            )}
            {isBulk && (
              <Text>
                Are you sure you want to add {isSingle ? 'this' : 'these'}{' '}
                {!isSingle && selectedRows.length} contact{!isSingle && 's'} to the suppression
                list? They will no longer receive emails.
              </Text>
            )}
          </Flex>
        </ModalBody>

        <ModalFooter justifyContent='flex-start' pb='0' px='0'>
          <Button variant='danger' mr={2} onClick={handleSuppress} isLoading={isLoading}>
            Suppress
          </Button>
          <Button onClick={onClose} isDisabled={isLoading}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default SuppressContactModal;
