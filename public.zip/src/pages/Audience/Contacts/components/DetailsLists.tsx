import { AddIcon } from '@chakra-ui/icons';
import { Badge, Box, Flex, Text, useDisclosure } from '@chakra-ui/react';
import { Contact } from '../types';
import SubscribeContactToListModal from './SubscribeContactToListModal';

type TagListProps = {
  label?: string;
};

type DetailsListsProps = {
  data?: Contact;
};

const ShowBadge = ({ label = '' }: TagListProps) => {
  return (
    <Badge variant='warning' textTransform='capitalize' mr='2' my='1'>
      {label.length > 50 ? `${label.substring(0, 50)}...` : label}
    </Badge>
  );
};

const DetailsLists = ({ data }: DetailsListsProps) => {
  const {
    isOpen: isSubscribeOpen,
    onOpen: onSubscribeOpen,
    onClose: onSubscribeClose,
  } = useDisclosure();

  return (
    <>
      <SubscribeContactToListModal
        isOpen={isSubscribeOpen}
        onClose={onSubscribeClose}
        customerIDs={[data?.id ?? 0]}
        isDetails
      />

      <Box>
        <Text fontWeight='bold' lineHeight='24px' mb='4'>
          Lists
        </Text>
        <Box borderWidth='1px' borderColor='gray.400' borderRadius='8px' px='20px' py='15px'>
          <Flex flexWrap='wrap'>
            {data?.lists?.map(({ id, title }, index) => (
              <ShowBadge key={`${id}${index}`} label={title} />
            ))}
            <Badge variant='infoOutlined' my='1' cursor='pointer' onClick={() => onSubscribeOpen()}>
              <AddIcon boxSize='2' mb='1' fontWeight='bold' /> Add
            </Badge>
          </Flex>
        </Box>
      </Box>
    </>
  );
};

export default DetailsLists;
