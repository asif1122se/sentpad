import { Box, Grid, GridItem, Text } from '@chakra-ui/react';
import { DetailBox, BoxLabel, BoxValue } from '../styles';
import { ContactDetailsGridProps } from '../types';

type CDBoxProps = {
  title?: string;
  items?: ContactDetailsGridProps[];
};

const ShowCDBox = ({ label, value }: ContactDetailsGridProps) => {
  return (
    <GridItem>
      <DetailBox>
        <BoxLabel fontSize={['10px', '10px', '10px', '12px', '14px']}>{label}</BoxLabel>
        <BoxValue
          fontSize={['12px', '12px', '12px', '14px', '17px']}
          lineHeight='{14px, 16px, 22px}'>
          {value}
        </BoxValue>
      </DetailBox>
    </GridItem>
  );
};

const DetailsBoxes = ({ title, items }: CDBoxProps) => {
  return (
    <Box mt='7'>
      <Text fontWeight='bold' lineHeight='24px' mb='4'>
        {title}
      </Text>
      {items && (
        <Grid templateColumns='repeat(3, 1fr)' gap={3}>
          {items?.map(({ label, value }) => {
            return (
              <>
                <ShowCDBox label={label} value={value} />
              </>
            );
          })}
        </Grid>
      )}
    </Box>
  );
};

export default DetailsBoxes;
