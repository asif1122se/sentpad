import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  Badge,
  Flex,
  Image,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { useFormik } from 'formik';
import { useMutation } from 'hooks/useMutation';
import { useState } from 'react';
import QUERY_KEYS from 'utils/queryKeys';
import { Link, ListBox, Note, NoteText } from '../styles';
import { UnsubscribeCustomers } from '../types';
import InfoIcon from 'assets/icons/info.svg';

type UnsubscribeContactsProps = {
  isOpen: boolean;
  onClose: () => void;
  customerIDs: string;
  lists?: [];
  resetSelectedRows?: () => void;
};

export const initialUnsubscribeValue = {
  customers: '',
  list: '',
};

const UnsubscribeSelectedContactsModal = ({
  isOpen,
  onClose,
  customerIDs,
  resetSelectedRows,
  lists,
}: UnsubscribeContactsProps) => {
  const queryClient = useQueryClient();
  const [selectedList, setSelectedList] = useState<any>([]);

  const { mutate, isLoading } = useMutation<UnsubscribeCustomers>({
    url: 'unsubscribe-customer',
    onSuccess: () => {
      setSelectedList([]);
      onClose();
      resetSelectedRows && resetSelectedRows();
      queryClient.invalidateQueries([QUERY_KEYS.CONTACTS]);
    },
    successMessage: 'Unsubscribed contact(s) successfully',
  });

  const { handleSubmit } = useFormik<UnsubscribeCustomers>({
    initialValues: initialUnsubscribeValue,
    enableReinitialize: true,
    onSubmit: (values) => {
      values.customers = customerIDs;
      mutate({ ...values, list: selectedList?.length > 0 ? selectedList?.toString() : '' });
    },
  });

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        onClose();
        setSelectedList([]);
      }}
      isCentered
      closeOnEsc={false}
      closeOnOverlayClick={false}>
      <ModalOverlay />
      <ModalContent maxW='540px'>
        <form onSubmit={handleSubmit}>
          <ModalHeader color='black' fontSize='16px' fontWeight={'bold'} lineHeight='32px'>
            Unsubscribe Selected Contact(s)
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody pt='0'>
            {customerIDs?.split(',')?.length > 1 ? (
              <Text my='2'>Are you sure you want to unsubscribe the selected contact(s)?</Text>
            ) : (
              <>
                <Flex justifyContent='space-between' mb='1px' px='2px'>
                  <Link onClick={() => setSelectedList(lists?.map((item: any) => item?.id))}>
                    Select All
                  </Link>
                  <Link onClick={() => setSelectedList([])}>Deselect All</Link>
                </Flex>
              </>
            )}
            {customerIDs?.split(',')?.length === 1 && (
              <>
                <ListBox>
                  {lists &&
                    lists?.map(({ id, title }) => (
                      <Badge
                        m='1'
                        key={id}
                        variant={
                          selectedList?.find((selectedID: any) => selectedID == id)
                            ? 'solid'
                            : 'warning'
                        }
                        colorScheme={
                          selectedList?.find((selectedID: any) => selectedID == id) ? 'orange' : ''
                        }
                        fontSize='12px'
                        fontWeight='600'
                        textTransform='capitalize'
                        cursor='pointer'
                        onClick={() =>
                          setSelectedList(
                            selectedList?.find((selectedID: any) => selectedID == id)
                              ? selectedList?.filter((filtredId: any) => filtredId !== id)
                              : selectedList?.length === 0
                              ? [id]
                              : [...selectedList, id],
                          )
                        }>
                        {title}
                      </Badge>
                    ))}
                </ListBox>
                <Note mt='2' mb='0' py='0'>
                  <Image src={InfoIcon} alt='Info' mt='4px' />
                  <NoteText>
                    Select a list to unsubscribe from. The contact will not receive further emails
                    sent to the selected lists.
                  </NoteText>
                </Note>
              </>
            )}
          </ModalBody>
          <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
            <Button
              isDisabled={
                selectedList?.length === 0 && customerIDs?.split(',')?.length < 2 ? true : false
              }
              type='submit'
              variant={
                selectedList?.length === 0 && customerIDs?.split(',')?.length < 2
                  ? 'default'
                  : 'solid'
              }
              colorScheme='red'
              mr='8px'
              isLoading={isLoading}>
              Unsubscribe
            </Button>
            <Button
              onClick={() => {
                onClose();
                setSelectedList([]);
              }}
              isDisabled={isLoading}>
              Cancel
            </Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default UnsubscribeSelectedContactsModal;
