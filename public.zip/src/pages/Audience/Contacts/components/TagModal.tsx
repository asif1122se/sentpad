import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Select,
  Stack,
} from '@chakra-ui/react';
import React from 'react';

const TagModal = ({ openTag, setOpenTag }: any) => {
  return (
    <Modal isOpen={openTag} onClose={() => setOpenTag(false)}>
      <ModalOverlay />
      <ModalContent maxW='540px'>
        <ModalHeader color='black' fontSize='18px' fontWeight='bold'>
          Add Tag to Contact
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <Stack gap='1rem' mb='5'>
            <Select size='md' placeholder='Select Tag'>
              <option value='4'></option>
            </Select>
          </Stack>
        </ModalBody>
        <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
          <Button variant='success' mr='8px'>
            Add
          </Button>
          <Button onClick={() => setOpenTag(false)}>Cancel</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default TagModal;
