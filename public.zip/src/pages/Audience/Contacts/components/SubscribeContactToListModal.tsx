import {
  Button,
  Center,
  Flex,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Spinner,
  Text,
  Image,
} from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { Select } from 'components';
import { useFormik } from 'formik';
import { useMutation } from 'hooks/useMutation';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { ContactLists, SubscribeContactsToList } from '../types';
import AlertIcon from 'assets/icons/alert.svg';

type SubscribeContactToListProps = {
  isOpen: boolean;
  onClose: () => void;
  customerIDs: number[];
  resetSelectedRows?: () => void;
  isDetails?: boolean;
};

export const initialSubscribeValue = {
  customer_ids: '',
  list_id: 0,
};

const SubscribeContactToListModal = ({
  isOpen,
  onClose,
  customerIDs,
  resetSelectedRows,
  isDetails,
}: SubscribeContactToListProps) => {
  const queryClient = useQueryClient();

  const {
    data: contactList,
    isLoading: isListLoading,
    isFetching: isListFetching,
  } = useQuery<ContactLists>({
    queryKey: [QUERY_KEYS.CONTACTS_LISTS_BY_ID, customerIDs],
    url: customerIDs.length === 1 ? `getContactLists/${customerIDs}` : 'getContactLists',
    enabled: isDetails || isOpen,
  });

  const { isLoading: isSubscribeLoading, mutate } = useMutation<SubscribeContactsToList>({
    url: 'subscribe-customers',
    onSuccess: () => {
      onClose();
      resetSelectedRows && resetSelectedRows();
      queryClient.invalidateQueries([QUERY_KEYS.CONTACTS]);
      queryClient.invalidateQueries([QUERY_KEYS.CONTACT]);
    },
    successMessage: `Contact${customerIDs.length > 1 ? '(s)' : ''} subscribed to list successfully`,
  });

  const { handleSubmit, handleChange, handleReset, values } = useFormik<SubscribeContactsToList>({
    initialValues: !contactList
      ? initialSubscribeValue
      : { ...initialSubscribeValue, list_id: contactList[0]?.id },
    enableReinitialize: true,
    onSubmit: ({ list_id }) => {
      mutate({
        customer_ids: customerIDs.toString(),
        list_id,
      });
    },
  });

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        onClose();
        handleReset(null);
      }}
      closeOnEsc={false}
      isCentered
      closeOnOverlayClick={false}>
      <ModalOverlay />
      <ModalContent maxW='540px'>
        <form onSubmit={handleSubmit}>
          <ModalHeader color='black' fontSize='18px' fontWeight='bold' lineHeight='32px'>
            Subscribe Contact(s) to List
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            {isListLoading || isListFetching ? (
              <Center mt='8px'>
                <Spinner />
              </Center>
            ) : (
              <>
                {contactList?.length === 0 ? (
                  <Flex alignItems='center'>
                    <Image src={AlertIcon} alt='Alert' height='50px' width='50px' />
                    <Text ml='1rem'>This contact is subscribed to all available lists.</Text>
                  </Flex>
                ) : (
                  <Select
                    my='2'
                    name='list_id'
                    size='md'
                    label='Select List'
                    value={values.list_id}
                    onChange={handleChange}>
                    {contactList?.map(({ id, title }) => (
                      <option key={id} value={id}>
                        {title.length > 50 ? `${title.substring(0, 50)}...` : title}
                      </option>
                    ))}
                  </Select>
                )}
              </>
            )}
          </ModalBody>
          <ModalFooter justifyContent='flex-start' p='16px 24px 24px'>
            {!isListLoading && !isListFetching && (
              <>
                {contactList?.length === 0 ? (
                  <Button
                    type='submit'
                    variant='black'
                    width='80px'
                    onClick={(e) => {
                      onClose();
                      handleReset(e);
                    }}>
                    OK
                  </Button>
                ) : (
                  <>
                    <Button
                      type='submit'
                      variant='success'
                      mr='8px'
                      isDisabled={isSubscribeLoading}
                      isLoading={isSubscribeLoading}>
                      Add
                    </Button>
                    <Button
                      onClick={(e) => {
                        onClose();
                        handleReset(e);
                      }}
                      isDisabled={isSubscribeLoading}>
                      Cancel
                    </Button>
                  </>
                )}
              </>
            )}
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};

export default SubscribeContactToListModal;
