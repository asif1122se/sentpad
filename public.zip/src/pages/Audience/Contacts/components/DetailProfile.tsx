import { Box, Button, Flex, Stack, Text } from '@chakra-ui/react';
import { useQueryClient } from '@tanstack/react-query';
import { DetailLabelValue, InputField, Select } from 'components';
import { useFormik } from 'formik';
import { useMutation } from 'hooks/useMutation';
import { useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import countryList from 'react-select-country-list';
import { ROUTE_PATHS } from 'router';
import { INITIAL_CONTACT_VALUES } from 'utils/constants';
import QUERY_KEYS from 'utils/queryKeys';
import { contactSchema } from '../schema';
import { ProfileContainer, ProfileHeader } from '../styles';
import { Contact, ContactForm, EditContact } from '../types';

type DetailProfileProps = {
  details?: Contact;
};

const DetailProfile = ({ details }: DetailProfileProps) => {
  const { edit } = useParams();
  const navigate = useNavigate();

  const queryClient = useQueryClient();

  const { handleSubmit, handleChange, handleBlur, handleReset, values, errors, touched, dirty } =
    useFormik<ContactForm>({
      initialValues: details ? details : INITIAL_CONTACT_VALUES,
      validationSchema: contactSchema,
      enableReinitialize: true,
      onSubmit: (values) =>
        mutate({
          first_name: values.first_name,
          last_name: values.last_name,
          phone_no: values.phone_no,
          country: values.country,
          address_one: values.address_one,
          address_two: values.address_two,
          city: values.city,
          state: values.state,
          zip_code: values.zip_code,
        }),
    });

  const { isLoading, mutate } = useMutation<EditContact>({
    url: `add-customers/${details?.id}`,
    onSuccess: () => {
      handleReset(null);
      queryClient.invalidateQueries([QUERY_KEYS.CONTACT]);
      navigate(`/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.CONTACT_DETAILS}/${details?.id}`);
    },
  });

  const countries: Array<{ label: string; value: string }> = useMemo(
    () => countryList().getData(),
    [],
  );

  return (
    <ProfileContainer>
      <form onSubmit={handleSubmit}>
        {/* PROFILE HEADER */}
        <Box width='100%' borderBottom='1px solid' borderColor='gray.400'>
          <ProfileHeader>
            <Flex ml='4' alignItems='center'>
              <Box alignItems='center'>
                <Text fontSize='18px' lineHeight='22px' fontWeight='bold'>
                  {details?.first_name} {details?.last_name}
                </Text>
                <Text fontSize='14px' lineHeight='22px'>
                  {details?.email}
                </Text>
                <Text fontSize='14px' lineHeight='22px' mt='1'>
                  {details?.phone_no}
                </Text>
              </Box>
            </Flex>
            <Flex gap='2'>
              {!!!edit ? (
                <Button
                  height='36px'
                  variant='infoOutlined'
                  onClick={() =>
                    navigate(
                      `/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.CONTACT_DETAILS}/${details?.id}/edit`,
                    )
                  }>
                  Edit Profile
                </Button>
              ) : (
                <>
                  <Button
                    height='36px'
                    variant='infoOutlined'
                    onClick={(e) => {
                      handleReset(e);
                      navigate(
                        `/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.CONTACT_DETAILS}/${details?.id}`,
                      );
                    }}>
                    Cancel
                  </Button>
                  <Button
                    type='submit'
                    height='36px'
                    variant='info'
                    isDisabled={!dirty}
                    isLoading={isLoading}>
                    Save
                  </Button>
                </>
              )}
            </Flex>
          </ProfileHeader>
        </Box>

        {/* PERSONAL DETAILS */}
        <Box width='100%' p='4'>
          <Box m='4' mt='4'>
            <Text fontSize='16px' fontWeight='bold' lineHeight='20px'>
              Personal Details
            </Text>
            <Stack mt='5' gap='5'>
              <Flex gap='1rem'>
                {edit ? (
                  <InputField
                    name='first_name'
                    width='50%'
                    label='First Name'
                    placeholder='Enter First Name'
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.first_name}
                    maxLength={75}
                    errorText={
                      touched['first_name'] && errors['first_name']
                        ? errors['first_name']
                        : undefined
                    }
                  />
                ) : (
                  <DetailLabelValue
                    name='first_name'
                    width='50%'
                    label='First Name'
                    value={details?.first_name}
                  />
                )}
                {edit ? (
                  <InputField
                    name='last_name'
                    width='50%'
                    label='Last Name'
                    placeholder='Enter Last Name'
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.last_name}
                    maxLength={75}
                    errorText={
                      touched['last_name'] && errors['last_name'] ? errors['last_name'] : undefined
                    }
                  />
                ) : (
                  <DetailLabelValue
                    name='last_name'
                    width='50%'
                    label='Last Name'
                    value={details?.last_name}
                  />
                )}
              </Flex>
              {edit ? (
                <InputField
                  name='phone_no'
                  label='Phone'
                  placeholder='Enter Phone Number'
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.phone_no}
                  errorText={
                    touched['phone_no'] && errors['phone_no'] ? errors['phone_no'] : undefined
                  }
                  maxLength={25}
                />
              ) : (
                <DetailLabelValue name='phone_no' label='Phone' value={details?.phone_no} />
              )}
              {edit ? (
                <InputField
                  name='address_one'
                  label='Address 1'
                  placeholder='Enter Address 1'
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.address_one}
                  maxLength={100}
                />
              ) : (
                <DetailLabelValue
                  name='address_one'
                  label='Address 1'
                  value={details?.address_one}
                />
              )}
              {edit ? (
                <InputField
                  name='address_two'
                  label='Address 2'
                  placeholder='Enter Address 2'
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.address_two}
                  maxLength={100}
                />
              ) : (
                <DetailLabelValue
                  name='address_two'
                  label='Address 2'
                  value={details?.address_two}
                />
              )}
              <Flex gap='4'>
                {edit ? (
                  <InputField
                    name='city'
                    label='City'
                    placeholder='Enter City'
                    width='40%'
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.city}
                    maxLength={50}
                  />
                ) : (
                  <DetailLabelValue name='city' width='40%' label='City' value={details?.city} />
                )}
                {edit ? (
                  <InputField
                    name='state'
                    label='State'
                    placeholder='Enter State'
                    width='40%'
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.state}
                    maxLength={50}
                  />
                ) : (
                  <DetailLabelValue name='state' width='40%' label='State' value={details?.state} />
                )}
                {edit ? (
                  <InputField
                    name='zip_code'
                    label='Zip'
                    width='20%'
                    placeholder='Enter Zip'
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.zip_code}
                    maxLength={10}
                  />
                ) : (
                  <DetailLabelValue
                    name='zip_code'
                    width='20%'
                    label='Zip'
                    value={details?.zip_code}
                  />
                )}
              </Flex>
              <>
                {edit ? (
                  <Select
                    name='country'
                    label='Country'
                    value={values.country}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    color={!values.country ? 'gray.500' : 'gray.800'}>
                    <option value=''>Select country</option>
                    {countries.map(({ label, value }) => (
                      <option key={value} value={label}>
                        {label}
                      </option>
                    ))}
                  </Select>
                ) : (
                  <DetailLabelValue name='country' label='Country' value={details?.country} />
                )}
              </>
            </Stack>
          </Box>
        </Box>
      </form>
    </ProfileContainer>
  );
};

export default DetailProfile;
