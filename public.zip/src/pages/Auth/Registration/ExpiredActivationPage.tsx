import { Flex, Heading, Image, Link, Text } from '@chakra-ui/react';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import EmailSentIllustration from 'assets/images/email-sent-illustration.svg';
import Reload from 'assets/icons/reload.png';

const ExpiredActivationPage = () => {
  return (
    <Flex>
      <Flex
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={EmailSentIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex justifyContent='center' alignItems='center' width='calc(100% - 700px)'>
        <Flex flexDirection='column'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='1rem' whiteSpace='pre-line'>
            Your activation link has expired
          </Heading>
          <Flex flexDirection='column' gap='1rem'>
            <Text fontSize='sm' whiteSpace='pre-line'>
              {`The link you are trying to access has already expired. Please resend \nanother activation link.`}
            </Text>
            <Link color='blue.700' fontWeight='semibold'>
              <Flex gap='2' alignItems='center'>
                <Image src={Reload} boxSize='20px' display='inline' />
                Resend Link
              </Flex>
            </Link>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default ExpiredActivationPage;
