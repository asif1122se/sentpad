import {
  Box,
  Button,
  Flex,
  Heading,
  Image,
  Text,
  Link,
  chakra,
  Tooltip,
  Spinner,
} from '@chakra-ui/react';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import SignupIllustration from 'assets/images/signup-illustration.svg';
import { useFormik } from 'formik';
import { InputField } from 'components';
import { Check, Cross, Links, PasswordTip } from './styles';
import { useNavigate } from 'react-router-dom';
import { ROUTE_PATHS } from 'router';
import { signUpSchema } from './schema';
import { POST } from 'utils/constants';
import { useMutation } from 'hooks/useMutation';
import { UserSignup } from './types';
import { useState } from 'react';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { IsSubscribed } from 'components/Layout/types';

const SignUpPage = () => {
  const navigate = useNavigate();

  const { handleSubmit, handleChange, values, errors, touched } = useFormik<UserSignup>({
    initialValues: { email: '', password: '', coupon_code: '' },
    validationSchema: signUpSchema,
    enableReinitialize: true,
    onSubmit: (values) =>
      mutate({
        email: values.email,
        password: values.password,
        coupon_code: values.coupon_code.toUpperCase(),
      }),
  });
  const { data } = useQuery<IsSubscribed>({
    url: 'plans/current-plan',
    queryKey: [QUERY_KEYS.IS_SUBSCRIBED],
    enabled: localStorage.getItem('jwtToken') ? true : false,
    showToast: false,
    onSuccess: (data) => {
      if (data?.email_verified && data?.exists) {
        navigate('/');
      }
    },
  });

  const { isLoading, mutate } = useMutation<UserSignup>({
    method: POST,
    url: 'register',
    onSuccess: (data) => {
      localStorage.setItem('jwtToken', `${data?.records?.auth_token}`);
      localStorage.setItem('email', `${data?.records?.email}`);
      navigate(`${ROUTE_PATHS.EMAIL_SENT}?email=${data?.records?.email}`);
    },
  });

  const validatePassFormat = () => {
    return (
      !values.coupon_code ||
      !/[a-z]/.test(values?.password) ||
      !/[A-Z]/.test(values?.password) ||
      values?.password?.length < 8 ||
      !/\d/.test(values?.password) ||
      !/[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/.test(values?.password)
    );
  };

  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        display={{ sm: 'none', md: 'flex' }}
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={SignupIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex
        justifyContent='center'
        alignItems='center'
        width={{ sm: '100%', md: 'calc(100% - 700px)' }}>
        <Flex flexDirection='column' gap='0.5rem'>
          <Heading as='h1' size='h3' fontWeight='bold'>
            Sign up
          </Heading>
          <form onSubmit={handleSubmit}>
            <Box w={{ sm: '300px', md: '400px' }}>
              <Flex direction='column' gap='0.5rem'>
                <Box mb='0.5rem'>
                  <InputField
                    label='Email *'
                    size='md'
                    type='email'
                    placeholder='Enter your email'
                    name='email'
                    errorText={touched['email'] && errors['email'] ? `${errors['email']}` : ''}
                    value={values.email}
                    onChange={handleChange}
                  />
                </Box>
                <Box mb='0.5rem'>
                  <InputField
                    label='Password *'
                    type='password'
                    placeholder='********'
                    size='md'
                    name='password'
                    errorText={''}
                    value={values.password}
                    onChange={handleChange}
                  />
                  <>
                    <PasswordTip>
                      <Text className='header'>Your password must contain:</Text>
                      <Flex>
                        <Box>{values?.password?.length >= 8 ? <Check /> : <Cross />}</Box>
                        <Text>Minimum 8 characters</Text>
                      </Flex>
                      <Flex>
                        <Box>{/[A-Z]/.test(values?.password) ? <Check /> : <Cross />}</Box>
                        <Text>At least 1 upper case</Text>
                      </Flex>
                      <Flex>
                        <Box>{/[a-z]/.test(values?.password) ? <Check /> : <Cross />}</Box>
                        <Text>At least 1 lower case</Text>
                      </Flex>
                      <Flex>
                        <Box>{/\d/.test(values?.password) ? <Check /> : <Cross />}</Box>
                        <Text>At least 1 number</Text>
                      </Flex>
                      <Flex>
                        <Box>
                          {/[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/.test(values?.password) ? (
                            <Check />
                          ) : (
                            <Cross />
                          )}
                        </Box>
                        <Text>At least 1 special character</Text>
                      </Flex>
                    </PasswordTip>
                  </>
                </Box>
                <Box mb='0.5rem'>
                  <InputField
                    label='Confirm Password *'
                    size='md'
                    type='password'
                    placeholder='********'
                    name='confirm_pass'
                    errorText={
                      touched['confirm_pass'] && errors['confirm_pass']
                        ? `${errors['confirm_pass']}`
                        : ''
                    }
                    value={values.confirm_pass}
                    onChange={handleChange}
                  />
                </Box>
                <Box mb='0.5rem'>
                  <InputField
                    label='Coupon Code *'
                    type='text'
                    size='md'
                    placeholder='Enter coupon code'
                    name='coupon_code'
                    errorText={''}
                    onChange={handleChange}
                    minLength={6}
                    maxLength={12}
                    value={values.coupon_code.toUpperCase()}
                  />
                </Box>

                <Text fontSize='sm'>
                  By creating an account, you agree to our{' '}
                  <Links
                    onClick={() =>
                      window.open('https://sendpad.com/index.php/terms-of-use/', '_blank')
                    }>
                    {' '}
                    Terms
                  </Links>{' '}
                  and have read and acknowledge the{' '}
                  <Links
                    onClick={() =>
                      window.open('https://sendpad.com/index.php/privacy-policy/', '_blank')
                    }>
                    Privacy Statement
                  </Links>
                  .
                </Text>

                <Button
                  variant='primary'
                  type='submit'
                  size='lg'
                  mt='1rem'
                  isLoading={isLoading}
                  isDisabled={
                    !values.email ||
                    !values.password ||
                    !values.confirm_pass ||
                    !values.coupon_code ||
                    validatePassFormat()
                  }>
                  Register
                </Button>
              </Flex>
            </Box>
          </form>
          <Flex flexDirection='column' alignItems='center' mt='1rem' gap='0.5rem'>
            <Text lineHeight='20px'>{'Already have an account?'}</Text>
            <Link
              color='blue.700'
              fontWeight='semibold'
              onClick={() => navigate(ROUTE_PATHS.SIGNIN)}>
              Sign in
            </Link>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default SignUpPage;
