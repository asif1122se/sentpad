import { Box, chakra, Flex, Text } from '@chakra-ui/react';
import styled from '@emotion/styled';
import { CheckIcon, SmallCloseIcon } from '@chakra-ui/icons';

export const PasswordTip = styled(Box)`
  margin-top: 5px;
  font-size: var(--chakra-fontSizes-sm);
  & div {
    margin-left: 3px;
  }
  & p {
    line-height: 22px;
    padding-left: 8px;
    font-size: 12px;
  }

  & .header {
    padding-left: 0px;
    padding-top: 3px;
    margin-bottom: 4px;
    font-weight: bold;
  }
`;

export const Cross = styled(SmallCloseIcon)({
  margin: '0',
  width: '16px',
  height: '16px',
  color: 'var(--chakra-colors-red-700)',
  cursor: 'pointer',
});

export const Check = styled(CheckIcon)({
  margin: '0 2px',
  width: '12px',
  height: '12px',
  color: 'var(--chakra-colors-green-500)',
  cursor: 'normal',
});

export const Note = styled(Flex)`
  width: 98%;
  align-items: flex-start;
  border: 1px solid #00bf9c;
  border-radius: 4px;
  padding: 18px;
  background: #eefdfa 0% 0% no-repeat padding-box;
`;

export const NoteText = styled(Text)`
  font-size: 14px;
  line-height: 20px;
  margin-left: 1rem;
  color: #009679;
  white-space: pre-line;
`;

export const Links = styled(chakra.span)`
  cursor: pointer;
  color: var(--chakra-colors-blue-700);
  font-weight: 500;
`;
