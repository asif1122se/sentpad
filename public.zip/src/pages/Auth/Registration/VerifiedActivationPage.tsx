import { Button, Flex, Heading, Image, Link, Text } from '@chakra-ui/react';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import EmailSentIllustration from 'assets/images/email-sent-illustration.svg';
import Info from 'assets/icons/info-green.svg';
import { Note, NoteText } from './styles';
import { useNavigate } from 'react-router-dom';
import { ROUTE_PATHS } from 'router';

const VerifiedActivationPage = () => {
  const navigate = useNavigate();
  return (
    <Flex>
      <Flex
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={EmailSentIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex justifyContent='center' alignItems='center' width='calc(100% - 700px)'>
        <Flex flexDirection='column' width='480px'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='1rem' whiteSpace='pre-line'>
            {'You have already activated \n your account.'}
          </Heading>
          <Flex flexDirection='column' gap='1rem'>
            <Note>
              <Image src={Info} boxSize='24px' mt='4px' />
              <NoteText>
                {`We have identified that your account is already active. \nYou can now log in using your email and password.`}
              </NoteText>
            </Note>
            <Link color='blue.700' fontWeight='semibold'>
              <Button
                variant='success'
                type='submit'
                mt='1rem'
                onClick={() => navigate(ROUTE_PATHS.SIGNIN)}>
                Go Back to Login
              </Button>
            </Link>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default VerifiedActivationPage;
