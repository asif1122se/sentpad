import { useState, useEffect } from 'react';
import { chakra, Flex, Heading, Image, Link, Spinner, Text } from '@chakra-ui/react';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import EmailSentIllustration from 'assets/images/email-sent-illustration.svg';
import Info from 'assets/icons/info-green.svg';
import Reload from 'assets/icons/reload.png';
import { Note, NoteText } from './styles';
import { useMutation } from 'hooks/useMutation';
import { POST } from 'utils/constants';

const EmailSentPage = () => {
  const [showCounter, setShowCounter] = useState<boolean>(false);
  const [showTimer, setShowTimer] = useState<boolean>(false);

  const { isLoading, mutate } = useMutation({
    method: POST,
    url: 'email/resend-email',
  });

  const resendLink = () => {
    mutate({});
    setShowTimer(true);
    setTimeout(() => {
      setShowTimer(false);
    }, 10000);
  };

  return (
    <Flex>
      <Flex
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={EmailSentIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex justifyContent='center' alignItems='center' width='calc(100% - 700px)'>
        <Flex flexDirection='column'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='1rem' whiteSpace='pre-line'>
            {'All Done! \nPlease check your email'}
          </Heading>
          <Flex flexDirection='column' gap='1rem'>
            <Note>
              {/* <InfoOutlineIcon color='#00bf9c' boxSize='24px' mt='4px' /> */}
              <Image src={Info} boxSize='24px' mt='4px' />
              <NoteText>
                {`We've sent an email to `}
                <chakra.span fontWeight='bold'>
                  {window.location.search.split('?email=')[1]}
                </chakra.span>
                {` \n with a link to activate your account.`}
              </NoteText>
            </Note>
            <Text fontSize='sm'>
              If the email is not in your inbox, please check your spam folder.
            </Text>
            <Link
              color='blue.700'
              fontWeight='semibold'
              style={{ pointerEvents: showTimer ? 'none' : 'auto' }}>
              <Flex gap='2' alignItems='center' onClick={() => !showTimer && resendLink()}>
                <Image src={Reload} boxSize='20px' display='inline' />
                Resend Link{showTimer && <Spinner>please wait</Spinner>}
              </Flex>
            </Link>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default EmailSentPage;
