export type UserSignup = {
  email: string;
  password: string;
  confirm_pass?: string;
  auth_token?: string;
  coupon_code: string;
};

export type accountSetup = {
  first_name: string;
  last_name: string;
  business_name: string;
  company_website: string;
  phone_no: string;
  auth_token: string | null;
};
