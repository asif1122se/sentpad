import { useState, useEffect } from 'react';
import { Box, Button, Flex, getToken, Heading, Image, Text } from '@chakra-ui/react';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import ProfileIllustration from 'assets/images/profile-illustration.svg';
import { Field, Form, Formik } from 'formik';
import { accountSettupSchema } from './schema';
import { InputField } from 'components';
import { useMutation } from 'hooks/useMutation';
import { POST } from 'utils/constants';
import { ROUTE_PATHS } from 'router';
import { useNavigate } from 'react-router-dom';
import { accountSetup } from './types';

const AccountInfoSetupPage = () => {
  const navigate = useNavigate();
  const { isLoading, mutate: accountSetup } = useMutation<accountSetup>({
    method: POST,
    url: 'account-setup',
    onSuccess: () => {
      navigate(ROUTE_PATHS.SIGNIN);
    },
  });

  const getToken = () => {
    const token = window.location.search.split('?authtoken=')[1];
    localStorage.setItem('jwtToken', token);
    localStorage.setItem('authToken', token);
  };

  useEffect(() => {
    getToken();
  }, []);

  return (
    <Flex>
      <Flex
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={ProfileIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex justifyContent='center' alignItems='center' width='calc(100% - 700px)'>
        <Flex flexDirection='column'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='1rem' whiteSpace='pre-line'>
            {`Let's set up your account`}
          </Heading>
          <Formik
            initialValues={{
              first_name: '',
              last_name: '',
              business_name: '',
              company_website: '',
              phone_no: '',
            }}
            validationSchema={accountSettupSchema}
            onSubmit={(values) =>
              accountSetup({ ...values, auth_token: localStorage.getItem('authToken') })
            }>
            {({ errors, touched, values }) => (
              <Form>
                <Flex flexDirection='column' gap='0.5rem' width='80%'>
                  <Flex gap='1rem'>
                    <Box mb='1rem'>
                      <Field
                        as={InputField}
                        label='First Name *'
                        type='text'
                        placeholder='Enter first name'
                        name='first_name'
                        errorText={''}
                      />
                    </Box>
                    <Box mb='1rem'>
                      <Field
                        as={InputField}
                        label='Last Name *'
                        type='text'
                        placeholder='Enter last name'
                        name='last_name'
                        errorText={''}
                      />
                    </Box>
                  </Flex>
                  <Box mb='1rem'>
                    <Field
                      as={InputField}
                      label='Business Name *'
                      type='text'
                      placeholder='Enter business name'
                      name='business_name'
                      errorText={''}
                    />
                    <Text fontSize='sm' color='gray.600' mt='1'>
                      You can always change this later in your Account Settings.
                    </Text>
                  </Box>
                  <Box mb='1rem'>
                    <Field
                      as={InputField}
                      label='Company Website (Optional)'
                      type='text'
                      placeholder='Enter URL'
                      name='company_website'
                      errorText={
                        touched['company_website'] && errors['company_website']
                          ? `${errors['company_website']}`
                          : ''
                      }
                    />
                  </Box>
                  <Box mb='1rem'>
                    <Field
                      as={InputField}
                      label='Phone (Optional)'
                      type='text'
                      placeholder='Enter your contact number'
                      name='phone_no'
                      errorText={
                        touched['phone_no'] && errors['phone_no'] ? `${errors['phone_no']}` : ''
                      }
                    />
                  </Box>
                  <Button
                    isDisabled={!values?.first_name || !values?.last_name || !values?.business_name}
                    variant='primary'
                    type='submit'
                    size='lg'
                    mt='1rem'>
                    Continue
                  </Button>
                </Flex>
              </Form>
            )}
          </Formik>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default AccountInfoSetupPage;
