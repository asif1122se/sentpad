import { Box, Button, Divider, Flex, Heading, Image, Text, FormControl } from '@chakra-ui/react';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import PaymentIllustration from 'assets/images/payment-illustration.svg';
import CreditCard from 'assets/icons/credit-card.svg';
import Stripe from 'assets/icons/stripe.png';
import { InputField, Select } from 'components';
import { Field, Form, Formik } from 'formik';
import CardIcon from 'assets/icons/card-small.png';
import CalendarIcon from 'assets/icons/calendar-small.png';
import InfoIcon from 'assets/icons/info-square-small.png';
import { useMemo } from 'react';
import countryList from 'react-select-country-list';
import { useMutation } from 'hooks/useMutation';
import { POST } from 'utils/constants';
import { ROUTE_PATHS } from 'router';
import { useNavigate } from 'react-router-dom';

const PaymentPage = () => {
  const countries: Array<{ label: string; value: string }> = useMemo(
    () => countryList().getData(),
    [],
  );

  const urlParams = window.location.search.split('&');
  const navigate = useNavigate();
  const { isLoading, mutate: accountSetup } = useMutation<any>({
    method: POST,
    url: 'plans/save-plan',
    onSuccess: () => {
      navigate(ROUTE_PATHS.SIGNIN);
    },
  });
  const newDate = new Date();
  const currentMonth = newDate.getMonth() + 1;
  const year = newDate.getFullYear();
  const currentYear = Number(String(year).slice(-2));

  const isValidated = (values: any) => {
    const format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\?~]/;
    return (
      !values?.first_name ||
      !values?.last_name ||
      values?.exp_month?.length !== 5 ||
      values?.number?.length !== 16 ||
      values?.cvv?.length < 3
      // ||
      // Number(String(values?.exp_month).slice(-2)) < currentYear ||
      // (currentYear == Number(String(values?.exp_month).slice(-2)) &&
      //   Number(String(values?.exp_month).slice(0, 2)) < currentMonth) ||
      // Number(String(values?.exp_month).slice(0, 2)) > currentMonth ||
      // format.test(values?.exp_month) ||
      // /[a-z]/.test(values?.exp_month) ||
      // /[A-Z]/.test(values?.exp_month)
    );
  };
  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        width='600px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={PaymentIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex justifyContent='center' alignItems='center' width='calc(100% - 600px)' m='0' px='4rem'>
        <Formik
          initialValues={{
            first_name: '',
            last_name: '',
            phone_no: '',
            country: '',
            city: '',
            state: '',
            zip_code: '',
            address: '',
            number: '',
            holder_name: '',
            cvv: '',
            exp_month: '',
            exp_year: '',
          }}
          onSubmit={(values) => {
            accountSetup({
              ...values,
              auth_token: localStorage.getItem('authToken'),
              plan_id: urlParams[1]?.split('id=')[1],
              plan_type: urlParams[0]?.split('?type=')[1],
              exp_month: Number(String(values?.exp_month).slice(0, 2)),
              exp_year: Number(String(values?.exp_month).slice(-2)),
            });
          }}>
          {({ errors, touched, values }) => (
            <Form>
              <Box mb='1rem'>
                <Text fontWeight='bold' fontSize='28px'>
                  Billing Information
                </Text>
                <Text fontSize='sm' color='gray.700'>
                  Setup your billing information to proceed.
                </Text>
              </Box>
              <Flex gap='4rem' width='100%'>
                <Flex flexDirection='column' gap='1rem' width='50%'>
                  <Flex gap='1rem' mb='0.5rem'>
                    <Field
                      as={InputField}
                      label='First Name *'
                      type='text'
                      placeholder='Enter first name'
                      name='first_name'
                      errorText={''}
                      size='md'
                    />
                    <Field
                      as={InputField}
                      label='Last Name *'
                      type='text'
                      placeholder='Enter last name'
                      name='last_name'
                      errorText={''}
                      size='md'
                    />
                  </Flex>
                  <Box mb='1rem'>
                    <Field
                      as={InputField}
                      label='Phone'
                      type='text'
                      placeholder='Enter your contact number'
                      name='phone_no'
                      size='md'
                    />
                  </Box>
                  <Box mb='1rem'>
                    <Field
                      as={InputField}
                      label='Address'
                      type='text'
                      placeholder='Enter address'
                      name='address'
                      size='md'
                    />
                  </Box>
                  <Flex gap='1rem' mb='1rem'>
                    <Field
                      as={InputField}
                      label='City'
                      type='text'
                      placeholder='Enter city'
                      name='city'
                      size='md'
                    />
                    <Field
                      as={InputField}
                      label='Zip Code'
                      type='text'
                      placeholder='Enter zip code'
                      name='zip_code'
                      size='md'
                    />
                  </Flex>
                  <Flex gap='1rem' mb='1rem' width='100%'>
                    <Box width='50%'>
                      <Field
                        as={InputField}
                        label='State'
                        type='text'
                        placeholder='Enter state'
                        name='state'
                        size='md'
                      />
                    </Box>
                    <Box width='50%' color='black'>
                      <Field>
                        {({ field }: any) => (
                          <FormControl id='ingredientId'>
                            <Select
                              name='country'
                              onChange={field.onChange}
                              label='Country'
                              size='md'>
                              <option value=''>Select country</option>
                              {countries.map(({ label, value }) => (
                                <option key={value} value={label}>
                                  {label}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                        )}
                      </Field>
                    </Box>
                  </Flex>
                </Flex>
                <Flex flexDirection='column' gap='0.5rem' width='50%'>
                  <Text fontWeight='semibold' lineHeight='20px'>
                    Payment Details
                  </Text>
                  <Flex
                    flexDirection='column'
                    gap='0.5rem'
                    border='1px solid #929BA8'
                    borderRadius='6px'
                    p='4'>
                    <Flex justifyContent='space-between' lineHeight='16px'>
                      <Text fontWeight='500'>Standard Plan</Text>
                      <Text fontWeight='500'>
                        ${urlParams[2].split('plan=')[1]}/
                        {urlParams[0].split('?type=')[1] == 'monthly' ? 'mo' : 'yr'}
                      </Text>
                    </Flex>
                    <Flex justifyContent='space-between' lineHeight='16px'>
                      <Text fontWeight='500'>Tax</Text>
                      <Text fontWeight='500'>$0.00</Text>
                    </Flex>
                    <Divider />
                    <Flex justifyContent='space-between' lineHeight='15px'>
                      <Text fontWeight='bold'>Total</Text>
                      <Text fontWeight='bold'>${urlParams[2].split('plan=')[1]}</Text>
                    </Flex>
                  </Flex>
                  <Flex alignItems='center' gap='0.5rem' mt='0.8rem'>
                    <Image src={CreditCard} boxSize='32px' />
                    <Box>
                      <Text fontWeight='bold' lineHeight='16px' fontSize='sm'>
                        Credit Card
                      </Text>
                      <Text fontSize='12px' color='gray.700' lineHeight='14px'>
                        Pay via your credit card
                      </Text>
                    </Box>
                  </Flex>
                  <Box mt='0.9rem'>
                    <Field
                      as={InputField}
                      size='md'
                      label='Card Number *'
                      placeholder='0000 0000 0000 0000'
                      name='number'
                      maxLength='16'
                      icon={<Image src={CardIcon} alt='Card' />}
                    />
                  </Box>
                  <Box mt='1rem'>
                    <Field
                      as={InputField}
                      size='md'
                      label='Card Holder Name *'
                      placeholder='Enter card holder’s name'
                      name='holder_name'
                    />
                  </Box>
                  <Flex gap='1rem' mt='1rem'>
                    <Box width='65%'>
                      <Field
                        as={InputField}
                        size='md'
                        label='Expiry Date *'
                        placeholder='MM/YY'
                        name='exp_month'
                        maxLength='5'
                        icon={<Image src={CalendarIcon} alt='Calendar' />}
                      />
                    </Box>
                    <Box width='35%'>
                      <Field
                        as={InputField}
                        size='md'
                        label='CVV *'
                        type='text'
                        placeholder='000'
                        name='cvv'
                        maxLength='4'
                        icon={<Image src={InfoIcon} alt='Info' />}
                      />
                    </Box>
                  </Flex>
                  <Box>
                    <Flex gap='2' justifyContent='center' alignItems='center' my='3'>
                      <Text fontSize='12px'>Powered by</Text>
                      <Image src={Stripe} width='60px' />
                    </Flex>
                    <Button
                      isLoading={isLoading}
                      isDisabled={isValidated(values)}
                      width='100%'
                      variant='success'
                      type='submit'
                      mt='1'>
                      Continue
                    </Button>
                  </Box>
                </Flex>
              </Flex>
            </Form>
          )}
        </Formik>
      </Flex>
    </Flex>
  );
};

export default PaymentPage;
