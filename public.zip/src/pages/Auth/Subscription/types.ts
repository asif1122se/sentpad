import { mixed } from 'yup';

export type Tier = {
  subscribers: number;
  monthly: number;
  annual: string;
};

export type AllPlans = {
  annual: string;
  annual_plan_id: number;
  monthly: string;
  monthly_plan_id: number;
  subscribers: number;
};

type Plan = {
  cost: string;
  created_at: string;
  deleted_at: string;
  description: string;
  id: number;
  plan_type: string;
  stripe_plan_id: string;
  stripe_product_id: string;
  subscribers: number;
  title: string;
  updated_at: string;
};

export type GetAllPlans = {
  all_plan: AllPlans[];
  plan: Plan;
};

export type Tiers = Tier[];

export type addPlanType = {
  id: string;
  pkgType: string;
};
