import { Badge, Box, Button, Flex, Heading, Image, Text } from '@chakra-ui/react';
import { PlanContainer, PlanFooter } from './styles';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { AllPlans } from './types';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import SubscriptionIllustration from 'assets/images/subscription-illustration.svg';
import CheckBulletIcon from 'assets/icons/check-bullet.svg';

const formatter = Intl.NumberFormat('en-US');

const SubscriptionPromoPage = () => {
  const navigate = useNavigate();
  const [selectedTier, setSelectedTier] = useState<AllPlans>();

  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={SubscriptionIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading size='md' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex justifyContent='center' alignItems='center' width='calc(100% - 700px)' flexWrap='wrap'>
        <Flex flexDirection='column' width='606px' gap='2rem'>
          <Box>
            <Text fontSize='28px' fontWeight='bold' mb='0.5rem'>
              SendPad Special Offer
            </Text>
            <Text fontWeight='500' fontSize='16px' width='300px'>
              Get the introductory subscription tier with up to 1,000 subscribers for a discounted
              price.
            </Text>
          </Box>
          <Flex gap='2rem'>
            <PlanContainer borderColor='black'>
              <Box>
                <Text fontSize='20px' fontWeight='bold'>
                  Monthly
                </Text>
                <Text mt='-8px' fontSize='32px' fontWeight='bold'>
                  $29
                </Text>
                <Flex mt='28px' flexDirection='column' gap='8px'>
                  <Flex>
                    <Image src={CheckBulletIcon} mr='8px' />
                    <Text>1,000 Contacts</Text>
                  </Flex>
                  <Flex>
                    <Image src={CheckBulletIcon} mr='8px' />
                    <Text>Enterprise Support</Text>
                  </Flex>
                </Flex>
              </Box>
              <PlanFooter>
                <Button
                  variant='black'
                  width='100%'
                  onClick={() =>
                    navigate(
                      `/payment?type=monthly&id=${
                        selectedTier?.monthly_plan_id
                      }&plan=${formatter.format(parseFloat(selectedTier?.monthly ?? '0'))}`,
                    )
                  }>
                  {"Let's Try"}
                </Button>
              </PlanFooter>
            </PlanContainer>
            <PlanContainer borderColor='teal.700'>
              <Box>
                <Text fontSize='20px' fontWeight='bold'>
                  Annual
                </Text>
                <Text mt='-8px' fontSize='32px' fontWeight='bold'>
                  $290
                </Text>
                <Badge mt='8px' variant='success' textTransform='capitalize'>
                  2 Months Free
                </Badge>
                <Flex mt='24px' flexDirection='column' gap='8px'>
                  <Flex>
                    <Image src={CheckBulletIcon} mr='8px' />
                    <Text>Billed Annually</Text>
                  </Flex>
                  <Flex>
                    <Image src={CheckBulletIcon} mr='8px' />
                    <Text>12,000 Contacts</Text>
                  </Flex>
                  <Flex>
                    <Image src={CheckBulletIcon} mr='8px' />
                    <Text>Enterprise Support</Text>
                  </Flex>
                </Flex>
              </Box>
              <PlanFooter>
                <Button
                  variant='success'
                  width='100%'
                  onClick={() =>
                    navigate(
                      `/payment?type=yearly&id=${
                        selectedTier?.annual_plan_id
                      }&plan=${formatter.format(parseFloat(selectedTier?.annual ?? '0'))}`,
                    )
                  }>
                  {"Let's Try"}
                </Button>
              </PlanFooter>
            </PlanContainer>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default SubscriptionPromoPage;
