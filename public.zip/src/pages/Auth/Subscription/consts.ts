export const tiers = [
  {
    subscribers: 1e3,
    monthly: 50,
    annual: 500,
  },
  {
    subscribers: 5e3,
    monthly: 1e2,
    annual: 1e3,
  },
  {
    subscribers: 1e4,
    monthly: 250,
    annual: 2500,
  },
  {
    subscribers: 2e4,
    monthly: 325,
    annual: 3250,
  },
  {
    subscribers: 3e4,
    monthly: 400,
    annual: 4000,
  },
  {
    subscribers: 4e4,
    monthly: 475,
    annual: 4750,
  },
  {
    subscribers: 5e4,
    monthly: 550,
    annual: 5500,
  },
  {
    subscribers: 75e3,
    monthly: 750,
    annual: 7500,
  },
  {
    subscribers: 1e5,
    monthly: 1e3,
    annual: 1e4,
  },
  {
    subscribers: 15e4,
    monthly: 1500,
    annual: 15000,
  },
  {
    subscribers: 2e6,
    monthly: 2e3,
    annual: 2e4,
  },
  {
    subscribers: 25e4,
    monthly: 25e2,
    annual: 25e3,
  },
  {
    subscribers: 3e5,
    monthly: 3e3,
    annual: 3e4,
  },
  {
    subscribers: 35e4,
    monthly: 35e2,
    annual: 35e3,
  },
  {
    subscribers: 4e5,
    monthly: 4e3,
    annual: 4e4,
  },
  {
    subscribers: 45e4,
    monthly: 45e2,
    annual: 45e3,
  },
  {
    subscribers: 5e5,
    monthly: 5e3,
    annual: 5e4,
  },
  {
    subscribers: 6e5,
    monthly: 6e3,
    annual: 6e4,
  },
  {
    subscribers: 7e5,
    monthly: 7e3,
    annual: 7e4,
  },
  {
    subscribers: 8e5,
    monthly: 8e3,
    annual: 8e4,
  },
  {
    subscribers: 9e5,
    monthly: 9e3,
    annual: 9e4,
  },
  {
    subscribers: 1e6,
    monthly: 9750,
    annual: 97500,
  },
  {
    subscribers: 125e4,
    monthly: 12e3,
    annual: 12e4,
  },
  {
    subscribers: 15e5,
    monthly: 14250,
    annual: 142500,
  },
  {
    subscribers: 2e6,
    monthly: 18750,
    annual: 187500,
  },
  {
    subscribers: 25e5,
    monthly: 23250,
    annual: 232500,
  },
  {
    subscribers: 3e6,
    monthly: 27750,
    annual: 277500,
  },
  {
    subscribers: 4e6,
    monthly: 33250,
    annual: 332500,
  },
  {
    subscribers: 5e6,
    monthly: 38750,
    annual: 387500,
  },
  {
    subscribers: 6e6,
    monthly: 44250,
    annual: 442500,
  },
  {
    subscribers: 7e6,
    monthly: 49750,
    annual: 497500,
  },
  {
    subscribers: 8e6,
    monthly: 55250,
    annual: 552500,
  },
  {
    subscribers: 9e6,
    monthly: 60750,
    annual: 607500,
  },
  {
    subscribers: 1e7,
    monthly: 66250,
    annual: 662500,
  },
];
