import { Box, Flex } from '@chakra-ui/react';
import styled from '@emotion/styled';

export const PlanContainer = styled(Flex)`
  padding: 24px;
  border-radius: 12px;
  border-width: 1px;
  border-style: solid;
  box-shadow: 0px 10px 16px #11213c1a;
  flex-direction: column;
  justify-content: space-between;
`;

export const PlanFooter = styled(Box)`
  padding-top: 20px;
  border-top: 1px solid var(--chakra-colors-gray-400);
  margin-top: 40px;
`;
