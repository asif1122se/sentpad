import {
  Box,
  Flex,
  Heading,
  Slider,
  SliderFilledTrack,
  SliderMark,
  SliderThumb,
  SliderTrack,
  Text,
  Tooltip,
  Image,
  Button,
  Badge,
  Spinner,
  Center,
} from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import SubscriptionIllustration from 'assets/images/subscription-illustration.svg';
import CheckBulletIcon from 'assets/icons/check-bullet.svg';
import { MdGraphicEq } from 'react-icons/md';
import { GetAllPlans, AllPlans, addPlanType } from './types';
import { PlanContainer, PlanFooter } from './styles';
import { GetAllSubsPackages, AddPlan } from '../../../services/apis/subscription';

const formatter = Intl.NumberFormat('en-US');

const SubscriptionPage = () => {
  const [selectedTier, setSelectedTier] = useState<AllPlans>();
  const [data, setData] = useState<GetAllPlans>();
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [annualBtnLoading, setAnnualBtnLoading] = useState<boolean>(false);
  const [monthlyBtnLoading, setMonthlyBtnLoading] = useState<boolean>(false);

  const getToken = () => {
    const token = window.location.search.split('?authtoken=')[1];
    localStorage.setItem('jwtToken', token);
    localStorage.setItem('authToken', token);
  };

  useEffect(() => {
    getToken();
  }, [data]);

  const getClosestTierValue = (value: number) => {
    return data?.all_plan
      ?.map((tier: any, index: number) => index)
      ?.reduce((a: number, b: number) => (Math.abs(b - value) < Math.abs(a - value) ? b : a));
  };

  const handleSliderChange = (value: number) => {
    const closestTier = getClosestTierValue(value);

    const selected = data?.all_plan?.find((tier: any, index: number) => index === closestTier);
    setSelectedTier(selected);
  };

  const getAllSubsPackagesApi = async () => {
    try {
      setIsLoading(true);
      const resp = await GetAllSubsPackages();
      if (resp) {
        setSelectedTier(resp?.all_plan[0]);
        setData(resp);
        setIsLoading(false);
      }
    } catch (err) {
      console.log(err);
      setIsLoading(false);
    }
  };

  const addPlanApi = async (planType: addPlanType) => {
    try {
      planType?.pkgType === 'monthly' && setMonthlyBtnLoading(true);
      planType?.pkgType === 'annual' && setAnnualBtnLoading(true);
      const resp = await AddPlan(`${planType?.id}`);
      if (resp) {
        window.location = resp?.records?.url;
        planType?.pkgType === 'monthly' && setMonthlyBtnLoading(false);
        planType?.pkgType === 'annual' && setAnnualBtnLoading(false);
      }
    } catch (err) {
      console.log(err);
      planType?.pkgType === 'monthly' && setMonthlyBtnLoading(false);
      planType?.pkgType === 'annual' && setAnnualBtnLoading(false);
    }
  };

  useEffect(() => {
    getAllSubsPackagesApi();
  }, []);

  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        display={{ sm: 'none', md: 'flex' }}
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={SubscriptionIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex
        justifyContent='center'
        alignItems='center'
        width={{ sm: '300px', md: 'calc(100% - 700px)' }}>
        <Flex
          py='1rem'
          justifyContent='center'
          flexDirection='column'
          w={{ sm: '300px', md: '606px' }}>
          <Heading mb='20px' size='h3' as='h3' fontWeight='bold'>
            {/* Select a plan to continue */}
            SendPad Special Offer
          </Heading>
          <Box mb='40px'>
            <Text color='gray.800' fontSize='14px'>
              <li>Free Trial for 100 Days on all Tiers</li>
              <li>Pay 50% off on the first tier (up to 1,000 contacts)</li>
            </Text>
          </Box>

          {isLoading && (
            <Center>
              <Spinner w='200px' h='200px' />
            </Center>
          )}
          {!isLoading && (
            <Flex flexDirection='column' justifyContent='center'>
              <Box mt='3'>
                <Slider
                  defaultValue={0}
                  id='slider'
                  min={0}
                  max={data?.all_plan && data?.all_plan?.length - 1}
                  onChange={handleSliderChange}>
                  <SliderMark value={0} mt='4' ml='-2.0' fontSize='12px' color='gray.600'>
                    {data?.all_plan[0]?.subscribers ?? 0} Contacts
                  </SliderMark>
                  <SliderMark
                    value={data?.all_plan?.length ?? 0}
                    mt='4'
                    ml={data?.all_plan ? -137 : 0}
                    fontSize='12px'
                    color='gray.600'
                    whiteSpace='nowrap'>
                    {data?.all_plan[data?.all_plan?.length - 1]?.subscribers ?? 0} Contacts
                  </SliderMark>
                  <SliderTrack
                    height='10px'
                    borderRadius='100px'
                    boxShadow='inset 0px 1px 1px #B2B9C3'>
                    <SliderFilledTrack background='#635AC7' />
                  </SliderTrack>
                  <Tooltip
                    hasArrow
                    bg='gray.900'
                    color='white'
                    placement='top'
                    isOpen={true}
                    label={selectedTier?.subscribers ?? 0}
                    gutter={12}
                    fontSize='12px'
                    borderRadius='4px'>
                    <SliderThumb boxSize={6}>
                      <Box color='purple.700' as={MdGraphicEq} />
                    </SliderThumb>
                  </Tooltip>
                </Slider>
              </Box>
              <Flex gap='1rem' mt='48px' justifyContent='center' flexWrap='wrap' width='100%'>
                <PlanContainer borderColor='black' w={{ sm: '80%', md: '290px' }}>
                  <Box>
                    <Text fontSize='20px' fontWeight='bold'>
                      Monthly
                    </Text>
                    <Text
                      mt='-8px'
                      fontSize={selectedTier?.monthly == '59' ? '22px' : '32px'}
                      fontWeight='bold'
                      as={selectedTier?.monthly == '59' ? 's' : 'samp'}>
                      ${formatter.format(parseFloat(selectedTier?.monthly ?? '0'))}
                    </Text>
                    {selectedTier?.monthly == '59' && (
                      <Text mt='-8px' fontSize='32px' fontWeight='bold'>
                        $
                        {selectedTier?.monthly && !Number.isInteger(+selectedTier?.monthly / 2)
                          ? (+selectedTier?.monthly / 2).toFixed(2)
                          : selectedTier?.monthly && +selectedTier?.monthly / 2}
                      </Text>
                    )}
                    <Flex mt='24px' flexDirection='column' gap='8px'>
                      <Flex>
                        <Image src={CheckBulletIcon} mr='8px' />
                        <Text>{selectedTier?.subscribers ?? 0} Contacts</Text>
                      </Flex>
                      <Flex>
                        <Image src={CheckBulletIcon} mr='8px' />
                        <Text>Enterprise Support</Text>
                      </Flex>
                    </Flex>
                  </Box>
                  <PlanFooter>
                    <Button
                      isLoading={monthlyBtnLoading}
                      variant='black'
                      mt='15px'
                      width='100%'
                      onClick={() =>
                        addPlanApi({ id: `${selectedTier?.monthly_plan_id}`, pkgType: 'monthly' })
                      }>
                      100-day Free Trial
                    </Button>
                  </PlanFooter>
                </PlanContainer>
                <PlanContainer borderColor='teal.700' w={{ sm: '80%', md: '290px' }}>
                  <Box>
                    <Text fontSize='20px' fontWeight='bold'>
                      Annual
                    </Text>
                    <Flex direction={'column'}>
                      <Text
                        as={selectedTier?.annual == '590' ? 's' : 'samp'}
                        mt='-8px'
                        fontSize={selectedTier?.annual == '590' ? '22px' : '32px'}
                        fontWeight='bold'>
                        ${formatter.format(parseFloat(selectedTier?.annual ?? '0'))}
                      </Text>
                      {selectedTier?.annual == '590' && (
                        <Text mt='-8px' fontSize='32px' fontWeight='bold'>
                          $
                          {selectedTier?.annual && !Number.isInteger(+selectedTier?.annual / 2)
                            ? (+selectedTier?.annual / 2).toFixed(2)
                            : selectedTier?.annual && +selectedTier?.annual / 2}
                        </Text>
                      )}
                      <Badge mt='8px' variant='success' textTransform='capitalize'>
                        2 Months Free
                      </Badge>
                    </Flex>
                    <Flex mt='24px' flexDirection='column' gap='8px'>
                      <Flex>
                        <Image src={CheckBulletIcon} mr='8px' />
                        <Text>Billed Annually</Text>
                      </Flex>
                      <Flex>
                        <Image src={CheckBulletIcon} mr='8px' />
                        <Text>{selectedTier?.subscribers ?? 0} Contacts</Text>
                      </Flex>
                      <Flex>
                        <Image src={CheckBulletIcon} mr='8px' />
                        <Text>Enterprise Support</Text>
                      </Flex>
                    </Flex>
                  </Box>
                  <PlanFooter>
                    {/* <Button
                      variant='success'
                      width='100%'
                      onClick={() =>
                        navigate(
                          `/payment?type=yearly&id=${
                            selectedTier?.annual_plan_id
                          }&plan=${formatter.format(parseFloat(selectedTier?.annual ?? '0'))}`,
                        )
                      }>
                      {'Subscribe'}
                    </Button> */}
                    <Button
                      isLoading={annualBtnLoading}
                      variant='success'
                      mt='15px'
                      width='100%'
                      onClick={() =>
                        addPlanApi({ id: `${selectedTier?.annual_plan_id}`, pkgType: 'annual' })
                      }>
                      100-day Free Trial
                    </Button>
                  </PlanFooter>
                </PlanContainer>
              </Flex>
            </Flex>
          )}
        </Flex>
      </Flex>
    </Flex>
  );
};

export default SubscriptionPage;
