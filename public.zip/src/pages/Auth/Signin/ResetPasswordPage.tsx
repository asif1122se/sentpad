import { Flex, Heading, Image, Text, Box, Button, Link } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import ResetPasswordIllustration from 'assets/images/reset-password-illustration.svg';
import { ROUTE_PATHS } from 'router';
import { useFormik } from 'formik';
import { resetPassSchema } from './schema';
import { InputField } from 'components';
import { useMutation } from 'hooks/useMutation';
import { POST } from 'utils/constants';
import { ResetPassword } from './types';
import { PasswordTip } from '../Registration/styles';
import { Check, Cross } from './styles';

const ResetPasswordPage = () => {
  const navigate = useNavigate();
  const token = window.location.search.split('?token=')[1];
  const { handleSubmit, handleChange, values, errors, touched } = useFormik<ResetPassword>({
    initialValues: { password: '', password_confirmation: '', token: token },
    validationSchema: resetPassSchema,
    enableReinitialize: true,
    onSubmit: (values) =>
      reset({
        password: values.password,
        password_confirmation: values.password_confirmation,
        token: values.token,
      }),
  });

  const { isLoading, mutate: reset } = useMutation<ResetPassword>({
    method: POST,
    url: 'reset-password-api',
    onSuccess: () => {
      navigate(ROUTE_PATHS.SIGNIN);
    },
  });

  const validatePassFormat = () => {
    return (
      !/[a-z]/.test(values?.password) ||
      !/[A-Z]/.test(values?.password) ||
      values?.password?.length < 8 ||
      !/\d/.test(values?.password) ||
      !/[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/.test(values?.password)
    );
  };

  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        display={{ sm: 'none', md: 'flex' }}
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={ResetPasswordIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex
        justifyContent='center'
        alignItems='center'
        width={{ sm: '100%', md: 'calc(100% - 700px)' }}>
        <Flex flexDirection='column'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='2rem'>
            Reset your Password
          </Heading>
          <form onSubmit={handleSubmit}>
            <Box w={{ sm: '100%', md: '400px' }}>
              <Flex direction='column'>
                <Box mb='1rem'>
                  <InputField
                    label='New Password *'
                    type='password'
                    size='md'
                    placeholder='*******'
                    name='password'
                    errorText={errors.password && touched.password ? errors.password : ''}
                    value={values.password}
                    onChange={handleChange}
                  />
                  <>
                    <PasswordTip>
                      <Text className='header'>Your password must contain:</Text>
                      <Flex>
                        <Box>{values?.password?.length >= 8 ? <Check /> : <Cross />}</Box>
                        <Text>Minimum 8 characters</Text>
                      </Flex>
                      <Flex>
                        <Box>{/[A-Z]/.test(values?.password) ? <Check /> : <Cross />}</Box>
                        <Text>At least 1 upper case</Text>
                      </Flex>
                      <Flex>
                        <Box>{/[a-z]/.test(values?.password) ? <Check /> : <Cross />}</Box>
                        <Text>At least 1 lower case</Text>
                      </Flex>
                      <Flex>
                        <Box>{/\d/.test(values?.password) ? <Check /> : <Cross />}</Box>
                        <Text>At least 1 number</Text>
                      </Flex>
                      <Flex>
                        <Box>
                          {/[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/.test(values?.password) ? (
                            <Check />
                          ) : (
                            <Cross />
                          )}
                        </Box>
                        <Text>At least 1 special character</Text>
                      </Flex>
                    </PasswordTip>
                  </>
                </Box>
                <Box>
                  <InputField
                    label='Confirm Password *'
                    type='password'
                    size='md'
                    placeholder='*******'
                    name='password_confirmation'
                    errorText={
                      errors.password_confirmation && touched.password_confirmation
                        ? errors.password_confirmation
                        : ''
                    }
                    value={values.password_confirmation}
                    onChange={handleChange}
                  />
                </Box>
                <Button
                  isDisabled={
                    !values.password || !values.password_confirmation || validatePassFormat()
                  }
                  isLoading={isLoading}
                  variant='primary'
                  type='submit'
                  size='md'
                  mt='1.5rem'>
                  Reset Password
                </Button>
              </Flex>
            </Box>
          </form>
          <Flex justifyContent='center' fontSize='md' alignItems='center' mt='30px' gap='1rem'>
            <Text lineHeight='20px'>{'Go back to '}</Text>
            <Link
              color='blue.700'
              fontWeight='semibold'
              onClick={() => navigate(ROUTE_PATHS.SIGNIN)}>
              Sign in
            </Link>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default ResetPasswordPage;
