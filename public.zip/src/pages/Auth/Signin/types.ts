export type LoginForm = {
  email: string;
  password: string;
};

export type LoginResult = {
  auth_token: string;
  created_at: string;
  email: string;
  email_verified_at: string | null;
  id: number;
  is_active: 0 | 1;
  name: string;
  updated_at: string;
  sub_exists: boolean;
  email_verified: boolean;
};

export type ResetPassword = {
  password: string;
  password_confirmation: string;
  token: string;
};
