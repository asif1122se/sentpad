import { Flex, Link, Heading, Image, Text, Box } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import ForgotPasswordNotificationIllustration from 'assets/images/forgot-password-notification-illustration.svg';
import { ROUTE_PATHS } from 'router';
import Info from 'assets/icons/info-green.svg';
import Reload from 'assets/icons/reload.png';

const ForgotPasswordNotificationPage = () => {
  const email = window.location.search.split('?email=')[1];
  const navigate = useNavigate();
  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        display={{ sm: 'none', md: 'flex' }}
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={ForgotPasswordNotificationIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex
        justifyContent='center'
        alignItems='center'
        width={{ sm: '100%', md: 'calc(100% - 700px)' }}>
        <Flex flexDirection='column' justifyContent='center'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='1rem'>
            All Done!
          </Heading>
          <Flex
            background='#EEFDFA 0% 0% no-repeat padding-box;'
            border='1px solid #00BF9C'
            borderRadius='4px'
            p='1rem'
            gap='1.5rem'
            alignItems='flex-start'
            width='fit-content'>
            <Box pl='3px' pt='2px' mr='-5px' display={{ sm: 'none', md: 'block' }}>
              <Image src={Info} />
            </Box>
            <Box p='0' pr='3px' width='fit-content' textAlign='left'>
              <Text color='#009679' fontWeight='bold' lineHeight='20px'>
                Success!
              </Text>
              <Text mt='3px' fontSize='14px' lineHeight='20px' color='#009679' whiteSpace='pre'>
                {`We have sent an email to ${email} with \nthe password reset instructions.`}
              </Text>
            </Box>
          </Flex>
          <Text
            fontSize='sm'
            mt='1rem'
            lineHeight='18px'>{`Didn't get your email? Check your spam folder.`}</Text>
          <Flex alignItems='center' gap='0.5rem' mt='1.8rem'>
            <Image src={Reload} boxSize='5' />
            <Link
              color='blue.700'
              fontWeight='500'
              onClick={() => navigate(ROUTE_PATHS.FORGOT_PASSWORD_EMAIL_ENTRY)}>
              Resend Instructions
            </Link>
          </Flex>
          <Flex
            flexDirection='row'
            justifyContent='center'
            alignItems='center'
            mt='40px'
            gap='0.5rem'>
            <Text lineHeight='20px'>{'Return to '}</Text>
            <Link
              color='blue.700'
              fontWeight='semibold'
              onClick={() => navigate(ROUTE_PATHS.SIGNIN)}>
              Log in
            </Link>{' '}
            page
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default ForgotPasswordNotificationPage;
