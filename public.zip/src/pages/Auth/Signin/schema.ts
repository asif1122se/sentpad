import * as Yup from 'yup';

export const signInSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('The Email field is required'),
  password: Yup.string().required('The Password field is required').min(8, 'Mininum 8 characters'),
});

export const emailEntrySchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('The Email field is required'),
});

export const resetPassSchema = Yup.object().shape({
  password: Yup.string().required('The Password field is required').min(8, 'Mininum 8 characters'),
  password_confirmation: Yup.string()
    .required('The Confirm Password field is required')
    .min(8, 'Mininum 8 characters')
    .oneOf([Yup.ref('password'), null], 'Passwords do not match. Please try again.'),
});
