import { Flex, Box, Stack, Link, Button, Heading, Image, Text } from '@chakra-ui/react';
import { InputField } from 'components';
import { useNavigate } from 'react-router-dom';
import { Field, Form, Formik } from 'formik';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import LoginIllustration from 'assets/images/login-illustration.svg';
import { useMutation } from 'hooks/useMutation';
import { POST } from 'utils/constants';
import { LoginForm, LoginResult } from 'pages/Auth/Signin/types';
import { signInSchema } from 'pages/Auth/Signin/schema';
import { ROUTE_PATHS } from 'router';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { IsSubscribed } from 'components/Layout/types';

const SignIn = () => {
  const navigate = useNavigate();

  const { isLoading, mutate: login } = useMutation<LoginForm, LoginResult>({
    method: POST,
    url: 'login',
    onSuccess: (result) => {
      if (result?.records?.sub_exists && result?.records?.email_verified) {
        localStorage.setItem('jwtToken', result?.records?.auth_token);
        localStorage.setItem('userName', result?.records?.name);
        localStorage.setItem('email', result?.records?.email);
        navigate('/');
      }
      if (result?.records.email_verified && !result.records.sub_exists) {
        navigate(`/subscription?authtoken=${result?.records?.auth_token}`);
      }
    },
  });

  useQuery<IsSubscribed>({
    url: 'plans/current-plan',
    queryKey: [QUERY_KEYS.IS_SUBSCRIBED],
    enabled: localStorage.getItem('jwtToken') ? true : false,
    showToast: false,
    onSuccess: (data) => {
      if (data?.email_verified && data?.exists) {
        navigate('/');
      }
    },
  });

  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        display={{ sm: 'none', md: 'flex' }}
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={LoginIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex
        justifyContent='center'
        alignItems='center'
        width={{ sm: '100%', md: 'calc(100% - 700px)' }}>
        <Flex flexDirection='column'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='2rem'>
            Sign in
          </Heading>
          <Formik
            initialValues={{
              email: '',
              password: '',
            }}
            validationSchema={signInSchema}
            onSubmit={(values) => login(values)}
            validateOnBlur={false}
            validateOnChange={false}>
            {({ errors, touched }) => (
              <Form>
                <Box w={{ sm: '100%', md: '400px' }}>
                  <Flex direction='column'>
                    <Box mb='1rem'>
                      <Field
                        as={InputField}
                        label='Email'
                        type='email'
                        placeholder='Enter your email'
                        name='email'
                        errorText={touched.email && errors.email}
                      />
                    </Box>
                    <Box mb='1rem'>
                      <Field
                        as={InputField}
                        label='Password'
                        type='password'
                        placeholder='*******'
                        name='password'
                        errorText={touched.password && errors.password}
                      />
                    </Box>
                    <Stack spacing={10}>
                      <Stack
                        direction={{ base: 'column', sm: 'row' }}
                        alignItems='center'
                        justifyContent='flex-end'>
                        <Link
                          color='blue.700'
                          fontSize='14px'
                          onClick={() => navigate(ROUTE_PATHS.FORGOT_PASSWORD_EMAIL_ENTRY)}>
                          Forgot password?
                        </Link>
                      </Stack>
                      <Button
                        isLoading={isLoading}
                        variant='primary'
                        type='submit'
                        size='lg'
                        mt='2rem'>
                        Sign in
                      </Button>
                    </Stack>
                  </Flex>
                </Box>
              </Form>
            )}
          </Formik>

          <Flex flexDirection='column' alignItems='center' mt='40px' gap='1rem'>
            <Text lineHeight='20px'>{"Don't have an account?"}</Text>
            <Link
              color='blue.700'
              fontWeight='semibold'
              onClick={() => navigate(ROUTE_PATHS.SIGNUP)}>
              Register now
            </Link>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default SignIn;
