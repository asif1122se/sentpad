import { Flex, Box, Link, Button, Heading, Image, Text, chakra, useToast } from '@chakra-ui/react';
import { InputField } from 'components';
import { useNavigate } from 'react-router-dom';
import { Field, Form, Formik } from 'formik';
import SendpadLogInLogo from 'assets/images/sendpad-login-logo.svg';
import ForgotPasswordIllustration from 'assets/images/forgot-password-illustration.svg';
import { useMutation } from 'hooks/useMutation';
import { POST } from 'utils/constants';
import { emailEntrySchema } from 'pages/Auth/Signin/schema';
import { ROUTE_PATHS } from 'router';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { IsSubscribed } from 'components/Layout/types';

const ForgotPasswordEmailEntryPage = () => {
  const navigate = useNavigate();
  const error = window.location.search.split('?error=')[1];
  const toast = useToast();
  const { isLoading, mutate: sendEmail } = useMutation<{ email: string }>({
    method: POST,
    url: 'forget-password-api',
    onSuccess: () => {
      const email = document.getElementById('email') as HTMLInputElement | null;
      const str = email?.value ?? '';
      let res = '';
      const ext = str.split('.').pop() ?? '';

      for (let i = 0; i < str.substring(1, str.indexOf(ext)).length; i++) {
        if (i === 0 || str[i] === '@') {
          if (str[i] === '@') {
            res += str[i];
            i++;
          }
          res += str[i];
        } else res += '*';
      }
      res += '.' + ext;
      navigate('/forgot-password-notification?email=' + res);
    },
  });

  const { data } = useQuery<IsSubscribed>({
    url: 'plans/current-plan',
    queryKey: [QUERY_KEYS.IS_SUBSCRIBED],
    enabled: localStorage.getItem('jwtToken') ? true : false,
    showToast: false,
    onSuccess: (data) => {
      if (data?.email_verified && data?.exists) {
        navigate('/');
      }
    },
  });

  const resetPassword = (values: { email: string }) => {
    if (!localStorage.getItem('jwtToken')) {
      sendEmail(values);
    } else if (!data?.email_verified || !data?.exists) {
      toast({
        title: `Please complete your account setup first.`,
        status: 'error',
        position: 'top-right',
        isClosable: true,
      });
    }
  };

  return (
    <Flex flexWrap='wrap' justifyContent='center'>
      <Flex
        display={{ sm: 'none', md: 'flex' }}
        width='700px'
        p='100px'
        bg='#F4F0F7'
        flexDirection='column'
        justifyContent='space-between'
        alignItems='center'>
        <Image src={SendpadLogInLogo} width='230px' />
        <Image src={ForgotPasswordIllustration} />
        <Flex flexDir='column' gap='22px'>
          <Text textAlign='center'>SendPad</Text>
          <Heading as='h2' size='h3' fontWeight='bold' textAlign='center' letterSpacing='-0.64px'>
            Create email broadcasts as quickly as the speed of light
          </Heading>
        </Flex>
      </Flex>
      <Flex
        justifyContent='center'
        alignItems='center'
        width={{ sm: '100%', md: 'calc(100% - 700px)' }}>
        <Flex flexDirection='column'>
          <Heading as='h1' size='h3' fontWeight='bold' mb='2rem'>
            Forgot Password
          </Heading>
          {(error === 'invalid_link' || error === 'link_expired') && (
            <Box width='100%' mb='1rem'>
              <Box
                background='#fcfafa 0% 0% no-repeat padding-box;'
                border='1px solid #ED4758'
                borderRadius='4px'
                p='1rem'
                fontWeight='bold'
                color='#ED4758'
                gap='1.5rem'
                alignItems='flex-start'
                fontSize='md'
                textAlign='left'
                width='fit-content'>
                <chakra.span>
                  The link you clicked has expired or has already been used.
                </chakra.span>
                <chakra.span as='div'>Please request a new link and try again.</chakra.span>
              </Box>
            </Box>
          )}

          <Formik
            initialValues={{
              email: '',
            }}
            validationSchema={emailEntrySchema}
            onSubmit={(values) => resetPassword(values)}
            validateOnBlur={false}
            validateOnChange={false}>
            {({ errors, touched }) => (
              <Form>
                <Box w={{ sm: '90%', md: '400px' }}>
                  <Flex direction='column' gap='1.5rem'>
                    <Box>
                      <Field
                        id='email'
                        size='md'
                        as={InputField}
                        label='Email'
                        placeholder='Enter your email'
                        name='email'
                        errorText={touched.email && errors.email}
                      />
                    </Box>

                    <Button isLoading={isLoading} variant='primary' type='submit' size='md'>
                      Recover Password
                    </Button>
                  </Flex>
                </Box>

                <Flex
                  flexDirection='row'
                  justifyContent='center'
                  alignItems='center'
                  mt='40px'
                  gap='0.5rem'>
                  <Text lineHeight='20px'>{'Go back to '}</Text>
                  <Link
                    color='blue.700'
                    fontWeight='semibold'
                    onClick={() => navigate(ROUTE_PATHS.SIGNIN)}>
                    Sign in
                  </Link>
                </Flex>
              </Form>
            )}
          </Formik>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default ForgotPasswordEmailEntryPage;
