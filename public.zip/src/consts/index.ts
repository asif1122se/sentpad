export const SENDPAD = 'SendPad';

// Navigation
export const DASHBOARD = 'Dashboard';
export const AUDIENCE = 'Audience';
export const CAMPAIGN = 'Campaign';
export const BROADCAST = 'Broadcasts';
export const BROADCASTS = 'Broadcasts';
export const AUTOMATION = 'Automation';
export const AUTORESPONDER = 'Autoresponders';
export const FORMS = 'Forms';
export const POP_UPS = 'Pop-ups';
export const INTEGRATIONS = 'Integrations';
export const OVERVIEW = 'Overview';
export const CONTACTS = 'Contacts';
export const LISTS = 'Lists';
export const SEGMENTS = 'Segments';
export const TAGS = 'Tags';
export const PERSONALIZATION = 'Personalization';
export const SENDER_PROFILE = 'Sender Profiles';
export const IMPORT_AND_EXPORT = 'Import & Export';

export const CONTENT = 'Content';
export const SCHEDULE = 'Schedule';
export const SCHEDULED = 'scheduled';
export const LOGOUT = 'Logout';

export const ACCOUNT = 'Account';
export const SECURITY = 'Security';
export const USERS = 'Users';
export const BILLING = 'Billing';
export const DOMAIN_SETUP = 'Domain Setup';
export const TRACKING = 'Tracking';
export const API = 'API';
