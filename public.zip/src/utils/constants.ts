export const GET = 'get';
export const POST = 'post';
export const PUT = 'put';
export const DELETE = 'delete';

export const PAGINATION_PAGE_SIZES = [10, 25, 50, 100];

export const INITIAL_CONTACT_VALUES = {
  list_id: 0,
  email: '',
  first_name: '',
  last_name: '',
  phone_no: '',
};
