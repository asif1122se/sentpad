import { format, subHours } from 'date-fns';
import { DomainSetup } from 'pages/Account/types';
import { AxisDomain } from 'recharts/types/util/types';

export type ObjectType = { [key: string]: string | number };

export const parseObjectToString = (obj: ObjectType) => {
  let stringObj = '';

  for (const prop in obj) {
    stringObj += `${prop}: ${obj[prop]}; `;
  }

  return stringObj;
};

//Get Timezone
export const getDifferenceInTimeZone = () => {
  const offset = new Date().getTimezoneOffset() / -60;
  if (offset.toString().split('').length == 1) {
    return `0${offset}`;
  }
  return offset;
};

export const removeEmptyProperties = (obj: any) => {
  for (const propName in obj) {
    if (obj[propName] === null || obj[propName] === undefined || obj[propName] === '') {
      delete obj[propName];
    }
  }
  return obj;
};

export const getTimeString = (timeString?: string) => {
  if (timeString) {
    const time = timeString.split(':');
    const hours = time[0];
    const minutes = time[1];
    return `${hours}:${minutes}`;
  } else {
    const date = new Date();
    return `${date.getHours()}:${date.getMinutes()}`;
  }
};

export const formatNumber = (num: number) => {
  const formatter = Intl.NumberFormat('en', { notation: 'compact' });
  if (num < 1e5) {
    return Intl.NumberFormat().format(num);
  } else if (num > 1e5 && num < 1e7) {
    const hundreds = Math.round((num / 100) % 10);
    return `${parseInt((num / 1e3).toString())}${hundreds > 0 ? `.${hundreds}` : ''}k`;
  } else {
    return formatter.format(num).toLowerCase();
  }
};

export const displayGreeting = (currentDate: Date) => {
  const hours = currentDate.getHours();

  if (hours < 12) return 'Good Morning';
  else if (hours >= 12 && hours <= 17) return 'Good Afternoon';
  else if (hours >= 17 && hours <= 24) return 'Good Evening';
};

export const formatDate = (date = '', type?: string) => {
  const validateDate = new Date(date);
  const formattedDate =
    validateDate.toString() == 'Invalid Date'
      ? date.slice(0, 3)
      : type === 'three_month'
      ? format(validateDate, 'MMM')
      : format(validateDate, 'MM/dd');
  return formattedDate;
};

export const getChartTickCount = (arr: number[]) => {
  const max = Math.max(...arr);
  return max >= 4 ? 4 : max;
};

export const UTCtoLocalTimeConverter = (date: any) => {
  const date1 = new Date(date);
  return date1.toLocaleString();
};

export const getDomain = (arr1: number[], arr2?: number[]) => {
  const max1 = Math.max(...arr1);
  const max2 = (arr2 && Math.max(...arr2)) ?? 0;
  return ['auto', (max1 > max2 ? max1 : max2) + 5] as AxisDomain;
};

export const numberWithCommas = (x: string) => {
  x = x.toString();
  const pattern = /(-?\d+)(\d{3})/;
  while (pattern.test(x)) x = x.replace(pattern, '$1,$2');
  return x;
};

export const isDomainVerified = ({
  is_dns_entry_verified,
  is_dkim_created,
  is_spf_verified,
}: DomainSetup) => {
  return is_dns_entry_verified === 1 && is_dkim_created === 1 && is_spf_verified;
};
