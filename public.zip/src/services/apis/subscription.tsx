import { performRequest } from '../networkService/requestBuilder';
import { POST, GET } from 'utils/constants';
import config from '../../config';

//get all packages
export const GetAllSubsPackages = () => {
  const url = `https://billing.sendpad.com/?plans=1`;
  const dataObj = { url: url, data: null, method: GET, token: false };
  return performRequest(dataObj);
};

//get all packages
export const AddPlan = (id: string) => {
  const url = `${config?.apiBaseUrl}/plans/choose-package/${id}`;
  const dataObj = { url: url, data: 1, method: GET, token: true };
  return performRequest(dataObj);
};

//get all packages
export const verifyCoupenCode = (code: string) => {
  // const url = `https://billing.sendpad.tk/?coupon_=${code ? code : 'test'}`;
  const url = `https://billing.sendpad.tk/?action=coupon&coupon_=${code}`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

//check subscription
export const checkSubscriptionApi = () => {
  // const url = `https://billing.sendpad.tk/?coupon_=${code ? code : 'test'}`;
  const url = `${config.apiBaseUrl}/plans/current-plan`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

//check subscription
export const verifiedSuccessApi = () => {
  const url = `${config.apiBaseUrl}/plans/plan-acknowledge`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

//amemberBilling api
export const amemberBillingApi = (planId: string) => {
  const url = `https://billing.sendpad.com/?plan_details_=${planId}`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};
