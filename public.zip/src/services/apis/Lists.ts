import { performRequest } from '../networkService/requestBuilder';
import { POST, GET } from 'utils/constants';
import config from '../../config';

//Add List API
export const AddListApi = (data: any) => {
  const url = `${config?.apiBaseUrl}/save-list`;
  const dataObj = { url: url, data: data, method: POST, token: true };
  return performRequest(dataObj);
};

//get list by id
export const GetListByIdApi = (id: any, searchedValue: string) => {
  const url = `${config?.apiBaseUrl}/list-detail/${id}?searchData=${searchedValue}`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};
