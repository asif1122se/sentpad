import { DELETE, GET, POST } from 'utils/constants';
import { performRequest } from '../networkService/requestBuilder';
import config from 'config';

//Get contact list
export const performGetContactListApi = () => {
  const url = `${config?.apiBaseUrl}/getContactLists`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

// Get sender Profile
export const performGetSenderProfilesApi = () => {
  const url = `${config?.apiBaseUrl}/getSenderProfiles`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

// Get sender Profile
export const performSaveBroadcastApi = (data: object) => {
  const url = `${config?.apiBaseUrl}/saveCampaignData`;
  const dataObj = { url: url, data: data, method: POST, token: true };
  return performRequest(dataObj);
};

// Get broadcast listings
export const performGetBroadcastApi = (data: string, filters: any) => {
  const url = `${config?.apiBaseUrl}/getCampaignsList?searchData=${data}&status_filter=${
    filters?.status_filter ? filters?.status_filter : ''
  }&lists_filter=${filters?.lists_filter ? filters?.lists_filter : ''}&date_filter=${
    filters?.date_filter ? filters?.date_filter : ''
  }`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

// Delete broadcast
export const performDeleteCompaignApi = (id: number) => {
  const url = `${config?.apiBaseUrl}/deleteCampaign/${id}`;
  const dataObj = { url: url, data: null, method: DELETE, token: true };
  return performRequest(dataObj);
};

// get comaign by id
export const performGetSingleBroadcastApi = (id: number | string | null) => {
  const url = `${config?.apiBaseUrl}/getCampaignData/${id}`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

// duplicate campaign
export const duplicateBroadcastApi = (data: any) => {
  const url = `${config?.apiBaseUrl}/duplicate-campaign?id=${data?.id}&campaign_name=${data?.campaign_name}`;
  const dataObj = { url: url, data: null, method: GET, token: true };
  return performRequest(dataObj);
};

// duplicate campaign
export const uploadImageApi = (data: any) => {
  const url = `${config?.apiBaseUrl}/upload-image`;
  const dataObj = { url: url, data: data, method: POST, token: true };
  return performRequest(dataObj);
};
