import { GET } from '../../utils/constants';
import axios, { AxiosRequestConfig } from 'axios';

type PerformRequestReturnType = {
  data: any;
};

export type ApiRequest = {
  url: string;
  data: any;
  method: string;
  token: boolean;
};

export default class NetworkManager {
  static performRequest({
    url,
    data,
    method,
    token,
  }: ApiRequest): Promise<PerformRequestReturnType> {
    const headers = {
      Accept: 'multipart/form-data',
      Authorization: token ? `Bearer ${localStorage.getItem('jwtToken')}` : '',
    };

    const config = { method, url, data, headers };
    return new Promise((resolve, reject) => {
      axios(config)
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          if (error.response?.status === 401 && method === GET) {
            return;
          } else {
            reject({ requestError: error });
          }
          console.log('Request Response Error', { ...error });
        });
    });
  }
}
