import NetworkManager, { ApiRequest } from './index';

export const performRequest = async (request: ApiRequest) => {
  try {
    const res = await NetworkManager.performRequest(request);
    return res.data;
  } catch (e) {
    return e;
  }
};
