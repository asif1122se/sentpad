import { Action, action } from 'easy-peasy';

type ModalObj = {
  name?: string;
  url?: string;
  isDelete?: boolean;
  action?: string;
  id?: number;
  header?: string;
  description?: string;
};

export interface ModalModel {
  selectedModal: ModalObj;
  add: Action<ModalModel, ModalObj>;
}

const modal: ModalModel = {
  selectedModal: {},
  add: action((state, payload) => {
    state.selectedModal = payload;
  }),
};

export default modal;
