import { Action, action } from 'easy-peasy';

// const initialBroadcastObj: BroadcastObj = {
//   campaign_name: '',
//   subject: '',
//   pre_header: '',
//   contactList: [],
//   status: '',
//   senderProfile: null,
//   body_content: '',
//   content: '',
//   templateThumbnail: null,
//   scheduled_time: null,
//   scheduleTime: null,
//   time_zone: '',
//   step: 1,
// };

export type BroadcastObj = {
  campaign_id?: number;
  campaign_name?: string;
  subject?: string;
  pre_header?: string;
  contactList?: any;
  status?: string;
  senderProfile?: any;
  body_content?: string;
  content?: string;
  templateThumbnail?: string | undefined;
  scheduled_time?: any;
  scheduleTime?: any;
  time_zone?: string;
  step?: number;
};

export interface BroadcastModel {
  broadcastObj: BroadcastObj;
  add: Action<BroadcastModel, BroadcastObj>;
}

const broadcast: BroadcastModel = {
  broadcastObj: {},
  add: action((state, payload: BroadcastObj) => {
    state.broadcastObj = payload;
  }),
};

export default broadcast;
