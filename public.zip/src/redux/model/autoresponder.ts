import { action, Action } from 'easy-peasy';
import { Email } from 'pages/Autoresponder/types';
import { AudienceListItem } from 'pages/Broadcast/components/AudienceList';
import { TrueOrFalse } from 'types';

export type DeleteCardSetting = {
  type: number | 'actions' | 'triggers';
  index?: number;
  id?: number;
};

export type ActiveSetting = {
  type: number | 'actions' | 'triggers' | 'send-message';
  index?: number;
};

type ListActionListItem = {
  lists: AudienceListItem[];
  index: number;
};
type EmailStats = {
  emails_sent?: string;
  open_rate?: string;
  emails_opened?: string;
  click_rate?: string;
  emails_clicked?: string;
};

export type BroadcastFormType = {
  id?: number;
  email_name: string;
  sender_profile_id: number;
  body_content: string;
  subject?: string;
  pre_header?: string;
  status: string;
  templateThumbnail?: string;
  is_active: TrueOrFalse;
  stats?: EmailStats;
};

export type Wait = {
  wait_type: string;
  wait_time?: number;
  specific_time: string | null;
  time_zone: string;
  specific_day?: string | null;
};

type Actions = {
  type: number | any;
  lists?: AudienceListItem[];
  unsubscribeList?: AudienceListItem[];
  email?: BroadcastFormType;
  wait?: Wait;
};

type AddActionFlow = Actions & {
  index: number;
};

type AutoresponderObj = {
  triggers: number[];
  subscribeToListTriggerList: AudienceListItem[];
  submitsAFormTriggerList: AudienceListItem[];
  activeSetting: ActiveSetting | null;
  actions: Array<Actions>;
  tempEmail: BroadcastFormType;
};

type LeftPanelObj = {
  isOpen: boolean;
};

export interface AutoresponderModel {
  autoresponderObj: AutoresponderObj;
  leftPanel: LeftPanelObj;
  add: Action<AutoresponderModel, AutoresponderObj | null>;
  addTrigger: Action<AutoresponderModel, number | any>;
  deleteTrigger: Action<AutoresponderModel, number>;
  addSubscribeToListTriggerList: Action<AutoresponderModel, Array<AudienceListItem>>;
  addSubmitsAFormTriggerList: Action<AutoresponderModel, Array<AudienceListItem>>;
  setActiveSetting: Action<AutoresponderModel, ActiveSetting | null>;
  onOpenLeftPanel: Action<AutoresponderModel>;
  onCloseLeftPanel: Action<AutoresponderModel>;
  addAction: Action<AutoresponderModel, AddActionFlow>;
  deleteAction: Action<AutoresponderModel, number>;
  addSubscribeToListActionList: Action<AutoresponderModel, ListActionListItem>;
  addUnsubscribeFromListActionList: Action<AutoresponderModel, ListActionListItem>;
  addSendEmailActionList: Action<AutoresponderModel, BroadcastFormType>;
  addTempEmail: Action<AutoresponderModel, BroadcastFormType | null>;
  addWait: Action<AutoresponderModel, Wait & { index: number }>;
  isClearStore: boolean;
  onClearStore: Action<AutoresponderModel, boolean>;
}

const initialTempEmail = {
  email_name: '',
  subject: '',
  pre_header: '',
  status: 'draft',
  sender_profile_id: 0,
  body_content: '',
  is_active: 0 as TrueOrFalse,
};

const initialAutoresponderObject: AutoresponderObj = {
  triggers: [],
  subscribeToListTriggerList: [],
  submitsAFormTriggerList: [],
  activeSetting: null,
  actions: [],
  tempEmail: initialTempEmail,
};

const autoresponder: AutoresponderModel = {
  autoresponderObj: initialAutoresponderObject,
  leftPanel: {
    isOpen: false,
  },
  isClearStore: false,
  add: action((state, payload) => {
    state.autoresponderObj = payload === null ? initialAutoresponderObject : payload;
  }),
  addTrigger: action((state, trigger) => {
    if (!state.autoresponderObj.triggers.includes(trigger)) {
      state.autoresponderObj.triggers = [...state.autoresponderObj.triggers, trigger];
    }
  }),
  deleteTrigger: action((state, index) => {
    state.autoresponderObj.triggers.splice(index, 1);
  }),
  addSubscribeToListTriggerList: action((state, item) => {
    state.autoresponderObj.subscribeToListTriggerList = item;
  }),
  addSubmitsAFormTriggerList: action((state, item) => {
    state.autoresponderObj.submitsAFormTriggerList = item;
  }),
  setActiveSetting: action((state, activeSetting) => {
    state.autoresponderObj.activeSetting = activeSetting;
  }),
  addAction: action((state, payload) => {
    const { index, ...action } = payload;
    const addedAction = {
      type: action.type,
      index,
    };

    state.autoresponderObj.actions.splice(index, 0, action);
    state.autoresponderObj.activeSetting = addedAction;
  }),
  deleteAction: action((state, index) => {
    state.autoresponderObj.actions.splice(index, 1);
  }),
  addSubscribeToListActionList: action((state, payload) => {
    const { lists, index } = payload;
    state.autoresponderObj.actions[index].lists = [...lists];
  }),
  addUnsubscribeFromListActionList: action((state, payload) => {
    const { lists, index } = payload;
    state.autoresponderObj.actions[index].unsubscribeList = [...lists];
  }),
  addSendEmailActionList: action((state, payload) => {
    const index = state.autoresponderObj.activeSetting?.index ?? 0;
    state.autoresponderObj.actions[index].email = payload;
  }),
  addTempEmail: action((state, payload) => {
    state.autoresponderObj.tempEmail = payload !== null ? payload : initialTempEmail;
  }),
  addWait: action((state, payload) => {
    const { index, ...wait } = payload;
    state.autoresponderObj.actions[index].wait = wait;
  }),
  onOpenLeftPanel: action((state) => {
    state.leftPanel.isOpen = true;
  }),
  onCloseLeftPanel: action((state) => {
    state.leftPanel.isOpen = false;
  }),
  onClearStore: action((state, payload) => {
    state.isClearStore = payload;
  }),
};

export default autoresponder;
