import { Action, action } from 'easy-peasy';

export interface FilterModel {
  filterObj: any;
  add: Action<FilterModel, { isclicked?: boolean }>;
}

const filter: FilterModel = {
  filterObj: '',
  add: action((state, payload) => {
    state.filterObj = payload;
  }),
};

export default filter;
