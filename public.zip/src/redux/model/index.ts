import broadcast, { BroadcastModel } from './broadcast';
import modal, { ModalModel } from './modal';
import filter, { FilterModel } from './filters';
import autoresponder, { AutoresponderModel } from './autoresponder';

export interface StoreModel {
  broadcast: BroadcastModel;
  modal: ModalModel;
  filter: FilterModel;
  autoresponder: AutoresponderModel;
}

const model: StoreModel = {
  broadcast,
  modal,
  filter,
  autoresponder,
};

export default model;
