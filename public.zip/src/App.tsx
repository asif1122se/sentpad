import AppProvider from 'components/AppProvider';
import { Router } from 'router';

const App: React.FC = () => (
  <AppProvider>
    <Router />
  </AppProvider>
);

export default App;
