import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import 'grapesjs/dist/css/grapes.min.css';
import 'grapesjs-preset-newsletter/dist/grapesjs-preset-newsletter.min.js';
import 'grapesjs-preset-newsletter/dist/grapesjs-preset-newsletter.css';
import 'components/EmailBuilder/styles/main.scss';
import 'index.css';
import { StoreProvider } from 'easy-peasy';
import store from './redux/store';

type Props = StoreProvider['props'] & { children: React.ReactNode };

// This is a workaround until easy-peasy supports React 18
const StoreProviderCasted = StoreProvider as unknown as React.ComponentType<Props>;

// Do not use createRoot yet as it can cause a duplicate render issue on the GrapesJS email builder panels
ReactDOM.render(
  <React.StrictMode>
    <StoreProviderCasted store={store}>
      <App />
    </StoreProviderCasted>
  </React.StrictMode>,
  document.getElementById('root'),
);
