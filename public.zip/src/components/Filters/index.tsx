import { FilterComponents } from './consts';

type FilterProps = {
  filterIndex: number;
  openDrawer: any;
  setOpenDrawer: any;
  values: any;
  setValues: any;
  onClickFilter: () => void;
};

const PageFilters = ({
  filterIndex,
  openDrawer,
  setOpenDrawer,
  values,
  setValues,
  onClickFilter,
}: FilterProps) => {
  const DisplayFilter = FilterComponents[filterIndex].comp;
  return (
    <>
      <DisplayFilter
        openDrawer={openDrawer}
        setOpenDrawer={setOpenDrawer}
        values={values}
        setValues={setValues}
        onClickFilter={onClickFilter}
      />
    </>
  );
};

export default PageFilters;
