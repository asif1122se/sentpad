import ContactFilters from 'pages/Audience/Contacts/components/Filters';
import BroadcastFilters from 'pages/Broadcast/components/Filters';
import AutorespondFilters from 'pages/Autoresponder/components/Filters';

export const enum FILTER_INDEX {
  Broadcast,
  Contact,
  Autorespond,
}

export const FilterComponents = [
  {
    comp: BroadcastFilters,
  },
  {
    comp: ContactFilters,
  },
  {
    comp: AutorespondFilters,
  },
];
