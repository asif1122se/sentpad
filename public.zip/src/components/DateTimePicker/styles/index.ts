import { Button } from '@chakra-ui/react';
import styled from '@emotion/styled';

export const ArrowButton = styled(Button)`
  width: 24px;
  height: 24px;
  min-width: 24px;
  padding: 0;
  box-shadow: 0px 2px 4px 0px rgba(81, 94, 114, 0.2);

  &:hover:not(:disabled) {
    border: 1px solid var(--chakra-colors-blue-700);
    background: unset;

    svg {
      color: var(--chakra-colors-blue-700);
    }
  }
`;

export const ResetButton = styled(Button)`
  position: absolute;
  right: 28px;
  bottom: 22px;
  box-shadow: 0px 2px 4px 0px rgba(81, 94, 114, 0.2);
`;
