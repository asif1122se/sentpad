import React, { useEffect, useRef, useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { format, addDays } from 'date-fns';
import InputField from 'components/InputField';
const DateRangePicker = ({
  getDate,
  selectsRange,
  isClearable,
  onChange,
  maxDate,
  value,
  isDateClear,
  showDate,
  setIsDateClear,
  ...restProps
}: any) => {
  const [dateRange, setDateRange] = useState([null, null]);
  const [startDate, endDate] = dateRange;

  const handleDateChange = (date: any) => {
    setDateRange(date);
    getDate(
      date[0] &&
        `${format(new Date(date[0]), 'yyyy-MM-dd')},${
          date[1] ? format(new Date(date[1]), 'yyyy-MM-dd') : ''
        }`,
    );
  };

  const handleClearDate = () => {
    setDateRange([null, null]);
  };

  useEffect(() => {
    handleClearDate();
  }, [isDateClear]);

  return (
    <DatePicker
      placeholderText='Click to select date'
      // maxDate={addDays(new Date(), 90)}
      selectsRange={true}
      startDate={startDate}
      endDate={endDate}
      onChange={(update: any) => {
        handleDateChange(update);
      }}
      value={value}
      customInput={
        <InputField
          borderColor='gray.400'
          h='9'
          fontSize='sm'
          placeholder='Click to select date'
          width='100%'
        />
      }
    />
  );
};

export default DateRangePicker;
