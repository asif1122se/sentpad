import DatePicker, {
  ReactDatePickerCustomHeaderProps,
  ReactDatePickerProps,
} from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { format } from 'date-fns';
import './styles/styles.scss';
import { Flex, Text } from '@chakra-ui/react';
import { ChevronLeftIcon, ChevronRightIcon } from '@chakra-ui/icons';
import { ArrowButton, ResetButton } from './styles';

type DatePickerProps = ReactDatePickerProps;

const CustomHeader = ({
  date,
  decreaseMonth,
  prevMonthButtonDisabled,
  increaseMonth,
  nextMonthButtonDisabled,
}: ReactDatePickerCustomHeaderProps) => {
  return (
    <Flex alignItems='center' justifyContent='space-between'>
      <ArrowButton onClick={decreaseMonth} isDisabled={prevMonthButtonDisabled} variant='outlined'>
        <ChevronLeftIcon />
      </ArrowButton>
      <Text fontWeight='medium' fontSize='14px'>
        {format(date, 'MMMM yyyy')}
      </Text>
      <ArrowButton onClick={increaseMonth} isDisabled={nextMonthButtonDisabled} variant='outlined'>
        <ChevronRightIcon />
      </ArrowButton>
    </Flex>
  );
};

const DateTimePicker = ({
  onChange,
  minDate,
  maxDate,
  startDate,
  ...restProps
}: DatePickerProps) => {
  return (
    <>
      <DatePicker
        selected={startDate}
        onChange={onChange}
        inline
        minDate={minDate}
        closeOnScroll={true}
        maxDate={maxDate}
        renderCustomHeader={CustomHeader}
        formatWeekDay={(day) => day.substring(0, 1)}
        timeInputLabel='Select Time'
        dateFormat='MM/dd/yyyy h:mm aa'
        showTimeInput
        {...restProps}>
        <ResetButton variant='blackOutlined' onClick={(e) => onChange(new Date(), e)}>
          Reset
        </ResetButton>
      </DatePicker>
    </>
  );
};

export default DateTimePicker;
