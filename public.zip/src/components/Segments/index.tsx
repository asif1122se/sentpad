import { Box, Text } from '@chakra-ui/react';

import { useState, useEffect } from 'react';
import {
  SegmentBoxDesign,
  SegmentButton,
  SegmentButtonBox,
  SegmentContainer,
  SegmentHeader,
  SegmentTextDesign,
} from './styles';
import ORSubFilters from './ORSubFilters';
import ANDSubFilters from './ANDSubFilters';

const index = ({ segmentFilters, getConditionsValues, showError, getSegmentByIdData }: any) => {
  const [orArr, setOrArr] = useState<any>([]);
  const [andSubFilterConditions, setAndSubFilterConditions] = useState<any>([]);

  const getOrSubFiltersValues = (data: any) => {
    setOrArr(data);
    andSubFilterConditions
      ? getConditionsValues([...data, andSubFilterConditions.flat(1)])
      : getConditionsValues([...data]);
  };

  const getAndSubFiltersValues = (data: any, index: any) => {
    const values = [...andSubFilterConditions];
    values[index] = data;
    setAndSubFilterConditions(values);
    getConditionsValues([...orArr, values.flat(1)]);
  };

  const formatAndConditionsArr = () => {
    const viewAllAndConditions =
      getSegmentByIdData &&
      getSegmentByIdData?.slice(
        getSegmentByIdData?.findIndex((x: any) => x.filter_operator === 'and'),
        getSegmentByIdData?.length,
      );
    const arrnew: any[] = [];
    for (let i = 0; i <= viewAllAndConditions?.length - 1; i++) {
      if (viewAllAndConditions[i]?.filter_operator == 'and') {
        arrnew.push([viewAllAndConditions[i]]);
      } else {
        arrnew[arrnew.length - 1].push(viewAllAndConditions[i]);
      }
    }
    setAndSubFilterConditions(arrnew);
  };

  useEffect(() => {
    getSegmentByIdData?.findIndex((x: any) => x.filter_operator === 'and') !== -1 &&
      formatAndConditionsArr();
  }, [getSegmentByIdData]);

  return (
    <Box>
      <SegmentHeader>Segment Conditions</SegmentHeader>

      <SegmentContainer>
        {/* OR CONDITION COMPONENT */}
        <ORSubFilters
          conditionType={''}
          segmentFilters={segmentFilters}
          getOrSubFiltersValues={getOrSubFiltersValues}
          orGroupIndex={index}
          showError={showError}
          getSegmentByIdData={getSegmentByIdData}
        />
      </SegmentContainer>

      {/* AND CONDITION COMPONENT */}
      {andSubFilterConditions &&
        andSubFilterConditions?.map((item: any, index: any) => (
          <>
            {' '}
            <>
              <ANDSubFilters
                segmentFilters={segmentFilters}
                getAndSubFiltersValues={getAndSubFiltersValues}
                orGroupIndex={index}
                getSegmentByIdData={getSegmentByIdData}
                orFilterData={item}
              />
            </>
          </>
        ))}

      <Box p='20px' width='50%'>
        <SegmentButton
          onClick={() => {
            setAndSubFilterConditions(
              andSubFilterConditions?.length > 0
                ? [
                    ...andSubFilterConditions,
                    [
                      {
                        segment_filter_id: '1',
                        filter_condition: null,
                        filter_value: null,
                        filter_operator: 'and',
                        days: 0,
                        months: 0,
                      },
                    ],
                  ]
                : [
                    [
                      {
                        segment_filter_id: '1',
                        filter_condition: null,
                        filter_value: null,
                        filter_operator: 'and',
                        days: 0,
                        months: 0,
                      },
                    ],
                  ],
            );
          }}>
          <SegmentButtonBox>
            <SegmentBoxDesign>
              <Text fontSize='18px' lineHeight='18px'>
                +
              </Text>
            </SegmentBoxDesign>
            <SegmentTextDesign>and</SegmentTextDesign>
            condition
          </SegmentButtonBox>
        </SegmentButton>
      </Box>
    </Box>
  );
};

export default index;
