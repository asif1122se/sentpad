import { Box, Button, Flex, HStack, Select, Switch, Text } from '@chakra-ui/react';
import styled from '@emotion/styled';
import InputField from 'components/InputField';

export const SegmentHeader = styled(Text)`
  font-size: 18px;
  line-height: 20px;
  font-weight: bold;
  margin: 20px 0;
`;

export const SegmentContainer = styled(Box)`
  background: #f2f6f9 0% 0% no-repeat padding-box;
  border-radius: 8px;
  padding: 20px;
  width: fit-content;
`;

export const SegmentFilterBox = styled(Flex)`
  background: #ffffff 0% 0% no-repeat padding-box;
  border-radius: 8px;
  padding: 20px;
  padding-top: 25px;
  width: fit-content;
  margin: 0;
  position: relative;
  gap: 0.5rem;
  color: black;
`;

export const SegmentList = styled(Flex)({
  fontSize: 'var(--chakra-fontSizes-sm);',
  minWidth: '400px',
  width: '100%',
  borderWidth: '1px',
  borderColor: 'var(--chakra-colors-gray-500)',
  borderRadius: '8px',
  alignItems: 'flex-start',
  justifyContent: 'space-between',
});

export const SegmentDatePicker = styled(Flex)({
  height: '40px',
  borderRadius: '5px',
  padding: '5px',
  border: '1px solid',
  borderColor: 'var(--chakra-colors-gray-500)',
  alignItems: 'center',
  justifyContent: 'center',
  fontFamily: 'Inter',
  fontSize: '14px',
  fontWeight: 'normal',
  paddingLeft: '0.5rem',
  color: '#11213C',
});

export const SegmentNumDateFilter = styled(Flex)({
  height: '40px',
  width: 'fit-content',
  borderRadius: '5px',
  border: '1px solid',
  borderColor: 'var(--chakra-colors-gray-500)',
  alignItems: 'center',
  justifyContent: 'flex-start',
  padding: '0 8px',
  gap: '5px',
});

export const SegmentButton = styled(Button)({
  width: 'fit-content',
  background: '#FFFFFF 0% 0% no-repeat padding-box',
  border: '1px solid #11213C',
});

export const SegmentButtonBox = styled(Flex)({
  padding: '3px 0',
  gap: '10px',
  justifyContent: 'center',
  alignItems: 'center',
  width: 'fit-content',
});

export const SegmentBoxDesign = styled(Box)({
  border: '1px solid #11213C',
  borderRadius: '100%',
  minWidth: '22px',
  width: '22px',
  height: '22px',
  padding: 0,
  marginBottom: 0,
});

export const SegmentTextDesign = styled(Text)({
  padding: '7px',
  background: '#11213C 0% 0% no-repeat padding-box',
  borderRadius: '4px',
  color: '#FFFFFF',
});

export const SegmentTextDesignWhite = styled(Text)({
  padding: '5px 8px',
  fontWeight: 'semibold',
  background: '#FFFFFF 0% 0% no-repeat padding-box',
  borderRadius: '4px',
  color: '#11213C',
});

export const SegmentTextDesignBlack = styled(Text)({
  padding: '5px 8px',
  fontWeight: 'semibold',
  background: '#f2f6f9 0% 0% no-repeat padding-box',
  borderRadius: '4px',
  color: '#11213C',
});

export const SegmentInputField = styled(InputField)({
  borderColor: 'transparent',
  height: '21px',
  fontSize: 'sm',
  placeholder: '0',
  minWidth: '50px',
  width: '60px',
  color: '#11213C',
  padding: '0 5px',
  textAlign: 'left',
});

export const FilterLinkBox = styled(Box)({
  padding: '0',
  marginY: '0.5rem',
  marginLeft: '1rem',
  textAlign: 'center',
  width: 'fit-content',
  justifyContent: 'center',
});
