import { ChevronDownIcon, DeleteIcon, SearchIcon } from '@chakra-ui/icons';
import {
  Box,
  Button,
  Center,
  Divider,
  Flex,
  Image,
  Menu,
  MenuButton,
  MenuDivider,
  MenuItem,
  MenuList,
  Select,
  Text,
  useDisclosure,
} from '@chakra-ui/react';
import AudienceList from 'pages/Broadcast/components/AudienceList';
import { useEffect, useRef, useState } from 'react';
import CalendarIcon from 'assets/icons/calendar-small.png';
import {
  SegmentBoxDesign,
  SegmentButton,
  SegmentButtonBox,
  SegmentDatePicker,
  SegmentFilterBox,
  SegmentInputField,
  SegmentList,
  SegmentNumDateFilter,
  SegmentTextDesign,
  FilterLinkBox,
  SegmentTextDesignWhite,
} from './styles';
import DatePicker from 'react-datepicker';
import InputField from 'components/InputField';
import { format, subDays } from 'date-fns';
import { UTCtoLocalTimeConverter } from 'utils';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';

const AndSubFilters = ({
  segmentFilters,
  getAndSubFiltersValues,
  showError,
  orGroupIndex,
  setAndSubFilterConditions,
  getSegmentByIdData,
  orConditionDataForAnd,
}: any) => {
  const { isOpen } = useDisclosure();
  const [values, setValues] = useState<any>([]);
  const [listsFilter, setListsFilter] = useState<any>({ lists_filter: '' });
  const [orSubFilterConditions, setOrSubFilterConditions] = useState<any>([
    {
      segment_filter_id: '1',
      filter_condition: null,
      filter_value: null,
      filter_operator: 'and',
      days: 0,
      months: 0,
    },
  ]);
  const { data: campaignList } = useQuery<any>({
    queryKey: [QUERY_KEYS.COMPAIGN_LIST],
    url: `getCampaignsList`,
  });

  const getList = (data: any, index: any) => {
    const ids = data?.map((item: any) => item?.id);
    setListsFilter(!listsFilter);
    const values = [...orSubFilterConditions];
    values[index]['filter_value'] = data;
    setOrSubFilterConditions(values);
  };

  const handleAddCondition = (condition: string) => {
    setOrSubFilterConditions([
      ...orSubFilterConditions,
      {
        segment_filter_id: '1',
        filter_condition: null,
        filter_value: null,
        filter_operator: condition,
        days: 0,
        months: 0,
      },
    ]);
  };
  const handleRemoveCondition = (index: any) => {
    const values = [...orSubFilterConditions];
    values.splice(index, 1);
    setOrSubFilterConditions(values);
  };

  const handleChangeCondition = (index: any, event: any, name: string) => {
    const values = [...orSubFilterConditions];
    if (name == 'filterId') {
      values[index]['filter_condition'] = null;
      values[index]['filter_value'] = null;
      values[index]['days'] = 0;
      values[index]['months'] = 0;
      setOrSubFilterConditions(values);
    }
    if (name == 'filterCondition') {
      values[index]['filter_value'] = null;
      values[index]['days'] = 0;
      values[index]['months'] = 0;
      setOrSubFilterConditions(values);
    }
    values[index][event.target.name] = event.target.value;
    setOrSubFilterConditions(values);
  };

  const formatOrConditionObj = () => {
    const result =
      orSubFilterConditions &&
      orSubFilterConditions?.map((item: any) => ({
        segment_filter_id: item?.segment_filter_id,
        filter_value:
          item?.filter_value !== null && typeof item?.filter_value !== 'string'
            ? item?.filter_value?.map((filterIds: any) => filterIds?.id)?.toString()
            : typeof item?.filter_value == 'string'
            ? item?.filter_value
            : item?.days > 0 && item?.months > 0
            ? format(
                new Date(
                  new Date(
                    subDays(new Date(), parseFloat(item?.days) + parseFloat(item?.months) * 30),
                  ),
                ),
                'yyyy-MM-dd',
              )
            : item?.days > 0 && item?.months < 1
            ? format(new Date(new Date(subDays(new Date(), item?.days))), 'yyyy-MM-dd')
            : item?.days < 1 && item?.months > 0
            ? format(new Date(new Date(subDays(new Date(), item?.months * 30))), 'yyyy-MM-dd')
            : null,
        filter_condition: item?.filter_condition?.filter_name
          ? `${item?.filter_condition?.id}`
          : item?.filter_condition,
        filter_operator: item?.filter_operator,
        days: item?.days,
        months: item?.months,
      }));
    getAndSubFiltersValues(result, orGroupIndex);
    setAndSubFilterConditions(result);
  };

  useEffect(() => {
    formatOrConditionObj();
  }, [orSubFilterConditions, listsFilter]);

  const formatObjectForView = () => {
    const res =
      orConditionDataForAnd &&
      orConditionDataForAnd?.map((formatOrObjectForView: any) => ({
        segment_filter_id: formatOrObjectForView?.segment_filter_object?.id
          ? `${formatOrObjectForView?.segment_filter_object?.id}`
          : '1',
        filter_condition: formatOrObjectForView?.filter_condition
          ? {
              filter_name: formatOrObjectForView?.filter_condition_object?.filter_name,
              id: formatOrObjectForView?.filter_condition_object?.id,
            }
          : null,
        filter_value: formatOrObjectForView?.lists
          ? formatOrObjectForView?.lists?.map((filterLists: any) => ({
              id: filterLists?.id,
              name: filterLists?.title,
            }))
          : formatOrObjectForView?.filter_value,
        filter_operator: formatOrObjectForView?.filter_operator,
        days: formatOrObjectForView?.days,
        months: formatOrObjectForView?.months,
      }));
    setOrSubFilterConditions(res);
  };

  useEffect(() => {
    orConditionDataForAnd && formatObjectForView();
  }, [getSegmentByIdData]);

  const inputRef = useRef<any>();
  const handleFocus = () => {
    inputRef?.current?.setFocus();
  };

  return (
    <>
      {orSubFilterConditions?.map((item: any, index: any) => (
        <>
          {item?.filter_operator == 'or' && (
            <>
              <FilterLinkBox>
                <Center height='20px' mt='-8px'>
                  <Divider orientation='vertical' borderWidth='2px' borderColor='#FFFFFF' />
                </Center>
                <SegmentTextDesignWhite>{item?.filter_operator}</SegmentTextDesignWhite>
                <Center height='20px' mb='-8px'>
                  <Divider orientation='vertical' borderWidth='2px' borderColor='#FFFFFF' />
                </Center>
              </FilterLinkBox>
            </>
          )}
          <SegmentFilterBox>
            <Select
              name='segment_filter_id'
              size='md'
              py='3px'
              minWidth='190px'
              width='fit-content'
              fontSize='14px'
              borderColor='gray.500'
              onChange={(event) => handleChangeCondition(index, event, 'filterId')}>
              {segmentFilters && (
                <option style={{ display: 'none' }}>
                  {
                    segmentFilters?.find(
                      (filterName: any) => filterName.id == item?.segment_filter_id,
                    )?.filter_name
                  }
                </option>
              )}
              {segmentFilters &&
                segmentFilters?.map((segmentFilterId: any) => (
                  <>
                    <option value={segmentFilterId?.id}>{segmentFilterId?.filter_name}</option>
                  </>
                ))}
            </Select>
            {/* is on list=1, is not on list=2 */}
            {(item?.segment_filter_id === '1' || item?.segment_filter_id === '2') && (
              <>
                <Flex direction={'column'} mt='-13px'>
                  {/* Audience list */}
                  <Box position='relative'>
                    <Text
                      position='absolute'
                      color='blue.700'
                      fontSize='sm'
                      cursor='pointer'
                      fontWeight='500'
                      right='0'
                      top='-7px'
                      onClick={() => {
                        getList([], index);
                      }}>
                      Remove All
                    </Text>
                    <AudienceList
                      showSelectAll={false}
                      removeText=''
                      customStyles={{
                        borderWidth: '1px',
                        borderColor: 'gray.500',
                        p: '5px',
                        borderRadius: '6px',
                        minWidth: '400px',
                        minH: '40px',
                      }}
                      getList={getList}
                      headingText=''
                      setValues={setValues}
                      values={{ list: item?.filter_value }}
                      keyIndex={index}
                    />
                  </Box>

                  {(!item?.filter_value || item?.filter_value == '') && showError && (
                    <Text fontSize={'xs'} color={'red'}>
                      This field is required{' '}
                    </Text>
                  )}
                </Flex>
              </>
            )}
            {/* Subscription date=3 */}
            {item?.segment_filter_id === '3' && (
              <Flex alignItems='center' gap='0.5rem'>
                <Flex direction={'column'}>
                  <Select
                    size='md'
                    py='3px'
                    minWidth='120px'
                    width='fit-content'
                    fontSize='14px'
                    borderColor='gray.500'
                    name='filter_condition'
                    onChange={(event) => handleChangeCondition(index, event, 'filterCondition')}>
                    <option value={item?.filter_condition?.id}>
                      {item?.filter_condition?.filter_name || 'Select Option'}
                    </option>
                    {segmentFilters &&
                      segmentFilters[2]?.condtions?.map((item: any) => (
                        <>
                          <option value={item?.id}>{item?.filter_name}</option>
                        </>
                      ))}
                  </Select>
                  {(!item?.filter_condition || item?.filter_condition == '') && showError && (
                    <Text fontSize={'xs'} color={'red'}>
                      This field is required{' '}
                    </Text>
                  )}
                </Flex>
                {/* Subscription date=3, is=6, is before=7, is after=8  */}
                {(item?.filter_condition === '3' ||
                  item?.filter_condition?.id === 3 ||
                  item?.filter_condition === '6' ||
                  item?.filter_condition?.id === 6 ||
                  item?.filter_condition === '7' ||
                  item?.filter_condition?.id === 7 ||
                  item?.filter_condition === '8' ||
                  item?.filter_condition?.id === 8 ||
                  item?.filter_condition === '') && (
                  <>
                    <Flex direction={'column'}>
                      <SegmentDatePicker>
                        <DatePicker
                          ref={inputRef}
                          placeholderText='Click to select date'
                          value={
                            item?.filter_value
                              ? format(new Date(item?.filter_value), 'dd/MM/yy')
                              : ''
                          }
                          onChange={(date) => {
                            handleChangeCondition(
                              index,
                              {
                                target: {
                                  name: 'filter_value',
                                  value: format(
                                    new Date(`${UTCtoLocalTimeConverter(date)}`),
                                    `${
                                      item?.filter_condition !== '6'
                                        ? 'yyyy-MM-dd hh:mm'
                                        : 'yyyy-MM-dd'
                                    }`,
                                  ),
                                },
                              },
                              'filterValue',
                            );
                          }}
                          maxDate={new Date()}
                        />
                        <Image
                          src={CalendarIcon}
                          onClick={() => handleFocus()}
                          alt='Calendar'
                          cursor='pointer'
                        />
                      </SegmentDatePicker>
                      {(!item?.filter_value || item?.filter_value == '') && showError && (
                        <Text fontSize={'xs'} color={'red'}>
                          This field is required{' '}
                        </Text>
                      )}
                    </Flex>
                  </>
                )}
                {/* in the last=9  */}
                {(item?.filter_condition === '9' || item?.filter_condition?.id === 9) && (
                  <>
                    <Flex direction={'column'}>
                      <SegmentNumDateFilter>
                        <SegmentInputField
                          onChange={(event) => handleChangeCondition(index, event, 'filterValue')}
                          name='days'
                          value={item?.days}
                        />
                        <Text fontSize='sm' color='gray.500' fontWeight='semibold'>
                          Days
                        </Text>
                      </SegmentNumDateFilter>
                      {item?.days == 0 && item?.months == 0 && showError && (
                        <Text fontSize={'xs'} color={'red'}>
                          Required{' '}
                        </Text>
                      )}
                    </Flex>
                    <Flex direction={'column'}>
                      <SegmentNumDateFilter>
                        <SegmentInputField
                          onChange={(event) => handleChangeCondition(index, event, 'filterValue')}
                          name='months'
                          value={item?.months}
                        />
                        <Text fontSize='sm' color='gray.500' fontWeight='semibold'>
                          Months
                        </Text>
                      </SegmentNumDateFilter>
                      {item?.days == 0 && item?.months == 0 && showError && (
                        <Text fontSize={'xs'} color={'red'}>
                          Required{' '}
                        </Text>
                      )}
                    </Flex>
                  </>
                )}
              </Flex>
            )}
            {/* Opened emails=4, Did not open emails=5 */}
            {(item?.segment_filter_id === '4' || item?.segment_filter_id === '5') && (
              <Flex alignItems='center' gap='0.5rem'>
                <Flex direction={'column'}>
                  <Menu>
                    <MenuButton
                      as={Button}
                      rightIcon={<ChevronDownIcon boxSize='5' />}
                      background='#FFFFFF 0% 0% no-repeat padding-box'
                      border='1px solid'
                      fontWeight='normal'
                      borderColor='gray.500'>
                      {item?.filter_condition?.filter_name
                        ? item?.filter_condition?.filter_name.length > 50
                          ? `${item?.filter_condition?.filter_name.substring(0, 50)}...`
                          : item?.filter_condition?.filter_name
                        : 'Select Option'}
                    </MenuButton>
                    <MenuList fontSize='sm' border='1px solid #D2D8DE' overflow='auto' maxH='450px'>
                      <MenuItem
                        _disabled={{ background: 'transparent' }}
                        isDisabled={true}
                        isFocusable={true}>
                        <InputField
                          color='blackAlpha.800'
                          placeholder='Enter to search'
                          size='md'
                          icon={
                            <SearchIcon as='button' cursor='pointer' color='gray.800' />
                          }></InputField>
                      </MenuItem>
                      {segmentFilters &&
                        segmentFilters[3]?.condtions?.map((emailOpt: any) => (
                          <>
                            <MenuItem
                              onClick={() =>
                                handleChangeCondition(
                                  index,
                                  {
                                    target: { name: 'filter_condition', value: emailOpt },
                                  },
                                  'filterCondition',
                                )
                              }>
                              {emailOpt?.filter_name}
                            </MenuItem>
                          </>
                        ))}
                      <MenuDivider border='1px solid #D2D8DE' />
                      <MenuItem
                        _disabled={{ background: 'transparent' }}
                        isDisabled={true}
                        isFocusable={false}
                        cursor={'auto'}>
                        <Text fontSize='sm' color='gray.500' fontWeight='500'>
                          EMAIL BROADCASTS
                        </Text>
                      </MenuItem>
                      {campaignList &&
                        campaignList.map((compaignItems: any) => (
                          <>
                            <MenuItem
                              onClick={() => {
                                handleChangeCondition(
                                  index,
                                  {
                                    target: {
                                      name: 'filter_condition',
                                      value: {
                                        filter_name: compaignItems?.campaign_name,
                                        id: 16,
                                      },
                                    },
                                  },
                                  'filterCondition',
                                );
                                handleChangeCondition(
                                  index,
                                  {
                                    target: {
                                      name: 'filter_value',
                                      value: `${compaignItems?.id}`,
                                    },
                                  },
                                  'filterValue',
                                );
                              }}>
                              {compaignItems?.campaign_name.length > 50
                                ? `${compaignItems?.campaign_name.substring(0, 50)}...`
                                : compaignItems?.campaign_name}
                            </MenuItem>
                          </>
                        ))}
                    </MenuList>
                  </Menu>
                  {(!item?.filter_condition || item?.filter_condition == '') && showError && (
                    <Text fontSize={'xs'} color={'red'}>
                      This field is required{' '}
                    </Text>
                  )}
                </Flex>
                {isOpen && (
                  <>
                    <SegmentNumDateFilter>
                      <SegmentInputField value='0' />
                      <Text fontSize='sm' color='gray.500' fontWeight='semibold'>
                        Days
                      </Text>
                    </SegmentNumDateFilter>
                    <SegmentNumDateFilter>
                      <SegmentInputField value='0' />
                      <Text fontSize='sm' color='gray.500' fontWeight='semibold'>
                        Months
                      </Text>
                    </SegmentNumDateFilter>
                  </>
                )}
                {/* in the last=9  */}
                {item?.filter_condition?.filter_name?.split(' ')[0] == 'Recent' && (
                  <>
                    <Flex direction={'column'}>
                      <SegmentNumDateFilter>
                        <SegmentInputField
                          onChange={(event) => handleChangeCondition(index, event, 'filterValue')}
                          name='days'
                          value={item?.days}
                        />
                        <Text fontSize='sm' color='gray.500' fontWeight='semibold'>
                          Days
                        </Text>
                      </SegmentNumDateFilter>
                      {item?.days == 0 && item?.months == 0 && showError && (
                        <Text fontSize={'xs'} color={'red'}>
                          Required{' '}
                        </Text>
                      )}
                    </Flex>
                    <Flex direction={'column'}>
                      <SegmentNumDateFilter>
                        <SegmentInputField
                          onChange={(event) => handleChangeCondition(index, event, 'filterValue')}
                          name='months'
                          value={item?.months}
                        />
                        <Text fontSize='sm' color='gray.500' fontWeight='semibold'>
                          Months
                        </Text>
                      </SegmentNumDateFilter>
                      {item?.days == 0 && item?.months == 0 && showError && (
                        <Text fontSize={'xs'} color={'red'}>
                          Required{' '}
                        </Text>
                      )}
                    </Flex>
                  </>
                )}
              </Flex>
            )}
            <DeleteIcon
              color='gray.700'
              mx='5px'
              mt='12px'
              boxSize='5'
              cursor='pointer'
              onClick={() => handleRemoveCondition(index)}
            />
          </SegmentFilterBox>
        </>
      ))}
      <Box mt='1rem'>
        <SegmentButton onClick={() => handleAddCondition('or')}>
          <SegmentButtonBox>
            <SegmentBoxDesign>
              <Text fontSize='18px' lineHeight='18px'>
                +
              </Text>
            </SegmentBoxDesign>
            <SegmentTextDesign>or</SegmentTextDesign>
            condition
          </SegmentButtonBox>
        </SegmentButton>
      </Box>
    </>
  );
};

export default AndSubFilters;
