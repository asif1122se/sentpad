import { Box, Center, Divider, Text, useDisclosure } from '@chakra-ui/react';

import { useState } from 'react';
import { FilterLinkBox, SegmentContainer, SegmentTextDesignBlack } from './styles';
import ANDFilterContainer from './ANDFilterContainer';

const ANDSubFilters = ({
  segmentFilters,
  getAndSubFiltersValues,
  orGroupIndex,
  orFilterData,
}: any) => {
  const [andSubFilterConditions, setAndSubFilterConditions] = useState<any>([1]);

  return (
    <>
      {andSubFilterConditions?.length > 0 && (
        <>
          <FilterLinkBox>
            <Center height='20px' mt='-8px'>
              <Divider orientation='vertical' borderWidth='2px' borderColor='#f2f6f9' />
            </Center>
            <SegmentTextDesignBlack>and</SegmentTextDesignBlack>
            <Center height='20px' mb='-8px'>
              <Divider orientation='vertical' borderWidth='2px' borderColor='#f2f6f9' />
            </Center>
          </FilterLinkBox>

          <SegmentContainer>
            <>
              <ANDFilterContainer
                segmentFilters={segmentFilters}
                andSubFilterConditions={andSubFilterConditions}
                setAndSubFilterConditions={setAndSubFilterConditions}
                getAndSubFiltersValues={getAndSubFiltersValues}
                orGroupIndex={orGroupIndex}
                orConditionDataForAnd={orFilterData}
              />
            </>
          </SegmentContainer>
        </>
      )}
    </>
  );
};

export default ANDSubFilters;
