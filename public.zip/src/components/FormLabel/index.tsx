import { FormLabel } from '@chakra-ui/react';
import styled from '@emotion/styled';

export default styled(FormLabel)`
  line-height: 1.25rem;
`;
