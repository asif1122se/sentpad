import React, { useRef, useState } from 'react';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Box,
  Button,
  Flex,
  Text,
  Select,
  InputGroup,
  Icon,
  InputRightElement,
  Input,
} from '@chakra-ui/react';
import { ChevronLeftIcon, ChevronRightIcon, CloseIcon, SearchIcon } from '@chakra-ui/icons';
import {
  useReactTable,
  flexRender,
  getCoreRowModel,
  ColumnDef,
  SortingState,
  getSortedRowModel,
  getPaginationRowModel,
  OnChangeFn,
} from '@tanstack/react-table';
import { IoFunnelOutline } from 'react-icons/io5';
import styled from '@emotion/styled';

import { ColumnProps } from 'types/general';
import PageFilters from 'components/Filters';
import { PAGINATION_PAGE_SIZES } from 'utils/constants';

const StyledTr = styled(Tr)<{ islast: boolean; isclickable: boolean }>`
  ${({ islast }) => islast && 'border-bottom: none;'};
  ${({ isclickable }) => isclickable && 'cursor: pointer;'}
`;

export type DataTableProps<T> = {
  data?: T[];
  columns: ColumnDef<T, any>[];
  getValue: (value: string) => void;
  colProps: ColumnProps[];
  onRowClick?: (row: T) => void;
  rowSelection?: T;
  setRowSelection?: OnChangeFn<T>;
  emptyMessage: string;
  rightToolbar?: JSX.Element;
  showPageSizeMenu?: boolean;
  showSearch?: boolean;
  showFilters?: boolean;
  showPagination?: boolean;
  filterIndex?: number;
  values?: any;
  setValues?: any;
  title?: string;
  boldFirstRow?: boolean;
  maxLength?: string | number;
};

const DataTable = ({
  data = [],
  columns,
  getValue,
  colProps,
  onRowClick,
  rowSelection,
  setRowSelection,
  emptyMessage,
  rightToolbar,
  showPageSizeMenu = false,
  showSearch = false,
  showFilters = true,
  showPagination = true,
  filterIndex = 0,
  values,
  setValues,
  title,
  maxLength,
}: DataTableProps<any>) => {
  const [sorting, setSorting] = React.useState<SortingState>([]);

  const table = useReactTable({
    columns,
    data,
    getCoreRowModel: getCoreRowModel(),
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onRowSelectionChange: setRowSelection,
    state: {
      sorting,
      rowSelection,
    },
    initialState: {
      pagination: {
        pageIndex: 0,
        pageSize: PAGINATION_PAGE_SIZES[0],
      },
    },
  });

  const [page, setPage] = useState(0);
  const [flagSearch, setFlagSearch] = useState<boolean>(false);
  const [isSearch, setIsSearch] = useState<boolean>(false);
  const [searchValue, setSearchValue] = useState<any>('');
  const [openMainDrawer, setOpenMainDrawer] = useState<boolean>(false);

  const handleChange = (e: any, flag: string) => {
    if (flag == 'remove') {
      getValue('');
      setIsSearch(false);
    } else {
      getValue(e.target.value);
      setIsSearch(e.target.value ? true : false);
    }
  };

  const inputRef = useRef<HTMLInputElement | null>(null);
  const handleFocus = () => {
    inputRef?.current?.focus();
  };

  return (
    <Box width={'100%'}>
      <PageFilters
        filterIndex={filterIndex}
        openDrawer={openMainDrawer}
        setOpenDrawer={setOpenMainDrawer}
        values={values}
        setValues={setValues}
        onClickFilter={() => null}
      />
      <Flex justifyContent={title ? 'space-between' : 'flex-end'} alignItems='center' mb='2'>
        {title && (
          <Text fontSize='lg' fontWeight='bold'>
            {title}
          </Text>
        )}
        <Flex></Flex>
        <Flex>
          {showPageSizeMenu && (
            <Flex alignItems='center'>
              <Text
                fontSize='sm'
                fontWeight='500'
                color='blackAlpha.900'
                whiteSpace='nowrap'
                alignItems='center'>
                Show rows
              </Text>
              <Select
                ml='2'
                borderColor='blackAlpha.600'
                width='fit-content'
                height='40px'
                fontSize='sm'
                textAlign='center'
                color='blackAlpha.900'
                value={table.getState().pagination.pageSize}
                onChange={(e) => {
                  table.setPageSize(Number(e.target.value));
                }}>
                {PAGINATION_PAGE_SIZES.map((pageSize) => (
                  <option key={pageSize} value={pageSize}>
                    {pageSize}
                  </option>
                ))}
              </Select>
            </Flex>
          )}
          <Flex alignItems='center'>
            {showSearch && (
              <Box h='10' display='inline-block' flexDirection='row' mx='2' alignItems='center'>
                <InputGroup>
                  {(flagSearch && (
                    <Input
                      autoFocus
                      ref={inputRef}
                      type='text'
                      value={searchValue}
                      fontSize='sm'
                      placeholder='Enter to search'
                      onChange={(e) => {
                        getValue(e.target.value);
                        setSearchValue(e.target.value);
                        setIsSearch(e.target.value ? true : false);
                      }}
                      width='250px'
                      h='10'
                      pr='35px'
                      borderColor='blackAlpha.600'
                    />
                  )) || <Box ml='10' />}
                  <InputRightElement>
                    {!isSearch ? (
                      <SearchIcon
                        cursor='pointer'
                        as='button'
                        color='gray.800'
                        onClick={() => {
                          setFlagSearch(!flagSearch);
                        }}
                      />
                    ) : (
                      <CloseIcon
                        boxSize='3'
                        onChange={(e) => {
                          handleChange(e, 'cross');
                        }}
                        onClick={() => {
                          setSearchValue('');
                          getValue('');
                          setIsSearch(false);
                          handleFocus();
                        }}
                      />
                    )}
                  </InputRightElement>
                </InputGroup>
              </Box>
            )}
          </Flex>

          <Flex alignItems='center' justifyContent='center' gap='2'>
            {showFilters && (
              <Icon
                boxSize='5'
                color='gray.800'
                mr='2'
                as={IoFunnelOutline}
                onClick={() => setOpenMainDrawer(true)}
                cursor='pointer'
              />
            )}
            {rightToolbar}
          </Flex>
        </Flex>
      </Flex>
      <Box
        border='1px solid'
        borderColor='gray.400'
        borderRadius='6px'
        width={'100%'}
        overflow={'auto'}>
        <Table borderWidth='0' borderColor='gray.400' mt='1'>
          <Thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <Tr key={headerGroup.id}>
                {headerGroup.headers.map((header, index) => {
                  // see https://tanstack.com/table/v8/docs/api/core/column-def#meta to type this correctly
                  const meta: any = header.column.columnDef.meta;
                  return (
                    <Th
                      fontWeight='600'
                      fontSize='sm'
                      color='black'
                      borderBottomColor='gray.400'
                      width={colProps[index].width}
                      px={colProps[index].paddingX}
                      pl={colProps[index].paddingLeft}
                      pr={colProps[index].paddingRight}
                      key={header.id}
                      textAlign={colProps[index]?.align as any}
                      onClick={header.column.getToggleSortingHandler()}
                      isNumeric={meta?.isNumeric}>
                      {flexRender(header.column.columnDef.header, header.getContext())}
                      {/* <chakra.span >
                        {header.column.getIsSorted() ? (
                          header.column.getIsSorted() === 'desc' ? (
                            <TriangleDownIcon aria-label='sorted descending' />
                          ) : (
                            <TriangleUpIcon aria-label='sorted ascending' />
                          )
                        ) : null}
                      </chakra.span> */}
                    </Th>
                  );
                })}
              </Tr>
            ))}
          </Thead>
          <Tbody borderTopWidth='2px' borderTopColor='gray.400'>
            {table.getRowModel().rows.map((row, index) => (
              <StyledTr
                key={row.id}
                islast={index === table.getRowModel().rows.length - 1}
                isclickable={!!onRowClick}
                onClick={() => onRowClick && onRowClick(row.original)}>
                {row.getVisibleCells().map((cell, index) => {
                  // see https://tanstack.com/table/v8/docs/api/core/column-def#meta to type this correctly
                  const meta: any = cell.column.columnDef.meta;
                  const boldTitle = index > 0 ? '500' : '600';

                  return (
                    <Td
                      key={cell.id}
                      px={colProps[index].paddingX as any}
                      pl={colProps[index].paddingLeft as any}
                      pr={colProps[index].paddingRight as any}
                      wordBreak={colProps[index].wordBreak as any}
                      fontWeight={boldTitle}
                      fontSize='sm'
                      alignItems='center'
                      textAlign={colProps[index].align as any}
                      paddingY='2'
                      isNumeric={meta?.isNumeric}
                      borderColor='gray.400'
                      borderBottomWidth='1px'>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </Td>
                  );
                })}
              </StyledTr>
            ))}
          </Tbody>
        </Table>
        {data?.length === 0 && (
          <Box textAlign='center'>
            <Text my='3' fontSize='md' color='gray.600' fontWeight='500'>
              {emptyMessage}
            </Text>
          </Box>
        )}
      </Box>
      {showPagination && (
        <Flex alignItems='center' justifyContent='center' mt='3'>
          <Flex alignItems='center'>
            <Text
              mt='1'
              fontSize='sm'
              fontWeight='400'
              whiteSpace='nowrap'
              alignItems='center'
              mr='1'>
              Go to:
            </Text>
            <Select
              ml='2'
              borderColor='blackAlpha.600'
              width='fit-content'
              height='40px'
              fontSize='sm'
              textAlign='center'
              color='blackAlpha.900'
              value={page}
              onChange={(e) => {
                table.setPageIndex(parseInt(e.target.value));
                setPage(parseInt(e.target.value));
              }}>
              {table.getPageOptions().map((option) => (
                <option key={option} value={option}>
                  {option + 1}
                </option>
              ))}
            </Select>
          </Flex>
          <Text fontSize='sm' mt='1' mx='2' fontWeight='400' letterSpacing='0.5px'>
            {table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1} -{' '}
            {table.getState().pagination.pageIndex * table.getState().pagination.pageSize +
              table.getRowModel().rows.length}{' '}
            of {maxLength ?? data.length}
          </Text>
          <Box height='32px'>
            <Button
              ml='2'
              w='32px'
              minW='32px'
              h='32px'
              padding='0'
              background='transparent linear-gradient(180deg, #FFFFFF 0%, #E8EBEE 100%) 0% 0% no-repeat padding-box;'
              borderWidth='1px'
              borderRightRadius='0'
              borderColor='gray.500'
              onClick={() => {
                table.previousPage();
                setPage(page - 1);
              }}
              isDisabled={!table.getCanPreviousPage()}>
              <ChevronLeftIcon w='24px' h='24px' />
            </Button>
            <Button
              ml='0'
              w='32px'
              minW='32px'
              h='32px'
              background='transparent linear-gradient(180deg, #FFFFFF 0%, #E8EBEE 100%) 0% 0% no-repeat padding-box;'
              borderWidth='1px'
              borderLeftRadius='0'
              borderColor='gray.500'
              onClick={() => {
                table.nextPage();
                setPage(page + 1);
              }}
              isDisabled={!table.getCanNextPage()}>
              <ChevronRightIcon w='24px' h='24px' />
            </Button>
          </Box>
        </Flex>
      )}
    </Box>
  );
};

export default DataTable;
