import { Button, Flex, Heading, Text } from '@chakra-ui/react';

type PageHeaderProps = {
  title: string;
  subtitle?: string;
  buttonLabel?: string;
  onClick?: () => void;
  variant?: string;
};

const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  subtitle,
  buttonLabel,
  variant = 'black',
  onClick,
}: PageHeaderProps) => {
  return (
    <Flex justifyContent='space-between' mb='2rem'>
      <Flex flexDirection='column'>
        {subtitle && <Text lineHeight='1.25rem'>{subtitle}</Text>}
        <Heading as='h1' fontSize='2rem' lineHeight='2.438rem'>
          {title}
        </Heading>
      </Flex>

      {buttonLabel && (
        <Button variant={variant} fontSize='14px' px='22px' onClick={onClick}>
          {buttonLabel}
        </Button>
      )}
    </Flex>
  );
};

export default PageHeader;
