import { Box, Flex, Image } from '@chakra-ui/react';
import NavMenu from './NavMenu';
import SendPadLogo from 'assets/images/sendpad-logo.svg';
import SidebarExpandIcon from 'assets/icons/sidebar-expand.svg';
import AccountSettings from './AccountSettings';

const Sidebar: React.FC = () => (
  <Flex
    flexDirection='column'
    justifyContent='space-between'
    background='#F4F0F7 0% 0% no-repeat padding-box'
    boxShadow='inset -12px 0px 25px #717C8D1A'
    w='250px'
    h='100%'
    p='16px'
    position='absolute'
    overflow={'hidden'}>
    <Box>
      <Flex p='21px 16px 30px' justifyContent='space-between' alignItems='center'>
        <Image src={SendPadLogo} alt='SendPad Logo' />
        {/* <Image src={SidebarExpandIcon} alt='Sidebar Expand Icon' /> */}
      </Flex>
      <NavMenu />
    </Box>
    <AccountSettings />
  </Flex>
);

export default Sidebar;
