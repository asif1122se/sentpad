import {
  AUDIENCE,
  AUTORESPONDER,
  CONTACTS,
  DASHBOARD,
  IMPORT_AND_EXPORT,
  LISTS,
  OVERVIEW,
  SEGMENTS,
  SENDER_PROFILE,
  LOGOUT,
  BROADCAST,
  FORMS,
} from 'consts';
import { NavMenuType } from './types';
import DashboardIcon from 'assets/icons/dashboard.svg';
import AudienceIcon from 'assets/icons/audience.svg';
import BroadcastIcon from 'assets/icons/broadcast.svg';
import AutomationIcon from 'assets/icons/automation.svg';
import FormsIcon from 'assets/icons/forms-inactive.svg';
import IntegrationsIcon from 'assets/icons/integrations.svg';

import AccountIcon from 'assets/icons/navigation/account.svg';
import SecurityIcon from 'assets/icons/navigation/security.svg';
import UsersIcon from 'assets/icons/navigation/users.svg';
import BillingIcon from 'assets/icons/navigation/billing.svg';
import DomainSetupIcon from 'assets/icons/navigation/domain-setup.svg';
import TrackingIcon from 'assets/icons/navigation/tracking.svg';
import APIIcon from 'assets/icons/navigation/api.svg';

import AccountActiveIcon from 'assets/icons/navigation/account-active.svg';
import SecurityActiveIcon from 'assets/icons/navigation/security-active.svg';
import UsersActiveIcon from 'assets/icons/navigation/users-active.svg';
import BillingActiveIcon from 'assets/icons/navigation/billing-active.svg';
import DomainSetupActiveIcon from 'assets/icons/navigation/domain-setup-active.svg';
import TrackingActiveIcon from 'assets/icons/navigation/tracking-active.svg';
import APIActiveIcon from 'assets/icons/navigation/api-active.svg';
import LogoutIcon from 'assets/icons/navigation/logout-icon.png';
import ROUTE_PATHS from 'router/routePaths';
import config from 'config';

export const NAV_LIST: NavMenuType[] = [
  {
    title: DASHBOARD,
    icon: DashboardIcon,
    path: '/',
  },
  {
    title: AUDIENCE,
    icon: AudienceIcon,
    submenu: [
      // {
      //   title: OVERVIEW,
      //   path: ROUTE_PATHS.HOME,
      // },
      {
        title: CONTACTS,
        path: `/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.CONTACTS}`,
      },
      {
        title: LISTS,
        path:
          localStorage.getItem('email') === config.demoUser
            ? `/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.LISTS_SAMPLE}`
            : `/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.LISTS}`,
      },
      {
        title: SEGMENTS,
        path: `/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.SEGMENTS}`,
      },
      {
        title: SENDER_PROFILE,
        path: `/${ROUTE_PATHS.AUDIENCE}/${ROUTE_PATHS.SENDER_PROFILE}`,
      },
    ],
  },
  {
    title: BROADCAST,
    icon: BroadcastIcon,
    path:
      localStorage.getItem('email') === config.demoUser
        ? `/${ROUTE_PATHS.BROADCAST_ANALYTICS}`
        : `/${ROUTE_PATHS.BROADCAST}`,
  },
  {
    title: AUTORESPONDER,
    path:
      localStorage.getItem('email') === config.demoUser
        ? `${ROUTE_PATHS.SAMPLE_AUTORESPONDER}`
        : ROUTE_PATHS.AUTORESPONDER,
    icon: AutomationIcon,
  },
  {
    title: FORMS,
    path: ROUTE_PATHS.FORMS,
    icon: FormsIcon,
  },
];

const path = location.pathname.split('/account-settings/');

export const GENERAL = [
  {
    icon: BillingIcon,
    iconActive: BillingActiveIcon,
    label: 'Billing',
    url: ROUTE_PATHS.BILLING_PATH,
    active: [ROUTE_PATHS.BILLING_PATH, ROUTE_PATHS.CHANGE_PLAN].indexOf(path[1]) >= 0,
  },
  {
    icon: DomainSetupIcon,
    iconActive: DomainSetupActiveIcon,
    label: 'Domain Setup',
    url: '/account-settings/domain-setup',
    active: false,
  },
  {
    icon: UsersIcon,
    iconActive: UsersActiveIcon,
    label: 'Opt in Settings',
    url: '/account-settings/opt-in',
    active: false,
  },
];

export const AUTOMATION = [
  {
    icon: DomainSetupIcon,
    iconActive: DomainSetupActiveIcon,
    label: 'Domain Setup',
    url: '/account-settings/domain-setup',
    active: false,
  },
  {
    icon: TrackingIcon,
    iconActive: TrackingActiveIcon,
    label: 'Tracking',
    url: '',
    active: false,
  },
  {
    icon: APIIcon,
    iconActive: APIActiveIcon,
    label: 'API',
    url: '',
    active: false,
  },
];

export const LOGOUT_MENU = {
  icon: LogoutIcon,
  iconActive: DomainSetupActiveIcon,
  label: 'Logout',
  url: '/signin',
  active: false,
};
