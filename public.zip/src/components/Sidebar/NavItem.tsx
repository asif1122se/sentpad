import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { Box, Button, Collapse, Text, Image } from '@chakra-ui/react';
import { NavMenuType, SubMenuType } from './types';
import { LOGOUT } from 'consts';
import { useStoreState, useStoreActions } from 'redux';
import { removeEmptyProperties } from 'utils';

const NavItem: React.FC<{ menu: NavMenuType }> = ({ menu }: { menu: NavMenuType }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);
  const modalAction = useStoreActions((actions) => actions.modal.add);

  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleOnClick = async (menu: any) => {
    if (window.location.pathname == '/broadcast/new') {
      modalAction({
        name: 'broadcast',
        url: ['autoresponder', 'forms'].includes(menu.path) ? `/${menu.path}` : menu.path,
      });
    }
    if (menu.title === LOGOUT) {
      localStorage.removeItem('jwtToken');
      navigate('/signin');
    }
    if (menu.title === LOGOUT && window.location.pathname == '/broadcast/new') {
      modalAction({ name: 'broadcast', url: '/signin' });
      localStorage.removeItem('jwtToken');
    }
    if (window.location.pathname !== '/broadcast/new') {
      navigate(menu.path);
    }
  };

  return (
    <>
      <Box>
        <Button
          variant='link'
          onClick={() => {
            !menu?.path && setIsCollapsed(!isCollapsed);
            menu?.path && handleOnClick(menu);
          }}
          color='gray.900'
          height='40px'
          fontWeight='normal'>
          {menu?.icon && <Image src={menu.icon} alt='icon' />}
          <Box ml='18px'>{menu.title}</Box>
        </Button>
      </Box>
      <Collapse in={isCollapsed} unmountOnExit>
        <Box>
          {menu.submenu?.map((elem: SubMenuType) => (
            <div key={elem?.title} onClick={() => handleOnClick({ path: elem?.path })}>
              <Button
                variant='link'
                textDecoration={'none!important'}
                color='gray.900'
                fontWeight='normal'>
                <Box>
                  <Text
                    ml='42px'
                    color='gray.900'
                    fontSize='sm'
                    fontWeight='normal'
                    height='1.5rem'>
                    {elem?.title}
                  </Text>
                </Box>
              </Button>
            </div>
          ))}
        </Box>
      </Collapse>
    </>
  );
};

export default NavItem;
