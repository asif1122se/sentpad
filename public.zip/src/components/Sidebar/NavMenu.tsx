import NavItem from './NavItem';
import { Box, Flex } from '@chakra-ui/react';
import { NAV_LIST } from './consts';

const NavMenu = () => {
  return (
    <>
      <Flex flexDirection='column' justifyContent='space-between' width='100%'>
        <Box px='1rem'>
          {NAV_LIST.map((navItem) => (
            <NavItem key={navItem.title} menu={navItem} />
          ))}
        </Box>
      </Flex>
    </>
  );
};

export default NavMenu;
