import { useState } from 'react';
import { Box, Button, Menu, MenuButton, Flex, MenuList, Text, Image, Link } from '@chakra-ui/react';
import AccountIcon from 'assets/icons/navigation/account.svg';
import { NavItem } from '../../../src/pages/Account/styles';
import { GENERAL, AUTOMATION, LOGOUT_MENU } from './consts';
import ArrowIcon from 'assets/icons/icon-down-arrow.svg';
import { useNavigate } from 'react-router';

const AccountSettings: React.FC = () => {
  const navigate = useNavigate();
  const [rotateIcon, setRotateIcon] = useState<boolean>(true);
  const style = {
    transform: rotateIcon ? 'rotate(180deg)' : '',
    transition: 'transform 150ms ease',
  };
  const path = location.pathname;

  return (
    <>
      <Box>
        <Menu closeOnSelect={false}>
          {({ onClose }) => (
            <>
              <MenuButton
                ml='12px'
                onClick={() => {
                  setRotateIcon(!rotateIcon);
                }}>
                <Flex>
                  <Button variant='link' color='gray.900' fontWeight='normal'>
                    <Image src={AccountIcon} alt='icon' height='33px' />
                    <Box ml='13px'>My Account</Box>
                  </Button>
                  <Image margin='5px' style={style} src={ArrowIcon} alt='icon' />
                </Flex>
              </MenuButton>
              <MenuList fontSize='sm' color='black' minWidth='210px' width='fit-content'>
                <Flex gap='4rem' ml='48px'>
                  <Flex flexDir='column' width='126px'>
                    <Flex flexDir='column' ml='-30px'>
                      {GENERAL.map(({ active, icon, iconActive, label, url }, index) => (
                        <>
                          <Flex>
                            <Link>
                              <Image
                                mt='5px'
                                src={active ? iconActive : icon}
                                alt={label}
                                onClick={() => {
                                  navigate(`${url}`);
                                  onClose();
                                  setRotateIcon(!rotateIcon);
                                }}
                              />
                            </Link>
                            <NavItem
                              key={index}
                              active={active}
                              to={url}
                              onClick={() => {
                                onClose();
                                setRotateIcon(!rotateIcon);
                              }}>
                              {label}
                            </NavItem>
                          </Flex>
                        </>
                      ))}
                    </Flex>
                  </Flex>
                </Flex>
                <Box borderTop='1px solid' borderColor='gray.300' pt='24px' mt='8px'>
                  <Flex
                    mt='-15px'
                    flexDir='column'
                    ml='19px'
                    onClick={() => localStorage.removeItem('jwtToken')}>
                    <Flex>
                      <Link>
                        <Image
                          mt='5px'
                          src={LOGOUT_MENU.active ? LOGOUT_MENU.iconActive : LOGOUT_MENU.icon}
                          alt={LOGOUT_MENU.label}
                        />
                      </Link>
                      <NavItem active={LOGOUT_MENU.active} to={LOGOUT_MENU.url}>
                        {LOGOUT_MENU.label}
                      </NavItem>
                    </Flex>
                  </Flex>
                </Box>
              </MenuList>
            </>
          )}
        </Menu>
      </Box>
    </>
  );
};
export default AccountSettings;
