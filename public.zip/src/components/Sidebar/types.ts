export type SubMenuType = {
  title: string;
  path: string;
};

export type NavMenuType = {
  title: string;
  path?: string;
  submenu?: SubMenuType[];
  icon?: string;
};
