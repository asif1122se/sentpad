import { Box } from '@chakra-ui/react';
import { ProfileDetailLabel, ProfileDetailValue } from './styles';

type DetailLabelValueProps = {
  name?: string;
  label: string;
  value?: string | number | null;
  width?: string;
  mr?: string;
};

const DetailLabelValue = ({ label, value, width, mr }: DetailLabelValueProps) => (
  <Box width={width} mr={mr}>
    <ProfileDetailLabel>{label}</ProfileDetailLabel>
    <ProfileDetailValue>{value ? value : '-'}</ProfileDetailValue>
  </Box>
);

export default DetailLabelValue;
