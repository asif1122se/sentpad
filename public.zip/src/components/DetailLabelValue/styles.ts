import styled from '@emotion/styled';
import { Text } from '@chakra-ui/react';

export const ProfileDetailLabel = styled(Text)`
  line-height: 17px;
  font-size: 14px;
  opacity: 1;
  margin: 0.25rem;
  color: #929ba8;
`;

export const ProfileDetailValue = styled(Text)`
  font-weight: bold;
  font-size: 16px;
  line-height: 20px;
  opacity: 1;
  margin: 0.25rem;
`;
