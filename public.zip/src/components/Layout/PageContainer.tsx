import { Center, Container, ContainerProps, Spinner } from '@chakra-ui/react';

type PageContainerProps = ContainerProps & {
  loading?: boolean;
  children: React.ReactNode;
};

const PageContainer: React.FC<PageContainerProps> = ({
  loading,
  children,
  ...restProps
}: PageContainerProps) => (
  <Container maxW='1436px' pt='2.875rem' {...restProps}>
    {loading ? (
      <Center height='800px'>
        <Spinner w='200px' height='200px' />
      </Center>
    ) : (
      children
    )}
  </Container>
);

export default PageContainer;
