import { useState, useEffect } from 'react';
import { Box, Flex, useToast } from '@chakra-ui/react';
import { Sidebar } from 'components';
import { Outlet, useNavigate } from 'react-router-dom';
import { useGlobalLogout } from 'auth/globalLogout';
import { useStoreActions } from 'redux';
import { PlanNotifications } from './components';
import VerifySubscription from './components/VerifySubscription';
import QUERY_KEYS from 'utils/queryKeys';
import { useQuery } from 'hooks/useQuery';
import { IsSubscribed } from './types';
import { useQueryClient } from '@tanstack/react-query';

import { checkSubscriptionApi, verifiedSuccessApi } from 'services/apis/subscription';

const GlobalLayout = () => {
  const [isReload] = useGlobalLogout();
  const modalAction = useStoreActions((actions) => actions.modal.add);
  const [showVerifMsg, setShowVerifMsg] = useState<boolean>(false);
  const [toastMsg, setToastMsg] = useState<string>('');
  const [showIcon, setShowIcon] = useState<boolean>(false);

  const navigate = useNavigate();
  const { data } = useQuery<IsSubscribed>({
    url: 'plans/current-plan',
    queryKey: [QUERY_KEYS.IS_SUBSCRIBED],
    enabled: localStorage.getItem('jwtToken') ? true : false,
    onSuccess: (data) => {
      localStorage.setItem('email', `${data?.email}`);
      if (!data?.email_verified) {
        navigate('/signin');
      } else if (!data?.exists) {
        navigate(`/subscription?authtoken=${localStorage.getItem('jwtToken')}`);
      }
    },
  });

  const showWelcomeMsg = () => {
    if (window.location.search?.split('?setup=')[1] == 'complete') {
      setToastMsg('Welcome to Sendpad! We have completed your account setup.');
      setShowIcon(true);
      setShowVerifMsg(true);
      setTimeout(() => {
        setShowVerifMsg(false);
      }, 5000);
    }
  };

  useEffect(() => {
    modalAction({});
    isReload && window.location.reload();
    showWelcomeMsg();
  }, [isReload]);

  return (
    <Flex
      flexDirection={'column'}
      minH='500px'
      height='100%'
      width='100%'
      padding='0'
      margin='0'
      color='blackAlpha.700'
      overflow={'auto'}
      fontWeight='bold'>
      <Flex>
        <Box minHeight={window.innerHeight * 0.995 + 'px'} minWidth='250px' flexGrow={'1'}>
          <Sidebar />
        </Box>
        <Box width='100%' flexGrow={'1'}>
          {/* <PlanNotifications /> */}
          {showVerifMsg && (
            <>
              <VerifySubscription
                toastMsg={toastMsg}
                setShowVerifMsg={setShowVerifMsg}
                showIcon={showIcon}
              />
            </>
          )}
          <Outlet />
        </Box>
      </Flex>
    </Flex>
  );
};

export default GlobalLayout;
