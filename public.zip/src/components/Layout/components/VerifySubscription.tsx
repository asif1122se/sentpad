import { Flex, Text } from '@chakra-ui/react';
import { Cross } from 'pages/Auth/Registration/styles';

const VerifySubscription = ({ toastMsg, setShowVerifMsg, showIcon }: any) => {
  return (
    <>
      <Flex
        width='100%'
        background='#F7EBED'
        py='3px'
        alignItems='center'
        justifyContent='center'
        height='48px'
        zIndex={999}>
        <Flex color='#CD1849' justifyContent='center' alignItems='center' gap='5px' fontSize='sm'>
          <Text color='#00BF9C'>{toastMsg}</Text>
          {showIcon && <Cross onClick={() => setShowVerifMsg(false)} />}
        </Flex>
      </Flex>
    </>
  );
};

export default VerifySubscription;
