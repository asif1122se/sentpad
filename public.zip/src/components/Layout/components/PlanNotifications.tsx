import { Button, chakra, Flex, Image, Text } from '@chakra-ui/react';
import InfoDanger from 'assets/icons/info-red.png';
import { useQuery } from 'hooks/useQuery';
import QUERY_KEYS from 'utils/queryKeys';
import { TrueOrFalse } from 'types';

const PlanNotifications = () => {
  // const { data } = useQuery<{ is_subscribe: TrueOrFalse }>({
  //   url: 'contact/check-subscription',
  //   queryKey: [QUERY_KEYS.CHECK_SUBSCRIPTION],
  // });

  return (
    <>
      {/* {data?.is_subscribe === 1 && ( */}
      <Flex
        width='100%'
        background='#F7EBED'
        py='3px'
        alignItems='center'
        justifyContent='center'
        height='48px'
        zIndex={999}>
        <Flex color='#CD1849' justifyContent='center' alignItems='center' gap='5px' fontSize='sm'>
          <Image src={InfoDanger} mr='1' />
          <Text color='#CD1849'>
            You have reached your <chakra.span fontWeight='bold'>subscription limit</chakra.span>.
            Please upgrade your subscription.
          </Text>
          <Button variant='dangerOutlined' size='sm'>
            Upgrade Plan
          </Button>
        </Flex>
      </Flex>
      {/* )} */}
      {/* <Box textAlign='right' width='340px'>
        <Text width='100%' fontSize='sm'>
          Temporary links to access these pages
        </Text>
        <Button mr='1' variant='outlined' size='sm'>
          Plan Canceled
        </Button>
        <Button my='1' variant='outlined' size='sm'>
          95% Reached
        </Button>
        <Button variant='outlined' size='sm' onClick={() => setIsLimitOpen(true)}>
          Limit Reached
        </Button>
        <Button ml='1' variant='outlined' onClick={onOpen} size='sm'>
          Limit Reached Popup
        </Button>
      </Box> */}
    </>
  );
};

export default PlanNotifications;
