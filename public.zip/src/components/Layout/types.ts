export type IsSubscribed = {
  exists: string;
  email_verified: boolean;
  email: string;
};
