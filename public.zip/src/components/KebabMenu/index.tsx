import { Flex, Icon, Menu, MenuButton, MenuItem, MenuList } from '@chakra-ui/react';
import { GoKebabVertical } from 'react-icons/go';

type KebabMenuItem = {
  label: string;
  disabled?: boolean;
  onClick?: React.MouseEventHandler<HTMLButtonElement> | undefined;
};

type KebabMenuProps = {
  menu: KebabMenuItem[];
  width?: string;
  height?: string;
  transparent?: boolean;
};

const KebabMenu = ({ menu, width, height, transparent }: KebabMenuProps) => {
  return (
    <Menu closeOnSelect={false}>
      {({ onClose }) => (
        <>
          <MenuButton>
            <Flex
              background={!transparent ? 'gray.300' : undefined}
              w={width ?? '10'}
              h={height ?? '10'}
              borderRadius='4px'
              justifyContent='center'
              alignItems='center'>
              <Icon height={height ?? '18px'} color='gray.600' as={GoKebabVertical} />
            </Flex>
          </MenuButton>
          <MenuList
            fontSize='sm'
            borderColor='gray.400'
            color='black'
            minWidth='110px'
            width='fit-content'>
            {menu.map(({ label, disabled, onClick }) => (
              <MenuItem
                key={label}
                fontWeight='500'
                isDisabled={disabled}
                color={disabled ? 'gray.600' : undefined}
                cursor={disabled ? 'not-allowed' : undefined}
                onClick={(e) => {
                  if (!disabled) {
                    onClick && onClick(e);
                    onClose();
                  }
                }}>
                {label}
              </MenuItem>
            ))}
          </MenuList>
        </>
      )}
    </Menu>
  );
};

export default KebabMenu;
