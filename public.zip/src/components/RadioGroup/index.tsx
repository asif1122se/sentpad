import { RadioGroup } from '@chakra-ui/react';
import styled from '@emotion/styled';

export default styled(RadioGroup)`
  .chakra-radio {
    &__label {
      font-size: 14px;
      line-height: 24px;
    }
  }
`;
