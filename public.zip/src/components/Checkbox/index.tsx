import { Checkbox } from '@chakra-ui/react';
import styled from '@emotion/styled';
import { HTMLProps, useRef, useEffect } from 'react';

export default styled(Checkbox)`
  font-weight: 500;

  .chakra-checkbox {
    &__control {
      width: 20px;
      height: 20px;
      border: 1px solid;
      border-color: var(--chakra-colors-gray-600);
      border-radius: 4px;

      &[data-checked],
      &[aria-checked='true'] {
        background: var(--chakra-colors-blue-700);
        border-color: var(--chakra-colors-blue-700);
      }
    }

    &__label {
      font-size: 14px;
      font-weight: 400;
      line-height: 24px;
      color: var(--chakra-colors-black);
    }
  }
`;

export const IndeterminateCheckbox = ({
  indeterminate,
  className = '',
  ...rest
}: { indeterminate?: boolean } & HTMLProps<HTMLInputElement>) => {
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const ref = useRef<HTMLInputElement>(null!);

  useEffect(() => {
    if (typeof indeterminate === 'boolean') {
      ref.current.indeterminate = !rest.checked && indeterminate;
    }
  }, [ref, indeterminate]);

  return (
    <input
      type='checkbox'
      ref={ref}
      className={className + ' cursor-pointer'}
      style={{ cursor: 'pointer' }}
      onClick={(e) => e.stopPropagation()}
      {...rest}
    />
  );
};
