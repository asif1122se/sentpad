import { Flex, FormLabelProps, Select as CUISelect, SelectProps, Text } from '@chakra-ui/react';
import FormLabel from 'components/FormLabel';
import { ErrorProps } from 'types';

type CustomSelectProps = SelectProps & {
  label?: string;
  errorText?: string;
  errorProps?: ErrorProps;
  labelProps?: FormLabelProps;
};

const Select = ({
  label,
  size,
  labelProps,
  errorText,
  errorProps,
  ...restProps
}: CustomSelectProps) => {
  return (
    <Flex flexDirection='column'>
      {label && (
        <FormLabel color='black' {...labelProps}>
          {label}
        </FormLabel>
      )}
      <CUISelect
        borderColor={!!errorText ? 'red.700' : 'gray.600'}
        color='gray.800'
        fontWeight='medium'
        fontSize='1rem'
        size={size ?? 'lg'}
        borderWidth={!!errorText ? '2px' : '1px'}
        {...restProps}
      />
      {errorText && (
        <Text color='red.700' mt='8px' fontWeight='medium' {...errorProps}>
          {errorText}
        </Text>
      )}
    </Flex>
  );
};

export default Select;
