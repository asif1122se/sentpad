import { Radio } from '@chakra-ui/react';
import styled from '@emotion/styled';

export default styled(Radio)`
    width: 20px;
    height: 20px;
    border: 1px solid var(--chakra-colors-gray-600);

    &[data-checked], &[aria-checked=true] {
      background: var(--chakra-colors-blue-700);
      border-color: var(--chakra-colors-blue-700);

      &::before {
        width: 10px;
        height: 10px;
      }
    }
  }
`;
