export const blankContent = {
  content: `<table style="padding: 5px; min-height: 300px; vertical-align: middle; width: 100%; height: 100%; margin: auto; font-family: Arial, sans-serif">
      <tr>
        <td style="vertical-align: middle;">
          <table style="margin: 0 auto; text-align:center; ">
            <tr>
              <td>
                <div>
                  <span style="font-size: 24px; font-weight: bold">Begin designing your email.</span>
                  <br />
                  <br />
                  Start by dragging a section to your desired location from the menu on the right.
                  <br />
                  <br />
                  Within a section, you can add text, images, and buttons from the content menu.
                </div>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>`,
  thumbnail: 'https://i.ibb.co/wgg64nb/blank.png',
};

export const notifyTemplateContent = {
  content: `<div
     style="
          width: 100%;
          height: 100%;
          text-align: center;
          font-family: Poppins, sans-serif;
          color: #000000;
          background: #ffffff 0% 0% no-repeat padding-box;
         
     "
>
     <table
          style="
               width: 620px;
               padding: 10px 15px;
               text-align: center;
               margin: 0 auto;
               background: #ffffff 0% 0% no-repeat padding-box;
          "
     >
          <tr>
               <td>
                    <img
                         style="margin: 20px auto"
                         src="https://i.ibb.co/x7YWjgH/notify.png"
                         width="85px"
                         height="28px"
                    />
               </td>
          </tr>
          <tr>
               <td>
                    <img
                         src="https://i.ibb.co/6m4X06P/notify-banner.png"
                         alt=""
                         width="100%"
                         height="340px"
                         style="
                              width: 100%;
                              margin-top: 10px;
                              object-fit: cover;
                         "
                    />
               </td>
          </tr>
          <tr>
               <td style="text-align: left">
                    <div
                         style="
                              font-weight: bold;
                              font-size: 20px;
                              line-height: 40px;
                              margin: 18px 0;
                         "
                    >
                         Hello, John Smith
                    </div>
               </td>
          </tr>
          <tr>
               <td style="text-align: left">
                    <div style="font-size: 18px; margin-bottom: 18px">
                         You are now subscribed to our email campaigns. You will
                         receive our weekly newsletter containing new products,
                         special deals, and exclusive discounts.
                    </div>
               </td>
          </tr>
          <tr>
               <td style="text-align: left">
                    <div style="font-size: 18px; margin-bottom: 18px">
                         Check out more details by clicking the link below.
                    </div>
               </td>
          </tr>
          <tr>
               <td style="text-align: left">
                    <a href="#">
                         <span
                              style="
                                   background: #024cf4 0% 0% no-repeat
                                        padding-box;
                                   color: #fff;
                                   display: inline-block;
                                   padding: 12px 30px;
                                   font-size: 14px;
                                   font-weight: bold;
                                   border-radius: 24px;
                              "
                              >Download</span
                         ></a
                    >
               </td>
          </tr>
          <tr>
               <td>
                    <img
                         style="margin: 20px auto"
                         src="https://i.ibb.co/x7YWjgH/notify.png"
                         width="85px"
                         height="28px"
                    />
               </td>
          </tr>
          <tr>
               <td style="text-align: center; color: #12284c">
                    You can also find us on
               </td>
          </tr>
          <tr>
               <td>
                    <table
                         style="
                              margin: 15px auto;
                              display: inline;
                              text-align: center;
                         "
                    >
                         <tr>
                              <td>
                                   <img
                                        src="https://i.ibb.co/23VvWKR/facebook.png"
                                        alt="facebook"
                                   />
                              </td>
                              <td>
                                   <img
                                        src="https://i.ibb.co/rQL1JXN/twitter.png"
                                        alt="twitter"
                                   />
                              </td>
                              <td>
                                   <img
                                        src="https://i.ibb.co/ZXc2Lg4/youtube.png"
                                        alt="youtube"
                                   />
                              </td>
                              <td>
                                   <img
                                        src="https://i.ibb.co/hs1SPFh/linkedin.png"
                                        alt="linkedin"
                                   />
                              </td>
                         </tr>
                    </table>
               </td>
          </tr>
     </table>
</div>
`,
  thumbnail: 'https://i.ibb.co/ZKGj1sw/thumbnail.png',
};

export const footer = `<div
     style="
          font-family: Arial, Helvetica, sans-serif;
          width: 100%;
          text-align: center;
          margin-top: 20px;
          color: #000000;
     "
>
     <div style="text-align: center; color: #12284c">
          <div style="margin-bottom: 12px">Sender Name</div>
          <div style="margin-bottom: 12px">Sender Company</div>
          <div style="margin-bottom: 12px">
               7th Street Name, RedLight Tower, New York, NY
          </div>
          <div>
               <a href="https://app.qasendpad.tk/unsubscription">Unsubscribe</a>
          </div>
     </div>
</div>
`;
