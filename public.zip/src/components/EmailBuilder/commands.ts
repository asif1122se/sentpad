import grapesjs from 'grapesjs';
import juice from 'juice';

export const commandsPlugin = (editor: grapesjs.Editor) => {
  const cm = editor.Commands;

  cm.add('set-device-desktop', {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    run: (editor: grapesjs.Editor) => editor.setDevice('Desktop'),
  });
  cm.add('set-device-mobile', {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    run: (editor) => editor.setDevice('Mobile'),
  });
  cm.add('set-device-tablet', {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    run: (editor) => editor.setDevice('Tablet'),
  });
  cm.add('clear-html', () => editor.DomComponents.clear());

  cm.add('get-inline-html', {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    run: (editor, sender, opts = {}) => {
      const tmpl = editor.getHtml() + `<style>${editor.getCss()}</style>`;
      return juice(tmpl, opts);
    },
  });
};
