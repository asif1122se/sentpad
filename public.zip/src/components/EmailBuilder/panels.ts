import grapesjs from 'grapesjs';
import SendpadBuilderLogo from 'assets/icons/sendpad-email-builder.svg';
import ClearIcon from 'assets/icons/email-builder/clear.svg';
import UndoIcon from 'assets/icons/email-builder/undo.svg';
import RedoIcon from 'assets/icons/email-builder/redo.svg';
import DesktopIcon from 'assets/icons/email-builder/desktop.svg';
import TabletIcon from 'assets/icons/email-builder/tablet.svg';
import MobileIcon from 'assets/icons/email-builder/mobile.svg';
import PreviewIcon from 'assets/icons/email-builder/preview.svg';
import LayersIcon from 'assets/icons/email-builder/layers.svg';
import BlocksIcon from 'assets/icons/email-builder/blocks.svg';
import SettingsIcon from 'assets/icons/email-builder/settings.svg';
import StylesIcon from 'assets/icons/email-builder/styles.svg';
import BordersIcon from 'assets/icons/email-builder/borders.svg';
import CodeIcon from 'assets/icons/email-builder/code.svg';
import FullScreenIcon from 'assets/icons/email-builder/fullscreen.svg';
import ImportIcon from 'assets/icons/email-builder/import.svg';

const swv = 'sw-visibility';
const expt = 'export-template';
const osm = 'open-sm';
const otm = 'open-tm';
const ola = 'open-layers';
const obl = 'open-blocks';
const ful = 'fullscreen';
const prv = 'preview';
const undo = 'undo';
const redo = 'redo';
const clear = 'core:canvas-clear';
const impt = 'gjs-open-import-template';

const basicActionsPanel = {
  id: 'basic-actions',
  el: '.panel__basic-actions',
  buttons: [
    {
      id: 'logo',
      active: false,
      className: 'logo',
      label: `<img src=${SendpadBuilderLogo} alt="Sendpad Logo"/>`,
    },
    {
      id: 'clear',
      active: false,
      className: 'clear',
      label: `<img src=${ClearIcon} alt="Clear" />`,
      command: clear,
      attributes: {
        'data-tooltip': 'Clear',
        'data-tooltip-pos': 'bottom',
      },
    },
    {
      id: 'undo',
      active: false,
      className: 'undo',
      label: `<img src=${UndoIcon} alt="Undo" />`,
      command: undo,
      attributes: {
        'data-tooltip': 'Undo',
        'data-tooltip-pos': 'bottom',
      },
    },
    {
      id: 'redo',
      active: false,
      className: 'redo',
      label: `<img src=${RedoIcon} alt="Redo" />`,
      command: redo,
      attributes: {
        'data-tooltip': 'Redo',
        'data-tooltip-pos': 'bottom',
      },
    },
  ],
};

const viewsPanel = {
  id: 'views',
  el: '.panel__views',
  buttons: [
    {
      id: osm,
      label: `<img src=${StylesIcon} alt="Styles" />`,
      command: osm,
      active: true,
      togglable: 0,
      attributes: { title: 'Open Style Manager' },
    },
    {
      id: otm,
      label: `<img src=${SettingsIcon} alt="Settings" />`,
      command: otm,
      togglable: 0,
      attributes: { title: 'Settings' },
    },
    // {
    //   id: ola,
    //   label: `<img src=${LayersIcon} alt="Layers" />`,
    //   command: ola,
    //   togglable: 0,
    //   attributes: { title: 'Open Layer Manager' },
    // },
    {
      id: obl,
      // className: 'fa fa-th-large',
      label: `<img src=${BlocksIcon} alt="Blocks" />`,
      command: obl,
      togglable: 0,
      attributes: { title: 'Open Blocks' },
    },
  ],
};

const devicesPanel = {
  id: 'panel-devices',
  el: '.panel__devices',
  buttons: [
    {
      id: 'device-desktop',
      label: `<img src=${DesktopIcon} alt="Desktop" />`,
      command: 'set-device-desktop',
      active: true,
      togglable: false,
      attributes: {
        'data-tooltip': 'Desktop',
        'data-tooltip-pos': 'bottom',
      },
    },
    {
      id: 'device-tablet',
      label: `<img src=${TabletIcon} alt="Tablet" />`,
      command: 'set-device-tablet',
      togglable: false,
      attributes: {
        'data-tooltip': 'Tablet',
        'data-tooltip-pos': 'bottom',
      },
    },
    {
      id: 'device-mobile',
      label: `<img src=${MobileIcon} alt="Mobile" />`,
      command: 'set-device-mobile',
      togglable: false,
      attributes: {
        'data-tooltip': 'Mobile',
        'data-tooltip-pos': 'bottom',
      },
    },
  ],
};

const rightActionsPanel = {
  id: 'right-actions',
  el: '.panel__right-actions',
  buttons: [
    {
      id: 'visibility',
      active: true,
      className: 'btn-toggle-borders',
      label: `<img src=${BordersIcon} alt="Borders" />`,
      command: swv,
      attributes: {
        'data-tooltip': 'View components',
        'data-tooltip-pos': 'bottom',
      },
    },
    {
      id: 'preview',
      active: false,
      label: `<img src=${PreviewIcon} alt="Preview" />`,
      command: prv,
      attributes: {
        'data-tooltip': 'Preview',
        'data-tooltip-pos': 'bottom',
      },
    },
    {
      id: 'fullscreen',
      active: false,
      label: `<img src=${FullScreenIcon} alt="Full Screen" />`,
      command: ful,
      attributes: {
        'data-tooltip': 'Fullscreen',
        'data-tooltip-pos': 'bottom',
      },
    },
  ],
};

const importExportPanel = {
  id: 'import-export',
  el: '.panel__import-export',
  buttons: [
    {
      id: 'code',
      active: false,
      label: `<img src=${CodeIcon} alt="View Code" />`,
      command: expt,
      attributes: {
        'data-tooltip': 'View code',
        'data-tooltip-pos': 'bottom',
      },
    },
    {
      id: 'import',
      className: 'import',
      label: `<img src=${ImportIcon} alt="Import" />`,
      command: impt,
      attributes: {
        'data-tooltip': 'Import template',
        'data-tooltip-pos': 'bottom',
      },
    },
  ],
};

const panels = [basicActionsPanel, devicesPanel, rightActionsPanel, viewsPanel, importExportPanel];

export const panelsPlugin = (editor: grapesjs.Editor) => {
  const pm = editor.Panels;

  panels.forEach((panel) => {
    pm.addPanel({ ...panel });
  });

  pm.removePanel('devices-c');
};
