import grapesjs from 'grapesjs';
import { blocksPlugin } from './blocks';
import { commandsPlugin } from './commands';
import { panelsPlugin } from './panels';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import newsLetterPreset from 'grapesjs-preset-newsletter';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import 'grapesjs-plugin-ckeditor';

const emailBuilderConfig = (): grapesjs.EditorConfig => {
  return {
    container: '#email-builder',
    // storageManager: false,
    height: '100%',
    plugins: ['gjs-plugin-ckeditor', newsLetterPreset, blocksPlugin, panelsPlugin, commandsPlugin],
    pluginsOpts: {
      newsLetterPreset: {
        inlineCss: true,
      },
      'gjs-plugin-ckeditor': {
        options: {
          language: 'en',
          toolbar: [
            { name: 'clipboard', items: ['Undo', 'Redo'] },
            { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike'] },
            {
              name: 'paragraph',
              items: [
                'NumberedList',
                'BulletedList',
                '-',
                'JustifyLeft',
                'JustifyCenter',
                'JustifyRight',
                'JustifyBlock',
              ],
            },
            { name: 'links', items: ['Link', 'Unlink'] },
            { name: 'insert', items: ['Table', 'HorizontalRule'] },
            '/',
            { name: 'styles', items: ['Format', 'Font', 'FontSize'] },
            { name: 'colors', items: ['TextColor', 'BGColor'] },
          ],
        },
      },
    },
    panels: {
      defaults: [{}],
    },
    showDevices: false,
    storageManager: false,

    deviceManager: {
      devices: [
        {
          name: 'Desktop',
          width: '', // default size
        },
        {
          name: 'Tablet',
          width: '900px',
        },
        {
          name: 'Mobile',
          width: '320px', // this value will be used on canvas width
          widthMedia: '480px', // this value will be used in CSS @media
        },
      ],
    },
  };
};

export default emailBuilderConfig;
