import grapesjs from 'grapesjs';
import 'grapesjs/dist/css/grapes.min.css';
import 'grapesjs-preset-newsletter/dist/grapesjs-preset-newsletter.css';
import 'components/EmailBuilder/styles/main.scss';
import { useEffect, useState } from 'react';
import emailBuilderConfig from './config';
import { useGlobalLogout } from 'auth/globalLogout';
import { Box, Button, Center, Flex, Image, Spinner, useToast } from '@chakra-ui/react';
import ThreeDotsIcon from 'assets/icons/email-builder/three-dots.svg';
import { uploadImageApi } from 'services/apis/broadcast';

type EmailBuilderProps = {
  isAutoresponder?: boolean;
  content?: string;
  onSave: (content: string) => void;
};

const EmailBuilder = ({ content, onSave }: EmailBuilderProps) => {
  const [isReload] = useGlobalLogout();
  const [editor, setEditor] = useState<grapesjs.Editor | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const toast = useToast();

  useEffect(() => {
    isReload && window.location.reload();
  }, [isReload]);

  useEffect(() => {
    const editor: grapesjs.Editor = grapesjs.init({
      ...emailBuilderConfig(),
      protectedCss: `img{
        max-width:100%
        height:auto;
        }`,
      assetManager: {
        autoAdd: true,
        uploadFile: async (e: any) => {
          setIsLoading(true);
          const files = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
          const formData = new FormData();
          formData.append('file', files);
          formData.append('page', '12');
          if (files?.size > 11e6) {
            toast({
              title: `Please select a file upto 10MB`,
              status: 'error',
              position: 'top-right',
              isClosable: true,
            });
            setIsLoading(false);
          } else if (
            !['png', 'PNG', 'jpg', 'JPG', 'jpeg', 'JPEG'].includes(files?.type?.split('/')[1])
          ) {
            toast({
              title: `Only png and jpg files are allowed`,
              status: 'error',
              position: 'top-right',
              isClosable: true,
            });
            setIsLoading(false);
          } else {
            const result = await uploadImageApi(formData);
            if (result) {
              editor.AssetManager.add(result);
              setIsLoading(false);
            }
          }
        },
      },
    });
    editor?.Panels.addPanel({
      id: 'panel-top',
      el: '.panel__top',
    });

    editor?.Panels?.getButton('views', 'open-blocks')?.set('active', true);

    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    editor?.on('run:core:canvas-clear:before', (opts) => {
      if (!confirm('Are you sure to clean the canvas?')) {
        opts.abort = true;
      }
    });

    const defaultContent = `<table style="padding: 5px; width: 100%; min-height: 500px; height: 100%; margin: 0 auto; font-family: Arial, sans-serif">
      <tr>
        <td>
          <table style="max-width: 550px; width: 90%; margin: auto">
            <tr>
              <td>
                <div>
                  <span style="font-size: 24px; font-weight: bold">Begin designing your email.</span>
                  <br />
                  <br />
                  Start by dragging a section to your desired location from the menu on the right.
                  <br />
                  <br />
                  Within a section, you can add text, images, and buttons from the content menu.
                </div>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>`;

    editor?.setComponents(content, {});

    setEditor(editor);
  }, []);

  const saveEmailTemplate = () => {
    if (editor && editor.getHtml()?.length < 5000) {
      onSave(editor?.Commands.get('get-inline-html').run(editor));
      //onSave(editor.getHtml());
    } else {
      toast({
        title: `You have reached the max characters (5000) for one email.`,
        status: 'error',
        position: 'top-right',
        isClosable: true,
      });
    }
  };

  return (
    <>
      {isLoading && (
        <Box height='100%' width='100%' position='absolute' zIndex='200'>
          <Center h='100px' position='absolute' top='45%' left='45%'>
            <Spinner w='150px' h='150px' color='white' />
          </Center>
        </Box>
      )}
      <div>
        <div className='panel__top'>
          <div className='panel__basic-actions'></div>
          <Flex className='panel__right'>
            <div className='panel__devices'></div>
            <div className='panel__right-actions'></div>
            <div className='panel__import-export'></div>
            <Flex h='40px' alignItems='center'>
              {/* <Button
                onClick={() => null}
                fontWeight='semibold'
                h='28px'
                w='40px'
                p='0'
                mr='6px'
                bgColor='white'>
                <Image src={ThreeDotsIcon} alt='Three Dots' />
              </Button> */}
              <Button
                onClick={saveEmailTemplate}
                fontWeight='semibold'
                h='28px'
                fontSize='12px'
                bgColor='white'
                color='purple.800'>
                Save & Continue
              </Button>
            </Flex>
            <div className='panel__views'></div>
          </Flex>
        </div>
        <div id='email-builder' />
        <div id='blocks' />
      </div>
    </>
  );
};

export default EmailBuilder;
