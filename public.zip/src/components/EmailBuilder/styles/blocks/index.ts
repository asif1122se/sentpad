import { ObjectType } from 'utils';

export const tableStyle: ObjectType = {
  height: '150px',
  margin: '0 auto 10px auto',
  padding: '5px 5px 5px 5px',
  width: '100%',
};

export const cellStyle: ObjectType = {
  padding: 0,
  margin: 0,
  'vertical-align': 'top',
};
