import React, { useState } from 'react';
import {
  FormControl,
  Input,
  Button,
  InputRightElement,
  InputGroup,
  InputProps as ChakraUIInputProps,
  FormControlProps,
  Text,
  Image,
  Flex,
  FormLabelProps,
  SwitchProps,
  Tooltip,
  InputRightAddon,
} from '@chakra-ui/react';
import { InfoOutlineIcon, SearchIcon, ViewIcon, ViewOffIcon } from '@chakra-ui/icons';
import AlertIcon from 'assets/icons/alert.svg';
import FormLabel from 'components/FormLabel';
import { StyledSwitch } from 'pages/Autoresponder/styles';
import { ErrorProps } from 'types';

export type InputProps = ChakraUIInputProps & {
  label?: string;
  fontSize?: string;
  formControlProps?: FormControlProps;
  formLabelProps?: FormLabelProps;
  type?: React.HTMLInputTypeAttribute | 'search';
  errorText?: string;
  withSwitch?: boolean;
  switchProps?: SwitchProps;
  icon?: JSX.Element;
  tooltip?: string;
  errorProps?: ErrorProps;
  hasRightAddOn?: boolean;
  rightAddOn?: string;
};

const sizeToHeight: { [key: string]: string } = {
  xs: '24px',
  sm: '32px',
  md: '40px',
  lg: '48px',
};

const InputField = ({
  label,
  type,
  placeholder,
  name,
  onChange,
  formControlProps,
  formLabelProps,
  icon,
  size,
  errorText,
  width,
  maxLength,
  fontSize = 'md',
  withSwitch,
  borderColor = 'gray.600',
  switchProps,
  minLength,
  tooltip,
  errorProps,
  hasRightAddOn = false,
  rightAddOn,
  ...restProps
}: InputProps) => {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <FormControl width={width} {...formControlProps}>
      {(label || withSwitch) && (
        <Flex justifyContent='space-between'>
          {label && (
            <Flex alignItems='center'>
              <FormLabel color='black' fontSize={fontSize} {...formLabelProps}>
                {label}
              </FormLabel>
              {tooltip && (
                <Tooltip
                  hasArrow
                  label={tooltip}
                  aria-label={tooltip}
                  bgColor='gray.800'
                  placement='right'>
                  <InfoOutlineIcon mb='0.5rem' />
                </Tooltip>
              )}
            </Flex>
          )}
          {switchProps && <StyledSwitch {...switchProps} />}
        </Flex>
      )}
      <InputGroup size={size ?? 'lg'}>
        <Input
          isInvalid={!!errorText}
          errorBorderColor='red.700'
          type={!showPassword ? type : 'text'}
          color='gray.800'
          placeholder={placeholder}
          name={name}
          onChange={onChange}
          borderColor={borderColor}
          fontSize={fontSize ?? '1rem'}
          fontWeight='medium'
          maxLength={maxLength}
          minLength={minLength}
          _placeholder={
            type === 'password'
              ? {
                  color: 'gray.500',
                  position: 'absolute',
                  top: '12px',
                }
              : {
                  color: 'gray.500',
                }
          }
          {...restProps}
          autocomplete='off'
        />
        {hasRightAddOn && (
          <InputRightAddon border='1px solid' borderColor={borderColor} minW='100px'>
            {rightAddOn}
          </InputRightAddon>
        )}
        {!!errorText && !hasRightAddOn && (
          <InputRightElement h={sizeToHeight[(size as string) ?? 'lg']}>
            <Image src={AlertIcon} alt='Error' />
          </InputRightElement>
        )}
        {type === 'password' && (
          <InputRightElement h={sizeToHeight[(size as string) ?? 'lg']}>
            <Button
              display={!!errorText ? 'none' : 'block'}
              variant={'ghost'}
              onClick={() => setShowPassword((showPassword) => !showPassword)}>
              {showPassword ? <ViewIcon color='black' /> : <ViewOffIcon color='black' />}
            </Button>
          </InputRightElement>
        )}
        {type === 'search' && (
          <InputRightElement h={sizeToHeight[(size as string) ?? 'lg']}>
            <SearchIcon color='gray.500' />
          </InputRightElement>
        )}
        {icon && <InputRightElement>{icon}</InputRightElement>}
      </InputGroup>
      {!!errorText && (
        <Text
          color='red.700'
          mt='8px'
          fontSize={fontSize ?? '14px'}
          fontWeight='medium'
          {...errorProps}>
          {errorText}
        </Text>
      )}
    </FormControl>
  );
};

export default InputField;
