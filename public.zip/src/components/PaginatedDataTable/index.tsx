import React, { useEffect, useRef, useState } from 'react';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Box,
  Button,
  Flex,
  Text,
  Select,
  InputGroup,
  Icon,
  InputRightElement,
  Input,
  Center,
  Spinner,
} from '@chakra-ui/react';
import { ChevronLeftIcon, ChevronRightIcon, CloseIcon, SearchIcon } from '@chakra-ui/icons';
import {
  useReactTable,
  flexRender,
  getCoreRowModel,
  ColumnDef,
  SortingState,
  getSortedRowModel,
  OnChangeFn,
  RowSelectionState,
} from '@tanstack/react-table';
import { IoFunnelOutline } from 'react-icons/io5';
import styled from '@emotion/styled';
import { ColumnProps, PaginatedTable } from 'types/general';
import PageFilters from 'components/Filters';
import { useQuery } from 'hooks/useQuery';
import { QueryKey } from '@tanstack/react-query';
import { useDebounce } from 'hooks/useDebounce';
import { PAGINATION_PAGE_SIZES } from 'utils/constants';

const StyledTr = styled(Tr)<{ islast: boolean; isclickable: boolean }>`
  ${({ islast }) => islast && 'border-bottom: none;'};
  ${({ isclickable }) => isclickable && 'cursor: pointer;'}
`;

export type PaginatedDataTableProps<T> = {
  columns: ColumnDef<T, any>[];
  colProps: ColumnProps[];
  onRowClick?: (row: T) => void;
  rowSelection?: RowSelectionState;
  setRowSelection?: OnChangeFn<RowSelectionState>;
  emptyMessage: string;
  rightToolbar?: JSX.Element;
  showPageSizeMenu?: boolean;
  showSearch?: boolean;
  showFilters?: boolean;
  filterIndex?: number;
  values?: any;
  setValues?: any;
  title?: string;
  boldFirstRow?: boolean;
  queryKey: QueryKey;
  endpoint: string;
  getData?: (data: PaginatedTable<T[]>) => void;
  params?: { [key: string]: string | number | undefined };
};

const PaginatedDataTable = <T,>({
  columns,
  colProps,
  onRowClick,
  rowSelection,
  setRowSelection,
  emptyMessage,
  rightToolbar,
  showPageSizeMenu = true,
  showSearch = false,
  showFilters = false,
  filterIndex = 0,
  values,
  setValues,
  title,
  queryKey,
  endpoint,
  getData,
  params,
}: PaginatedDataTableProps<T>) => {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(PAGINATION_PAGE_SIZES[0]);
  const [showSearchField, setShowSearchField] = useState<boolean>(false);
  const [isSearch, setIsSearch] = useState<boolean>(false);
  const [searchValue, setSearchValue] = useState('');
  const debouncedSearchValue = useDebounce(searchValue, 500);
  const [openMainDrawer, setOpenMainDrawer] = useState<boolean>(false);
  const [filter, setFilter] = useState<boolean>(false);

  const { data, isLoading, isFetching, refetch } = useQuery<PaginatedTable<T[]>>({
    url: endpoint,
    params: {
      page,
      per_page: pageSize,
      searchData: debouncedSearchValue,
      ...params,
    },
    queryKey: [...queryKey, page, pageSize, debouncedSearchValue],
    onSuccess: (data) => {
      getData && data && getData(data);
      setFilter(false);
      setValues && setValues({ ...values, filterBtnLoading: false });
    },
  });

  const [sorting, setSorting] = React.useState<SortingState>([]);

  const table = useReactTable({
    columns,
    data: data?.data ?? [],
    getCoreRowModel: getCoreRowModel(),
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
    onRowSelectionChange: setRowSelection,
    state: {
      sorting,
      rowSelection,
    },
  });

  const inputRef = useRef<HTMLInputElement | null>(null);
  const handleFocus = () => {
    inputRef?.current?.focus();
  };

  useEffect(() => {
    if (filter) {
      refetch();
    }
  }, [filter]);
  return (
    <Box>
      <PageFilters
        filterIndex={filterIndex}
        openDrawer={openMainDrawer}
        setOpenDrawer={setOpenMainDrawer}
        values={values}
        setValues={setValues}
        onClickFilter={() => setFilter(true)}
      />
      <Flex justifyContent={title ? 'space-between' : 'flex-end'} alignItems='center' mb='2'>
        {title && (
          <Text fontSize='lg' fontWeight='bold'>
            {title}
          </Text>
        )}
        <Flex></Flex>
        <Flex>
          <Flex alignItems='center'>
            {showSearch && (
              <Box h='10' display='inline-block' flexDirection='row' mx='2' alignItems='center'>
                <InputGroup>
                  {(showSearchField && (
                    <Input
                      autoFocus
                      ref={inputRef}
                      type='text'
                      value={searchValue}
                      fontSize='sm'
                      placeholder='Enter to search'
                      onChange={(e) => {
                        setSearchValue(e.target.value);
                        setIsSearch(e.target.value ? true : false);
                      }}
                      width='250px'
                      h='10'
                      pr='35px'
                      borderColor='blackAlpha.600'
                    />
                  )) || <Box ml='10' />}
                  <InputRightElement>
                    {!isSearch ? (
                      <SearchIcon
                        cursor='pointer'
                        as='button'
                        color='gray.800'
                        onClick={() => {
                          setShowSearchField(!showSearchField);
                        }}
                      />
                    ) : (
                      <CloseIcon
                        boxSize='3'
                        onClick={() => {
                          setSearchValue('');
                          setIsSearch(false);
                          handleFocus();
                        }}
                      />
                    )}
                  </InputRightElement>
                </InputGroup>
              </Box>
            )}
          </Flex>

          <Flex alignItems='center' justifyContent='center' gap='2'>
            {showFilters && (
              <Icon
                boxSize='5'
                color='gray.800'
                mr='2'
                as={IoFunnelOutline}
                onClick={() => setOpenMainDrawer(true)}
                cursor='pointer'
              />
            )}
            {showPageSizeMenu && (
              <Flex alignItems='center'>
                <Text
                  fontSize='sm'
                  fontWeight='500'
                  color='blackAlpha.900'
                  whiteSpace='nowrap'
                  alignItems='center'>
                  Show rows
                </Text>
                <Select
                  ml='2'
                  borderColor='blackAlpha.600'
                  width='fit-content'
                  height='40px'
                  fontSize='sm'
                  textAlign='center'
                  color='blackAlpha.900'
                  value={pageSize}
                  onChange={(e) => {
                    setPageSize(parseInt(e.target.value));
                    setPage(1);
                  }}>
                  {PAGINATION_PAGE_SIZES.map((pageSize) => (
                    <option key={pageSize} value={pageSize}>
                      {pageSize}
                    </option>
                  ))}
                </Select>
              </Flex>
            )}
            {rightToolbar}
          </Flex>
        </Flex>
      </Flex>
      <Box border='1px solid' borderColor='gray.400' borderRadius='6px'>
        <Table borderWidth='0' borderColor='gray.400' mt='1' overflowX='auto'>
          <Thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <Tr key={headerGroup.id}>
                {headerGroup.headers.map((header, index) => {
                  // see https://tanstack.com/table/v8/docs/api/core/column-def#meta to type this correctly
                  const meta: any = header.column.columnDef.meta;
                  return (
                    <Th
                      fontWeight='600'
                      fontSize='sm'
                      color='black'
                      borderBottomColor='gray.400'
                      width={colProps[index].width as any}
                      px={colProps[index].paddingX as any}
                      pl={colProps[index].paddingLeft as any}
                      pr={colProps[index].paddingRight as any}
                      key={header.id}
                      textAlign={colProps[index].align as any}
                      onClick={header.column.getToggleSortingHandler()}
                      isNumeric={meta?.isNumeric}>
                      {flexRender(header.column.columnDef.header, header.getContext())}
                      {/* <chakra.span >
                        {header.column.getIsSorted() ? (
                          header.column.getIsSorted() === 'desc' ? (
                            <TriangleDownIcon aria-label='sorted descending' />
                          ) : (
                            <TriangleUpIcon aria-label='sorted ascending' />
                          )
                        ) : null}
                      </chakra.span> */}
                    </Th>
                  );
                })}
              </Tr>
            ))}
          </Thead>
          <Tbody borderTopWidth='2px' borderTopColor='gray.400'>
            {!(isLoading || isFetching) &&
              table.getRowModel().rows.map((row, index) => (
                <StyledTr
                  key={row.id}
                  islast={index === table.getRowModel().rows.length - 1}
                  isclickable={!!onRowClick}
                  onClick={() => onRowClick && onRowClick(row.original)}>
                  {row.getVisibleCells().map((cell, index) => {
                    // see https://tanstack.com/table/v8/docs/api/core/column-def#meta to type this correctly
                    const meta: any = cell.column.columnDef.meta;
                    const boldTitle = index > 0 ? '500' : '600';

                    return (
                      <Td
                        key={cell.id}
                        px={colProps[index].paddingX as any}
                        pl={colProps[index].paddingLeft as any}
                        pr={colProps[index].paddingRight as any}
                        wordBreak={colProps[index].wordBreak as any}
                        fontWeight={boldTitle}
                        fontSize='sm'
                        alignItems='center'
                        textAlign={colProps[index].align as any}
                        paddingY='2'
                        isNumeric={meta?.isNumeric}
                        borderColor='gray.400'
                        borderBottomWidth='1px'>
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </Td>
                    );
                  })}
                </StyledTr>
              ))}
          </Tbody>
        </Table>
        {(isLoading || isFetching) && (
          <Center p='8px'>
            <Spinner />
          </Center>
        )}
        {!isLoading && !isFetching && (data?.data === undefined || data?.data.length === 0) && (
          <Box textAlign='center'>
            <Text my='3' fontSize='md' color='gray.600' fontWeight='500'>
              {emptyMessage}
            </Text>
          </Box>
        )}
      </Box>
      <Flex alignItems='center' justifyContent='center' my='3'>
        <Flex alignItems='center'>
          <Text
            mt='1'
            fontSize='sm'
            fontWeight='400'
            whiteSpace='nowrap'
            alignItems='center'
            mr='1'>
            Go to:
          </Text>
          <Select
            ml='2'
            borderColor='blackAlpha.600'
            width='fit-content'
            height='40px'
            fontSize='sm'
            textAlign='center'
            color='blackAlpha.900'
            value={page}
            onChange={(e) => setPage(parseInt(e.target.value))}>
            {Array.from(Array(Math.ceil((data?.total ?? 0) / pageSize)), (e, i) => i + 1).map(
              (value) => (
                <option key={value} value={value}>
                  {value}
                </option>
              ),
            )}
          </Select>
        </Flex>
        <Text fontSize='sm' mt='1' mx='2' fontWeight='400' letterSpacing='0.5px'>
          {`${data?.from ? `${data.from} - ${data.to} of ${data.total}` : ''}`}
        </Text>
        <Box height='32px'>
          <Button
            ml='2'
            w='32px'
            minW='32px'
            h='32px'
            padding='0'
            background='transparent linear-gradient(180deg, #FFFFFF 0%, #E8EBEE 100%) 0% 0% no-repeat padding-box;'
            borderWidth='1px'
            borderRightRadius='0'
            borderColor='gray.500'
            onClick={() => setPage(page - 1)}
            isDisabled={data?.current_page === undefined || data?.current_page === 1}>
            <ChevronLeftIcon w='24px' h='24px' />
          </Button>
          <Button
            ml='0'
            w='32px'
            minW='32px'
            h='32px'
            background='transparent linear-gradient(180deg, #FFFFFF 0%, #E8EBEE 100%) 0% 0% no-repeat padding-box;'
            borderWidth='1px'
            borderLeftRadius='0'
            borderColor='gray.500'
            onClick={() => setPage(page + 1)}
            isDisabled={data?.current_page === data?.last_page}>
            <ChevronRightIcon w='24px' h='24px' />
          </Button>
        </Box>
      </Flex>
    </Box>
  );
};

export default PaginatedDataTable;
