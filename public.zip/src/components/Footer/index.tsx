import { Box } from '@chakra-ui/react';

function Footer() {
  return (
    <Box border='1px solid blue' h='100%'>
      Footer
    </Box>
  );
}

export default Footer;
