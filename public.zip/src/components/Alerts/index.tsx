import { useStoreState } from 'redux';
import { Confirmation } from './Confirmation';

const AlertHandler = () => {
  const modalState = useStoreState((state) => state.modal.selectedModal);

  return (
    <>
      {(modalState?.action === 'confirm_delete' || modalState?.action === 'confirm_duplicate') && (
        <Confirmation />
      )}
    </>
  );
};

export default AlertHandler;
