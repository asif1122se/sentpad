import React from 'react';
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogContent,
  AlertDialogOverlay,
  useDisclosure,
  Button,
} from '@chakra-ui/react';
import { useStoreActions } from 'redux';

export const DuplicateCampaign = () => {
  const cancelRef = React.useRef<any>(null);
  const { onClose } = useDisclosure();
  const modalAction = useStoreActions((actions) => actions.modal.add);

  return (
    <>
      <AlertDialog leastDestructiveRef={cancelRef} isOpen={true} onClose={onClose}>
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogBody>Are You Sure?</AlertDialogBody>
            <AlertDialogFooter>
              <Button onClick={() => modalAction({})}>Cancel</Button>
              <Button colorScheme='red' onClick={() => modalAction({})} ml={3}>
                Continue
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  );
};
