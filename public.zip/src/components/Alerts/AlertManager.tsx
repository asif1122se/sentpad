import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogContent,
  AlertDialogOverlay,
  useDisclosure,
  Button,
  useToast,
} from '@chakra-ui/react';
import { useStoreState, useStoreActions } from 'redux';
import { performSaveBroadcastApi } from 'services/apis/broadcast';
import { format } from 'date-fns';

const AlertManager = () => {
  const navigate = useNavigate();
  const cancelRef = React.useRef<any>(null);
  const { onOpen, onClose } = useDisclosure();
  const modalState = useStoreState((state) => state.modal.selectedModal);
  const broadcastState = useStoreState((state) => state.broadcast.broadcastObj);
  const modalAction = useStoreActions((actions) => actions.modal.add);
  const broadcastAction = useStoreActions((actions) => actions.broadcast.add);
  const toast = useToast();
  const [isBtnLoading, setIsBtnLoading] = useState<boolean>(false);

  const handleSaveBroadcast = async (flag: string) => {
    modalAction({});
    if (flag === 'discard') {
      broadcastAction({});
      navigate(`${modalState.url == '/signin' ? '/signin' : modalState.url}`);
    }
    if (flag === 'save' && !broadcastState?.campaign_name) {
      modalAction({});
    }
    if (flag === 'save' && broadcastState?.campaign_name) {
      setIsBtnLoading(true);
      const uniqueList = [...new Set(broadcastState?.contactList?.map((item: any) => item.id))];
      // const contactListIds = broadcastState?.contactList?.map((item: any) => item.id);

      try {
        const broadcastCreationResult = await performSaveBroadcastApi({
          ...broadcastState,
          campaign_name: broadcastState?.campaign_name ? broadcastState?.campaign_name : '',
          list_ids: uniqueList?.toString(),
          sender_profile_id: broadcastState?.senderProfile?.id,
          step: broadcastState?.step ? broadcastState?.step + 1 : 1,
          scheduled_time:
            broadcastState.status == 'scheduled'
              ? format(new Date(broadcastState?.scheduled_time), 'yyyy-MM-dd HH:mm')
              : '',
          time_zone: broadcastState?.time_zone,
          status: 'draft',
          senderProfile: undefined,
          contactList: undefined,
          body_content: broadcastState?.body_content,
        });
        if (broadcastCreationResult?.errors?.length === 0) {
          setIsBtnLoading(false);
          broadcastAction({});
          toast({
            title: `${broadcastCreationResult?._metadata?.message}`,
            status: 'success',
            isClosable: true,
            position: 'top-right',
          });
          navigate(`${modalState.url == '/signin' ? '/signin' : '/broadcast'}`);
        } else {
          setIsBtnLoading(false);
          toast({
            title: 'Something went wrong',
            status: 'error',
            isClosable: true,
            position: 'top-right',
          });
        }
      } catch (err) {
        console.log(err);
      }
    }
  };

  return (
    <>
      <AlertDialog
        isCentered
        leastDestructiveRef={cancelRef}
        isOpen={modalState?.name == 'broadcast'}
        onClose={onClose}>
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogBody>
              You have not saved the changes you made. Do you want to save before you exit?
            </AlertDialogBody>

            <AlertDialogFooter>
              <Button variant='danger' onClick={() => handleSaveBroadcast('discard')}>
                Continue without saving
              </Button>
              <Button
                variant='success'
                onClick={() => handleSaveBroadcast('save')}
                ml={3}
                isLoading={isBtnLoading}>
                Save and Continue
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  );
};

export default AlertManager;
