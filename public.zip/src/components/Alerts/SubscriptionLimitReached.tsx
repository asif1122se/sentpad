import {
  Button,
  Image,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalOverlay,
  Text,
} from '@chakra-ui/react';
import UserLock from 'assets/icons/user-lock.svg';

type SubscriptionLimitReachedProps = {
  isOpen: boolean;
  onClose: () => void;
};

const SubscriptionLimitReached = ({ isOpen, onClose }: SubscriptionLimitReachedProps) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered>
      <ModalOverlay />
      <ModalContent>
        <ModalCloseButton size='sm' />
        <ModalBody textAlign='center' p='2rem'>
          <Image boxSize='90px' src={UserLock} margin='1rem auto' />
          <Text mb='2' fontSize='22px' lineHeight='32px' fontWeight='bold'>
            Subscription Limit Reached
          </Text>
          <Text fontSize='sm' px='1rem' lineHeight='22px'>
            You have reached your subscription limit. Please upgrade your subscription plan to
            continue.
          </Text>
          <Button variant='primary' mt='5' width='100%' onClick={onClose}>
            Upgrade Plan
          </Button>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default SubscriptionLimitReached;
