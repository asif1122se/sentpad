import React, { useState } from 'react';
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogContent,
  AlertDialogOverlay,
  useDisclosure,
  Button,
  useToast,
  AlertDialogHeader,
  Text,
} from '@chakra-ui/react';
import { useStoreState, useStoreActions } from 'redux';
import { CloseIcon } from '@chakra-ui/icons';
import { InputField } from 'components';
import { duplicateBroadcastApi } from 'services/apis/broadcast';
import { useQueryClient } from '@tanstack/react-query';
import QUERY_KEYS from 'utils/queryKeys';

export const Confirmation = () => {
  const cancelRef = React.useRef<any>(null);
  const { onClose } = useDisclosure();
  const modalState = useStoreState((state) => state.modal.selectedModal);
  const modalAction = useStoreActions((actions) => actions.modal.add);
  const queryClient = useQueryClient();

  const [btnLoading, setBtnLoading] = useState<boolean>();
  const toast = useToast();
  const [values, setvalues] = useState<any>(`${modalState?.name} (duplicate)`);

  const handleSubmit = async () => {
    setBtnLoading(true);
    try {
      const duplicateApiRes = await duplicateBroadcastApi({
        campaign_name: values,
        id: modalState?.id,
      });
      if (duplicateApiRes?.errors?.length === 0) {
        setBtnLoading(false);
        modalAction({});
        queryClient.invalidateQueries([QUERY_KEYS.BROADCAST_LIST]);
        toast({
          title: `${duplicateApiRes?._metadata?.message}`,
          status: 'success',
          isClosable: true,
          position: 'top-right',
        });
      } else {
        setBtnLoading(false);
        toast({
          title: `${duplicateApiRes?.errors[0]}`,
          status: 'error',
          isClosable: true,
          position: 'top-right',
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <>
      <AlertDialog isCentered leastDestructiveRef={cancelRef} isOpen={true} onClose={onClose}>
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize='lg' color='blackAlpha.900' fontWeight='bolder'>
              {modalState.header}
              <CloseIcon
                boxSize='3'
                color='gray.600'
                onClick={() => modalAction({})}
                display='inline'
                float='right'
                cursor='pointer'
              />
            </AlertDialogHeader>
            <form>
              <AlertDialogBody fontWeight='500' color='black'>
                {modalState.description}
                {modalState.action == 'confirm_duplicate' && (
                  <InputField
                    fontSize='sm'
                    borderColor='gray.600'
                    my='2'
                    h='9'
                    placeholder='Enter broadcast name'
                    onChange={(e) => setvalues(e.target.value)}
                    value={values}
                    name='campaign_name'
                  />
                )}
              </AlertDialogBody>
              <AlertDialogFooter justifyContent='left'>
                <Button
                  variant={
                    !values
                      ? 'default'
                      : modalState.action == 'confirm_duplicate'
                      ? 'success'
                      : 'danger'
                  }
                  isDisabled={modalState?.action == 'confirm_duplicate' && !values ? true : false}
                  fontSize='sm'
                  fontWeight='bolder'
                  colorScheme='red'
                  isLoading={btnLoading}
                  onClick={() =>
                    modalState?.action == 'confirm_delete'
                      ? modalAction({ ...modalState, isDelete: true, action: undefined })
                      : handleSubmit()
                  }
                  mr='3'>
                  {modalState.action == 'confirm_duplicate' ? 'Duplicate' : 'Delete'}
                </Button>

                <Button fontWeight='bolder' fontSize='sm' onClick={() => modalAction({})}>
                  Cancel
                </Button>
              </AlertDialogFooter>
            </form>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  );
};
