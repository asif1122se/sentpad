import React, { useEffect } from 'react';
import { Box } from '@chakra-ui/react';

const Header = () => <>
      <Box border='1px solid red' h='100%'>
        Header
      </Box>
    </>;

export default Header;
